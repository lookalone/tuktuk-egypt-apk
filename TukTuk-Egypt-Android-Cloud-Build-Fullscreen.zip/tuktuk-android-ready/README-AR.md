# توكتوك مصر — Android build payload

هذه الحزمة تحتوي على آخر نسخة من ملفات الويب المرفوعة من Netlify داخل `www/`، مع غلاف Capacitor للبناء السحابي.

ارفع ملف ZIP هذا إلى مستودع GitHub بالاسم `TukTuk-Egypt-Android-Cloud-Build.zip`، واستخدم ملف `build-apk.yml` المقدم منفصلًا في المسار `.github/workflows/build-apk.yml`. عند نجاح GitHub Actions، نزّل Artifact باسم `TukTuk-Egypt-APK`.

ملحوظة: يخفي إعداد Android أشرطة النظام أثناء اللعب؛ يمكن إظهارها مؤقتًا بالسحب من حافة الشاشة حسب إصدار Android والشركة المصنعة.
