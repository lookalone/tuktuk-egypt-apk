/* =====================================================================
   pwa.js — يخلّي اللعبة تشتغل زي التطبيق:
   تتثبّت على الشاشة الرئيسية، تفتح ملء الشاشة بالعرض، وتشتغل من غير نت
   ===================================================================== */
(function () {
  const TT = window.TT || (window.TT = {});
  const P = TT.PWA = { deferred: null, installed: false };
  P.standalone = () => window.matchMedia('(display-mode: fullscreen)').matches || window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
  P.isIOS = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

  // شاشة التحميل
  function hideSplash() { const s = document.getElementById('splash'); if (!s || s.classList.contains('out')) return; s.classList.add('out'); setTimeout(() => s.remove(), 600); }
  window.addEventListener('load', () => setTimeout(hideSplash, 700));
  setTimeout(hideSplash, 6000);

  // Service Worker (بيشتغل بس لما اللعبة تكون على موقع http/https)
  if ('serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js').then(reg => {
        reg.addEventListener('updatefound', () => {
          const w = reg.installing; if (!w) return;
          w.addEventListener('statechange', () => {
            if (w.state === 'installed' && navigator.serviceWorker.controller) P.onUpdate && P.onUpdate();
          });
        });
      }).catch(() => { });
    });
  }

  // زرار التثبيت
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); P.deferred = e; P.onChange && P.onChange(); });
  window.addEventListener('appinstalled', () => { P.deferred = null; P.installed = true; P.onChange && P.onChange(); });
  P.canInstall = () => !P.standalone() && (!!P.deferred || P.isIOS);
  P.install = async function () {
    if (P.deferred) { P.deferred.prompt(); const r = await P.deferred.userChoice.catch(() => null); P.deferred = null; P.onChange && P.onChange(); return r && r.outcome === 'accepted'; }
    return false;
  };

  // قفل الشاشة على الوضع العرضي لما تبقى ملء الشاشة أو متثبّتة
  P.lockLandscape = function () { try { if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => { }); } catch (e) { } };
  document.addEventListener('fullscreenchange', () => { if (document.fullscreenElement) P.lockLandscape(); });
  if (P.standalone()) { document.documentElement.classList.add('is-app'); window.addEventListener('load', P.lockLandscape); }
  // منع القايمة اللي بتظهر بالضغط المطوّل (الزووم بالدبل تاب متقفل من الـ CSS)
  document.addEventListener('contextmenu', e => { if (e.target.closest && !e.target.closest('textarea, input')) e.preventDefault(); });
})();
