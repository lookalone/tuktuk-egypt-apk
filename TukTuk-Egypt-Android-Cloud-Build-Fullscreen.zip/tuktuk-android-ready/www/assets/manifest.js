/* =====================================================================
   assets/manifest.js — إعدادات الصور الخارجية
   اللعبة بتستخدم الصور اللي في مجلد assets تلقائيًا.
   عشان تغيّر شكل أي حاجة: استبدل ملف الـ PNG بنفس الاسم ونفس المقاس
   وحدّث الصفحة. لو مسحت صورة أو ما اتحملتش، اللعبة بترسمها بالكود.

   الأسماء (art.js → A.P):
     assets/characters/<sheet>_sheet.png   شخصيات (sprite sheet)
         driver_sayed / driver_hamo / driver_adel
         passenger_student / employee / mother / merchant / farmer / tourist / moallem / granny / alien / astro
         npc1 … npc5 (المارة وأصحاب العربيات) — kid (العيل اللي مع الأم)
     assets/characters/animal_<cow|buffalo|camel|donkey|chicken>.png   160×130، الارتكاز (70,120)
     assets/tuktuk/tuktuk_<basic|prince|space|scooter|microbus|bike|skate>_<back|front>.png  (المقاسات في art.js → A.PIMG)
     assets/tiles/vehicle_<type>_<رقم اللون>.png                      الارتكاز (20,190) = آخر العربية من ورا على الأرض
     assets/tiles/tile_<bump|pothole|water|...>.png                   280×120، الارتكاز (140,90) = نص العائق على خط الطريق
     assets/tiles/bg_<streets|country|desert|city|mars>_<far|mid>_<0-3>.png   1200×310 شفافة (طبقات Parallax)
     assets/ui/ui_coin.png و ui_coin_cosmic.png                         64×64
   ===================================================================== */
window.TT = window.TT || {};
TT.ASSET_MANIFEST = {
  enabled: true,            // false = تجاهل كل الصور وارسم كل حاجة بالكود
  use: {                    // تقدر تقفل مجموعة معينة بس
    characters: true, animals: true, tuktuks: true, vehicles: true, obstacles: true, backgrounds: true, ui: true
  },
  // شبكة الـ sprite sheet: 23 صف (وضع) × 8 أعمدة (frames)، كل خلية 128×160
  // الارتكاز (القدمين) عند (64,150)، والرسم متكبر 1.4 مرة عن حجم اللعبة
  sheetLayout: {
    cellW: 128, cellH: 160, anchorX: 64, anchorY: 150, frames: 8, scale: 1 / 1.4,
    poses: ['idle', 'sit', 'drive', 'walk', 'run', 'point', 'wave', 'talk', 'angry', 'apologize', 'argue', 'windup', 'push', 'dodge', 'stumble', 'fallen', 'repair', 'celebrate', 'surprised', 'dizzy', 'pedal', 'skate', 'cheer'],
    // مدة دورة الحركة بالثانية لكل وضع (الـ 8 frames بتتوزع عليها)
    periods: { idle: 3.14, sit: 5.71, drive: 8.98, walk: 0.785, run: 0.483, point: 1.047, wave: 0.628, talk: 1.257, angry: 0.449, apologize: 2.094, argue: 0.698, windup: 1, push: 1, dodge: 1, stumble: 0.419, fallen: 1.571, repair: 0.524, celebrate: 0.393, surprised: 1, dizzy: 2.094, pedal: 1.047, skate: 3.14, cheer: 0.698 }
  }
};
