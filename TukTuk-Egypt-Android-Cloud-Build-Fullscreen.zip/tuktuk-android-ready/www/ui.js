/* =====================================================================
   ui.js — واجهة المستخدم (DOM): القوائم، الخريطة، المرآب، العدادات،
   النوافذ، أزرار اللمس. منفصلة عن منطق اللعبة في game.js
   ===================================================================== */
(function () {
  'use strict';
  const TT = window.TT, A = TT.Art;
  const $ = s => document.querySelector(s);
  const t = (ar, en) => TT.t(ar, en);
  const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const fmt = n => Math.round(n).toLocaleString('en-US');
  const UI = TT.UI = { touch: {} };
  const S = () => TT.Save.data;
  const G = () => TT.G;

  /* ---------------- portraits (mini canvases using the same art) ---------------- */
  function portrait(look, pose, w, h, sc, bg) {
    const c = document.createElement('canvas'); const dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = w * dpr; c.height = h * dpr; c.style.width = w + 'px'; c.style.height = h + 'px';
    const x = c.getContext('2d'); x.scale(dpr, dpr);
    if (bg) { x.fillStyle = bg; x.fillRect(0, 0, w, h); }
    A.person(x, w / 2, h - 4, look, pose || 'idle', 0.5, { scale: sc || 1, noShadow: true });
    return c;
  }
  function tukCanvas(w, h, opts) {
    const c = document.createElement('canvas'); const dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = w * dpr; c.height = h * dpr; c.style.width = w + 'px'; c.style.height = h + 'px';
    const x = c.getContext('2d'); x.scale(dpr, dpr);
    const d = S(), m = opts.model || TT.Save.model(), kind = m.kind || 'tuktuk', g = TT.GEOM[kind];
    const span = (g.front + g.back) * TT.PX + 20, tall = (g.roof + 0.6) * TT.PX;
    const s = Math.min(w / span, h / tall, kind === 'skate' ? 2.2 : 1.6);
    x.translate(w / 2 + ((g.back - g.front) / 2) * TT.PX * s, h - (g.H0 * TT.PX + 12) * s); x.scale(s, s);
    const paint = opts.paint || TT.paintColor(m.id), veh = d.vehicles[m.id] || {};
    x.globalAlpha = .3; x.fillStyle = '#000'; x.beginPath(); x.ellipse(0, (g.H0) * TT.PX, (g.front + g.back) * TT.PX / 2, 6, 0, 0, Math.PI * 2); x.fill(); x.globalAlpha = 1;
    const wr = g.wheelR * TT.PX, wy = (g.H0 - g.wheelR) * TT.PX;
    for (const wx of [g.rearX * TT.PX, g.frontX * TT.PX]) { if (kind === 'bike') { x.strokeStyle = '#222'; x.lineWidth = 3; x.beginPath(); x.arc(wx, wy, wr - 1.5, 0, 7); x.stroke(); } else if (kind === 'skate') { x.fillStyle = '#fafafa'; x.beginPath(); x.arc(wx, wy, 3, 0, 7); x.fill(); } else A.wheel(x, wx, wy, wr, 0.3, d.tireType === 'sand' ? '#d7a85b' : d.tireType === 'farm' ? '#f9a825' : d.tireType === 'space' ? '#38d9ff' : undefined); }
    const SE = { tuktuk: [22, 20.5, 0.78, 'drive'], scooter: [-14, 7, 0.85, 'drive'], bike: [-6, 5, 0.85, 'pedal'], skate: [6, -1, 0.95, 'skate'], microbus: [86, -7, 0.8, 'drive'], sport: [-4, 10, 0.56, 'drive'] }[kind];
    A.playerBody(x, kind, { color: paint, trim: m.trim, space: m.space, style: m.style, decal: opts.decal || d.decal, t: 0, damage: opts.damage || 0, inside: opts.driver ? (cc => A.person(cc, SE[0], SE[1], TT.driverLook(), SE[3], 0, { scale: SE[2], noShadow: true })) : null });
    if (opts.acc !== false) A.accessories(x, kind, opts.accs || TT.accOpts(), opts.t || 0.3, { subOn: true, partyOn: true, celebrate: !!opts.celebrate, dirt: opts.dirt != null ? opts.dirt : (veh.dirt || 0) });
    return c;
  }

  function cartCanvas(gid, tier, w, h, paint) {
    const c = document.createElement('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1);
    c.width = w * dpr; c.height = h * dpr; c.style.width = w + 'px'; c.style.height = h + 'px';
    const x = c.getContext('2d'); x.scale(dpr, dpr); const sc = Math.min(w / 175, h / 125);
    x.translate(w / 2 + 10 * sc, h - 30 * sc); x.scale(sc, sc);
    x.globalAlpha = .3; x.fillStyle = '#000'; x.beginPath(); x.ellipse(-8, 29, 80, 5, 0, 0, 7); x.fill(); x.globalAlpha = 1;
    const A = TT.Art; A.wheel(x, -41, 15, 14, 0.4); A.wheel(x, 46, 15, 14, 0.4);
    A.vendorCart(x, gid, tier, { color: paint || TT.paintColor('basic'), t: 0.4, stockFrac: 1, sign: t(TT.CART_NAMES[gid][0], TT.CART_NAMES[gid][1]), inside: cc => A.person(cc, 22, 20.5, TT.driverLook(), 'drive', 0, { scale: 0.78, noShadow: true }) });
    return c;
  }
  UI.cartCanvas = cartCanvas;

  /* ---------------- عن اللعبة + التنويه ---------------- */
  UI.openInstallHelp = function () {
    const ios = TT.PWA && TT.PWA.isIOS;
    const steps = ios ? [['1', t('افتح اللعبة من Safari', 'Open the game in Safari')], ['2', t('دوس على زرار المشاركة ⬆️ تحت', 'Tap the Share button ⬆️')], ['3', t('اختار «إضافة إلى الشاشة الرئيسية» ➕', 'Choose “Add to Home Screen” ➕')], ['4', t('افتح اللعبة من الأيقونة الجديدة 🛺', 'Open it from the new icon 🛺')]]
      : [['1', t('افتح اللعبة من Chrome', 'Open the game in Chrome')], ['2', t('دوس على النقط التلاتة ⋮ فوق', 'Tap the ⋮ menu')], ['3', t('اختار «تثبيت التطبيق» أو «إضافة إلى الشاشة الرئيسية»', 'Choose “Install app” or “Add to Home screen”')], ['4', t('افتح اللعبة من الأيقونة الجديدة 🛺', 'Open it from the new icon 🛺')]];
    const b = openModal(`<div class="inst-box"><h3>📲 ${t('ثبّت اللعبة زي التطبيق', 'Install like an app')}</h3>
      <ol class="inst-steps">${steps.map(([n, x]) => `<li><b>${n}</b><span>${x}</span></li>`).join('')}</ol>
      <p class="hint">${t('بعد التثبيت هتفتح ملء الشاشة بالعرض، وتشتغل من غير إنترنت.', 'Once installed it opens fullscreen in landscape and works offline.')}</p>
      <div class="row center"><button class="btn gold" id="instOk">${t('تمام', 'OK')}</button></div></div>`, 'small', 'install');
    b.querySelector('#instOk').onclick = closeModal;
  };
  UI.openDisclaimer = function () {
    const b = openModal(`<div class="disc-box"><div class="disc-ic">🎬</div><h3>${t('تنويه', 'Notice')}</h3>
      <p>${t('اللعبة دي <b>خيالية</b>، وكل الشخصيات والأحداث والأماكن والأسعار والغرامات اللي فيها من وحي الخيال، ومش بالضرورة اللي بيحصل في اللعبة يحصل في الواقع.', 'This game is <b>fictional</b>. Characters, events, places, prices and fines are imaginary and do not necessarily reflect reality.')}</p>
      <p>${t('حاولنا نقدّم لكم متعة مالهاش آخر… على أن تكون التكملة في الأجزاء القادمة إن شاء الله 🛺✨', 'We tried to bring you endless fun… to be continued in the next parts 🛺✨')}</p>
      <div class="row center"><button class="btn big gold" id="discOk">${t('يلا نبدأ! 🚀', "Let's go! 🚀")}</button></div></div>`, 'small', 'disclaimer');
    b.querySelector('#discOk').onclick = () => { S().seenDisclaimer = true; TT.Save.write(); closeModal(); };
  };
  UI.openAbout = function () {
    const sec = (ic, h, items) => `<section class="ab-sec"><h4><span>${ic}</span>${h}</h4><ul>${items.map(x => `<li>${x}</li>`).join('')}</ul></section>`;
    const b = openModal(`<div class="about-box">
      <div class="ab-head"><img class="ab-logo" alt="" src="${(TT.ASSET_DATA && TT.ASSET_DATA['assets/ui/logo.png']) || 'assets/ui/logo.png'}"><div><h3>${t('توكتوك مصر', 'Tuk Tuk Egypt')}</h3><p>${t('اركب التوكتوك ولف مصر كلها: وصّل الزباين، اكسب فلوسك، طوّر مركبتك… وخلّي بالك من الكماين!', 'Ride across Egypt: carry riders, earn money, upgrade your ride… and watch out for checkpoints!')}</p></div></div>
      <div class="ab-credit"><div class="ab-dev">💻 ${t('تم برمجة اللعبة بواسطة', 'Developed by')} <b>${t('محمد المتولي', 'Mohamed El-Metwally')}</b></div><a class="ab-mail" href="mailto:lookalone@gmail.com">✉️ lookalone@gmail.com</a></div>
      <div class="ab-grid">
        ${sec('🎯', t('الهدف', 'Goal'), [t('وصّل العدد المطلوب من الركاب واوصل لآخر الخط ← ⭐', 'Deliver the required riders and reach the finish ← ⭐'), t('اكسب هدف الفلوس ← ⭐⭐', 'Hit the money target ← ⭐⭐'), t('من غير مخالفات ولا انقلاب ← ⭐⭐⭐', 'No fines, no flips ← ⭐⭐⭐'), t('النجوم بتفتح مناطق جديدة في خريطة مصر', 'Stars unlock new regions')])}
        ${sec('🎮', t('التحكم', 'Controls'), [t('🔑 شغّل المفتاح الأول', '🔑 Turn the key first'), t('البنزين يمين والفرامل شمال — الضغط المطوّل على الفرامل = رجوع', 'Gas right, brake left — hold brake to reverse'), t('💡 الكشافات: واطي / عالي / شبورة', '💡 Lights: low / high / fog'), t('⌨️ W/S سواقة · I مفتاح · L كشافات · Space كلاكس · E تفاعل · Tab خريطة', '⌨️ W/S drive · I key · L lights · Space horn · E interact · Tab map')])}
        ${sec('🚏', t('الركاب والفلوس', 'Riders & money'), [t('اقف قدام الموقف والركاب بيركبوا وينزلوا لوحدهم', 'Stop at a station — riders hop on and off'), t('الأجرة على قد المشوار، والبقشيش لو الزبون مبسوط', 'Fares grow with distance, tips for happy riders'), t('⛽ فوّل من البنزينة أو استخدم الجركن', '⛽ Refuel at stations or use a can'), t('🔧 صلّح وطوّر من الورشة — وفيه تصليح بالدين', '🔧 Repair & upgrade in the workshop — even on credit')])}
        ${sec('👮', t('الطريق والمرور', 'Road & police'), [t('📸 خلّي بالك من الرادار وحدود السرعة', '📸 Watch radars and speed limits'), t('اقف للكمين وجاوب الظابط صح', 'Stop at checkpoints and answer correctly'), t('لو هربت… عربية الشرطة هتجري وراك!', 'Run away… and the police will chase you!'), t('📱 رد على صاحب التوكتوك وإلا هياخده منك', '📱 Answer the tuk owner or he takes it back')])}
      </div>
      <div class="row center"><button class="btn gold" id="abOk">${t('تمام 👍', 'OK 👍')}</button><button class="btn" id="abDisc">🎬 ${t('التنويه', 'Notice')}</button></div></div>`, 'wide', 'about');
    b.querySelector('#abOk').onclick = closeModal;
    b.querySelector('#abDisc').onclick = () => UI.openDisclaimer();
  };

  /* ---------------- مساعدة ⓘ لكل شاشة ---------------- */
  const HELP = {
    menu: () => [['🛺', t('الفكرة', 'The idea'), t('سوق توكتوك في شوارع مصر: وصّل الركاب أو بيع بضاعة، واكسب فلوس، وطوّر مركبتك.', 'Drive a tuk tuk across Egypt: carry riders or sell goods, earn money and upgrade.')],
      ['🗺️', t('الخريطة', 'Map'), t('اختار المنطقة والمرحلة، وكمان وضع اللعب: ركاب أو بيّاع.', 'Pick a region, a level and the play mode: taxi or vendor.')],
      ['🔧', t('الورشة', 'Workshop'), t('تطوير وصيانة ودهان ومركبات جديدة وعربيات بيع.', 'Upgrades, repairs, paint, new vehicles and vendor carts.')],
      ['🔑', t('أول ما تبدأ', 'When you start'), t('شغّل المفتاح، دوس بنزين يمين وفرامل شمال، واقف قدام المحطات.', 'Turn the key, gas on the right, brake on the left, stop at stations.')]],
    map: () => [['★', t('نجمة 1', '1 star'), t('وصّل العدد المطلوب من الركاب (أو بيع العدد المطلوب) واوصل لآخر الخط.', 'Deliver (or sell) the required amount and reach the finish.')],
      ['★★', t('نجمتين', '2 stars'), t('وكمان حقق هدف الفلوس.', 'Also hit the money target.')],
      ['★★★', t('3 نجوم', '3 stars'), t('ومن غير مخالفات ولا انقلاب.', 'With no fines and no flips.')],
      ['🧍', t('وضع الركاب', 'Taxi mode'), t('بتلم ركاب من المحطات وتوصلهم.', 'Pick riders up at stations and drop them off.')],
      ['🛒', t('وضع البيّاع', 'Vendor mode'), t('بتسوق عربية بيع وتقف عند التجمعات والناس تيجي تشتري. العربية بتتطور من الورشة.', 'Drive a vendor cart, stop at crowds and people come to buy. Upgrade it in the workshop.')],
      ['🔓', t('المناطق المقفولة', 'Locked regions'), t('بتتفتح بالنجوم، أو بكود الفتح من الإعدادات.', 'Unlock with stars or an unlock code in Settings.')]],
    garage: () => ({
      upgrade: [['🔧', t('التطوير', 'Upgrades'), t('كل مستوى محرك بيزوّد السرعة القصوى 6% والسحب 12%. السرعة والفرامل والتعليق والإطارات والتانك والكشافات كل واحد ليه 5 مستويات.', 'Each engine level adds 6% top speed and 12% pull. Every upgrade has 5 levels.')]],
      acc: [['🔊', t('الاكسسوارات', 'Accessories'), t('السماعة والزينة ليهم زراير 🔊 و✨ أثناء السواقة. لما توصّل راكب الزينة بتعمل احتفال.', 'Use 🔊 and ✨ while driving. Lights party when you deliver a rider.')]],
      look: [['🎨', t('المظهر', 'Looks'), t('غيّر لون المركبة والملصقات. الألوان بتتشترى مرة واحدة.', 'Change paint and decals. Each is bought once.')]],
      wash: [['🧽', t('المغسلة', 'Car wash'), t('المية والرمل والطين بيوسخوا المركبة، والركاب بيتضايقوا من العربية الوسخة. التلميع بيقلّل الوساخة.', 'Water, sand and mud make it dirty and riders dislike that. Wax slows dirt.')]],
      repair: [['🛠️', t('الصيانة', 'Repairs'), t('الكمين بيدّي مخالفة لو أي جزء أقل من 35%. المطبات والحفر بسرعة بتضرب التعليق والإطارات.', 'Checkpoints fine you if any part is below 35%. Fast bumps hurt suspension and tires.')],
        ['💥', t('الدخان والانفجار', 'Smoke & explosion'), t('لما المحرك أو الهيكل يتبهدل المركبة بتدخّن، ولو كمّلت خبط بتفرقع والرحلة تخلص. السقف بيرجع لما تصلّح الهيكل.', 'A wrecked engine/body smokes and can explode. Repairing the body restores the roof.')],
        ['🪪', t('الرخصة', 'License'), t('الرخصة بتخلص بعد 25 مرحلة، وجدّدها هنا عشان الكماين.', 'Your license lasts 25 levels — renew it here.')]],
      carts: [['🛒', t('عربيات البيع', 'Vendor carts'), t('لكل بضاعة عربية خاصة. بتبدأ خشب، وتطوّرها لستانلس، وبعدين لمحل متنقل.', 'Each good has its own cart: wooden → stainless → mobile shop.')],
        ['📈', t('فايدة التطوير', 'Why upgrade'), t('بضاعة أكتر، سعر أعلى للحتة، وزباين أكتر بييجوا لما تنادي.', 'More stock, higher price per item and more customers.')]],
      tires: [['🛞', t('الإطارات', 'Tires'), t('إطارات الرمل للصحرا، والزراعي للريف، والفضاء للمريخ.', 'Sand tires for the desert, farm tires for the countryside, space tires for Mars.')]],
      buy: [['🛵', t('المركبات', 'Vehicles'), t('كل مركبة ليها عدد ركاب وسرعة. مركبات السباق أسرع بس أصعب في المطبات. العجلة والسكيت من غير بنزين.', 'Each vehicle has seats and speed. Race vehicles are faster but twitchier. Bike and skate need no fuel.')]]
    })[UI.garageTab] || [],
    drivers: () => [['🧑‍✈️', t('السواقين', 'Drivers'), t('كل سواق ليه ميزة: فرامل أحسن، أو ركاب أصبر، أو بقشيش أكتر. الشخصيات ثابتة الشكل في كل الأوضاع.', 'Each driver has a perk. Characters keep the same look everywhere.')]],
    achievements: () => [['🏆', t('الإنجازات', 'Achievements'), t('بتتفتح لوحدها وانت بتلعب، وكل إنجاز ليه مكافأة فلوس.', 'Unlocked as you play, each with a cash reward.')]],
    ledger: () => [['📒', t('الحسابات', 'Ledger'), t('كل جنيه دخل أو خرج: أجرة وبيع وبنزين ومخالفات وتصليح.', 'Every pound in or out: fares, sales, fuel, fines and repairs.')]],
    settings: () => [['🔓', t('كود الفتح', 'Unlock code'), t('اكتب 0000 تفتح اللعبة كلها، أو code ورقم المرحلة تفتح لحد المرحلة دي: ', 'Type 0000 to unlock all, or code + level number: ') + (() => { let n = 1; return TT.WORLDS.map(W => { const a = n; n += W.levels; return t(W.name, W.en) + ' ' + a + '–' + (n - 1); }).join(' · '); })()],
      ['🌐', t('اللغة', 'Language'), t('في وضع الإنجليزي الواجهة بتتترجم، لكن كلام الركاب بيفضل بالمصري.', 'In English mode the UI is translated; rider banter stays Egyptian.')],
      ['🎮', t('التحكم', 'Controls'), t('البنزين يمين والفرامل شمال (ممكن تعكسهم). كيبورد: W بنزين، S فرامل ورجوع، I مفتاح، Space كلاكس، E تفاعل، F انزل، L كشافات، C نادي، Tab خريطة، Esc إيقاف.', 'Gas right, brake left (swappable). Keys: W gas, S brake/reverse, I key, Space horn, E interact, F exit, L lights, C call, Tab map, Esc pause.')]],
    task: () => { const g = G(), L = g.L, C = g.ch, out = [];
      if (L) out.push(['★', t('المهمة الأساسية', 'Main objective'), g.vendor ? t('بيع ' + L.required + ' حتة: اقف عند التجمعات (المحطات) والناس هتيجي، أو دوس "نادي على البضاعة".', 'Sell ' + L.required + ': stop at crowds or call out.') : t('وصّل ' + L.required + ' ركاب: اقف قدام المحطة اللي عليها 🧍 وهم يركبوا، ووصّل كل واحد لمحطته (مكتوبة في اللوحة على اليمين ومعلّمة على الخريطة).', 'Deliver ' + L.required + ' riders: stop at stations with 🧍 and take each to their stop.')]);
      if (L) out.push(['★★', t('هدف الفلوس', 'Money target'), t('اكسب ' + L.target + ' ج: وصّل في الميعاد عشان تاخد مكافأة، وخلّي الركاب مبسوطين عشان البقشيش.', 'Earn ' + L.target + ': on-time bonuses and tips from happy riders.')]);
      out.push(['★★★', t('من غير غلطات', 'Clean run'), t('ولا مخالفة ولا انقلاب: التزم بالسرعة واقف في الإشارات والكماين.', 'No violations or flips: obey limits, lights and checkpoints.')]);
      if (C) out.push(['🎯', t('التحدي', 'Challenge') + ': ' + C.text, C.tip]);
      return out; },
    free: () => [['🛣️', t('الفكرة', 'The idea'), t('رحلة طويلة من غير مراحل، بتعدّي فيها بين البلاد واحدة ورا التانية. الهدف إنك تكسب فلوس.', 'A long trip with no levels, crossing region after region. The goal is to earn money.')],
      ['🏁', t('السباقات', 'Races'), t('عربيات هتطلب تتسابق معاك، أو تقرّب من عربية عليها 🏁 وتتحداها. اختار الرهان، ولو كسبت بتاخد الرهان مضروب، وكل ما تكسب ورا بعض المكسب بيزيد.', 'Cars will challenge you, or approach a 🏁 car to challenge it. Pick a bet — wins pay a multiple that grows with your streak.')],
      ['☕', t('الاستراحة', 'Rest stops'), t('السواق بيتعب مع الوقت (😴). لو التعب زاد هتغفل وانت سايق! اقف في الاستراحة واشرب شاي أو كُل أو نام.', 'Fatigue (😴) builds up — too much and you doze off at the wheel. Rest, eat or sleep at rest stops.')],
      ['🔧', t('ورش الطريق', 'Road workshops'), t('صلّح المركبة من غير ما ترجع، بس أغلى 25%.', 'Repair on the road, 25% pricier.')],
      ['🌦️', t('الوقت والطقس', 'Time & weather'), t('الوقت بيعدّي من الصبح للعشا، وممكن تمطر أو ترعد. بالليل وفي المطر شغّل الكشافات.', 'Time flows from morning to night and it may rain or storm. Use headlights at night and in rain.')]],
    lines: () => [['💬', t('التعليقات', 'Comments'), t('اختار نوع التعليق من القايمة، وعدّل الكلام في المربع: كل سطر تعليق لوحده. دوس احفظ وهيظهر في اللعبة على طول.', 'Pick a category, edit the box (one line per comment), then save.')], ['🗣️', t('الحوارات', 'Dialogues'), t('في الحوارات اكتب كلام الراكب وبعده علامة | وبعدها رد السواق.', 'For dialogues write: rider line | driver reply.')], ['↩️', t('رجوع', 'Restore'), t('زرار «رجّع الأصلي» بيرجّع تعليقات اللعبة الأصلية للنوع ده.', 'Restore original brings back the default lines.')]],
    intro: () => [['🔑', t('التشغيل', 'Start'), t('دوس على زرار المفتاح الأول عشان المحرك يدور.', 'Tap the key button to start the engine.')],
      ['🦶', t('الدواسات', 'Pedals'), t('البنزين يمين والفرامل شمال. اضغط مطوّل على الفرامل وانت واقف عشان ترجع لورا.', 'Gas right, brake left. Hold brake while stopped to reverse.')],
      ['🚏', t('المحطات', 'Stations'), t('اقف قدام الموقف والركاب بينزلوا ويطلعوا لوحدهم. زرار "ركّب" بيخليك تختار وتفاصل.', 'Stop at a station: riders get on and off by themselves. "Pick up" lets you choose and haggle.')],
      ['🗺️', t('الخريطة', 'Map'), t('دوس على شريط الطريق فوق تكبر الخريطة وتشوف أماكن نزول ركابك.', 'Tap the route bar to enlarge the map and see drop-offs.')],
      ['👮', t('الكماين والرادار', 'Police & radar'), t('اقف تمامًا قبل الكمين، وخلّي بالك من حد السرعة قبل الرادار.', 'Stop fully before checkpoints and watch the limit near radars.')]]
  };
  function helpBtn(key) { return `<button class="info-btn" data-help="${key}" aria-label="info">i</button>`; }
  UI.showHelp = function (key) {
    const items = (HELP[key] || (() => []))(); if (!items.length) return;
    const prev = G().modal && $('#modalBody').innerHTML, wasModal = G().mode === 'play' && G().modal;
    const html = `<div class="help-box"><h3>ⓘ ${t('إزاي تلعب', 'How it works')}</h3><div class="help-list">${items.map(([ic, h, d]) => `<div class="help-row"><span class="hic">${ic}</span><div><b>${h}</b><p>${d}</p></div></div>`).join('')}</div><div class="row center"><button class="btn gold" id="helpOk">${t('فهمت 👍', 'Got it 👍')}</button></div></div>`;
    if (wasModal) { // جوه شاشة بداية المرحلة: نعرض فوقها ونرجع
      const ov = document.createElement('div'); ov.className = 'help-ov'; ov.innerHTML = `<div class="panel">${html}</div>`; document.body.appendChild(ov);
      ov.querySelector('#helpOk').onclick = () => ov.remove(); ov.onclick = e => { if (e.target === ov) ov.remove(); }; return;
    }
    const b = openModal(html, 'wide', 'help'); b.querySelector('#helpOk').onclick = closeModal;
  };
  document.addEventListener('click', e => { const b = e.target.closest && e.target.closest('[data-help]'); if (b) { TT.Audio.play('click'); UI.showHelp(b.dataset.help); } });

  /* ---------------- screens ---------------- */
  function show(id) {
    document.querySelectorAll('.screen').forEach(s => s.classList.toggle('hidden', s.id !== id));
    $('#hud').classList.toggle('hidden', id !== 'play');
    document.body.classList.toggle('in-game', id === 'play');
    UI.current = id;
  }
  UI.show = show;
  function header(title, back, help) {
    return `<div class="scr-head"><button class="btn back" data-go="${back || 'menu'}">➜ ${t('رجوع', 'Back')}</button><h2>${title}${help ? helpBtn(help) : ''}</h2>
      <div class="wallet"><span>💰 ${fmt(S().money)} ${t('ج', 'EGP')}</span><span>⭐ ${TT.Save.totalStars()}</span><span>🧑‍✈️ ${t('مستوى', 'Lv')} ${TT.Save.driverLevel()}</span>${S().debt > 0 ? `<span class="debt-chip">🧾 ${t('دين', 'Debt')} ${fmt(S().debt)}</span>` : ''}</div></div>`;
  }
  function bindGo(root) { root.querySelectorAll('[data-go]').forEach(b => b.onclick = () => { TT.Audio.play('click'); go(b.dataset.go); }); }
  function go(id) {
    if (id === 'menu') renderMenu(); else if (id === 'map') renderMap(); else if (id === 'garage') renderGarage(); else if (id === 'drivers') renderDrivers();
    else if (id === 'achievements') renderAch(); else if (id === 'settings') renderSettings(); else if (id === 'ledger') renderLedger(); else if (id === 'lines') renderLines(); else if (id === 'license') { renderMenu(); UI.openLicense(() => { closeModal(); renderMenu(); }); id = 'menu'; }
    show(id);
  }
  UI.go = go;

  /* ---------------- MENU ---------------- */
  // مشهد متحرك ورا القايمة: التوكتوك ماشي في شوارع العوالم المختلفة
  let menuRAF = null;
  function menuScene(cv) {
    const themes = ['streets', 'alex', 'country', 'saeed', 'desert', 'city', 'mars'];
    let t0 = performance.now(), last = t0, camX = 0;
    const loop = now => {
      if (UI.current !== 'menu' || !cv.isConnected) { menuRAF = null; return; }
      const dt = Math.max(0, Math.min(0.05, (now - last) / 1000)); last = now; camX += dt * 260;
      const dpr = Math.min(2, window.devicePixelRatio || 1), W = cv.clientWidth, H = cv.clientHeight;
      if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
      const x = cv.getContext('2d'), sc = H / 540, VW = W / sc, tt = Math.max(0, now - t0) / 1000;
      const theme = themes[Math.floor(tt / 9) % themes.length], pal = A.PAL[theme];
      x.setTransform(dpr * sc, 0, 0, dpr * sc, 0, 0);
      A.background(x, theme, camX, VW, 540, tt, dpr * sc, 'high');
      const RY = 352;
      x.fillStyle = pal.side; x.fillRect(0, RY - 56, VW, 18); x.fillStyle = pal.curb; x.fillRect(0, RY - 38, VW, 5);
      x.fillStyle = pal.road; x.fillRect(0, RY - 33, VW, 55); x.fillStyle = pal.curb; x.fillRect(0, RY + 22, VW, 6);
      x.fillStyle = pal.side; x.fillRect(0, RY + 28, VW, 18); x.fillStyle = pal.fore; x.fillRect(0, RY + 46, VW, 300);
      x.fillStyle = 'rgba(255,255,255,.6)'; for (let k = -((camX * 1) % 70); k < VW; k += 70) x.fillRect(k, RY - 13, 36, 3);
      // tuktuk
      const m = TT.Save.model(), kind = m.kind || 'tuktuk', g = TT.GEOM[kind], bob = Math.sin(tt * 9) * 1.2;
      const tx = VW * (TT.lang === 'ar' ? 0.7 : 0.3), ty = RY - g.H0 * TT.PX + bob;
      x.save(); x.translate(tx, RY); x.globalAlpha = .3; x.fillStyle = '#000'; x.beginPath(); x.ellipse(0, 2, (g.front + g.back) * 24, 6, 0, 0, 7); x.fill(); x.restore();
      const wr = g.wheelR * TT.PX; for (const wx of [g.rearX, g.frontX]) A.wheel(x, tx + wx * TT.PX, RY - wr, wr, tt * 14);
      x.save(); x.translate(tx, ty); x.rotate(Math.sin(tt * 2.2) * 0.015);
      const SE = { tuktuk: [22, 20.5, 0.78, 'drive'], scooter: [-14, 7, 0.85, 'drive'], bike: [-6, 5, 0.85, 'pedal'], skate: [6, -1, 0.95, 'skate'], microbus: [86, -7, 0.8, 'drive'], sport: [-4, 10, 0.56, 'drive'] }[kind];
      A.playerBody(x, kind, { color: TT.paintColor(), trim: m.trim, space: m.space, style: m.style, decal: S().decal, t: tt, shake: 0.4, inside: c => A.person(c, SE[0], SE[1], TT.driverLook(), SE[3], tt, { scale: SE[2], noShadow: true, pedal: tt * 8 }) });
      A.accessories(x, kind, TT.accOpts(), tt, { subOn: true, partyOn: true, celebrate: false, dirt: 0 });
      x.restore();
      for (let k = 0; k < 3; k++) { const a = ((tt * 1.3 + k * 0.33) % 1); x.globalAlpha = (1 - a) * 0.45; x.fillStyle = theme === 'mars' ? '#c0563a' : '#b8a68a'; x.beginPath(); x.arc(tx - g.back * TT.PX - a * 60, RY - 6 - a * 20, 4 + a * 10, 0, 7); x.fill(); }
      x.globalAlpha = 1;
      menuRAF = requestAnimationFrame(loop);
    };
    if (!menuRAF) menuRAF = requestAnimationFrame(loop);
  }
  function renderMenu() {
    const d = S(), el = $('#menu');
    const snap = d.snapshot; const W = snap ? TT.WORLDS[snap.world] : null;
    const drv = TT.DRIVERS.find(x => x.id === d.driver) || TT.DRIVERS[0];
    const tiles = [['map', '🗺️', t('خريطة مصر', 'Map'), TT.WORLDS.length + ' ' + t('منطقة', 'regions') + ' · ' + TT.WORLDS.reduce((s, W) => s + W.levels, 0) + ' ' + t('مرحلة', 'levels')], ['garage', '🔧', t('المرآب', 'Garage'), t('تطوير · اكسسوارات · مغسلة', 'Upgrades · extras · wash')], ['drivers', '🧑‍✈️', t('السواق', 'Driver'), t(drv.name, drv.en)],
      ['achievements', '🏆', t('الإنجازات', 'Achievements'), t('مهام وسجل مخالفات', 'Goals & fines log')], ['ledger', '📒', t('الحسابات', 'Ledger'), t('دخل ومصروفات', 'Income & costs')], ['license', '🪪', t('المرور', 'Traffic office'), t('غرامات · حوادث · تجديد', 'Fines · crashes · renewal')], ['lines', '💬', t('التعليقات', 'Comments'), t('اكتب كلام السواق والزباين', 'Write your own lines')], ['settings', '⚙️', t('الإعدادات', 'Settings'), t('صوت · تحكم · عوائق', 'Sound · controls · obstacles')]];
    el.innerHTML = `
      <div class="menu2">
        <canvas id="menuScene"></canvas><div class="menu-shade"></div>
        <div class="menu-top">
          <div class="mchips"><span>💰 ${fmt(d.money)}</span><span>⭐ ${TT.Save.totalStars()}</span><span>🧑‍✈️ ${t('مستوى', 'Lv')} ${TT.Save.driverLevel()}</span><span>🛢️ ${d.jerry || 0}</span></div>
          <div class="mtools"><button class="ibtn install-btn ${TT.PWA && TT.PWA.canInstall() ? '' : 'hidden'}" id="mInstall">📲 <span>${t('ثبّت اللعبة', 'Install')}</span></button><button class="ibtn about-btn" id="mAbout" title="${t('عن اللعبة', 'About')}">📖 <span>${t('عن اللعبة', 'About')}</span></button><button class="ibtn" id="mLang">${t('EN', 'ع')}</button><button class="ibtn" id="mFull" title="fullscreen">⛶</button></div>
        </div>
        <div class="menu-main">
          <div class="brand">${helpBtn('menu')}
            <img class="logo" alt="توكتوك مصر" src="${(TT.ASSET_DATA && TT.ASSET_DATA['assets/ui/logo.png']) || 'assets/ui/logo.png'}">
          </div>
          <nav class="menu-nav">
            <button class="play-btn" id="mPlay"><span class="pi">▶</span><span><b>${t('ابدأ اللعب', 'Play')}</b><small>${t('اختار المنطقة والمرحلة', 'Choose region & level')}</small></span></button>
            <button class="free-btn" id="mFree"><span class="pi">🛣️</span><span><b>${t('السواقة الحرة', 'Free drive')}</b><small>${t('رحلة طويلة · سباقات برهان · فلوس', 'Long trip · bet races · money')}</small></span></button>
            ${snap ? `<button class="cont-btn" id="mCont">⟲ <span><b>${t('كمّل آخر رحلة', 'Continue')}</b><small>${esc(t(W.name, W.en))} — ${t('مرحلة', 'Level')} ${snap.level + 1}</small></span></button>` : ''}
            <div class="tile-grid">${tiles.map(([id, ic, nm, sub]) => `<button class="mtile" data-go="${id}"><span class="ti">${ic}</span><b>${nm}</b><small>${esc(sub)}</small></button>`).join('')}</div>
          </nav>
        </div>
        <div class="menu-foot">${t('الغرامات والأسعار في اللعبة خيالية', 'All fines and prices are fictional')}</div>
      </div>`;
    bindGo(el);
    $('#mPlay').onclick = () => { TT.Audio.init(); go('map'); };
    $('#mAbout').onclick = () => { TT.Audio.play('click'); UI.openAbout(); };
    $('#mInstall').onclick = async () => { TT.Audio.play('click'); if (TT.PWA.deferred) { if (await TT.PWA.install()) toast(t('📲 اللعبة اتثبتت على الموبايل!', '📲 Installed!'), 'good'); } else UI.openInstallHelp(); };
    if (TT.PWA) TT.PWA.onChange = () => { const b = $('#mInstall'); if (b) b.classList.toggle('hidden', !TT.PWA.canInstall()); };
    if (!d.seenDisclaimer) setTimeout(() => { if (!S().seenDisclaimer && UI.current === 'menu' && $('#modal').classList.contains('hidden')) UI.openDisclaimer(); }, document.getElementById('splash') ? 1700 : 400);
    $('#mFree').onclick = () => { TT.Audio.init(); UI.openFreeStart(); };
    if (snap) $('#mCont').onclick = () => { TT.Audio.init(); TT.Game.startLevel(snap.world, snap.level, true); };
    $('#mLang').onclick = () => { d.settings.lang = d.settings.lang === 'ar' ? 'en' : 'ar'; TT.lang = d.settings.lang; TT.Save.write(); applyLang(); renderMenu(); };
    $('#mFull').onclick = fullscreen;
    menuRAF = null; requestAnimationFrame(() => menuScene($('#menuScene')));
  }
  function applyLang() { document.documentElement.lang = TT.lang; document.documentElement.dir = TT.lang === 'ar' ? 'rtl' : 'ltr'; }
  function fullscreen() {
    const e = document.documentElement;
    const p = e.requestFullscreen ? e.requestFullscreen() : e.webkitRequestFullscreen ? e.webkitRequestFullscreen() : null;
    if (p && p.then) p.then(() => { if (screen.orientation && screen.orientation.lock) screen.orientation.lock('landscape').catch(() => { }); }).catch(() => { });
  }

  /* ---------------- MAP ---------------- */
  function worldStars(W) { let s = 0; for (let i = 0; i < W.levels; i++) s += S().stars[W.id + '-' + i] || 0; return s; }
  function worldUnlocked(W) { const u = S().unlocks; return u.all || TT.Save.totalStars() >= W.unlockStars || u.levels.some(k => k.indexOf(W.id + '-') === 0); }
  function levelOpen(W, i) { const d = S(), u = d.unlocks, key = W.id + '-' + i; if (u.all || u.levels.includes(key)) return true; return worldUnlocked(W) && (i === 0 || (d.stars[W.id + '-' + (i - 1)] || 0) >= 1); }
  /* أكواد الفتح: 0000 = كل اللعبة، أو رقم مرحلة من 1 لـ 30 (ترقيم متصل عبر العوالم) */
  function applyCode(raw) {
    const d = S(); const code = String(raw || '').toLowerCase().replace(/code|كود/g, '').replace(/[\s\-_:#]/g, '').replace(/[٠-٩]/g, c => '٠١٢٣٤٥٦٧٨٩'.indexOf(c));
    const total = TT.WORLDS.reduce((s, W) => s + W.levels, 0);
    if (!/^\d+$/.test(code)) return { ok: false, msg: t('اكتب رقم المرحلة (1 لـ ' + total + ') أو 0000', 'Type a level number (1–' + total + ') or 0000') };
    if (code === '0000') {
      d.unlocks.all = true;
      for (const m of TT.TUKTUKS) if (!d.ownedTuktuks.includes(m.id)) { d.ownedTuktuks.push(m.id); d.vehicles[m.id] = { fuel: m.tank, damage: { engine: 0, tires: 0, suspension: 0, brakes: 0, body: 0 } }; }
      d.ownedTires = TT.TIRE_TYPES.map(x => x.id); d.ownedPaints = TT.PAINTS.map(x => x.id); d.ownedDecals = TT.DECALS.map(x => x.id); d.accessories = TT.ACCESSORIES.map(x => x.id); d.accOn = d.accOn || {};
      for (const u of TT.UPGRADES) d.upgrades[u.id] = 5;
      if (d.money < 100000) d.money = 100000;
      if (d.xp < 120 * 81) d.xp = 120 * 81; // driver level 10
      TT.Save.write();
      return { ok: true, msg: t('اتفتح كل حاجة! كل العوالم والمراحل، وكل المركبات والاكسسوارات، والتطويرات على الآخر، و100,000 جنيه', 'Everything unlocked: all worlds & levels, tuk tuks, max upgrades, 100,000 EGP') };
    }
    const n = parseInt(code, 10);
    if (n < 1 || n > total) return { ok: false, msg: t('رقم المرحلة لازم يكون من 1 لـ ' + total, 'Level must be 1–' + total) };
    let k = n - 1, wi = 0; while (k >= TT.WORLDS[wi].levels) { k -= TT.WORLDS[wi].levels; wi++; }
    const W = TT.WORLDS[wi], key = W.id + '-' + k;
    if (!d.unlocks.levels.includes(key)) d.unlocks.levels.push(key);
    let extra = '';
    if (W.needsSpace && !d.ownedTuktuks.includes('space')) { const m = TT.TUKTUKS.find(x => x.id === 'space'); d.ownedTuktuks.push('space'); d.vehicles.space = { fuel: m.tank, damage: { engine: 0, tires: 0, suspension: 0, brakes: 0, body: 0 } }; extra = t(' + توكتوك الفضاء', ' + Space Tuk'); }
    TT.Save.write(); UI.selWorld = wi;
    return { ok: true, msg: t('اتفتحت: ' + W.name + ' — مرحلة ' + (k + 1), 'Unlocked: ' + W.en + ' — level ' + (k + 1)) + extra };
  }
  UI.applyCode = applyCode;
  UI.selWorld = 0;
  // أماكن العوالم على خريطة مصر (نسبة من العرض/الطول)
  // إسقاط خطوط الطول والعرض على الخريطة (مصر من 24.6 لـ 37 شرق، ومن 21.6 لـ 31.9 شمال)
  const LON0 = 24.4, LON1 = 37.2, LAT0 = 21.5, LAT1 = 32.1;
  const proj = (lon, lat) => [(lon - LON0) / (LON1 - LON0), (LAT1 - lat) / (LAT1 - LAT0)];
  const WICONS = { streets: '🏙️', country: '🌾', alex: '🌊', desert: '🏜️', saeed: '🏛️', city: '🌆', mars: '🚀' };
  const CICONS = { streets: '🕌', country: '🌾', alex: '⛵', desert: '🏜️', saeed: '🛶', city: '🏙️', giza: '🔺', mansoura: '🌉', tanta: '🍬', portsaid: '⚓', ismailia: '🌳', suez: '🚢', fayoum: '💧', minya: '🏺', luxor: '🏛️', aswan: '⛵', hurghada: '🐠', sharm: '🤿', matrouh: '🏖️', siwa: '🌴', damietta: '🪑', mars: '🚀' };
  const worldDone = W => { for (let i = 0; i < W.levels; i++) if (!(S().stars[W.id + '-' + i] > 0)) return false; return true; };
  UI.worldDone = worldDone;
  /* ---------- زووم وتحريك خريطة مصر: زرارين +/− أو عجلة الماوس أو صباعين، واسحب عشان تتحرك ---------- */
  UI.mapZ = UI.mapZ || { s: 1, x: 0, y: 0 };
  UI.mapZoomInit = function () {
    const box = $('#egypt2'), z = $('#egZoom'), cv = $('#egyptMap'); if (!box || !z) return;
    const Z = UI.mapZ; let redrawT = null;
    const clampZ = () => { const W = box.clientWidth, H = box.clientHeight; Z.s = Math.max(1, Math.min(5, Z.s)); Z.x = Math.min(0, Math.max(W * (1 - Z.s), Z.x)); Z.y = Math.min(0, Math.max(H * (1 - Z.s), Z.y)); };
    const apply = (redraw) => { clampZ(); z.style.transform = `translate(${Z.x}px,${Z.y}px) scale(${Z.s})`; box.style.setProperty('--iz', 1 / Z.s); box.classList.toggle('zoomed', Z.s > 1.5); if (redraw) { clearTimeout(redrawT); redrawT = setTimeout(() => drawEgypt(cv, Z.s), 140); } };
    const zoomAt = (f, cx, cy) => { const old = Z.s; Z.s = Math.max(1, Math.min(5, Z.s * f)); const k = Z.s / old; Z.x = cx - (cx - Z.x) * k; Z.y = cy - (cy - Z.y) * k; apply(true); };
    const center = () => [box.clientWidth / 2, box.clientHeight / 2];
    box.querySelectorAll('[data-z]').forEach(b => b.onclick = e => { e.stopPropagation(); TT.Audio.play('click'); const [cx, cy] = center(); if (b.dataset.z === 'in') zoomAt(1.5, cx, cy); else if (b.dataset.z === 'out') zoomAt(1 / 1.5, cx, cy); else { Z.s = 1; Z.x = 0; Z.y = 0; apply(true); } });
    box.onwheel = e => { e.preventDefault(); const r = box.getBoundingClientRect(); zoomAt(e.deltaY < 0 ? 1.18 : 1 / 1.18, e.clientX - r.left, e.clientY - r.top); };
    const pts = new Map(); let moved = 0, last = null, pinch = null;
    box.onpointerdown = e => { if (e.target.closest('.eg-ctl')) return; pts.set(e.pointerId, [e.clientX, e.clientY]); moved = 0; last = [e.clientX, e.clientY]; if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]) }; } };
    box.onpointermove = e => {
      if (!pts.has(e.pointerId)) return; pts.set(e.pointerId, [e.clientX, e.clientY]);
      if (pts.size === 2 && pinch) { const [a, b] = [...pts.values()], d2 = Math.hypot(a[0] - b[0], a[1] - b[1]), r = box.getBoundingClientRect(); zoomAt(d2 / pinch.d, (a[0] + b[0]) / 2 - r.left, (a[1] + b[1]) / 2 - r.top); pinch.d = d2; moved = 99; return; }
      if (Z.s <= 1 || !last) return; const dx = e.clientX - last[0], dy = e.clientY - last[1]; moved += Math.abs(dx) + Math.abs(dy); last = [e.clientX, e.clientY]; if (moved > 6) { box.setPointerCapture && box.setPointerCapture(e.pointerId); Z.x += dx; Z.y += dy; apply(false); }
    };
    const up = e => { pts.delete(e.pointerId); if (pts.size < 2) pinch = null; if (!pts.size) last = null; };
    box.onpointerup = up; box.onpointercancel = up;
    box.addEventListener('click', e => { if (moved > 6) { e.stopPropagation(); e.preventDefault(); moved = 0; } }, true);
    // أول ما تختار مدينة والخريطة مكبّرة، خليها في النص
    apply(false);
  };
  function drawEgypt(cv, zs) {
    const dpr = Math.min(2, window.devicePixelRatio || 1) * Math.min(3, zs || (UI.mapZ ? UI.mapZ.s : 1)), W = cv.clientWidth, H = cv.clientHeight;
    cv.width = W * dpr; cv.height = H * dpr; const x = cv.getContext('2d'); x.scale(dpr, dpr);
    const P = (lon, lat) => { const p = proj(lon, lat); return [p[0] * W, p[1] * H]; };
    const poly = (pts, fill, stroke, lw) => { x.beginPath(); pts.forEach((q, i) => { const [px, py] = P(q[0], q[1]); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.closePath(); if (fill) { x.fillStyle = fill; x.fill(); } if (stroke) { x.strokeStyle = stroke; x.lineWidth = lw || 1; x.stroke(); } };
    const line = (pts, col, lw, dash) => { x.beginPath(); pts.forEach((q, i) => { const [px, py] = P(q[0], q[1]); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.strokeStyle = col; x.lineWidth = lw; x.setLineDash(dash || []); x.stroke(); x.setLineDash([]); };
    // البحر
    let g = x.createLinearGradient(0, 0, W, H); g.addColorStop(0, '#2b7bb9'); g.addColorStop(1, '#1d5f93'); x.fillStyle = g; x.fillRect(0, 0, W, H);
    x.strokeStyle = 'rgba(255,255,255,.07)'; x.lineWidth = 1; for (let i = 0; i < 26; i++) { const yy = (i / 26) * H; x.beginPath(); for (let xx = 0; xx <= W; xx += 12) x.lineTo(xx, yy + Math.sin(xx * 0.05 + i) * 2); x.stroke(); }
    // اليابسة المجاورة (ليبيا والسودان وفلسطين والسعودية) باهتة
    x.fillStyle = '#c9b48a'; x.globalAlpha = 0.45;
    poly([[LON0, LAT1 - 0.5], [25, 31.6], [25, 22], [LON0, 22]], '#c9b48a'); poly([[LON0, 22], [36.9, 22], [37.2, 21.8], [37.2, LAT0], [LON0, LAT0]], '#c9b48a'); poly([[34.22, 31.32], [35.2, 31.9], [37.2, 32.1], [37.2, 29.3], [34.95, 29.4]], '#c9b48a'); poly([[34.95, 29.4], [34.82, 28.6], [34.85, 28.1], [35.3, 28.0], [36.0, 26.9], [36.6, 25.9], [37.2, 25.0], [37.2, 29.4]], '#c9b48a');
    x.globalAlpha = 1;
    // مصر
    const EG = [[25, 31.6], [25.15, 31.55], [27, 31.4], [28.5, 31.05], [29.9, 31.25], [30.3, 31.47], [31, 31.58], [31.6, 31.52], [32.2, 31.28], [32.6, 31.07], [33.4, 31.15], [34.22, 31.32], [34.9, 29.5], [34.6, 28.6], [34.25, 27.73], [33.75, 28.2], [33.2, 28.9], [32.6, 29.95], [32.35, 29.6], [32.7, 28.9], [33.6, 27.3], [34.2, 26.3], [35.1, 24.8], [35.8, 23.9], [36.9, 22], [31.4, 22], [25, 22], [25, 29.2], [24.85, 30.0]];
    x.save(); x.shadowColor = 'rgba(0,0,0,.45)'; x.shadowBlur = 16; x.shadowOffsetY = 4;
    g = x.createLinearGradient(0, 0, 0, H); g.addColorStop(0, '#f2dba6'); g.addColorStop(1, '#ddb36f'); poly(EG, g); x.restore();
    poly(EG, null, 'rgba(120,80,30,.65)', 1.6);
    // تضاريس رملية خفيفة
    x.save(); x.beginPath(); EG.forEach((q, i) => { const [px, py] = P(q[0], q[1]); i ? x.lineTo(px, py) : x.moveTo(px, py); }); x.closePath(); x.clip();
    for (let i = 0; i < 70; i++) { x.fillStyle = 'rgba(150,100,40,' + (0.04 + A.hash(i) * 0.06) + ')'; x.beginPath(); x.ellipse(A.hash(i * 3) * W, A.hash(i * 7) * H, 12 + A.hash(i) * 30, 3 + A.hash(i * 5) * 5, -0.3, 0, 7); x.fill(); }
    // جبال سيناء والبحر الأحمر: مثلثات صغيرة
    const mtn = (lon, lat, sz) => { const [px, py] = P(lon, lat); x.fillStyle = 'rgba(150,100,55,.55)'; x.beginPath(); x.moveTo(px - sz, py); x.lineTo(px, py - sz * 0.9); x.lineTo(px + sz, py); x.fill(); x.fillStyle = 'rgba(255,255,255,.25)'; x.beginPath(); x.moveTo(px, py - sz * 0.9); x.lineTo(px + sz * 0.25, py - sz * 0.6); x.lineTo(px - sz * 0.1, py - sz * 0.55); x.fill(); };
    const ms = Math.max(4, W * 0.009);
    [[33.9, 28.6], [34.1, 28.8], [33.7, 28.9], [34.3, 28.4], [33.6, 27.3], [33.8, 26.6], [34.1, 26.0], [34.5, 25.3], [34.9, 24.4], [35.2, 23.6], [33.3, 27.6]].forEach(([lo, la]) => mtn(lo, la, ms));
    x.restore();
    // الدلتا والوادي الأخضر
    poly([[31.2, 30.15], [30.3, 31.45], [30.8, 31.55], [31.6, 31.5], [31.85, 31.4], [32.15, 31.2], [31.3, 30.15]], '#7cb555');
    const NILE = [[32.9, 23.7], [32.88, 24.5], [32.95, 25.1], [32.6, 25.6], [32.75, 26.15], [32.0, 26.55], [31.6, 27.2], [30.95, 27.9], [30.75, 28.6], [30.95, 29.2], [31.25, 29.8], [31.24, 30.1]];
    line(NILE, '#7cb555', Math.max(10, W * 0.028)); line(NILE, '#2f86c9', 2.6);
    line([[31.24, 30.1], [30.95, 30.6], [30.6, 31.0], [30.42, 31.45]], '#2f86c9', 2); line([[31.24, 30.1], [31.35, 30.7], [31.62, 31.1], [31.82, 31.5]], '#2f86c9', 2);
    poly([[32.9, 23.7], [32.6, 23.2], [32.0, 22.6], [31.4, 22.0], [31.9, 22.0], [32.5, 22.7], [33.1, 23.4]], '#3d95d1'); // بحيرة ناصر
    poly([[30.45, 29.42], [30.8, 29.4], [30.75, 29.5], [30.45, 29.5]], '#3d95d1'); // قارون
    poly([[25.4, 29.15], [25.7, 29.1], [25.7, 29.25], [25.4, 29.25]], 'rgba(61,149,209,.8)'); // سيوة
    line([[32.3, 31.25], [32.33, 30.8], [32.27, 30.55], [32.4, 30.3], [32.55, 29.97]], '#3d95d1', 2.2); // قناة السويس
    // أسماء المناطق
    const lab = (s2, lon, lat, size, col) => { const [px, py] = P(lon, lat); x.font = '700 ' + size + 'px ' + A.FONT; x.fillStyle = col; x.textAlign = 'center'; x.fillText(s2, px, py); };
    const fs = Math.max(9, W * 0.024);
    lab(t('البحر الأبيض المتوسط', 'Mediterranean Sea'), 28.5, 31.85, fs, 'rgba(255,255,255,.75)'); lab(t('البحر الأحمر', 'Red Sea'), 35.6, 25.6, fs, 'rgba(255,255,255,.75)');
    lab(t('الصحراء الغربية', 'Western Desert'), 27.6, 26.2, fs * 1.1, 'rgba(110,70,25,.45)'); lab(t('سيناء', 'Sinai'), 33.9, 29.9, fs, 'rgba(110,70,25,.5)'); lab(t('الصحراء الشرقية', 'Eastern Desert'), 33.4, 26.6, fs * 0.85, 'rgba(110,70,25,.4)');
    lab(t('النيل', 'Nile'), 31.2, 26.9, fs * 0.85, 'rgba(30,90,150,.7)');
    // أهرامات صغيرة
    const pyr = (lon, lat, sz) => { const [px, py] = P(lon, lat); x.fillStyle = '#c08a40'; x.beginPath(); x.moveTo(px - sz, py); x.lineTo(px, py - sz * 1.1); x.lineTo(px + sz, py); x.fill(); x.fillStyle = 'rgba(0,0,0,.2)'; x.beginPath(); x.moveTo(px, py - sz * 1.1); x.lineTo(px + sz, py); x.lineTo(px, py); x.fill(); };
    pyr(30.95, 29.86, 5); pyr(30.85, 29.88, 4);
    // خط المريخ
    const [mx, my] = P(36.4, 31.0), [cx0, cy0] = P(31.25, 30.05);
    x.setLineDash([4, 6]); x.strokeStyle = 'rgba(255,255,255,.6)'; x.lineWidth = 1.6; x.beginPath(); x.moveTo(cx0, cy0); x.quadraticCurveTo((cx0 + mx) / 2, my - H * 0.12, mx, my); x.stroke(); x.setLineDash([]);
    // بوصلة ومقياس
    const cr = Math.max(14, W * 0.035), ccx = W - cr - 12, ccy = H - cr - 34;
    x.fillStyle = 'rgba(14,17,27,.55)'; x.beginPath(); x.arc(ccx, ccy, cr, 0, 7); x.fill(); x.fillStyle = '#ff5252'; x.beginPath(); x.moveTo(ccx, ccy - cr * 0.8); x.lineTo(ccx - cr * 0.25, ccy); x.lineTo(ccx + cr * 0.25, ccy); x.fill(); x.fillStyle = '#fff'; x.beginPath(); x.moveTo(ccx, ccy + cr * 0.8); x.lineTo(ccx - cr * 0.25, ccy); x.lineTo(ccx + cr * 0.25, ccy); x.fill();
    x.font = '800 10px ' + A.FONT; x.textAlign = 'center'; x.fillStyle = '#fff'; x.fillText('N', ccx, ccy - cr - 3);
  }
  function currentLevel(W) { const d = S(); for (let i = 0; i < W.levels; i++) if (levelOpen(W, i) && !(d.stars[W.id + '-' + i] > 0)) return i; return W.levels - 1; }
  function renderMap() {
    const el = $('#map'); const d = S();
    const total = TT.Save.totalStars(), max = TT.WORLDS.reduce((s, W) => s + W.levels * 3, 0);
    const W = TT.WORLDS[UI.selWorld] || TT.WORLDS[0], un = worldUnlocked(W), ws = worldStars(W), done = worldDone(W);
    const doneN = TT.WORLDS.filter(worldDone).length;
    const pins = TT.WORLDS.map((w, i) => { const pp = proj(w.ll[0], w.ll[1]), u = worldUnlocked(w), dn = worldDone(w); return `<button class="pin2 ${i === UI.selWorld ? 'sel' : ''} ${u ? '' : 'locked'} ${dn ? 'done' : ''} ${w.id === 'mars' ? 'mars' : ''}" data-w="${i}" style="left:${(pp[0] * 100).toFixed(2)}%;top:${(pp[1] * 100).toFixed(2)}%" title="${esc(t(w.name, w.en))}"><span class="pi">${CICONS[w.id] || WICONS[w.theme]}</span>${dn ? '<i class="ok">✓</i>' : u ? '' : '<i class="lk">🔒</i>'}<span class="pl">${esc(t(w.name, w.en))}</span></button>`; }).join('');
    const chips = TT.WORLDS.map((w, i) => { const u = worldUnlocked(w), dn = worldDone(w); return `<button class="cchip ${i === UI.selWorld ? 'sel' : ''} ${u ? '' : 'locked'} ${dn ? 'done' : ''}" data-w="${i}">${CICONS[w.id] || ''} ${esc(t(w.name, w.en))}${dn ? ' ✓' : u ? '' : ' 🔒'}</button>`; }).join('');
    const feats = []; const F = W.features || {};
    if (F.lights) feats.push('🚦 ' + t('إشارات', 'Lights')); if (F.radars) feats.push('📸 ' + t('رادارات', 'Radars')); if (F.checkpoints) feats.push('👮 ' + t('كماين', 'Checkpoints'));
    if (F.blockers) feats.push('🚗 ' + t('ركنة صف تاني', 'Double parking')); if (F.storms) feats.push('🌪️ ' + t('عواصف', 'Storms')); if (F.tunnels) feats.push('🚇 ' + t('أنفاق', 'Tunnels'));
    if (F.villageZones) feats.push('🐄 ' + t('قرى وبهايم', 'Villages')); if (W.gravity < 9) feats.push('🪐 ' + t('جاذبية ضعيفة', 'Low gravity'));
    if (W.id !== 'mars') feats.push('🌉 ' + t('كباري وزحمة', 'Bridges & jams'));
    const cur = currentLevel(W), STEP = 62, ROADH = 118;
    const pts = []; for (let i = 0; i < W.levels; i++) pts.push([36 + i * STEP, ROADH / 2 + Math.sin(i * 0.85) * 30]);
    const path = pts.map((p, i) => (i ? 'L' : 'M') + p[0] + ' ' + p[1]).join(' ');
    let nodes = '';
    pts.forEach((p, i) => {
      const key = W.id + '-' + i, st = d.stars[key] || 0, rt = (d.rates || {})[key] || 0, open = levelOpen(W, i);
      nodes += `<button class="rnode ${open ? '' : 'locked'} ${st ? 'done' : ''} ${i === cur && open ? 'cur' : ''} ${(i + 1) % 10 === 0 ? 'boss' : ''}" data-l="${i}" ${open ? '' : 'disabled'} style="left:${p[0]}px;top:${p[1]}px"><b>${open ? i + 1 : '🔒'}</b>${open ? `<span class="st">${'★'.repeat(st)}<i>${'★'.repeat(3 - st)}</i></span>` : ''}${rt ? `<em class="rt">${rt}/5</em>` : ''}</button>`;
    });
    el.innerHTML = header('🗺️ ' + t('خريطة مصر', 'Map of Egypt'), 'menu', 'map') + `
      <div class="map3">
        <div class="egypt2" id="egypt2"><div class="eg-zoom" id="egZoom"><canvas id="egyptMap"></canvas>${pins}</div><div class="eg-ctl"><button data-z="in" aria-label="zoom in">＋</button><button data-z="out" aria-label="zoom out">－</button><button data-z="reset" aria-label="reset">⤢</button></div><div class="map-total">⭐ ${total}/${max} · ✓ ${doneN}/${TT.WORLDS.length}</div></div>
        <div class="wpanel2 theme-${W.theme}">
          <div class="city-chips" id="cityChips">${chips}</div>
          <div class="wp-head"><span class="wp-ic">${CICONS[W.id] || WICONS[W.theme]}</span><div><h3>${esc(t(W.name, W.en))} ${done ? `<span class="done-tag">✓ ${t('خلّصتها', 'Completed')}</span>` : ''}</h3><div class="wp-prog"><i style="width:${ws / (W.levels * 3) * 100}%"></i></div><small>⭐ ${ws}/${W.levels * 3} · ${W.levels} ${t('مرحلة', 'levels')}${done ? ' · ' + t('تقدر تلعبها تاني وتحسّن نجومك', 'replay to improve your stars') : ''}</small></div>
            ${un ? `<button class="btn gold go-cur" id="goCur">▶ ${t('مرحلة', 'Level')} ${cur + 1}</button>` : ''}</div>
          <div class="feats">${feats.map(f => `<span>${f}</span>`).join('')}</div>
          <div class="mode-pick"><div class="seg"><button data-mode="taxi" class="${d.settings.mode !== 'vendor' ? 'sel' : ''}">🧍 ${t('ركاب', 'Taxi')}</button><button data-mode="vendor" class="${d.settings.mode === 'vendor' ? 'sel' : ''}">🛒 ${t('بيّاع', 'Vendor')}</button></div>
            ${d.settings.mode === 'vendor' ? `<div class="goods">${Object.entries(TT.GOODS).map(([id, g]) => `<button data-goods="${id}" class="${(d.settings.goods || 'potato') === id ? 'sel' : ''}"><span>${g.icon}</span><b>${t(g.name, g.en)}</b><small>${TT.CART_TIERS[(d.carts || {})[id] || 0].icon} ${t(TT.CART_TIERS[(d.carts || {})[id] || 0].name, TT.CART_TIERS[(d.carts || {})[id] || 0].en)}</small></button>`).join('')}</div>` : ''}</div>
          ${un ? '' : `<div class="lock-msg">🔒 ${t('اجمع', 'Collect')} ${W.unlockStars} ⭐ ${t('عشان تفتح المنطقة دي (معاك', 'to unlock (you have')} ${total})${W.needsSpace ? '<br>🚀 ' + t('ومحتاج "توكتوك الفضاء" من المرآب', 'and the Space Tuk') : ''}<br><small>${t('أو استخدم كود الفتح من الإعدادات', 'or use an unlock code in Settings')}</small></div>`}
          <div class="road-scroll" id="roadScroll"><div class="road" style="width:${pts.length * STEP + 60}px;height:${ROADH}px">
            <svg width="${pts.length * STEP + 60}" height="${ROADH}"><path d="${path}" class="road-base"/><path d="${path}" class="road-line"/></svg>${nodes}
            <div class="road-tuk" style="left:${pts[cur][0]}px;top:${pts[cur][1] - 34}px">🛺</div></div></div>
        </div>
      </div>`;
    bindGo(el);
    requestAnimationFrame(() => {
      const cv = $('#egyptMap'); if (cv) { drawEgypt(cv); UI.mapZoomInit(); }
      const rs = $('#roadScroll'); if (rs) { const target = pts[cur][0] - rs.clientWidth / 2; rs.scrollLeft = TT.lang === 'ar' && getComputedStyle(rs).direction === 'rtl' ? -(pts.length * STEP + 60 - rs.clientWidth - target) : target; }
      const cc = $('#cityChips .sel'); if (cc) cc.scrollIntoView({ block: 'nearest', inline: 'center' });
    });
    el.querySelectorAll('[data-mode]').forEach(b => b.onclick = () => { d.settings.mode = b.dataset.mode; TT.Save.write(); TT.Audio.play('click'); renderMap(); });
    el.querySelectorAll('[data-goods]').forEach(b => b.onclick = () => { d.settings.goods = b.dataset.goods; TT.Save.write(); TT.Audio.play('click'); renderMap(); });
    el.querySelectorAll('.pin2, .cchip').forEach(b => b.onclick = () => { UI.selWorld = +b.dataset.w; TT.Audio.play('click'); renderMap(); });
    el.querySelectorAll('.rnode:not(.locked)').forEach(b => b.onclick = () => tryStart(UI.selWorld, +b.dataset.l));
    const gc = $('#goCur'); if (gc) gc.onclick = () => tryStart(UI.selWorld, cur);
  }
  function tryStart(wi, li) {
    const W = TT.WORLDS[wi], d = S();
    if (W.needsSpace) {
      const sp = TT.TUKTUKS.filter(m => m.space).map(m => m.id).find(id => d.ownedTuktuks.includes(id));
      if (!sp) { modalMsg('🚀 ' + t('المريخ محتاج توكتوك فضاء', 'Mars needs a space tuk'), t('اشتري "توكتوك الفضاء" من المرآب الأول.', 'Buy the Space Tuk in the garage first.'), [[t('روح المرآب', 'Garage'), () => { closeModal(); UI.garageTab = 'buy'; go('garage'); }], [t('تمام', 'OK'), closeModal]]); return; }
      d.tuktuk = sp;
    } else if (TT.Save.model().space && !W.needsSpace) { /* space tuk works anywhere */ }
    if (d.settings.mode === 'vendor' && (TT.Save.model().kind || 'tuktuk') !== 'tuktuk') {
      const tk = TT.TUKTUKS.find(m => (m.kind || 'tuktuk') === 'tuktuk' && !m.space && d.ownedTuktuks.includes(m.id)); d.tuktuk = tk ? tk.id : 'basic';
      toast(t('عربية البيع بتتركّب على التوكتوك 🛺', 'The vendor cart mounts on a tuk tuk 🛺'), 'warn');
    }
    if ((d.license || { left: 5 }).left <= 0) { UI.openLicense(() => tryStart(wi, li)); return; }
    const dm = TT.Save.veh().damage, worst = Math.max(dm.engine, dm.body);
    if (worst >= 0.82 && !UI._riskOk) {
      let c = 0; for (const k in dm) c += Math.ceil(dm[k] * REPAIR[k]);
      const b = openModal(`<div class="warn-box"><div class="wb-ic">🔥</div><h3>${t('المركبة حالتها حرجة', 'Your vehicle is in critical shape')}</h3>
        <p>${t('المحرك أو الهيكل متبهدل. لو خبطت خبطة كمان هتفرقع والرحلة هتخلص.', 'Engine or body is wrecked. One more hit and it explodes.')}</p>
        <div class="row center"><button class="btn gold" id="wbFix">🔧 ${t('صلّحها دلوقتي', 'Repair now')} — 💰 ${fmt(c)}</button>${S().money < c ? `<button class="btn debt" id="wbDebt">🤝 ${t('صلّحها بالدين', 'Repair on credit')}</button>` : ''}<button class="btn" id="wbGo">${t('اطلع على مسؤوليتي', 'Go anyway')}</button></div></div>`, 'small', 'warn');
      b.querySelector('#wbFix').onclick = () => { if (!spend(c)) return; TT.Save.ledger(t('صيانة شاملة', 'Full repair'), -c, 'repair'); for (const k in dm) dm[k] = 0; TT.Save.veh().roofOff = false; TT.Save.write(); TT.Audio.play('fuel'); closeModal(); tryStart(wi, li); };
      const wd = b.querySelector('#wbDebt'); if (wd) wd.onclick = () => { if (!TT.Save.repairOnDebt(c, t('صيانة شاملة', 'Full repair'))) { toast(t('الأسطى مش هيدّيك دين أكتر من ', 'Max credit ') + fmt(TT.Save.debtLimit()), 'bad'); return; } for (const k in dm) dm[k] = 0; TT.Save.veh().roofOff = false; TT.Save.write(); TT.Audio.play('fuel'); closeModal(); tryStart(wi, li); };
      b.querySelector('#wbGo').onclick = () => { closeModal(); UI._riskOk = true; tryStart(wi, li); UI._riskOk = false; };
      return;
    }
    if (d.snapshot && (d.snapshot.world !== wi || d.snapshot.level !== li)) d.snapshot = null;
    TT.Audio.init();
    TT.Game.startLevel(wi, li, false);
  }

  /* ---------------- GARAGE ---------------- */
  UI.garageTab = 'upgrade';
  const upCost = (u, lvl) => Math.round(u.base * Math.pow(lvl + 1, 1.35) / 10) * 10;
  const REPAIR = { engine: 500, tires: 250, suspension: 350, brakes: 200, body: 300 };
  const PART_NAME = { engine: ['المحرك', 'Engine'], tires: ['الإطارات', 'Tires'], suspension: ['التعليق', 'Suspension'], brakes: ['الفرامل', 'Brakes'], body: ['الهيكل', 'Body'] };
  function spend(cost) { if (S().money < cost) { TT.Audio.play('error'); toast(t('الفلوس مش مكفية!', 'Not enough money!'), 'bad'); return false; } return true; }
  function renderGarage() {
    const el = $('#garage'), d = S(), tab = UI.garageTab, veh = TT.Save.veh(), m = TT.Save.model();
    const tabs = [['upgrade', '🔧 ' + t('تطوير', 'Upgrades')], ['acc', '🔊 ' + t('اكسسوارات', 'Accessories')], ['carts', '🛒 ' + t('عربيات البيع', 'Vendor carts')], ['look', '🎨 ' + t('المظهر', 'Paint & decals')], ['wash', '🧽 ' + t('المغسلة', 'Car wash')], ['repair', '🛠️ ' + t('الصيانة', 'Repairs')], ['tires', '🛞 ' + t('الإطارات', 'Tires')], ['buy', '🛵 ' + t('شراء مركبة', 'Buy vehicle')]];
    d.accessories = d.accessories || []; d.accOn = d.accOn || {};
    let body = '';
    if (tab === 'upgrade') {
      body = '<div class="cards">' + TT.UPGRADES.map(u => {
        const lvl = d.upgrades[u.id], max = lvl >= 5, cost = upCost(u, lvl);
        const eff = { engine: t('+6% سرعة · +12% سحب', '+6% speed · +12% pull'), speed: t('+6% سرعة قصوى', '+6% top speed'), brakes: t('+7% فرملة', '+7% braking'), suspension: t('ثبات أكتر في المطبات', 'steadier over bumps'), tires: t('+5% تماسك', '+5% grip'), fuel: t('-8% استهلاك', '-8% consumption'), lights: t('كشافات أبعد', 'longer headlights') }[u.id] || '';
        return `<div class="card up"><div class="ic">${u.icon}</div><div class="nm">${t(u.name, u.en)}</div><div class="eff">${eff}</div><div class="lv">${t('المستوى', 'Level')} ${lvl}/5 <span class="mini-pips">${'●'.repeat(lvl)}<i>${'●'.repeat(5 - lvl)}</i></span></div>
          <div class="pips">${[0, 1, 2, 3, 4].map(i => `<i class="${i < lvl ? 'on' : ''}"></i>`).join('')}</div>
          <button class="btn buy ${max ? 'off' : ''}" data-up="${u.id}" ${max ? 'disabled' : ''}>${max ? t('أقصى مستوى', 'MAX') : '💰 ' + fmt(cost)}</button></div>`;
      }).join('') + '</div>';
    } else if (tab === 'look') {
      const cur = veh.paint || '';
      body = `<h4>${t('اللون', 'Paint')} — ${t(m.name, m.en)}</h4><div class="swatches"><button class="sw ${!cur ? 'sel' : ''}" data-paint="" style="background:${m.color}">${!cur ? '✓' : t('أصلي', 'Stock')}</button>` + TT.PAINTS.map(p => { const own = d.ownedPaints.includes(p.id); return `<button class="sw ${cur === p.id ? 'sel' : ''}" data-paint="${p.id}" style="background:${p.c}">${own ? (cur === p.id ? '✓' : '') : '💰' + p.price}</button>`; }).join('') + '</div>';
      body += `<h4>${t('الملصقات والزينة', 'Decals')}</h4><div class="cards">` + TT.DECALS.map(p => { const own = d.ownedDecals.includes(p.id); return `<div class="card small ${d.decal === p.id ? 'sel' : ''}"><div class="nm">${p.name}</div><button class="btn buy" data-decal="${p.id}">${own ? (d.decal === p.id ? t('مركّب ✓', 'Equipped ✓') : t('ركّب', 'Equip')) : '💰 ' + p.price}</button></div>`; }).join('') + '</div>';
    } else if (tab === 'acc') {
      body = '<div class="cards">' + TT.ACCESSORIES.map(a => { const own = d.accessories.includes(a.id), on = own && d.accOn[a.id] !== false;
        return `<div class="card ${on ? 'sel' : ''}"><div class="ic">${a.icon}</div><div class="nm">${t(a.name, a.en)}</div><div class="lv">${a.desc}</div>
          <button class="btn buy" data-acc="${a.id}">${own ? (on ? t('شغّال ✓ — اقفله', 'On ✓ — turn off') : t('شغّله', 'Turn on')) : '💰 ' + fmt(a.price)}</button></div>`; }).join('') + '</div>';
    } else if (tab === 'carts') {
      d.carts = d.carts || {};
      body = '<div class="cards carts">' + Object.keys(TT.GOODS).map(gid => {
        const g = TT.GOODS[gid], tier = d.carts[gid] || 0, TR = TT.CART_TIERS[tier], nx = TT.CART_TIERS[tier + 1], sel = d.settings.goods === gid;
        return `<div class="card cart ${sel ? 'sel' : ''}"><div class="pv" data-cart="${gid}" data-tier="${tier}"></div>
          <div class="nm">${g.icon} ${t(TT.CART_NAMES[gid][0], TT.CART_NAMES[gid][1])}</div>
          <div class="tiers">${TT.CART_TIERS.map((x, i) => `<span class="${i <= tier ? 'on' : ''} ${i === tier ? 'cur' : ''}">${x.icon} ${t(x.name, x.en)}</span>`).join('')}</div>
          <div class="lv">💵 ${Math.round(g.price * TR.priceMul)} ${t('ج للحتة', 'EGP each')} · 📦 ×${TR.stock} · 👥 ×${TR.attract}</div>
          <div class="row">${nx ? `<button class="btn buy gold" data-cartup="${gid}">⬆️ ${t(nx.name, nx.en)} — 💰 ${fmt(nx.price)}</button>` : `<button class="btn buy off" disabled>${t('أعلى مستوى ✓', 'Max ✓')}</button>`}
          <button class="btn buy ${sel && d.settings.mode === 'vendor' ? 'off' : ''}" data-cartuse="${gid}">${sel && d.settings.mode === 'vendor' ? t('مختارة ✓', 'Selected ✓') : t('اشتغل بيها', 'Use it')}</button></div></div>`;
      }).join('') + '</div>';
    } else if (tab === 'wash') {
      const dirt = Math.round((veh.dirt || 0) * 100), wax = Math.round((veh.wax || 0) * 100);
      body = `<div class="wash-box"><div class="dirt-meter">🧼 ${t('درجة الوساخة', 'Dirt')}: <b>${dirt}%</b><div class="meter"><i style="width:${dirt}%;background:#8d6e63"></i></div>${wax ? `✨ ${t('تلميع', 'Wax')}: ${wax}%` : ''}</div>
        <div class="row center"><button class="btn gold" data-wash="basic" ${dirt ? '' : 'disabled'}>🚿 ${t('غسيل', 'Wash')} — 💰 40</button><button class="btn" data-wash="wax">✨ ${t('غسيل + تلميع (بيقلل الوساخة)', 'Wash + wax (slows dirt)')} — 💰 90</button></div></div>`;
    } else if (tab === 'repair') {
      const dm = veh.damage; let all = 0;
      body = '<div class="cards">' + Object.keys(dm).map(k => {
        const c = Math.ceil(dm[k] * REPAIR[k]); all += c; const pct = Math.round((1 - dm[k]) * 100);
        return `<div class="card up"><div class="ic">${{ engine: '⚙️', tires: '🛞', suspension: '🔩', brakes: '🛑', body: '🚪' }[k]}</div><div class="nm">${t(PART_NAME[k][0], PART_NAME[k][1])}</div><div class="meter"><i style="width:${pct}%;background:${pct > 65 ? '#43a047' : pct > 35 ? '#f9a825' : '#e53935'}"></i></div><div class="lv">${pct}%</div>
          <button class="btn buy ${c ? '' : 'off'}" data-fix="${k}" ${c ? '' : 'disabled'}>${c ? '🔧 ' + fmt(c) : t('سليم', 'OK')}</button></div>`;
      }).join('') + '</div>';
      const need = Math.ceil((TT.vehParams().tank - veh.fuel) * 1.0);
      body += `${d.debt > 0 ? `<div class="debt-box">🧾 ${t('عليك دين للأسطى', 'You owe the mechanic')} <b>${fmt(d.debt)} ${t('ج', 'EGP')}</b> <small>${t('بيتخصم 25% من أي فلوس تكسبها', '25% of earnings go to it')}</small><button class="btn" id="gPayDebt">💳 ${t('سدّد', 'Pay')}</button></div>` : ''}<div class="row center"><button class="btn gold" data-fixall="1" ${all ? '' : 'disabled'}>🔧 ${t('صلّح الكل', 'Repair all')} — 💰 ${fmt(all)}</button>${all && d.money < all ? `<button class="btn debt" id="gFixDebt">🤝 ${t('صلّح بالدين', 'Repair on credit')}</button>` : ''}
        <button class="btn" id="gLic">🏛️ ${t('قسم المرور', 'Traffic unit')} (🪪 ${Math.max(0, (d.license || { left: 5 }).left)} · 🧾 ${fmt(TT.pendingTotal())})</button>
        <button class="btn" id="gJerry">🛢️ ${t('جركن احتياطي', 'Spare fuel can')} — 💰 ${TT.JERRY.priceGarage} (${t('معاك', 'have')} ${d.jerry || 0})</button>
        <button class="btn" data-fuel="1" ${need > 0 ? '' : 'disabled'}>⛽ ${t('فوّل التانك', 'Fill tank')} (${Math.round(veh.fuel / TT.vehParams().tank * 100)}%) — 💰 ${fmt(need)}</button></div>`;
    } else if (tab === 'tires') {
      body = '<div class="cards">' + TT.TIRE_TYPES.map(p => { const own = d.ownedTires.includes(p.id); return `<div class="card ${d.tireType === p.id ? 'sel' : ''}"><div class="ic">🛞</div><div class="nm">${t(p.name, p.en)}</div>
        <div class="lv">${t('رمل', 'Sand')} ${Math.round(p.sand * 100)}% · ${t('زراعي', 'Farm')} ${Math.round(p.farm * 100)}%${p.space ? ' · 🚀' : ''}</div>
        <button class="btn buy" data-tire="${p.id}">${own ? (d.tireType === p.id ? t('مركّبة ✓', 'Equipped ✓') : t('ركّب', 'Equip')) : '💰 ' + fmt(p.price)}</button></div>`; }).join('') + '</div>';
    } else if (tab === 'buy') {
      const lvl = TT.Save.driverLevel(), maxV = Math.max(...TT.TUKTUKS.map(x => x.vmax)), maxP = Math.max(...TT.TUKTUKS.map(x => x.power));
      const groups = [['🛺 ' + t('توكتوك', 'Tuk tuks'), mm => (mm.kind || 'tuktuk') === 'tuktuk'], ['🛵 ' + t('موتوسيكلات وعجل', 'Bikes & scooters'), mm => ['scooter', 'bike', 'skate'].includes(mm.kind)], ['🚐 ' + t('ميكروباص', 'Microbus'), mm => mm.kind === 'microbus'], ['🏎️ ' + t('عربيات سباق — غالية!', 'Race cars — pricey!'), mm => mm.kind === 'sport']];
      const gi = groups.findIndex(gg => gg[1](m)); if (UI.buyCat == null) UI.buyCat = Math.max(0, gi);
      body = `<div class="buy-cats">${groups.map(([gname], i) => `<button class="bc ${UI.buyCat === i ? 'sel' : ''}" data-bcat="${i}">${gname}</button>`).join('')}</div>` + groups.filter((gg, i) => i === UI.buyCat).map(([gname, f]) => `<div class="cards veh">` + TT.TUKTUKS.filter(f).map(mm => { const own = d.ownedTuktuks.includes(mm.id), locked = lvl < mm.req;
        const bar = (lab, v) => `<div class="sbar"><span>${lab}</span><i><b style="width:${Math.round(Math.min(1, v) * 100)}%"></b></i></div>`;
        return `<div class="card tuk ${d.tuktuk === mm.id ? 'sel' : ''} ${mm.kind === 'sport' ? 'lux' : ''}">${!own ? `<span class="price">${locked ? '🔒 ' + t('مستوى', 'Lv') + ' ' + mm.req : '💰 ' + fmt(mm.price)}</span>` : d.tuktuk === mm.id ? `<span class="price own">✓ ${t('بتاعتك', 'Yours')}</span>` : ''}<div class="pv" data-pv="${mm.id}"></div><div class="nm">${t(mm.name, mm.en)}</div>
        <div class="sbars">${bar('⏱️', mm.vmax / maxV)}${bar('⚡', mm.power / maxP)}<div class="lv">👥 ${mm.seats} · ${Math.round(mm.vmax * 3.6)} ${t('كم/س', 'km/h')} · ${mm.fuel === false ? t('من غير بنزين', 'no fuel') : '⛽ ' + mm.tank}</div></div>
        <button class="btn buy ${locked && !own ? 'off' : ''} ${own && d.tuktuk === mm.id ? 'cur' : ''}" data-tuk="${mm.id}" ${locked && !own ? 'disabled' : ''}>${own ? (d.tuktuk === mm.id ? t('مستخدمة ✓', 'Selected ✓') : t('استخدمها', 'Use')) : locked ? '🔒 ' + t('محتاج مستوى', 'Needs level') + ' ' + mm.req : t('اشتري', 'Buy') + ' — ' + fmt(mm.price)}</button></div>`; }).join('') + '</div>').join('');
    }
    const vp = TT.vehParams(), cond = Math.round(TT.conditionPct() * 100), fuelP = Math.round(veh.fuel / vp.tank * 100), maxV = Math.max(...TT.TUKTUKS.map(x => x.vmax)) * 1.35;
    const sb = (ic, lab, v, txt) => `<div class="gstat"><span>${ic} ${lab}</span><i><b style="width:${Math.round(Math.max(0.04, Math.min(1, v)) * 100)}%"></b></i><em>${txt}</em></div>`;
    const side = tab === 'carts' ? `<div class="gs-name">🛒 ${t('عربيات البيع', 'Vendor carts')}</div><p class="gs-note">${t('اختار العربية وطوّرها', 'Pick a cart and upgrade it')}</p>` : `<div class="gs-name">${t(m.name, m.en)}${m.race ? ' <span class="tag">🏁 ' + t('سباق', 'Race') + '</span>' : ''}</div>
      <div class="gstats">${sb('⏱️', t('السرعة', 'Speed'), vp.vmax / maxV, Math.round(vp.vmax * 3.6) + ' ' + t('كم/س', 'km/h'))}${sb('⚡', t('السحب', 'Pull'), vp.accel / 14, vp.accel.toFixed(1))}${sb('🛑', t('الفرامل', 'Brakes'), vp.brake / 12, vp.brake.toFixed(1))}${sb('🛞', t('التماسك', 'Grip'), vp.grip / 1.4, Math.round(vp.grip * 100) + '%')}${sb('🔧', t('الحالة', 'Condition'), cond / 100, cond + '%')}${vp.human ? '' : sb('⛽', t('البنزين', 'Fuel'), fuelP / 100, fuelP + '%')}</div>`;
    const TT_TITLES = { upgrade: t('طوّر مركبتك — كل جزء ليه 5 مستويات', 'Upgrade your ride — 5 levels each'), acc: t('اكسسوارات بتظهر على المركبة', 'Accessories shown on your vehicle'), carts: t('عربية لكل بضاعة: خشب ← ستانلس ← محل متنقل', 'One cart per good: wood → steel → shop'), look: t('الدهان والملصقات', 'Paint & decals'), wash: t('نضّف المركبة', 'Clean your vehicle'), repair: t('صلّح وجدّد الرخصة', 'Repair & renew license'), tires: t('إطارات لكل أرض', 'Tires for every terrain'), buy: t('توكتوك، موتوسيكلات، ميكروباص وعربيات سباق', 'Tuk tuks, bikes, microbus & race cars') };
    el.innerHTML = header('🔧 ' + t('ورشة التوكتوك', 'Tuk Tuk Workshop'), 'menu', 'garage') + `
      <div class="gar"><nav class="gar-tabs">${tabs.map(([id, n]) => `<button class="tab ${tab === id ? 'sel' : ''}" data-tab="${id}">${n}</button>`).join('')}</nav>
      <aside class="gar-side"><div class="preview" id="gPrev"></div>${side}</aside>
      <main class="gar-main" id="garMain"><div class="gar-title">${(tabs.find(x => x[0] === tab) || [, ''])[1]}<small>${TT_TITLES[tab] || ''}</small></div>${body}</main></div>`;
    if (tab === 'carts') { const gid = d.settings.goods || 'potato'; $('#gPrev').appendChild(cartCanvas(gid, (d.carts || {})[gid] || 0, 260, 165)); }
    else $('#gPrev').appendChild(tukCanvas(260, 175, { damage: 1 - TT.conditionPct(), driver: false }));
    const gm = $('#garMain'); if (gm) { if (UI._garTab === tab) gm.scrollTop = UI._garScroll || 0; gm.onscroll = () => { UI._garScroll = gm.scrollTop; }; UI._garTab = tab; }
    el.querySelectorAll('[data-cart]').forEach(p => p.appendChild(cartCanvas(p.dataset.cart, +p.dataset.tier, 120, 74)));
    el.querySelectorAll('[data-pv]').forEach(p => p.appendChild(tukCanvas(120, 62, { model: TT.TUKTUKS.find(x => x.id === p.dataset.pv), decal: 'none' })));
    bindGo(el);
    el.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { UI.garageTab = b.dataset.tab; renderGarage(); });
    el.querySelectorAll('[data-bcat]').forEach(b => b.onclick = () => { UI.buyCat = +b.dataset.bcat; TT.Audio.play('click'); renderGarage(); });
    const act = (sel, fn) => el.querySelectorAll(sel).forEach(b => b.onclick = () => { fn(b); TT.Save.write(); renderGarage(); });
    act('[data-up]', b => { const u = TT.UPGRADES.find(x => x.id === b.dataset.up), lvl = d.upgrades[u.id]; const c = upCost(u, lvl); if (lvl < 5 && spend(c)) { TT.Save.ledger(t('تطوير ', 'Upgrade ') + t(u.name, u.en), -c, 'upgrade'); d.upgrades[u.id]++; TT.Audio.play('cash'); } });
    act('[data-cartup]', b => { const gid = b.dataset.cartup, tier = d.carts[gid] || 0, nx = TT.CART_TIERS[tier + 1]; if (nx && spend(nx.price)) { TT.Save.ledger(t('تطوير ', 'Upgrade ') + t(TT.CART_NAMES[gid][0], TT.CART_NAMES[gid][1]) + ' — ' + t(nx.name, nx.en), -nx.price, 'upgrade'); d.carts[gid] = tier + 1; d.settings.goods = gid; TT.Audio.play('cash'); toast(t('العربية اتطورت لـ ', 'Cart upgraded to ') + t(nx.name, nx.en) + ' ' + nx.icon, 'good'); } });
    act('[data-cartuse]', b => { d.settings.goods = b.dataset.cartuse; d.settings.mode = 'vendor'; TT.Audio.play('click'); });
    const fd = $('#gFixDebt'); if (fd) fd.onclick = () => { let c = 0; for (const k in veh.damage) c += Math.ceil(veh.damage[k] * REPAIR[k]); if (!TT.Save.repairOnDebt(c, t('صيانة شاملة', 'Full repair'))) { toast(t('الأسطى مش هيدّيك دين أكتر من ', 'Mechanic won\'t lend more than ') + fmt(TT.Save.debtLimit()) + t(' ج', ' EGP'), 'bad'); return; } for (const k in veh.damage) veh.damage[k] = 0; veh.roofOff = false; TT.Save.write(); TT.Audio.play('fuel'); toast(t('🤝 الأسطى صلّحها وكتبها عليك', '🤝 Repaired on credit'), 'good'); renderGarage(); };
    const pd = $('#gPayDebt'); if (pd) pd.onclick = () => { const pay = Math.min(d.debt, Math.max(0, d.money)); if (!pay) { toast(t('مفيش فلوس معاك', 'No money'), 'bad'); return; } d.money -= pay; d.debt -= pay; d.ledger.unshift({ t: Date.now(), label: t('سداد دين الورشة', 'Debt payment'), amount: -pay, kind: 'repair' }); TT.Save.write(); TT.Audio.play('cash'); renderGarage(); };
    const gl = $('#gLic'); if (gl) gl.onclick = () => UI.openLicense(() => renderGarage());
    const gj = $('#gJerry'); if (gj) gj.onclick = () => { TT.buyJerry(TT.JERRY.priceGarage); renderGarage(); };
    act('[data-acc]', b => { const a = TT.ACCESSORIES.find(x => x.id === b.dataset.acc); if (d.accessories.includes(a.id)) d.accOn[a.id] = d.accOn[a.id] === false; else if (spend(a.price)) { TT.Save.ledger(t('اكسسوار: ', 'Accessory: ') + t(a.name, a.en), -a.price, 'upgrade'); d.accessories.push(a.id); d.accOn[a.id] = true; TT.Audio.play('cash'); } });
    el.querySelectorAll('[data-wash]').forEach(b => b.onclick = () => { const wax = b.dataset.wash === 'wax', cost = wax ? 90 : 40; if (!spend(cost)) return; TT.Save.ledger(wax ? t('غسيل وتلميع', 'Wash & wax') : t('غسيل', 'Wash'), -cost, 'repair'); TT.Audio.init(); TT.Audio.play('wash'); const pv = $('#gPrev'); pv.classList.add('washing'); setTimeout(() => { veh.dirt = 0; if (wax) veh.wax = 1; TT.Save.write(); renderGarage(); toast(t('العربية بتلمع ✨', 'Sparkling clean ✨'), 'good'); }, 1400); });
    act('[data-paint]', b => { if (!b.dataset.paint) { veh.paint = null; return; } const p = TT.PAINTS.find(x => x.id === b.dataset.paint); if (d.ownedPaints.includes(p.id)) veh.paint = p.id; else if (spend(p.price)) { TT.Save.ledger(t('دهان', 'Paint'), -p.price, 'upgrade'); d.ownedPaints.push(p.id); veh.paint = p.id; } });
    act('[data-decal]', b => { const p = TT.DECALS.find(x => x.id === b.dataset.decal); if (d.ownedDecals.includes(p.id)) d.decal = p.id; else if (spend(p.price)) { TT.Save.ledger(t('ملصق ', 'Decal ') + p.name, -p.price, 'upgrade'); d.ownedDecals.push(p.id); d.decal = p.id; } });
    act('[data-fix]', b => { const k = b.dataset.fix, c = Math.ceil(veh.damage[k] * REPAIR[k]); if (spend(c)) { TT.Save.ledger(t('إصلاح ', 'Repair ') + t(PART_NAME[k][0], PART_NAME[k][1]), -c, 'repair'); veh.damage[k] = 0; if (k === 'body') veh.roofOff = false; TT.Audio.play('fuel'); } });
    act('[data-fixall]', () => { let c = 0; for (const k in veh.damage) c += Math.ceil(veh.damage[k] * REPAIR[k]); if (c && spend(c)) { TT.Save.ledger(t('صيانة شاملة', 'Full repair'), -c, 'repair'); for (const k in veh.damage) veh.damage[k] = 0; veh.roofOff = false; TT.Audio.play('fuel'); } });
    act('[data-fuel]', () => { const need = Math.ceil(TT.vehParams().tank - veh.fuel); if (need > 0 && spend(need)) { TT.Save.ledger(t('بنزين من الورشة', 'Fuel at garage'), -need, 'fuel'); veh.fuel = TT.vehParams().tank; TT.Audio.play('fuel'); } });
    act('[data-tire]', b => { const p = TT.TIRE_TYPES.find(x => x.id === b.dataset.tire); if (d.ownedTires.includes(p.id)) d.tireType = p.id; else if (spend(p.price)) { TT.Save.ledger(t(p.name, p.en), -p.price, 'upgrade'); d.ownedTires.push(p.id); d.tireType = p.id; } });
    act('[data-tuk]', b => { const mm = TT.TUKTUKS.find(x => x.id === b.dataset.tuk); if (d.ownedTuktuks.includes(mm.id)) d.tuktuk = mm.id; else if (spend(mm.price)) { TT.Save.ledger(t('شراء ', 'Bought ') + t(mm.name, mm.en), -mm.price, 'upgrade'); d.ownedTuktuks.push(mm.id); d.vehicles[mm.id] = { fuel: mm.tank, damage: { engine: 0, tires: 0, suspension: 0, brakes: 0, body: 0 } }; d.tuktuk = mm.id; TT.Audio.play('win'); } });
  }

  /* ---------------- DRIVERS ---------------- */
  function renderDrivers() {
    const el = $('#drivers'), d = S(); d.ownedDrivers = d.ownedDrivers || ['sayed', 'hamo', 'adel']; d.ownedOutfits = d.ownedOutfits || ['default']; d.outfitOn = d.outfitOn || {};
    const sel = TT.DRIVERS.find(x => x.id === UI.drvView) || TT.DRIVERS.find(x => x.id === d.driver) || TT.DRIVERS[0]; UI.drvView = sel.id;
    const perkTxt = p => [p.sat ? '😊 ' + t('رضا الركاب', 'Rider mood') + ' +' + p.sat : '', p.brake ? '🛑 ' + t('فرامل', 'Brakes') + ' +' + Math.round(p.brake * 100) + '%' : '', p.dmg ? '🛡️ ' + t('ضرر أقل', 'Less damage') + ' ' + Math.round((1 - p.dmg) * 100) + '%' : '', p.fuel ? '⛽ ' + t('بنزين أقل', 'Less fuel') + ' ' + Math.round((1 - p.fuel) * 100) + '%' : '', p.tips ? '🎁 ' + t('بقشيش', 'Tips') + ' ×' + p.tips : '', p.race ? '🏁 ' + t('المنافسين أبطأ', 'Slower rivals') : ''].filter(Boolean).join(' · ');
    const cards = TT.DRIVERS.map(dr => { const own = d.ownedDrivers.includes(dr.id), cur = d.driver === dr.id;
      return `<button class="dcard ${cur ? 'cur' : ''} ${sel.id === dr.id ? 'sel' : ''} ${own ? '' : 'locked'}" data-view="${dr.id}"><div class="pv" data-por="${dr.id}"></div><div class="dc-t"><b>${t(dr.name, dr.en)}</b><small>${cur ? '✓ ' + t('شغّال', 'Active') : own ? t('عندك', 'Owned') : '💰 ' + fmt(dr.price)}</small></div></button>`; }).join('');
    const own = d.ownedDrivers.includes(sel.id), curOut = d.outfitOn[sel.id] || 'default';
    const outfits = TT.OUTFITS.map(o => { const has = d.ownedOutfits.includes(o.id), on = curOut === o.id;
      return `<button class="ocard ${on ? 'on' : ''}" data-out="${o.id}"><span>${o.icon}</span><b>${t(o.name, o.en)}</b><small>${on ? '✓ ' + t('لابسه', 'Wearing') : has ? t('البس', 'Wear') : '💰 ' + fmt(o.price)}</small></button>`; }).join('');
    const statBar = (ic, lab, v) => `<div class="dstat"><span>${ic} ${lab}</span><i><b style="width:${Math.round(Math.max(0.08, Math.min(1, v)) * 100)}%"></b></i></div>`;
    const P = sel.perk || {}, outOn = TT.OUTFITS.find(o => o.id === curOut) || TT.OUTFITS[0];
    el.innerHTML = header('🧑‍✈️ ' + t('السواقين واللبس', 'Drivers & outfits'), 'menu', 'drivers') + `<div class="drv3">
      <section class="d3-strip">${cards}</section>
      <section class="d3-stage">
        <div class="d3-hero"><div class="d3-spot"></div><div class="d3-figs" id="drvHero"></div><span class="d3-outfit">${outOn.icon} ${t(outOn.name, outOn.en)}</span></div>
        <div class="d3-info"><h3>${t(sel.name, sel.en)}</h3><p>${esc(sel.desc)}</p>
          <div class="dstats">${statBar('😊', t('رضا الركاب', 'Rider mood'), 0.4 + (P.sat || 0) / 10)}${statBar('🛑', t('الفرامل', 'Braking'), 0.4 + (P.brake || 0) * 6)}${statBar('🛡️', t('تحمّل', 'Toughness'), P.dmg ? 1.4 - P.dmg : 0.4)}${statBar('⛽', t('توفير', 'Economy'), P.fuel ? 1.5 - P.fuel : 0.4)}${statBar('🎁', t('بقشيش', 'Tips'), P.tips ? P.tips / 1.8 : 0.4)}${statBar('🏁', t('سباق', 'Racing'), P.race ? 1.3 - P.race : 0.4)}</div>
          <div class="perks">✨ ${perkTxt(P) || t('سواق عادي', 'Regular driver')}</div>
          <div class="d3-act">${own ? (d.driver === sel.id ? `<span class="chip ok">✓ ${t('ده السواق دلوقتي', 'Current driver')}</span>` : `<button class="btn gold" id="dUse">✅ ${t('اشتغل بيه', 'Use')}</button>`) : `<button class="btn gold" id="dBuy">💰 ${t('اشتري', 'Hire')} — ${fmt(sel.price)}</button>`}</div></div>
        <div class="d3-wardrobe"><h4>👕 ${t('دولاب اللبس', 'Wardrobe')}</h4><div class="outfits">${outfits}</div></div>
      </section></div>`;
    el.querySelectorAll('[data-por]').forEach(p => p.appendChild(portrait(TT.driverLook(p.dataset.por), 'idle', 50, 70, 0.75)));
    const hero = $('#drvHero'); ['wave', 'idle', 'celebrate'].forEach((po, i) => { const cv = portrait(TT.driverLook(sel.id), po, 140, 236, i === 1 ? 2.5 : 2.0); cv.className = 'f' + i; hero.appendChild(cv); });
    bindGo(el);
    el.querySelectorAll('[data-view]').forEach(b => b.onclick = () => { UI.drvView = b.dataset.view; TT.Audio.play('click'); renderDrivers(); });
    const ub = $('#dUse'); if (ub) ub.onclick = () => { d.driver = sel.id; TT.Save.write(); TT.Audio.play('click'); renderDrivers(); };
    const bb = $('#dBuy'); if (bb) bb.onclick = () => { if (!spend(sel.price)) return; TT.Save.ledger(t('سواق جديد: ', 'Hired: ') + t(sel.name, sel.en), -sel.price, 'upgrade'); d.ownedDrivers.push(sel.id); d.driver = sel.id; TT.Save.write(); TT.Audio.play('cash'); renderDrivers(); };
    el.querySelectorAll('[data-out]').forEach(b => b.onclick = () => { const o = TT.OUTFITS.find(x => x.id === b.dataset.out); if (!d.ownedOutfits.includes(o.id)) { if (!spend(o.price)) return; TT.Save.ledger(t('لبس: ', 'Outfit: ') + t(o.name, o.en), -o.price, 'upgrade'); d.ownedOutfits.push(o.id); TT.Audio.play('cash'); } else TT.Audio.play('click'); d.outfitOn[sel.id] = o.id; TT.Save.write(); renderDrivers(); });
  }

  /* ---------------- محرر التعليقات ---------------- */
  function renderLines() {
    const el = $('#lines'), d = S(); d.customLines = d.customLines || {};
    const cats = TT.LINE_CATS, cur = cats.find(c => c.id === UI.lineCat) || cats[0]; UI.lineCat = cur.id;
    let lastG = '', list = '';
    for (const c of cats) { if (c.group !== lastG) { list += `<div class="lc-g">${c.group}</div>`; lastG = c.group; } list += `<button class="lcat ${c.id === cur.id ? 'sel' : ''} ${d.customLines[c.id] ? 'mod' : ''}" data-lc="${c.id}">${esc(c.name)}<small>${c.get().length}</small></button>`; }
    const hint = cur.type === 'pair' ? t('كل سطر حوار: كلام الراكب | رد السواق', 'One exchange per line: rider | driver') : cur.type === 'chat' ? t('كل سطر: سؤال الزبون | رد حلو | رد وحش', 'Per line: question | nice reply | rude reply') : t('كل سطر = تعليق واحد. اللعبة بتختار منهم عشوائي.', 'One line per comment — picked at random.');
    el.innerHTML = header('💬 ' + t('تعليقات اللعبة', 'Game comments'), 'menu', 'lines') + `<div class="lines-wrap">
      <nav class="lc-list">${list}</nav>
      <section class="lc-edit"><div class="lc-head"><b>${esc(cur.group)} ← ${esc(cur.name)}</b>${d.customLines[cur.id] ? `<span class="chip ok">✏️ ${t('متعدّل', 'Edited')}</span>` : ''}</div>
        <p class="lc-hint">💡 ${hint}</p>
        <textarea id="lcText" dir="auto" spellcheck="false">${esc(cur.get().join('\n'))}</textarea>
        <div class="row center"><button class="btn gold" id="lcSave">💾 ${t('احفظ', 'Save')}</button><button class="btn" id="lcTry">🎲 ${t('جرّب سطر', 'Preview')}</button><button class="btn ghost" id="lcReset">↩️ ${t('رجّع الأصلي', 'Restore original')}</button></div>
        <div id="lcPrev" class="lc-prev"></div></section></div>`;
    bindGo(el);
    el.querySelectorAll('[data-lc]').forEach(b => b.onclick = () => { UI.lineCat = b.dataset.lc; TT.Audio.play('click'); renderLines(); });
    const read = () => $('#lcText').value.split('\n').map(s => s.trim()).filter(Boolean);
    $('#lcSave').onclick = () => { const v = read(); if (!v.length) { toast(t('اكتب سطر واحد على الأقل', 'Write at least one line'), 'warn'); return; } cur.set(v); d.customLines[cur.id] = cur.get(); TT.Save.write(); TT.Audio.play('cash'); toast(t('اتحفظ ✓ — هتظهر في اللعبة', 'Saved ✓'), 'good'); renderLines(); };
    $('#lcReset').onclick = () => { delete d.customLines[cur.id]; cur.set(TT.LINE_ORIG[cur.id].slice()); TT.Save.write(); toast(t('رجعت التعليقات الأصلية', 'Restored'), 'info'); renderLines(); };
    $('#lcTry').onclick = () => { const v = read(); if (!v.length) return; const s1 = v[Math.floor(Math.random() * v.length)].split('|').map(x => x.trim()); $('#lcPrev').innerHTML = `<div class="bub a">${esc(s1[0])}</div>${s1[1] ? `<div class="bub b">${esc(s1[1])}</div>` : ''}`; };
  }

  /* ---------------- ACHIEVEMENTS & VIOLATIONS ---------------- */
  function renderAch() {
    const el = $('#achievements'), d = S(); d.stats.stars = TT.Save.totalStars();
    const ach = TT.ACHIEVEMENTS.map(a => { const v = Math.min(a.goal, d.stats[a.stat] || 0), done = v >= a.goal; return `<div class="ach ${done ? 'done' : ''}"><span class="ai">${done ? '🏆' : '🎯'}</span><div class="an">${t(a.name, a.en)}<div class="meter"><i style="width:${v / a.goal * 100}%"></i></div></div><b>${fmt(v)}/${fmt(a.goal)}</b></div>`; }).join('');
    const vl = d.violationsLog.length ? d.violationsLog.slice(0, 20).map(v => `<div class="vrow"><b>🚨 ${t(TT.VIOLATIONS[v.kind].name, TT.VIOLATIONS[v.kind].en)}</b><span>${esc(v.reason || '')}</span><em>-${v.fine} ${t('ج', 'EGP')}</em></div>`).join('') : `<p class="hint">${t('مفيش مخالفات لحد دلوقتي 👏', 'No fines yet 👏')}</p>`;
    el.innerHTML = header('🏆 ' + t('المهام والإنجازات', 'Achievements'), 'menu', 'achievements') + `<div class="two-col"><div class="panel-box"><h4>${t('الإنجازات', 'Achievements')}</h4>${ach}</div>
      <div class="panel-box"><h4>${t('سجل المخالفات', 'Violations log')} · ${t('السمعة', 'Reputation')} ${Math.round(d.rep)}/100</h4>${vl}
      <h4>${t('إحصائيات', 'Stats')}</h4><div class="stats-grid"><span>🧍 ${t('توصيلات', 'Rides')}: ${d.stats.deliveries}</span><span>💵 ${t('إجمالي الدخل', 'Earned')}: ${fmt(d.stats.earned)}</span><span>🔄 ${t('انقلابات', 'Flips')}: ${d.stats.flips}</span><span>🥊 ${t('خناقات', 'Fights')}: ${d.stats.fights}</span><span>🙏 ${t('ربنا يهديك', 'Walk-aways')}: ${d.stats.peace}</span><span>🪙 ${t('عملات', 'Coins')}: ${d.stats.coins}</span></div></div></div>`;
    bindGo(el);
  }
  function renderLedger() {
    const el = $('#ledger'), d = S();
    const rows = d.ledger.length ? d.ledger.map(l => `<div class="lrow ${l.amount >= 0 ? 'in' : 'out'}"><span>${new Date(l.t).toLocaleString(TT.lang === 'ar' ? 'ar-EG' : 'en-GB', { hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })}</span><b>${esc(l.label)}</b><em>${l.amount >= 0 ? '+' : ''}${fmt(l.amount)}</em></div>`).join('') : `<p class="hint">${t('لسه مفيش حركات', 'No entries yet')}</p>`;
    let inc = 0, out = 0; d.ledger.forEach(l => l.amount >= 0 ? inc += l.amount : out += l.amount);
    el.innerHTML = header('📒 ' + t('سجل الدخل والمصروفات', 'Income & expenses'), 'menu', 'ledger') + `<div class="panel-box ledger"><div class="ltot"><span class="in">${t('دخل', 'In')} +${fmt(inc)}</span><span class="out">${t('مصروفات', 'Out')} ${fmt(out)}</span><span>${t('الرصيد', 'Balance')} ${fmt(d.money)}</span></div>${rows}</div>`;
    bindGo(el);
  }

  /* ---------------- SETTINGS ---------------- */
  function renderSettings() {
    const el = $('#settings'), st = S().settings;
    const tg = (k, label) => `<label class="tog"><input type="checkbox" data-set="${k}" ${st[k] ? 'checked' : ''}><span></span>${label}</label>`;
    el.innerHTML = header('⚙️ ' + t('الإعدادات', 'Settings'), 'menu', 'settings') + `<div class="panel-box settings">
      <h4>🔊 ${t('الصوت', 'Sound')}</h4>${tg('sfx', t('المؤثرات الصوتية', 'Sound effects'))}${tg('music', t('الموسيقى', 'Music'))}
      <h4>🎨 ${t('الجرافيك', 'Graphics')}</h4><div class="seg"><button data-q="high" class="${st.quality === 'high' ? 'sel' : ''}">${t('عالي', 'High')}</button><button data-q="low" class="${st.quality === 'low' ? 'sel' : ''}">${t('خفيف (للأجهزة الضعيفة)', 'Low (weak devices)')}</button></div>
      <h4>🎮 ${t('التحكم', 'Controls')}</h4>${tg('pedalsLeft', t('الدواسات على الشمال', 'Pedals on the left'))}${tg('vibrate', t('اهتزاز الموبايل', 'Vibration'))}
      <h4>🚧 ${t('كمية العوائق (لكل المراحل)', 'Obstacle amounts (all levels)')}</h4>${amountsHTML()}
      <h4>🌐 ${t('اللغة', 'Language')}</h4><div class="seg"><button data-lang="ar" class="${st.lang === 'ar' ? 'sel' : ''}">العربية</button><button data-lang="en" class="${st.lang === 'en' ? 'sel' : ''}">English</button></div>
      <h4>🔑 ${t('أكواد الفتح', 'Unlock codes')}</h4>
      <div class="code-row"><input id="codeIn" type="text" inputmode="text" autocomplete="off" placeholder="code 0000"><button class="btn gold" id="codeBtn">${t('فعّل', 'Apply')}</button></div>
      <div id="codeMsg" class="hint"></div>
      <h4>💾 ${t('الحفظ', 'Save')}</h4><button class="btn danger" id="resetBtn">🗑️ ${t('مسح التقدم', 'Reset progress')}</button></div>`;
    bindGo(el);
    { const box = el.querySelector('.panel-box.settings'); if (box) { const kids = [...box.childNodes]; box.innerHTML = ''; let sec = null; for (const n of kids) { if (!sec && n.nodeType === 3 && !n.textContent.trim()) continue; if (n.nodeName === 'H4' || !sec) { sec = document.createElement('section'); sec.className = 'set-sec'; box.appendChild(sec); } sec.appendChild(n); } } }
    el.querySelectorAll('[data-set]').forEach(i => i.onchange = () => { st[i.dataset.set] = i.checked; applySettings(); TT.Save.write(); });
    bindAmounts(el, () => renderSettings());
    el.querySelectorAll('[data-q]').forEach(b => b.onclick = () => { st.quality = b.dataset.q; TT.Save.write(); TT.resize(); renderSettings(); });
    el.querySelectorAll('[data-lang]').forEach(b => b.onclick = () => { st.lang = b.dataset.lang; TT.lang = st.lang; TT.Save.write(); applyLang(); renderSettings(); });
    const runCode = () => { const r = applyCode($('#codeIn').value); const m = $('#codeMsg'); m.textContent = (r.ok ? '✅ ' : '❌ ') + r.msg; m.style.color = r.ok ? '#81c784' : '#ff8a80'; TT.Audio.play(r.ok ? 'win' : 'error'); if (r.ok) { $('#codeIn').value = ''; el.querySelector('.wallet').outerHTML = header('', 'menu').match(/<div class="wallet">[\s\S]*?<\/div>/)[0]; } };
    $('#codeBtn').onclick = runCode; $('#codeIn').onkeydown = e => { if (e.key === 'Enter') runCode(); };
    $('#resetBtn').onclick = () => modalMsg('⚠️ ' + t('مسح كل التقدم؟', 'Erase all progress?'), t('الفلوس والنجوم والتطويرات هتتمسح ومش هترجع.', 'Money, stars and upgrades will be lost forever.'), [[t('أيوه امسح', 'Yes, erase'), () => { TT.Save.reset(); TT.lang = 'ar'; applyLang(); closeModal(); go('menu'); toast(t('اتمسح التقدم', 'Progress reset'), 'warn'); }, 'danger'], [t('لا', 'No'), closeModal]]);
  }
  function applySettings() {
    const st = S().settings; TT.Audio.sfx = st.sfx; const wasMusic = TT.Audio.music; TT.Audio.music = st.music;
    if (st.music && !wasMusic) { TT.Audio.init(); TT.Audio.startMusic(); } if (!st.music) TT.Audio.stopMusic();
    document.body.classList.toggle('pedals-left', !!st.pedalsLeft);
    $('#ctlHint') && $('#ctlHint').classList.toggle('hidden', !st.hints);
  }

  /* ---------------- MODAL ---------------- */
  // نوافذ إجبارية من غير زرار قفل (لازم تختار فيها)
  const NO_X = ['police', 'jail', 'mediation', 'station'];
  function openModal(html, cls, name) {
    const m = $('#modal'); m.className = 'modal ' + (cls || ''); $('#modalBody').innerHTML = html; m.classList.remove('hidden');
    if (G().mode !== 'menu') G().modal = name || 'modal';
    UI._modalName = name || 'modal';
    if (!NO_X.includes(name)) { const x = document.createElement('button'); x.className = 'modal-x'; x.setAttribute('aria-label', t('رجوع', 'Back')); x.innerHTML = '✕'; x.onclick = e => { e.stopPropagation(); TT.Audio.play('click'); modalBack(name); }; $('#modalBody').prepend(x); }
    return $('#modalBody');
  }
  // زرار ✕: يرجع للخطوة اللي قبلها حسب نوع النافذة
  function modalBack(name) {
    const b = $('#modalBody'), g = G();
    if (name === 'intro') { closeModal(); TT.Game.quit(); if (g.L == null) { UI.selWorld = UI.selWorld || 0; go('map'); } return; }
    if (name === 'pause') { closeModal(); TT.Game.pause(false); return; }
    if (name === 'end') { const m = b.querySelector('#eMap, #fsMenu'); if (m) { m.click(); return; } }
    const back = b.querySelector('#offClose, #talkClose, #fClose, #rClose, #sClose, #helpOk, #frX, #wbGo, #discOk, #abOk, .btn.ghost');
    if (back && name !== 'warn') { back.click(); if (!$('#modal').classList.contains('hidden') && UI._modalName === name) closeModal(); return; }
    closeModal(); if (g.mode === 'play' && g.paused) TT.Game.pause(false);
  }
  UI.modalBack = modalBack;
  function closeModal() { $('#modal').classList.add('hidden'); G().modal = null; }
  UI.closeModal = closeModal;
  function modalMsg(title, text, buttons) {
    const b = openModal(`<h3>${title}</h3><p>${text}</p><div class="row center">${buttons.map((x, i) => `<button class="btn ${x[2] || (i === 0 ? 'gold' : '')}" data-i="${i}">${x[0]}</button>`).join('')}</div>`, 'small', 'msg');
    b.querySelectorAll('[data-i]').forEach(btn => btn.onclick = () => { TT.Audio.play('click'); buttons[+btn.dataset.i][1](); });
  }
  UI.modalMsg = modalMsg;

  /* ---------------- LEVEL START / HUD ---------------- */
  UI.onLevelStart = function (L, resumed, opts) {
    show('play'); closeModal(); ctlMode = ''; setControls('drive');
    $('#fightCtl').classList.add('hidden'); $('#flipPanel').classList.add('hidden'); $('#fuelPanel').classList.add('hidden'); $('#chatBox').classList.add('hidden');
    $('#toasts').innerHTML = '';
    UI.setMode(G().tuk.mode);
    // route marks
    const marks = L.stations.map(s => `<i class="st" data-st="${s.idx}" style="left:${s.x / L.finish * 100}%"></i>`).join('') + L.gas.map(g => `<i class="gs" style="left:${g.x / L.finish * 100}%">⛽</i>`).join('') + `<i class="fin" style="left:100%">🏁</i>`;
    $('#hRouteMarks').innerHTML = marks;
    UI._raceKey = ''; $('#racePanel').classList.add('hidden'); $('#phoneUI').classList.add('hidden');
    if (opts && opts.free) { UI.regionBanner(L, opts.first); applySettings(); return; }
    const F = [], z = L.zones, lim = L.radars.length ? Math.min(...L.radars.map(r => r.limit)) : L.W.speedLimit;
    if (L.radars.length) F.push(['📸', t('رادار ' + lim, 'Radar ' + lim), t('رادار سرعة — الحد ' + lim + ' كم/س', 'Speed camera — limit ' + lim + ' km/h')]);
    if (L.lights.length) F.push(['🚦', t('إشارات', 'Lights'), t('اقف قبل الخط الأبيض لو الإشارة حمرا', 'Stop at the white line on red')]);
    if (L.checkpoints.length) F.push(['👮', t('كمين', 'Checkpoint'), t('لازم توقف تمامًا قبل الكمين', 'Come to a full stop before it')]);
    if (z.quiet.length) F.push(['🔇', t('هدوء', 'Quiet'), t('ممنوع الكلاكس في المنطقة الهادية', 'No horn in the quiet zone')]);
    if (z.noPark.length) F.push(['🅿️', t('ممنوع الوقوف', 'No stopping'), t('الرصيف الأحمر والأبيض: ممنوع تقف أكتر من 4 ثواني', 'Red/white curb: no stopping over 4 s')]);
    if (L.blockers.length) F.push(['🚙', t('صف تاني', 'Double-park'), t('عربية راكنة صف تاني: زمّر أو انزل كلّم صاحبها', 'Honk or talk to the owner')]);
    if (z.village.length) F.push(['🏘️', t('قرية', 'Village'), t('السرعة أقل جوه القرية', 'Lower limit in the village')]);
    if (z.bridge.length) F.push(['🌉', t('كوبري', 'Bridge'), '']);
    if (z.tunnel.length) F.push(['🚇', t('نفق', 'Tunnel'), t('شغّل الكشافات (L)', 'Headlights on (L)')]);
    if (z.storm.length) F.push(['🌪️', t('عاصفة', 'Storm'), t('شغّل الكشافات (L)', 'Headlights on (L)')]);
    if (z.jam.length) F.push(['🚗', t('زحمة', 'Traffic jam'), '']);
    if (L.W.gravity < 9) F.push(['🪐', t('جاذبية ضعيفة', 'Low gravity'), t('القفزات أطول والانقلاب أسهل', 'Longer jumps, easier flips')]);
    const V = G().vendor, gd = V && TT.GOODS[V.id], fuelPct = Math.round(TT.Save.veh().fuel / TT.vehParams().tank * 100);
    const goal1 = V ? t('بيع', 'Sell') + ` <b>${L.required}</b> ${gd.icon}` : t('وصّل', 'Deliver') + ` <b>${L.required}</b> ${t('ركاب', 'riders')}`;
    const intro = `<div class="lvl-intro2">
      <div class="li-head theme-${L.W.theme}"><span class="li-ic">${CICONS[L.W.id] || WICONS[L.W.theme] || '🛺'}</span><div><small>${esc(t(L.W.name, L.W.en))}</small><h3>${t('مرحلة', 'Level')} ${L.li + 1}${V ? ` · <span class="li-mode">🛒 ${t(TT.CART_NAMES[V.id][0], TT.CART_NAMES[V.id][1])}</span>` : ''}</h3></div>
        <div class="li-stats"><span>📏 ${(L.len / 1000).toFixed(1)} ${t('كم', 'km')}</span><span>🚏 ${L.stations.length}</span><span>${V ? '📦 ' + V.stock : '🧍 ' + L.passengers.length}</span><span class="${fuelPct < 30 ? 'low' : ''}">⛽ ${fuelPct}%</span>${(S().license || { left: 25 }).left <= 0 ? `<span class="low">🪪 ${t('منتهية', 'Expired')}</span>` : ''}</div>${helpBtn('intro')}</div>
      <div class="li-body">
        <section class="li-col">
          <h4>🎯 ${t('المطلوب', 'Objectives')}</h4>
          <div class="li-goals">
            <div class="goal"><span class="gs">★</span><p>${goal1} <small>${t('واوصل لآخر الخط', 'and reach the finish')}</small></p></div>
            <div class="goal"><span class="gs">★★</span><p>${t('اكسب', 'Earn')} <b>${L.target}</b> ${t('ج أو أكتر', 'EGP or more')}</p></div>
            <div class="goal"><span class="gs">★★★</span><p>${t('من غير مخالفات ولا انقلاب', 'No fines, no flips')}</p></div>
            ${G().ch ? `<div class="goal ch"><span class="gs">🎯</span><p>${esc(G().ch.text)} <small>+${G().ch.bonus} ${t('ج', 'EGP')} · ${t('تحدي إضافي', 'bonus challenge')}</small></p>${helpBtn('task')}</div>` : ''}
          </div>
          ${F.length ? `<h4>🛣️ ${t('في الطريق', 'On this road')}</h4><div class="li-feats">${F.map(([ic, n, d]) => `<span ${d ? `title="${esc(d)}"` : ''}>${ic} ${n}</span>`).join('')}</div>` : ''}
        </section>
        <section class="li-col">
          <h4>⚙️ ${t('جهّز الطريق: العوائق والجو والوقت', 'Set up the road: obstacles, weather & time')}</h4>
          ${amountsHTML()}
        </section>
      </div>
      <div class="li-foot"><button class="btn big gold li-go" id="goBtn">${resumed ? t('كمّل', 'Resume') : t('يلا بينا!', 'Let\'s go!')} 🛺</button></div></div>`;
    const b = openModal(intro, 'wide intro-m', 'intro');
    bindAmounts(b, key => { if (resumed) { UI.onLevelStart(L, resumed); return; } TT.Game.startLevel(L.wi, L.li, false); });
    b.querySelector('#goBtn').onclick = () => { TT.Audio.init(); applySettings(); closeModal(); };
  };
  /* اختيار كمية العوائق والمطبات والزحمة قبل بداية المرحلة */
  const AMOUNTS = [['none', 'مفيش', 'None'], ['few', 'قليل', 'Few'], ['normal', 'عادي', 'Normal'], ['many', 'كتير', 'Many']];
  const WEATHERS = [['auto', '🎲', 'عشوائي', 'Random'], ['clear', '☀️', 'صافي', 'Clear'], ['cloudy', '☁️', 'غيم', 'Cloudy'], ['fog', '🌫️', 'شبورة', 'Fog'], ['rain', '🌧️', 'مطر', 'Rain'], ['storm', '⛈️', 'رعد', 'Storm']];
  const TIMES = [['auto', '🎲', 'عشوائي', 'Random'], ['morning', '🌅', 'الصبح', 'Morning'], ['noon', '☀️', 'الضهر', 'Noon'], ['afternoon', '🌤️', 'العصر', 'Afternoon'], ['sunset', '🌇', 'المغرب', 'Sunset'], ['night', '🌙', 'بالليل', 'Night']];
  function amountsHTML() {
    const st = S().settings, row = (key, label) => `<div class="amt-row"><span>${label}</span><div class="seg">${AMOUNTS.map(([v, ar, en]) => `<button data-amt="${key}" data-v="${v}" class="${(st[key] || 'normal') === v ? 'sel' : ''}">${t(ar, en)}</button>`).join('')}</div></div>`;
    const row2 = (key, label, opts) => `<div class="amt-row"><span>${label}</span><div class="seg icons">${opts.map(([v, ic, ar, en]) => `<button data-amt="${key}" data-v="${v}" title="${t(ar, en)}" class="${(st[key] || 'auto') === v ? 'sel' : ''}">${ic}<small>${t(ar, en)}</small></button>`).join('')}</div></div>`;
    return `<div class="amounts">${row('obstacles', '🚧 ' + t('العوائق', 'Obstacles'))}${row('bumps', '〰️ ' + t('المطبات', 'Speed bumps'))}${row('traffic', '🚗 ' + t('الزحمة', 'Traffic'))}${row('animals', '🐐 ' + t('الحيوانات', 'Animals'))}${row('police', '👮 ' + t('المرور', 'Police'))}${row2('fines', '🧾 ' + t('المخالفات', 'Fines'), [['on', '🧾', 'بتتسجل', 'Recorded'], ['off', '🔔', 'تنبيه بس', 'Warn only']])}${row2('checkpoints', '👮 ' + t('الكماين', 'Checkpoints'), [['on', '👮', 'موجودة', 'On'], ['off', '🚫', 'من غير', 'Off']])}${row2('weather', '🌦️ ' + t('الجو', 'Weather'), WEATHERS)}${row2('timeOfDay', '🕐 ' + t('الوقت', 'Time'), TIMES)}</div>`;
  }
  function bindAmounts(root, after) {
    root.querySelectorAll('[data-amt]').forEach(b => b.onclick = () => { const st = S().settings; if (st[b.dataset.amt] === b.dataset.v) return; st[b.dataset.amt] = b.dataset.v; TT.Save.write(); TT.Audio.play('click'); after(b.dataset.amt); });
  }

  const ICONS = { student: '🎒', employee: '💼', mother: '👩‍👧', merchant: '🧺', farmer: '🌾', tourist: '📷', moallem: '😎', granny: '👵', alien: '👽', astro: '👨‍🚀' };
  let lastRiderKey = '';
  UI.hud = function () {
    const g = G(); if (g.mode !== 'play' || !g.L) return;
    const d = S(), T = g.tuk, L = g.L, vp = g.vp || TT.vehParams();
    $('#hMoney').textContent = fmt(d.money); $('#hMoney').parentElement.classList.toggle('neg', d.money < 0);
    $('#hRep').textContent = Math.round(d.rep);
    if (g.env) { const E = g.env, ph = TT.phaseOf(E.clock), h = Math.floor(E.clock) % 24, mi = Math.floor((E.clock % 1) * 60), h12 = ((h + 11) % 12) + 1, wic = { clear: '', cloudy: '☁️', fog: '🌫️', rain: '🌧️', storm: '⛈️' }[E.weather] || '';
      const txt = `${ph[2]} ${t(ph[3], ph[4])} · ${h12}:${String(Math.floor(mi / 10) * 10).padStart(2, '0')} ${h < 12 ? t('ص', 'AM') : t('م', 'PM')}${wic ? ' · ' + wic : ''}${g.free && g.fatigue != null ? ` · 😴 ${Math.round(g.fatigue)}%` : ''}`;
      if (UI._envTxt !== txt) { UI._envTxt = txt; $('#hEnv').textContent = txt; $('#hEnv').classList.toggle('night', E.dark > 0.35); } }
    $('#hLvl').textContent = TT.Save.driverLevel();
    $('#hPax').textContent = TT.Game.seatsUsed() + '/' + (TT.Save.model().seats || 3);
    const fuelPct = TT.Save.veh().fuel / vp.tank * 100;
    $('#hFuel').style.width = fuelPct + '%'; $('#hFuel').parentElement.classList.toggle('low', fuelPct < 20);
    const cond = TT.conditionPct() * 100; $('#hCond').style.width = cond + '%'; $('#hCond').parentElement.classList.toggle('low', cond < 40);
    $('#hMe').style.left = Math.min(100, T.x / L.finish * 100) + '%';
    document.querySelectorAll('#hRouteMarks .st').forEach(e => { const i = +e.dataset.st; e.classList.toggle('dest', g.riding.some(p => p.to === i)); e.classList.toggle('wait', L.stations[i].waiting.length > 0); });
    const s = g.stats; const fares = s.income + s.tips;
    if (g.free) { const F = TT.freeData(), tr = F.trip || { money0: d.money, km: 0 }, earn = d.money - tr.money0, nx = TT.WORLDS.find(W => W.id === TT.FREE_ROUTE[(F.seg + 1) % TT.FREE_ROUTE.length]);
      $('#hMission').innerHTML = `🛣️ ${esc(t(L.W.name, L.W.en))} ← ${esc(t(nx.name, nx.en))} · 📏 ${(tr.km + T.x / 1000).toFixed(1)} ${t('كم', 'km')} · ${earn >= 0 ? '💵 +' : '💸 '}${fmt(earn)} · 🏆 ${F.streak}`; }
    else { const C = g.ch, cs = C ? (C.done ? ' · 🎯✅' : C.failed ? ' · 🎯❌' : ' · 🎯' + (C.goal && ['ontime', 'coins', 'quiet', 'time'].includes(C.id) ? ' ' + C.prog + '/' + C.goal : '')) : '';
      $('#hMission').innerHTML = `${g.vendor ? TT.GOODS[g.vendor.id].icon : '🧍'} ${s.delivered}/${L.required} · 💵 ${fmt(fares)}/${L.target} · 🚨 ${s.violations}${cs}`; }
    UI.raceHud(g);
    $('#dozeFx').style.opacity = g.free ? (g.dozeT > 0 ? 0.92 : g.fatigue > 75 ? (0.15 + 0.15 * Math.sin(Date.now() / 300)) : 0) : 0;
    // current speed limit (مناطق سرعة مختلفة + تنبيه الرادار)
    const lim = TT.limitAt(L, T.x);
    $('#hLimit').textContent = lim; $('#hLimit').classList.toggle('over', TT.util.kmh(T.vx) > lim + 3); $('#hLimit').classList.toggle('radar', !!g.radarAhead);
    // riders panel
    const key = g.vendor ? 'v' + g.vendor.stock + '/' + g.vendor.sold : g.riding.map(p => p.id + p.state).join();
    if (key !== lastRiderKey) {
      lastRiderKey = key;
      if (g.vendor) { const V = g.vendor, gd = TT.GOODS[V.id]; $('#riders').innerHTML = `<div class="rider vend"><span class="av">${gd.icon}</span><div class="rinfo"><b>${esc(t(gd.name, gd.en))} · ${V.price} ${t('ج', 'EGP')}</b><div class="rmeta">📦 ${V.stock} · ✅ ${V.sold}/${L.required}</div><div class="tbar"><i style="width:${V.stock / V.start * 100}%;background:#ffb300"></i></div></div></div>`; }
      else $('#riders').innerHTML = g.riding.map(p => `<div class="rider" data-p="${p.id}"><span class="av">${ICONS[p.type] || '🧍'}</span><div class="rinfo"><b>${esc(L.stations[p.to].name)}</b><div class="rmeta"><span class="dist"></span> · ${p.fare}${t('ج', 'EGP')}</div><div class="tbar"><i></i></div></div><span class="face"></span></div>`).join('');
    }
    g.riding.forEach(p => {
      const el = document.querySelector(`.rider[data-p="${p.id}"]`); if (!el) return;
      const dist = Math.max(0, L.stations[p.to].x - T.x);
      el.querySelector('.dist').textContent = dist < 1000 ? Math.round(dist) + t(' م', ' m') : (dist / 1000).toFixed(1) + t(' كم', ' km');
      if (L.stations[p.to].x < T.x - 8) el.querySelector('.dist').textContent = '↩ ' + t('فاتت!', 'passed!');
      const rem = 1 - p.t / p.timeLimit; const bar = el.querySelector('.tbar i');
      bar.style.width = clamp01(rem) * 100 + '%'; bar.style.background = rem > 0.4 ? '#43a047' : rem > 0 ? '#f9a825' : '#e53935';
      el.querySelector('.face').textContent = p.state === 'boarding' ? '🚶' : p.sat > 75 ? '😄' : p.sat > 50 ? '🙂' : p.sat > 30 ? '😐' : '😠';
    });
    // controls state
    const ctx = TT.contextAction();
    const ab = $('#btnAction'), eb = $('#btnExit');
    if (g.driver) {
      setControls('foot');
      ab.classList.toggle('hidden', !(ctx && (ctx.talk || ctx.accident))); if (ctx && ctx.accident) { ab.textContent = '🚨 ' + t('شوف إيه اللي حصل', 'See what happened'); ab.className = 'act-btn refuel'; } else if (ctx && ctx.talk) { ab.textContent = '💬 ' + t('كلّم ', 'Talk to ') + ctx.talk.name; ab.className = 'act-btn talk'; }
      eb.classList.toggle('dim', !(ctx && ctx.enter)); setTxt(eb, '<i>🛺</i><small>' + t('اركب', 'Get in') + '</small>');
    } else {
      setControls('drive');
      ab.classList.toggle('hidden', !ctx); if (ctx) { ab.textContent = ({ drop: '⬇ ', pickup: '⬆ ', refuel: '⛽ ', unclamp: '🔓 ' }[ctx.id] || '') + ctx.label; ab.className = 'act-btn pulse ' + ctx.id; }
      eb.classList.toggle('dim', !TT.canExit()); setTxt(eb, '<i>🚶</i><small>' + t('انزل', 'Get out') + '</small>');
    }
    $('#btnLights').classList.toggle('on', T.lights); { const lm = T.lights ? (T.lightMode || 'low') : 'off'; setTxt($('#btnLights'), '<i>' + { off: '💡', low: '💡', high: '🔆', fog: '🌫️' }[lm] + '</i><small>' + { off: t('كشافات', 'Lights'), low: t('واطي', 'Low'), high: t('عالي', 'High'), fog: t('شبورة', 'Fog') }[lm] + '</small>'); }
    const ao = TT.accOpts();
    $('#btnSub').classList.toggle('hidden', !ao.sub || !!g.driver); $('#btnSub').classList.toggle('on', !!g.subOn);
    $('#btnParty').classList.toggle('hidden', !ao.party || !!g.driver); $('#btnParty').classList.toggle('on', !!g.partyOn);
    $('#btnKick').classList.toggle('hidden', !(g.riding.some(p => p.state === 'riding') && Math.abs(T.vx) < 0.6 && !g.driver && !g.flip));
    const stNear = !g.driver && g.L.stations.some(s => Math.abs(s.x - T.x) < 7) && Math.abs(T.vx) < 0.6 && !g.input.hand;
    $('#handHint').classList.add('hidden');
    const kb = $('#btnKey'); kb.classList.toggle('hidden', !!vp.human || !!g.driver); kb.classList.toggle('on', !!T.engineOn); kb.classList.toggle('off', !T.engineOn); setTxt(kb, '<i>🔑</i><small>' + (T.engineOn ? t('شغّال', 'ON') : t('شغّل', 'START')) + '</small>');
    $('#btnCall').classList.toggle('hidden', !(g.vendor && !g.driver && Math.abs(T.vx) < 0.4 && g.vendor.stock > 0));
    $('#btnHand').classList.toggle('on', !!g.input.hand);
    $('#jerryN').textContent = d.jerry || 0; $('#btnJerry').classList.toggle('hidden', !!vp.human || !!g.driver); $('#btnJerry').classList.toggle('dim', !(d.jerry > 0));
    const ng = g.L.gas.find(q => q.x > T.x - 3);
    drawGauge(TT.util.kmh(T.vx), fuelPct, vp, lim, ng ? Math.max(0, ng.x - T.x) : null);
    if (g.fight) { $('#fpHP').style.width = Math.max(0, g.fight.pHP) + '%'; $('#fnHP').style.width = Math.max(0, g.fight.nHP / (g.fight.npc.temper === 'hothead' ? 1.25 : g.fight.npc.temper === 'coward' ? 0.55 : 0.95)) + '%'; $('#fNpcName').textContent = g.fight.npc.name; $('#fWarn').classList.toggle('show', g.fight.nState === 'windup'); }
    if (!$('#bigMap').classList.contains('hidden') && (UI._bmT = (UI._bmT || 0) + 1) % 5 === 0) UI.renderBigMap();
    if (g.flip && g.flip.phase === 'down') $('#flipProg').style.width = ((g.flip.pushes || 0) / 6 * 100) + '%';
  };
  const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
  let ctlMode = '';
  function setTxt(el, html) { if (el._h !== html) { el._h = html; el.innerHTML = html; } }
  function setControls(mode) {
    if (ctlMode === mode) return; ctlMode = mode;
    document.body.classList.toggle('on-foot', mode === 'foot');
    $('#btnBrake .pd-lb').textContent = t('فرامل', 'BRAKE');
    $('#btnBrake .pd-lb').textContent = mode === 'foot' ? t('لورا', 'BACK') : t('فرامل', 'BRAKE'); $('#brakeSub').textContent = mode === 'foot' ? '' : t('مطوّل = رجوع', 'hold = reverse');
    $('#btnGas .pd-lb').textContent = mode === 'foot' ? t('قدّام', 'WALK') : t('بنزين', 'GAS');
    $('#btnCall').textContent = '📣 ' + t('نادي على البضاعة', 'Call out');
    $('#btnHorn small').textContent = t('كلاكس', 'Horn'); $('#btnHand small').textContent = t('فرامل يد', 'Handbrake'); $('#btnSub small').textContent = t('صب', 'Sub'); $('#btnParty small').textContent = t('زينة', 'Lights fx');
    $('#btnKick').innerHTML = '🗯️ ' + t('نزّلهم', 'Kick out'); $('#handHint').textContent = '🅿️ ' + t('شد فرامل اليد للتحميل', 'Pull handbrake to load');

  }
  let gaugeSize = '';
  function drawGauge(speed, fuel, vp, limit, nextGas) {
    const c = $('#gauge'), dpr = Math.min(2, window.devicePixelRatio || 1);
    const W = c.clientWidth || 260, H = c.clientHeight || 86, key = W + 'x' + H + 'x' + dpr;
    if (gaugeSize !== key) { gaugeSize = key; c.width = Math.round(W * dpr); c.height = Math.round(H * dpr); }
    const x = c.getContext('2d'); x.setTransform(dpr, 0, 0, dpr, 0, 0); x.clearRect(0, 0, W, H);
    const F = A.FONT, human = vp && vp.human, g = G(), T = g.tuk;
    const MAX = Math.max(60, Math.ceil((vp ? vp.vmax * 3.6 * 1.12 : 60) / 20) * 20);
    x.textAlign = 'center'; x.textBaseline = 'middle'; x.lineCap = 'round';
    // ---- عداد السرعة: قوس نص دايرة في النص ----
    const r = Math.min(H * 0.86, W * 0.24), cx = human ? W / 2 : W * 0.43, cy = H * 0.96, a0 = Math.PI, a1 = Math.PI * 2;
    const ang = v => a0 + (a1 - a0) * Math.min(1, Math.max(0, v / MAX));
    x.lineWidth = r * 0.14; x.strokeStyle = 'rgba(255,255,255,.09)'; x.beginPath(); x.arc(cx, cy, r, a0, a1); x.stroke();
    if (limit && limit < MAX) { x.strokeStyle = 'rgba(255,82,82,.35)'; x.beginPath(); x.arc(cx, cy, r, ang(limit), a1); x.stroke(); }
    const over = limit && speed > limit + 3;
    const sg = x.createLinearGradient(cx - r, 0, cx + r, 0); sg.addColorStop(0, '#00e5ff'); sg.addColorStop(0.6, over ? '#ff9100' : '#76ff03'); sg.addColorStop(1, over ? '#ff1744' : '#c6ff00');
    x.save(); x.shadowColor = over ? '#ff1744' : '#00e5ff'; x.shadowBlur = 10; x.strokeStyle = sg; x.beginPath(); x.arc(cx, cy, r, a0, Math.max(a0 + 0.001, ang(speed))); x.stroke(); x.restore();
    x.lineWidth = 1.2; x.strokeStyle = 'rgba(255,255,255,.45)';
    const step = MAX > 120 ? 20 : 10;
    for (let v = step; v < MAX; v += step) { const aa = ang(v), c1 = Math.cos(aa), s1 = Math.sin(aa); x.beginPath(); x.moveTo(cx + c1 * r * 0.76, cy + s1 * r * 0.76); x.lineTo(cx + c1 * r * 0.84, cy + s1 * r * 0.84); x.stroke(); }
    const na = ang(speed); x.strokeStyle = '#fff'; x.lineWidth = 3; x.beginPath(); x.moveTo(cx + Math.cos(na) * r * 0.7, cy + Math.sin(na) * r * 0.7); x.lineTo(cx + Math.cos(na) * r * 1.0, cy + Math.sin(na) * r * 1.0); x.stroke();
    x.fillStyle = over ? '#ff8a80' : '#fff'; x.font = '900 ' + Math.round(r * 0.46) + 'px ' + F; x.fillText(speed, cx, cy - r * 0.34);
    x.fillStyle = 'rgba(255,255,255,.55)'; x.font = '700 ' + Math.max(8, Math.round(r * 0.14)) + 'px ' + F; x.fillText(t('كم/س', 'km/h') + (limit ? ' · ' + t('الحد', 'limit') + ' ' + limit : ''), cx, cy - r * 0.06);
    // ---- لمبات التابلوه على الشمال ----
    const lamps = [['💡', T && T.lights, '#ffd54f'], ['P', g.input && g.input.hand, '#ff5252'], ['🔑', T && (T.engineOn || human), '#69f0ae']];
    lamps.forEach(([ic, on, col], i) => { const lx = W * 0.07, ly = H * (0.2 + i * 0.3), rr = Math.min(10, H * 0.12); x.fillStyle = on ? col : 'rgba(255,255,255,.07)'; x.globalAlpha = on ? 0.95 : 1; x.beginPath(); x.arc(lx, ly, rr, 0, 7); x.fill(); x.globalAlpha = 1; x.fillStyle = on ? '#1b1b1b' : 'rgba(255,255,255,.35)'; x.font = '900 ' + Math.round(rr * 1.1) + 'px ' + F; x.fillText(ic, lx, ly + 0.5); });
    if (human) return;
    // ---- عداد البنزين على اليمين ----
    const fr = r * 0.6, fx = Math.min(W - fr - 10, cx + r + fr + 16), fy = H * 0.96, b0 = Math.PI, b1 = Math.PI * 2, fa = b0 + (b1 - b0) * Math.max(0, Math.min(1, fuel / 100));
    x.lineWidth = fr * 0.2; x.strokeStyle = 'rgba(255,255,255,.09)'; x.beginPath(); x.arc(fx, fy, fr, b0, b1); x.stroke();
    const fc = fuel < 20 ? '#ff5252' : fuel < 40 ? '#ffb300' : '#69f0ae';
    x.save(); x.shadowColor = fc; x.shadowBlur = fuel < 20 ? 12 * (0.6 + 0.4 * Math.sin(Date.now() / 150)) : 6; x.strokeStyle = fc; x.beginPath(); x.arc(fx, fy, fr, b0, Math.max(b0 + 0.001, fa)); x.stroke(); x.restore();
    x.fillStyle = 'rgba(255,255,255,.55)'; x.font = '800 ' + Math.round(fr * 0.22) + 'px ' + F; x.fillText('E', fx - fr * 1.02, fy - fr * 0.14); x.fillText('F', fx + fr * 1.02, fy - fr * 0.14);
    x.font = Math.round(fr * 0.26) + 'px ' + F; x.fillText(g.L && g.L.W.id === 'mars' ? '⚡' : '⛽', fx, fy - fr * 0.74);
    x.fillStyle = fuel < 20 ? '#ff8a80' : '#fff'; x.font = '900 ' + Math.round(fr * 0.3) + 'px ' + F; x.fillText(Math.round(fuel) + '%', fx, fy - fr * 0.44);
    if (nextGas != null) { x.fillStyle = 'rgba(255,213,79,.9)'; x.font = '800 ' + Math.max(8, Math.round(fr * 0.18)) + 'px ' + F; x.fillText('→ ' + (nextGas < 1000 ? Math.round(nextGas) + t('م', 'm') : (nextGas / 1000).toFixed(1) + t('كم', 'km')), fx, fy - fr * 0.14); }
  }
  UI.setMode = function (m) { const v = { eco: ['🍃', t('اقتصادي', 'Eco')], normal: ['⚙️', t('عادي', 'Normal')], sport: ['🔥', t('رياضي', 'Sport')] }[m] || ['⚙️', '']; $('#btnMode').innerHTML = `<i>${v[0]}</i><small>${v[1]}</small>`; };

  /* ---------------- toasts / notifications ---------------- */
  function toast(msg, kind, dur) {
    const box = $('#toasts'); if (!box) return;
    if ([...box.children].some(c => c.dataset.m === String(msg) && !c.classList.contains('out'))) return;
    const e = document.createElement('div'); e.className = 'toast ' + (kind || 'info');
    const ic = { good: '✅', bad: '⛔', warn: '⚠️', radar: '📸', info: 'ℹ️' }[kind || 'info'] || 'ℹ️', m = String(msg), lead = /^\p{Extended_Pictographic}/u.test(m);
    e.dataset.m = m; e.innerHTML = (lead ? '' : `<span class="ti-ic">${ic}</span>`) + `<span class="ti-tx">${esc(m)}</span>`; box.appendChild(e);
    while (box.children.length > 3) box.removeChild(box.firstChild);
    setTimeout(() => { e.classList.add('out'); setTimeout(() => e.remove(), 400); }, (dur || 2.4) * 1000);
  }
  UI.toast = toast;
  UI.violation = function (name, fine, reason) {
    const e = document.createElement('div'); e.className = 'violation';
    e.innerHTML = `<div class="vt">🚨 ${t('مخالفة', 'Violation')}: ${esc(name)}</div><div class="vf">🧾 ${fine} ${t('جنيه', 'EGP')}</div><div class="vr">${esc(reason)}</div><div class="vp">${t('اتسجلت عليك — بتتدفع في الكمين أو في المرور', 'Recorded — paid at a checkpoint or the traffic unit')}</div>`;
    $('#hud').appendChild(e); setTimeout(() => { e.classList.add('out'); setTimeout(() => e.remove(), 500); }, 3800);
  };
  UI.tripSummary = function (r) {
    const e = document.createElement('div'); e.className = 'trip';
    e.innerHTML = `<div class="tt">✅ ${t('توصيلة', 'Delivered')}: ${esc(r.name)}</div><div class="stars">${'★'.repeat(r.stars)}<i>${'★'.repeat(5 - r.stars)}</i></div>
      <div class="tl"><span>${t('الأجرة', 'Fare')} ${r.base}</span>${r.bonus ? `<span>⏱️ ${t('في الميعاد', 'On time')} +${r.bonus}</span>` : `<span class="bad">${t('متأخر', 'Late')} (${r.time}/${r.limit}${t('ث', 's')})</span>`}${r.tip ? `<span>🎁 ${t('بقشيش', 'Tip')} +${r.tip}</span>` : ''}</div><div class="tot">+${r.total} ${t('ج', 'EGP')}</div>`;
    $('#hud').appendChild(e); setTimeout(() => { e.classList.add('out'); setTimeout(() => e.remove(), 500); }, 4200);
  };
  UI.fuelEmpty = function (on) {
    const p = $('#fuelPanel'); p.classList.toggle('hidden', !on);
    if (!on) return;
    const have = S().jerry || 0, ng = G().L.gas.find(q => q.x > G().tuk.x - 3);
    p.innerHTML = `<b>⛽ ${t('البنزين خلص!', 'Out of fuel!')}</b><span>${ng ? t('أقرب بنزينة بعد ', 'Next station in ') + Math.round(ng.x - G().tuk.x) + t(' م — زقّه لحد هناك', ' m — coast there') : t('مفيش بنزينة قدام', 'No station ahead')}</span>
      <div class="row">${have ? `<button class="btn gold" id="efUse">🛢️ ${t('فضّي جركن (معاك ' + have + ')', 'Use a can (' + have + ' left)')}</button>` : ''}<button class="btn ${have ? '' : 'gold'}" id="efBtn">🏍️ ${t('اطلب حد يجيب جركن', 'Call for a can')} (${TT.JERRY.emergency} ${t('ج', 'EGP')})</button></div>`;
    if (have) $('#efUse').onclick = () => { TT.emergencyFuel(); UI.fuelEmpty(Save0().veh().fuel <= 0); };
    $('#efBtn').onclick = () => { const j = S().jerry; S().jerry = 0; TT.emergencyFuel(); S().jerry = j; };
  };
  const Save0 = () => TT.Save;
  /* ---------------- محطة البنزين ---------------- */
  UI.openFuel = function (gs) {
    const render = () => {
      const vp = TT.vehParams(), veh = TT.Save.veh(), price = TT.fuelPrice(), pct = Math.round(veh.fuel / vp.tank * 100);
      const full = Math.ceil((vp.tank - veh.fuel) * price), half = Math.ceil(Math.max(0, vp.tank * 0.5 - veh.fuel) * price);
      const b = openModal(`<div class="fuel-modal"><h3>⛽ ${esc(gs.name || t('بنزينة', 'Fuel station'))}</h3>
        <div class="tank"><div class="tank-bar"><i style="width:${pct}%"></i></div><b>${pct}%</b></div>
        <div class="fuel-opts">
          <button class="btn gold" data-f="1" ${full > 0 ? '' : 'disabled'}>⛽ ${t('فوّل لحد آخره', 'Fill up')}<small>${full} ${t('ج', 'EGP')}</small></button>
          <button class="btn" data-f="0.5" ${half > 0 ? '' : 'disabled'}>⛽ ${t('نص تانك', 'Half tank')}<small>${half} ${t('ج', 'EGP')}</small></button>
          <button class="btn" id="buyJ">🛢️ ${t('اشتري جركن احتياطي', 'Buy spare can')}<small>${TT.JERRY.priceStation} ${t('ج', 'EGP')} · ${t('معاك', 'have')} ${S().jerry || 0}</small></button>
        </div>
        <p class="hint">${t('الجركن بيزوّد 30% من التانك، وتقدر تفضّيه في أي وقت وانت واقف من زرار 🛢️', 'A can adds 30% of the tank — pour it any time you are stopped with 🛢️')}</p>
        <div class="row center"><button class="btn ghost" id="fClose">${t('خلاص', 'Done')}</button></div></div>`, 'small', 'fuel');
      b.querySelectorAll('[data-f]').forEach(btn => btn.onclick = () => { TT.refuel(+btn.dataset.f); render(); });
      b.querySelector('#buyJ').onclick = () => { TT.buyJerry(TT.JERRY.priceStation); render(); };
      b.querySelector('#fClose').onclick = closeModal;
    };
    render();
  };

  /* ---------------- passenger offer (station) ---------------- */
  UI.openOffer = function (st) {
    const render = (msg) => {
      const L = G().L, cap = TT.Save.model().seats || 3, free = cap - TT.Game.seatsUsed();
      if (!st.waiting.length) { closeModal(); return; }
      const cards = st.waiting.map(p => {
        const dist = L.stations[p.to].x - st.x, canSit = free >= p.seats;
        return `<div class="offer"><div class="pv" data-por="${p.id}"></div><div class="oi"><b>${ICONS[p.type] || ''} ${esc(t(p.T.name, p.T.en))}</b>
          <div>📍 ${t('إلى', 'To')}: <b>${esc(L.stations[p.to].name)}</b></div><div>📏 ${(dist / 1000).toFixed(2)} ${t('كم', 'km')} · ⏱️ ${p.timeLimit} ${t('ث', 's')}${p.seats > 1 ? ' · 💺×2' : ''}</div>
          <div class="fare">💰 ${p.fare} ${t('جنيه', 'EGP')}</div></div>
          <div class="ob">${canSit ? `<button class="btn gold" data-acc="${p.id}">✔ ${t('اتفضل اركب', 'Accept')}</button>${p.nego ? '' : `<button class="btn" data-neg="${p.id}">🤝 ${t('فاصل (+30%)', 'Haggle (+30%)')}</button>`}` : `<span class="full">${t('مفيش مكان', 'No room')}</span>`}</div></div>`;
      }).join('');
      const b = openModal(`<h3>🚏 ${esc(st.name)} <small>💺 ${free}/${cap} ${t('فاضي', 'free')}</small></h3>${msg ? `<div class="nego-msg">${esc(msg)}</div>` : ''}<div class="offers">${cards}</div><div class="row center"><button class="btn" id="offClose">${t('خلاص كده', 'Done')}</button></div>`, 'wide', 'offer');
      b.querySelectorAll('[data-por]').forEach(e => { const p = st.waiting.find(q => q.id === e.dataset.por); e.appendChild(portrait(p.look, 'wave', 64, 100, 1)); });
      b.querySelectorAll('[data-acc]').forEach(btn => btn.onclick = () => { const p = st.waiting.find(q => q.id === btn.dataset.acc); const r = TT.boardPassenger(p, false); if (!r.ok && r.msg) toast(r.msg, 'warn'); render(); });
      b.querySelectorAll('[data-neg]').forEach(btn => btn.onclick = () => { const p = st.waiting.find(q => q.id === btn.dataset.neg); const r = TT.boardPassenger(p, true); TT.Audio.play(r.nego === 'yes' ? 'cash' : 'error'); render('"' + r.msg + '"'); });
      b.querySelector('#offClose').onclick = closeModal;
    };
    render();
  };

  /* ---------------- NPC talk ---------------- */
  const TEMPER_HINT = { calm: ['شكله هادي', 'Looks calm'], stubborn: ['شكله عنيد', 'Looks stubborn'], hothead: ['شكله عصبي جدًا', 'Hot-headed'], coward: ['شكله خوّاف', 'Looks timid'] };
  UI.openTalk = function (npc) {
    let reply = npc.kind === 'bystander' ? t('أهلًا يا اسطى', 'Hello driver') : npc.kind === 'blocker' ? t('عايز إيه؟ أنا راكن هنا خمس دقايق بس', 'What? I\'m only parked 5 minutes') : t('انت خبطتني! هتعمل إيه دلوقتي؟', 'You hit me! What now?');
    const render = () => {
      const conflict = npc.kind !== 'bystander' && !npc.resolved;
      const opts = [['greet', '👋 ' + t('تحية', 'Greet')], ['apologize', '🙏 ' + t('اعتذار', 'Apologize')], ['move', '🚗 ' + t('ممكن توسّع الطريق؟', 'Please move')], ['complain', '📢 ' + t('شكوى', 'Complain')], ['argue', '🗯️ ' + t('جدال', 'Argue')], ['peace', '🕊️ ' + t('ربنا يهديك وأمشي', 'Let it go & walk away')], ['fight', '🥊 ' + t('تصعيد لخناقة', 'Escalate to a fight')]];
      const b = openModal(`<div class="talk"><div class="pv" id="talkPor"></div><div class="ti"><h3>${esc(npc.name)} <small>${t(TEMPER_HINT[npc.temper][0], TEMPER_HINT[npc.temper][1])}</small></h3>
        ${conflict ? `<div class="mood">😡 ${t('عصبيته', 'Anger')}<div class="meter"><i style="width:${npc.mood}%"></i></div></div>` : ''}
        <div class="reply">"${esc(reply)}"</div></div></div>
        <div class="talk-opts">${opts.map(([id, n]) => `<button class="btn ${id === 'fight' ? 'danger' : id === 'peace' ? 'gold' : ''}" data-o="${id}">${n}</button>`).join('')}</div>
        <p class="hint small-hint">💡 ${t('الخناقة كرتونية ومن غير دم، بس ليها عواقب: سمعة وغرامة وتأخير على الركاب.', 'Fights are cartoonish and bloodless but cost reputation, fines and time.')}</p>
        <div class="row center"><button class="btn ghost" id="talkClose">${t('امشي', 'Leave')}</button></div>`, 'wide', 'talk');
      b.querySelector('#talkPor').appendChild(portrait(npc.look, conflict ? (npc.mood > 60 ? 'angry' : 'talk') : 'wave', 90, 120, 1.15));
      b.querySelectorAll('[data-o]').forEach(btn => btn.onclick = () => {
        TT.Audio.play('click');
        const r = TT.talk(npc, btn.dataset.o);
        if (btn.dataset.o === 'fight') return;
        reply = r.reply || reply;
        if (r.end) { render(); setTimeout(() => { if (G().modal === 'talk') closeModal(); }, 1300); }
        else render();
      });
      b.querySelector('#talkClose').onclick = closeModal;
    };
    render();
  };
  UI.closeTalk = function () { if (G().modal === 'talk') closeModal(); };

  /* ---------------- chat question during ride ---------------- */
  UI.showChat = function (p, c) {
    const box = $('#chatBox'); box.classList.remove('hidden');
    box.innerHTML = `<div class="q">${ICONS[p.type] || '🧍'} <b>${esc(t(p.T.name, p.T.en))}:</b> ${esc(c.q)}</div><div class="opts">${c.a.map((a, i) => `<button class="btn small" data-a="${i}">${esc(a.t)}</button>`).join('')}</div><div class="cbar"><i></i></div>`;
    box.querySelectorAll('[data-a]').forEach(b => b.addEventListener('pointerdown', e => { e.preventDefault(); TT.answerChat(+b.dataset.a); }));
  };
  UI.hideChat = function () { $('#chatBox').classList.add('hidden'); };

  /* ---------------- الصلح أو البوكس ---------------- */
  UI.openMediation = function (npc, crowd) {
    const elder = { skin: '#9b6640', shirt: '#eceff1', pants: '#eceff1', galabeya: true, turban: '#fff', mustache: true, beard: true };
    const b = openModal(`<div class="talk"><div class="pv" id="medPor"></div><div class="ti"><h3>👥 ${t('الناس اتلمّت', 'A crowd gathered')} <small>(${crowd} ${t('واحد', 'people')})</small></h3>
      <div class="reply">"${t('يا جماعة صلّوا على النبي! اتصالحوا وكل واحد يروح لحاله… ولا نطلبلكم البوليس؟', 'Come on, make peace and go your ways… or shall we call the police?')}"</div></div></div>
      <p class="hint">${t('لو ما اتصالحتوش، البوكس هييجي ياخدكم على القسم، والمركبة هتتكلبش.', 'Without reconciliation the police truck takes you both and your vehicle gets clamped.')}</p>
      <div class="row center"><button class="btn gold" id="medYes">🤝 ${t('اتصالح', 'Make peace')}</button><button class="btn danger" id="medNo">✋ ${t('مش هصالح', 'Refuse')}</button></div>`, 'small', 'mediation');
    b.querySelector('#medPor').appendChild(portrait(elder, 'talk', 90, 120, 1.15));
    b.querySelector('#medYes').onclick = () => { closeModal(); TT.mediate(true); };
    b.querySelector('#medNo').onclick = () => { closeModal(); TT.mediate(false); };
  };
  /* ---------------- السواقة الحرة: بانر، سباق، استراحة، ورشة، ملخص ---------------- */
  UI.regionBanner = function (L, first) {
    const el = $('#regionBanner'), ic = CICONS[L.W.id] || WICONS[L.W.theme] || '🛣️';
    el.innerHTML = `<small>${first ? t('🛣️ السواقة الحرة — بداية الرحلة', '🛣️ Free drive — trip begins') : t('🛣️ دخلت منطقة جديدة', '🛣️ New region')}</small><b>${ic} ${t('أهلاً بيك في', 'Welcome to')} ${esc(t(L.W.name, L.W.en))}</b><span>⛽ ${L.gas.length} · ☕ ${L.rests.length} · 🔧 ${L.shops.length} · 🚏 ${L.stations.length}</span>`;
    el.classList.remove('hidden'); el.classList.remove('out'); clearTimeout(UI._rbT);
    UI._rbT = setTimeout(() => { el.classList.add('out'); setTimeout(() => el.classList.add('hidden'), 600); }, 3200);
  };
  UI.raceHud = function (g) {
    const el = $('#racePanel'), R = g.rival, RC = g.race;
    if (!R || !['offer', 'count', 'race'].includes(R.state)) { if (UI._raceKey) { UI._raceKey = ''; el.classList.add('hidden'); } return; }
    if (R.state === 'offer') {
      const key = 'offer' + R.name + R.initiator; if (UI._raceKey === key) return; UI._raceKey = key;
      const bets = R.initiator === 'npc' ? [R.bet] : TT.raceBets(), F = TT.freeData();
      el.innerHTML = `<div class="rp-head"><span class="rp-ic">🏁</span><div><b>${R.initiator === 'npc' ? esc(R.name) + ' ' + t('بيتحدّاك!', 'challenges you!') : t('تتحدّى', 'Challenge') + ' ' + esc(R.name) + '؟'}</b><small>${t('اكسب الرهان', 'Win the bet')} ×${(1.8 + 0.2 * Math.min(F.streak, 10)).toFixed(1)}${F.streak ? ' · 🔥 ' + t('سلسلة', 'streak') + ' ' + F.streak : ''}</small></div></div>
        <div class="rp-btns">${bets.map(b => `<button class="btn gold" data-bet="${b}">✅ ${fmt(b)} ${t('ج', 'EGP')}</button>`).join('')}<button class="btn ghost" id="rpNo">✖</button></div>`;
      el.querySelectorAll('[data-bet]').forEach(b => b.onpointerdown = e => { e.preventDefault(); TT.raceAccept(+b.dataset.bet); });
      el.querySelector('#rpNo').onpointerdown = e => { e.preventDefault(); TT.raceDecline(); };
      el.classList.remove('hidden'); return;
    }
    if (R.state === 'count' && RC) { const n = Math.ceil(RC.count), key = 'c' + n; if (UI._raceKey === key) return; UI._raceKey = key; el.innerHTML = `<div class="rp-count">${n > 0 ? n : t('يلا!', 'GO!')}</div><small>${t('الرهان', 'Bet')} ${fmt(RC.bet)} ${t('ج', 'EGP')} · ${RC.dist} ${t('م', 'm')}</small>`; el.classList.remove('hidden'); TT.Audio.play('beep'); return; }
    if (R.state === 'race' && RC) {
      UI._raceKey = 'race'; const T = g.tuk, lead = Math.round(T.x - R.x), left = Math.max(0, Math.round(RC.finishX - T.x)), pct = Math.min(100, (T.x - RC.startX) / RC.dist * 100), rp = Math.min(100, (R.x - RC.startX) / RC.dist * 100);
      el.innerHTML = `<div class="rp-race"><b class="${lead >= 0 ? 'win' : 'lose'}">${lead >= 0 ? '🥇 ' + t('إنت قدّام بـ', 'Ahead by') : '🥈 ' + t('إنت ورا بـ', 'Behind by')} ${Math.abs(lead)} ${t('م', 'm')}</b><span>🏁 ${left} ${t('م', 'm')}</span></div>
        <div class="rp-track"><i class="rv" style="left:${rp}%">🏎️</i><i class="me" style="left:${pct}%">🛺</i></div>`;
      el.classList.remove('hidden');
    }
  };
  UI.raceResult = function (win, RC) { const el = $('#regionBanner'); el.innerHTML = win ? `<b>🏆 ${t('كسبت السباق!', 'You won!')}</b><span>🔥 ${t('سلسلة الفوز', 'Win streak')} ×${TT.freeData().streak}</span>` : `<b>😞 ${t('خسرت السباق', 'You lost')}</b><span>${t('السلسلة رجعت صفر', 'Streak reset')}</span>`; el.classList.remove('hidden', 'out'); clearTimeout(UI._rbT); UI._rbT = setTimeout(() => { el.classList.add('out'); setTimeout(() => el.classList.add('hidden'), 600); }, 2600); };
  UI.openRest = function (q) {
    const render = () => {
      const g = G(), fat = Math.round(g.fatigue || 0);
      const b = openModal(`<div class="rest-box"><h3>☕ ${esc(q.name)}</h3>
        <div class="tank"><div class="tank-bar fat"><i style="width:${fat}%"></i></div><b>😴 ${fat}%</b></div>
        <div class="fuel-opts">
          <button class="btn" data-r="tea">🫖 ${t('كوباية شاي', 'Cup of tea')}<small>10 ${t('ج', 'EGP')} · ${t('التعب -45', 'fatigue -45')}</small></button>
          <button class="btn gold" data-r="meal">🍲 ${t('أكلة محترمة', 'Proper meal')}<small>35 ${t('ج', 'EGP')} · ${t('التعب يروح خالص + سمعة', 'no fatigue + reputation')}</small></button>
          <button class="btn" data-r="sleep">🛏️ ${t('نام 3 ساعات', 'Sleep 3 hours')}<small>${t('ببلاش · الوقت يعدّي', 'free · time passes')}</small></button>
        </div>
        <div class="row center"><button class="btn ghost" id="rClose">${t('يلا نكمّل', 'Back on the road')}</button></div></div>`, 'small', 'rest');
      b.querySelectorAll('[data-r]').forEach(x => x.onclick = () => { if (TT.rest(x.dataset.r)) { toast(t('ارتحت شوية 😌', 'Feeling better 😌'), 'good'); render(); } });
      b.querySelector('#rClose').onclick = closeModal;
    }; render();
  };
  UI.openRoadShop = function (q) {
    const render = () => {
      const veh = TT.Save.veh(), dm = veh.damage; let all = 0; const MUL = 1.25;
      const rows = Object.keys(dm).map(k => { const c = Math.ceil(dm[k] * REPAIR[k] * MUL); all += c; const pct = Math.round((1 - dm[k]) * 100); return `<div class="part"><span>${t(PART_NAME[k][0], PART_NAME[k][1])}</span><div class="meter"><i style="width:${pct}%;background:${pct > 65 ? '#43a047' : pct > 35 ? '#f9a825' : '#e53935'}"></i></div><button class="btn ${c ? '' : 'off'}" data-fx="${k}" ${c ? '' : 'disabled'}>${c ? '🔧 ' + fmt(c) : '✓'}</button></div>`; }).join('');
      const b = openModal(`<div class="shop-box"><h3>🔧 ${esc(q.name)} <small>${t('أسعار الطريق أغلى 25%', 'Road prices +25%')}</small></h3><div class="parts">${rows}</div>
        <div class="row center"><button class="btn gold" id="sAll" ${all ? '' : 'disabled'}>🔧 ${t('صلّح الكل', 'Repair all')} — ${fmt(all)}</button>${all && S().money < all ? `<button class="btn debt" id="sDebt">🤝 ${t('بالدين', 'On credit')}</button>` : ''}<button class="btn ghost" id="sClose">${t('خلاص', 'Done')}</button></div></div>`, 'small', 'shop');
      const fix = ks => { let c = 0; for (const k of ks) c += Math.ceil(dm[k] * REPAIR[k] * MUL); if (!c || !spend(c)) return; TT.Save.ledger(t('ورشة الطريق', 'Road workshop'), -c, 'repair'); G().stats.repairs += c; for (const k of ks) { dm[k] = 0; if (k === 'body') veh.roofOff = false; } TT.Save.write(); TT.Audio.play('fuel'); G().smokeWarned = false; G().critWarned = false; G().dmgStart = 0; render(); };
      b.querySelectorAll('[data-fx]').forEach(x => x.onclick = () => fix([x.dataset.fx]));
      b.querySelector('#sAll').onclick = () => fix(Object.keys(dm));
      const sd = b.querySelector('#sDebt'); if (sd) sd.onclick = () => { if (!TT.Save.repairOnDebt(all, t('ورشة الطريق', 'Road workshop'))) { toast(t('الأسطى مش هيدّيك دين أكتر من ', 'Max credit ') + fmt(TT.Save.debtLimit()), 'bad'); return; } for (const k in dm) dm[k] = 0; veh.roofOff = false; TT.Save.write(); TT.Audio.play('fuel'); G().smokeWarned = false; G().critWarned = false; G().dmgStart = 0; toast(t('🤝 الأسطى صلّحها وكتبها عليك', '🤝 Repaired on credit'), 'good'); render(); };
      b.querySelector('#sClose').onclick = closeModal;
    }; render();
  };
  UI.freeSummary = function (r) {
    const b = openModal(`<div class="lvl-end free-end"><h3>${r.failed ? '💥 ' + t('الرحلة انتهت — المركبة فرقعت', 'Trip over — vehicle exploded') : '🛣️ ' + t('نهاية الرحلة', 'Trip complete')}</h3>
      <div class="fs-grid"><div><b>${r.km.toFixed(1)}</b><small>${t('كيلو', 'km')}</small></div><div><b class="${r.earned >= 0 ? 'in' : 'out'}">${r.earned >= 0 ? '+' : ''}${fmt(r.earned)}</b><small>${t('صافي الفلوس', 'net money')}</small></div><div><b>${r.wins}/${r.races}</b><small>${t('سباقات كسبتها', 'races won')}</small></div><div><b>${r.segs}</b><small>${t('مناطق عدّيتها', 'regions crossed')}</small></div><div><b>🔥 ${r.best}</b><small>${t('أحسن سلسلة', 'best streak')}</small></div></div>
      <div class="row center"><button class="btn big gold" id="fsAgain">🛣️ ${t('رحلة جديدة', 'New trip')}</button><button class="btn" id="fsGarage">🔧 ${t('الورشة', 'Workshop')}</button><button class="btn" id="fsMenu">🏠 ${t('القايمة', 'Menu')}</button></div></div>`, 'wide', 'end');
    b.querySelector('#fsAgain').onclick = () => { closeModal(); UI.openFreeStart(); };
    b.querySelector('#fsGarage').onclick = () => { closeModal(); G().mode = 'menu'; G().L = null; go('garage'); };
    b.querySelector('#fsMenu').onclick = () => { closeModal(); G().mode = 'menu'; G().L = null; go('menu'); };
  };
  UI.openFreeStart = function () {
    const F = TT.freeData(), d = S(), cur = F.seg % TT.FREE_ROUTE.length;
    const RN = TT.FREE_ROUTE.length, route = [0, 1, 2, 3, 4].map(k => { const id = TT.FREE_ROUTE[(cur + k) % RN], W = TT.WORLDS.find(w => w.id === id); return `<span class="fr-stop ${k === 0 ? 'cur' : ''}">${CICONS[W.id] || WICONS[W.theme]} ${esc(t(W.name, W.en))}</span>`; }).join('<i>←</i>') + `<i>… ${RN} ${t('مدينة', 'cities')}</i>`;
    const m = TT.Save.model();
    const b = openModal(`<div class="free-start"><h3>🛣️ ${t('السواقة الحرة', 'Free drive')} ${helpBtn('free')}</h3>
      <div class="fr-route">${route}</div>
      <div class="fr-stats"><span>📏 ${F.km.toFixed(1)} ${t('كم إجمالي', 'km total')}</span><span>🏆 ${F.wins} ${t('سباق', 'races')}</span><span>🔥 ${t('أحسن سلسلة', 'Best streak')} ${F.best}</span><span>🛺 ${esc(t(m.name, m.en))}</span></div>
      <div class="fr-feats"><span>☕ ${t('استراحات', 'Rest stops')}</span><span>⛽ ${t('بنزينات', 'Fuel')}</span><span>🔧 ${t('ورش', 'Workshops')}</span><span>🏁 ${t('سباقات برهان', 'Bet races')}</span><span>🧍 ${t('ركاب', 'Riders')}</span><span>🌦️ ${t('ليل ونهار ومطر', 'Day, night & rain')}</span></div>
      <div class="row center">${F.trip ? `<button class="btn big gold" id="frCont">▶ ${t('كمّل الرحلة', 'Continue trip')}</button><button class="btn" id="frNew">🆕 ${t('رحلة جديدة', 'New trip')}</button>` : `<button class="btn big gold" id="frNew">▶ ${t('يلا على الطريق', 'Hit the road')}</button>`}<button class="btn ghost" id="frX">${t('رجوع', 'Back')}</button></div></div>`, 'wide', 'free');
    const go2 = n => { closeModal(); if (d.settings.mode === 'vendor') { /* السواقة الحرة دايمًا ركاب */ } TT.Audio.init(); TT.Game.startFree(n); };
    if (F.trip) b.querySelector('#frCont').onclick = () => go2(false);
    b.querySelector('#frNew').onclick = () => go2(true);
    b.querySelector('#frX').onclick = closeModal;
  };

  /* ---------------- تذكير بالمهام اللي لسه ---------------- */
  UI.nag = function (items) {
    let el = $('#taskNag'); if (!el) { el = document.createElement('div'); el.id = 'taskNag'; el.className = 'task-nag'; $('#hud').appendChild(el); }
    el.innerHTML = `<span class="tn-ic">📌</span><div><b>${t('فيه مهمة لسه ما خلصتش', 'You still have an unfinished task')}</b><small>${items.map(esc).join(' · ')}</small></div><button class="info-btn" data-help="task">i</button>`;
    el.classList.remove('hidden', 'out'); TT.Audio.play('beep'); clearTimeout(UI._nagT);
    UI._nagT = setTimeout(() => { el.classList.add('out'); setTimeout(() => el.classList.add('hidden'), 400); }, 7000);
  };

  /* ---------------- التليفون ---------------- */
  UI.phone = function (P) {
    const el = $('#phoneUI');
    if (!P) { el.classList.add('out'); setTimeout(() => { if (!G().phone) el.classList.add('hidden'); }, 300); return; }
    el.classList.remove('hidden', 'out');
    const c = P.c, imp = ['🔕 ' + t('رقم مش مهم', 'Not important'), t('عادي', 'Normal'), '⭐ ' + t('مهم', 'Important'), '⭐⭐ ' + t('مهم جدًا', 'Very important')][c.imp] || '';
    const head = `<div class="ph-notch"></div><div class="ph-av" style="background:${c.bg}">${c.icon}</div><b class="ph-name">${esc(t(c.name, c.en))}</b><span class="ph-imp i${c.imp}">${imp}</span>`;
    if (P.state === 'ring') {
      el.className = 'phone-ui ring';
      el.innerHTML = head + `<div class="ph-status">📳 ${t('بيتصل بيك…', 'Calling…')}</div><div class="ph-btns"><button class="ph-no" id="phNo">✖<small>${t('تجاهل', 'Ignore')}</small></button><button class="ph-yes" id="phYes">📞<small>${t('رد', 'Answer')}</small></button></div><div class="ph-warn">${t('الرد وانت ماشي بيضايق الركاب', 'Answering while moving annoys riders')}</div>`;
      el.querySelector('#phYes').onpointerdown = e => { e.preventDefault(); TT.phoneAnswer(); };
      el.querySelector('#phNo').onpointerdown = e => { e.preventDefault(); TT.phoneIgnore(false); };
    } else if (P.state === 'talk') {
      el.className = 'phone-ui talk';
      const cur = P.cur || { who: 0, text: '…' };
      el.innerHTML = head + `<div class="ph-status">🟢 ${t('مكالمة جارية', 'On call')}</div><div class="ph-msg ${cur.who ? 'me' : 'them'}">${esc(cur.text)}</div><div class="ph-btns"><button class="ph-no" id="phEnd">📵<small>${t('اقفل', 'Hang up')}</small></button></div>`;
      el.querySelector('#phEnd').onpointerdown = e => { e.preventDefault(); if (P.c.mechanic && P.mp) { P.state = 'offer'; UI.phone(P); } else TT.phoneHang(); };
    } else if (P.state === 'offer') {
      el.className = 'phone-ui talk';
      el.innerHTML = head + `<div class="ph-msg them">🔧 ${esc(P.mp.name)}<br><b>${P.mp.cost} ${t('ج', 'EGP')}</b></div><div class="ph-btns"><button class="ph-no" id="phLater">⏳<small>${t('بعدين', 'Later')}</small></button><button class="ph-yes" id="phPay">💳<small>${t('ابعتله', 'Pay')}</small></button></div>`;
      el.querySelector('#phPay').onpointerdown = e => { e.preventDefault(); TT.phoneMech(true); };
      el.querySelector('#phLater').onpointerdown = e => { e.preventDefault(); TT.phoneMech(false); };
    }
  };

  /* ---------------- وحدة المرور: تجديد الرخصة كل 5 مراحل ---------------- */
  UI.openLicense = function (after) {
    const d = S(), rc = d.record || {}, list = d.pendingFines || [], due = TT.pendingTotal(), total = due + TT.LICENSE_FEE, left = (d.license || { left: 5 }).left;
    const groups = {}; for (const f of list) { const g = groups[f.kind] = groups[f.kind] || { n: 0, sum: 0 }; g.n++; g.sum += f.fine; }
    const acc = (rc.crashes || 0) + (rc.animals || 0), bad = acc + (rc.flips || 0) * 0.5 + (rc.explosions || 0) * 2 + list.length * 0.5;
    const grade = bad === 0 ? ['🏅', t('سواق مثالي — ولا غلطة!', 'Perfect driver — not a single mistake!'), 'g'] : bad < 4 ? ['👍', t('كويس، بس خلّي بالك شوية', 'Good, just be a bit more careful'), 'm'] : ['⚠️', t('محتاج تهدّى وتلتزم بالقواعد', 'You need to calm down and follow the rules'), 'b'];
    const cell = (ic, n, lab) => `<div class="lc"><span>${ic}</span><b>${n}</b><small>${lab}</small></div>`;
    const b = openModal(`<div class="lic-box"><h3>🏛️ ${t('وحدة المرور — تجديد الرخصة', 'Traffic unit — license renewal')}</h3>
      <p class="lic-sub">${left <= 0 ? t('الرخصة خلصت — جدّدها عشان تكمّل', 'Your license expired — renew to continue') : t('باقي', 'Remaining') + ' ' + left + ' ' + t('مراحل على التجديد — ممكن تجدد بدري', 'levels before renewal — you can renew early')}</p>
      <div class="lic-grid">${cell('🛣️', rc.levels || 0, t('مراحل', 'levels'))}${cell('💥', rc.crashes || 0, t('حوادث عربيات', 'car crashes'))}${cell('🐐', rc.animals || 0, t('خبط بهايم', 'animal hits'))}${cell('🙃', rc.flips || 0, t('انقلاب', 'flips'))}${cell('🔥', rc.explosions || 0, t('انفجار', 'explosions'))}${cell('🥊', rc.fights || 0, t('خناقات', 'fights'))}${cell('🚨', list.length, t('مخالفات', 'violations'))}</div>
      <div class="lic-grade ${grade[2]}">${grade[0]} ${grade[1]}</div>
      ${list.length ? `<div class="fine-list">${Object.entries(groups).map(([k, g]) => `<div><span>🚨 ${esc(t(TT.VIOLATIONS[k].name, TT.VIOLATIONS[k].en))} ×${g.n}</span><b>${fmt(g.sum)}</b></div>`).join('')}</div>` : ''}
      <div class="lic-total"><span>🧾 ${t('مخالفات', 'Fines')} ${fmt(due)} + 🪪 ${t('رسوم', 'fee')} ${TT.LICENSE_FEE}</span><b>= ${fmt(total)} ${t('ج', 'EGP')}</b></div>
      <div class="row center"><button class="btn gold big" id="licPay">💳 ${t('ادفع وجدّد', 'Pay & renew')}</button><button class="btn ghost" id="licBack">${t('رجوع', 'Back')}</button></div></div>`, 'wide', 'license');
    b.querySelector('#licPay').onclick = () => { const paid = TT.renewLicense(); toast(t('🪪 الرخصة اتجددت لـ 5 مراحل — دفعت ' + fmt(paid) + ' ج', '🪪 License renewed for 5 levels — paid ' + fmt(paid)), 'good', 3); closeModal(); after && after(); };
    b.querySelector('#licBack').onclick = () => { closeModal(); if (G().mode === 'menu' && UI.current === 'garage') renderGarage(); };
  };

  /* ---------------- تفتيش الشرطة ---------------- */
  UI.openPolice = function (c) {
    const officer = { skin: '#a8714a', shirt: '#1a237e', pants: '#1a237e', hair: '#111', cap: '#1a237e', mustache: true };
    const show = (html, pose) => { const b = openModal(`<div class="talk police"><div class="pv" id="polPor"></div><div class="ti">${html}</div></div>`, 'small', 'police'); b.querySelector('#polPor').appendChild(portrait(officer, pose || 'point', 90, 120, 1.15)); return b; };
    const finish0 = () => { closeModal(); TT.policeDone(c); };
    const finish = () => {
      const due = TT.pendingTotal(), list = S().pendingFines || [];
      if (!due) { finish0(); return; }
      const b2 = show(`<h3>📋 ${t('عليك مخالفات متسجلة', 'You have recorded fines')}</h3><div class="reply">"${t('عليك', 'You owe')} ${list.length} ${t('مخالفة بـ', 'fines totaling')} ${fmt(due)} ${t('جنيه يا اسطى، ادفع وكمّل', 'EGP, pay and carry on')}"</div>
        <div class="fine-list">${list.slice(-4).reverse().map(f => `<div><span>🚨 ${esc(t(TT.VIOLATIONS[f.kind].name, TT.VIOLATIONS[f.kind].en))}</span><b>${f.fine}</b></div>`).join('')}${list.length > 4 ? `<div class="more">+${list.length - 4} ${t('كمان', 'more')}</div>` : ''}</div>
        <div class="row center"><button class="btn gold" id="pPay">💳 ${t('ادفع', 'Pay')} ${fmt(due)} ${t('ج', 'EGP')}</button></div>`, 'point');
      b2.querySelector('#pPay').onclick = () => { const r = TT.payFines(); toast(t('دفعت ' + r.count + ' مخالفة', 'Paid ' + r.count + ' fines'), 'good'); finish0(); };
    };
    const testStep = () => {
      if (!TT.policeNeedsTest(c)) { finish(); return; }
      const b = show(`<h3>🧪 ${t('تحليل مخدرات', 'Drug test')}</h3><div class="reply">"${t('هنعملك تحليل سريع يا اسطى، إجراء روتيني', 'Quick routine drug test, driver')}"</div>
        <div class="row center"><button class="btn gold" id="pT1">✅ ${t('ماشي يا باشا', 'Sure, officer')}</button><button class="btn danger" id="pT2">❌ ${t('مش هعمل', 'Refuse')}</button></div>`);
      b.querySelector('#pT1').onclick = () => { const b2 = show(`<h3>🧪 ${t('جاري التحليل…', 'Testing…')}</h3><div class="test-anim"><span></span><span></span><span></span></div>`, 'idle'); setTimeout(() => { const tr = TT.policeStep(c, 'test', 'ok'); if (tr && tr.positive) { const bx = show(`<h3>❌ ${t('النتيجة: إيجابي!', 'Result: POSITIVE!')}</h3><div class="reply">"${t('التحليل طلع إيجابي يا حلو… اتفضل معانا على البوكس', 'Positive… into the truck')}"</div><div class="row center"><button class="btn danger" id="pArr">🚓 ${t('يا باشا أنا مظلوم!', 'I\'m innocent!')}</button></div>`, 'angry'); bx.querySelector('#pArr').onclick = () => { closeModal(); c.done = true; c.state = 'open'; c.inspecting = false; TT.policeArrest('drugs'); }; return; } const b3 = show(`<h3>✅ ${t('النتيجة: سلبي', 'Result: negative')}</h3><div class="reply">"${t('تمام يا اسطى، اتفضل', 'All good, go ahead')}"</div><div class="row center"><button class="btn gold" id="pDone">${t('شكرًا يا باشا', 'Thanks')}</button></div>`, 'wave'); b3.querySelector('#pDone').onclick = finish; }, 1800); };
      b.querySelector('#pT2').onclick = () => { TT.policeStep(c, 'test', 'refuse'); finish(); };
    };
    const b = show(`<h3>👮 ${c.patrol ? t('دورية مرور', 'Traffic patrol') : t('كمين مرور', 'Checkpoint')}</h3><div class="reply">"${t('الرخص والبطاقة يا اسطى', 'License and ID please')}"</div>
      <div class="lic">🪪 ${t('رخصتك سارية لـ', 'License valid for')} <b>${Math.max(0, (S().license || { left: 5 }).left)}</b> ${t('مراحل', 'levels')} · 🧾 ${t('مخالفات متسجلة', 'Recorded fines')}: <b>${fmt(TT.pendingTotal())}</b></div>
      <div class="row center"><button class="btn gold" id="pP1">📄 ${t('اتفضل الرخص والبطاقة', 'Here they are')}</button><button class="btn" id="pP2">😬 ${t('نسيتهم في البيت', 'Forgot them')}</button></div>`);
    const quizStep = () => {
      const Q = TT.POLICE_QS[Math.floor(Math.random() * TT.POLICE_QS.length)], opts = Q.a.map((x, i) => [x, i === 0]).sort(() => Math.random() - 0.5);
      const bq = show(`<h3>❓ ${t('سؤال من الظابط', 'Officer\'s question')}</h3><div class="reply">"${esc(Q.q)}"</div><div class="quiz-opts">${opts.map(([x, ok], i) => `<button class="btn" data-qa="${ok ? 1 : 0}">${esc(x)}</button>`).join('')}</div>`, 'talk');
      bq.querySelectorAll('[data-qa]').forEach(bb => bb.onclick = () => { const ok = bb.dataset.qa === '1'; TT.policeStep(c, 'quiz', ok ? 'right' : 'wrong'); if (ok) { toast(t('👮 كويس يا اسطى', '👮 Good answer'), 'good', 1.6); testStep(); } else { const bw = show(`<h3>😠 ${t('إجابة غلط!', 'Wrong answer!')}</h3><div class="reply">"${t('لأ يا حبيبي مش كده… اتكتبلك مخالفة', 'No… that\'s a fine')}"</div><div class="row center"><button class="btn gold" id="pQN">${t('حاضر يا باشا', 'Okay officer')}</button></div>`, 'angry'); bw.querySelector('#pQN').onclick = testStep; } });
    };
    b.querySelector('#pP1').onclick = () => { TT.policeStep(c, 'papers', 'show'); quizStep(); };
    b.querySelector('#pP2').onclick = () => { TT.policeStep(c, 'papers', 'forgot'); quizStep(); };
  };

  /* ---------------- السجن ---------------- */
  UI.jailScene = function (o) {
    const b = openModal(`<div class="jail-box"><div class="jail-cell"><div class="jail-pv" id="jailPor"></div><div class="jail-bars"></div><div class="tears"><i>💧</i><i>💧</i><i>💧</i><i>💧</i></div></div>
      <div class="jail-txt"><h3>🔒 ${o.reason === 'drugs' ? t('اتحجزت في القسم — تحليل إيجابي', 'Detained — positive drug test') : t('اتمسكت واترحّلت على القسم', 'Caught and taken to the station')}</h3>
      <div class="reply cry">"${esc(pick0(TT.LINES.jail))}"</div>
      <p class="hint">${o.reason === 'drugs' ? t('لازم تدفع غرامة عشان يفرجوا عنك، والمهمة فشلت.', 'Pay the fine to be released — the mission failed.') : t('هربت من الكمين والشرطة مسكتك. ادفع الغرامة عشان تخرج، والمهمة فشلت.', 'You fled the checkpoint and got caught. Pay to get out — mission failed.')}</p>
      <div class="row center"><button class="btn danger" id="jPay">💸 ${t('ادفع الغرامة', 'Pay fine')} ${fmt(o.fine)} ${t('ج', 'EGP')}</button></div></div></div>`, 'wide', 'jail');
    const pv = b.querySelector('#jailPor'); pv.appendChild(portrait(TT.driverLook(), 'apologize', 120, 170, 1.55));
    TT.Audio.play('error');
    b.querySelector('#jPay').onclick = () => { closeModal(); TT.jailPay(o.fine); };
  };
  const pick0 = a => a[Math.floor(Math.random() * a.length)];
  /* ---------------- الحادثة ---------------- */
  UI.openAccident = function (a) {
    const b = openModal(`<div class="acc-box"><h3>🚨 ${t('حادثة قافلة الطريق', 'Accident blocking the road')}</h3>
      <div class="reply">"${t('عربية خبطت واحد معدّي والناس اتلمّت… والعربيات كلها واقفة!', 'A car hit a pedestrian, a crowd gathered… traffic is stuck!')}"</div>
      <div class="fuel-opts"><button class="btn gold" data-ac="police">📞 ${t('اتصل بالبوليس والإسعاف', 'Call police & ambulance')}<small>${t('ببلاش · بياخدوا شوية وقت', 'free · takes a while')}</small></button>
      <button class="btn" data-ac="calm">🤝 ${t('راضي الناس وساعد المصاب', 'Calm them & help the injured')}<small>100 ${t('ج · أسرع وسمعة أحسن', 'EGP · faster, better rep')}</small></button></div>
      <div class="row center"><button class="btn ghost" id="acX">${t('رجوع', 'Back')}</button></div></div>`, 'small', 'accident');
    b.querySelectorAll('[data-ac]').forEach(x => x.onclick = () => { if (TT.accidentAct(a, x.dataset.ac) !== false) closeModal(); });
    b.querySelector('#acX').onclick = closeModal;
  };

  /* ---------------- خريطة الطريق الكبيرة ---------------- */
  UI.toggleBigMap = function (force) {
    const el = $('#bigMap'), g = G(); if (!g.L) return;
    const open = force != null ? force : el.classList.contains('hidden');
    el.classList.toggle('hidden', !open); if (!open) return;
    UI.renderBigMap();
  };
  UI.renderBigMap = function () {
    const el = $('#bigMap'), g = G(), L = g.L, T = g.tuk, X = x => (x / L.finish * 100).toFixed(2) + '%';
    let h = `<div class="bm-head"><b>🗺️ ${t('خريطة الطريق', 'Route map')}</b><span>${(T.x / 1000).toFixed(2)} / ${(L.finish / 1000).toFixed(2)} ${t('كم', 'km')}</span><button class="bm-x">✕</button></div><div class="bm-track"><div class="bm-line"></div>`;
    for (const z of L.zones.bridge) h += `<div class="bm-zone br" style="left:${X(z.a)};width:${((z.b - z.a) / L.finish * 100).toFixed(2)}%">🌉</div>`;
    for (const z of L.zones.tunnel) h += `<div class="bm-zone tn" style="left:${X(z.a)};width:${((z.b - z.a) / L.finish * 100).toFixed(2)}%">🚇</div>`;
    for (const z of L.zones.jam) h += `<div class="bm-zone jm" style="left:${X(z.a)};width:${((z.b - z.a) / L.finish * 100).toFixed(2)}%">🚗</div>`;
    L.stations.forEach((st, i) => {
      const drop = g.riding.filter(p => p.to === st.idx).length, wait = g.vendor ? st.buyers : st.waiting.length, passed = st.x < T.x - 8;
      h += `<div class="bm-st ${drop ? 'drop' : ''} ${wait && !passed ? 'wait' : ''} ${passed ? 'passed' : ''} ${i % 2 ? 'dn' : 'up'}" style="left:${X(st.x)}"><i></i><span>${drop ? '⬇ ' : ''}${esc(st.name)}${wait && !passed ? ' · ' + (g.vendor ? TT.GOODS[g.vendor.id].icon : '🧍') + wait : ''}</span></div>`;
    });
    for (const gs of L.gas) h += `<div class="bm-ic" style="left:${X(gs.x)}">⛽</div>`;
    for (const r of L.radars) h += `<div class="bm-ic radar" style="left:${X(r.x)}">📸<small>${r.limit}</small></div>`;
    for (const c of L.checkpoints) h += `<div class="bm-ic" style="left:${X(c.x)}">👮</div>`;
    for (const l of L.lights) h += `<div class="bm-ic sm" style="left:${X(l.x)}">🚦</div>`;
    h += `<div class="bm-ic fin" style="left:100%">🏁</div><div class="bm-me" style="left:${X(T.x)}">🛺</div></div>`;
    h += `<div class="bm-legend"><span class="lg drop">⬇ ${t('نزول ركابك', 'Your drop-offs')}</span><span class="lg wait">🧍 ${t('ركاب مستنيين', 'Waiting')}</span><span>⛽ ${t('بنزينة', 'Fuel')}</span><span>📸 ${t('رادار', 'Radar')}</span><span>👮 ${t('كمين', 'Checkpoint')}</span><span>🌉 ${t('كوبري', 'Bridge')}</span><span>🚇 ${t('نفق', 'Tunnel')}</span><span>🚗 ${t('زحمة', 'Jam')}</span></div>`;
    el.innerHTML = h;
    el.onpointerdown = e => { e.preventDefault(); UI.toggleBigMap(false); };
  };

  UI.openStation = function () {
    const b = openModal(`<div class="station-card"><div class="big">🚓</div><h3>${t('في قسم الشرطة', 'At the police station')}</h3>
      <p>${t('اتعملكم محضر خناقة في الطريق العام. قعدت ساعتين في الحجز لحد ما اتصالحتوا قدام الظابط.', 'A street-fight report was filed. You spent two hours in the holding cell until you made up in front of the officer.')}</p>
      <ul><li>🚨 ${t('غرامة مشاجرة', 'Fight fine')}: ${TT.VIOLATIONS.fight.fine} ${t('ج', 'EGP')}</li><li>🔒 ${t('المركبة متكلبشة — فك الكلبش', 'Vehicle clamped — release')}: ${TT.unclampCost} ${t('ج', 'EGP')}</li><li>🧍 ${t('الركاب اللي كانوا معاك مشيوا', 'Your riders left')}</li><li>⭐ ${t('السمعة', 'Reputation')} −8</li></ul>
      <div class="row center"><button class="btn gold" id="stOut">${t('خرجت من القسم', 'Leave the station')}</button></div></div>`, 'small', 'station');
    b.querySelector('#stOut').onclick = () => { closeModal(); TT.arrestDone(); };
  };

  /* ---------------- fight / flip ---------------- */
  UI.showFight = function (on) { $('#fightCtl').classList.toggle('hidden', !on); $('#controls').classList.toggle('hidden', on); };
  UI.showFlipPanel = function (on) { $('#flipPanel').classList.toggle('hidden', !on); if (on) $('#flipProg').style.width = '0%'; };
  UI.flipSelf = function () { TT.flipAction('self'); };

  /* ---------------- pause / end ---------------- */
  UI.togglePause = function (force) {
    const g = G(); if (g.mode !== 'play') return;
    if (g.modal && g.modal !== 'pause' && force !== true) return;
    if (g.modal === 'pause' && force !== true) { closeModal(); TT.Game.pause(false); return; }
    if (g.modal === 'pause') return;
    TT.Game.pause(true);
    const d = S();
    const b = openModal(`<h3>⏸ ${t('اللعبة واقفة', 'Paused')}</h3>
      <div class="menu-btns"><button class="btn big gold" id="pRes">▶ ${t('كمّل', 'Resume')}</button>
      ${g.free ? `<button class="btn danger" id="pEndFree">🏁 ${t('إنهاء الرحلة وشوف الحساب', 'End trip & see results')}</button>` : ''}
      <div class="row ${g.free ? 'hidden' : ''}"><button class="btn" id="pRestart">⟲ ${t('أعد المرحلة', 'Restart level')}</button><button class="btn" id="pLedger">📒 ${t('حسابات المرحلة', 'Level ledger')}</button></div>
      <div class="row"><label class="tog"><input type="checkbox" id="pSfx" ${d.settings.sfx ? 'checked' : ''}><span></span>${t('مؤثرات', 'SFX')}</label><label class="tog"><input type="checkbox" id="pMus" ${d.settings.music ? 'checked' : ''}><span></span>${t('موسيقى', 'Music')}</label></div>
      <button class="btn" id="pQuit">💾 ${t('احفظ واخرج للقايمة', 'Save & quit to menu')}</button></div>`, 'small', 'pause');
    b.querySelector('#pRes').onclick = () => { closeModal(); TT.Game.pause(false); };
    const pe = b.querySelector('#pEndFree'); if (pe) pe.onclick = () => { closeModal(); TT.Game.pause(false); TT.endFree(); };
    b.querySelector('#pRestart').onclick = () => modalMsg(t('تعيد المرحلة؟', 'Restart level?'), t('هتبدأ المرحلة من الأول (الفلوس اللي اتصرفت مش هترجع).', 'The level restarts (money already spent stays spent).'), [[t('أيوه', 'Yes'), () => { closeModal(); TT.Game.restart(); }], [t('لا', 'No'), () => { closeModal(); UI.togglePause(true); }]]);
    b.querySelector('#pLedger').onclick = () => { const s = g.stats; modalMsg('📒 ' + t('حسابات المرحلة', 'Level ledger'), levelTable(s), [[t('رجوع', 'Back'), () => { closeModal(); UI.togglePause(true); }]]); };
    b.querySelector('#pSfx').onchange = e => { d.settings.sfx = e.target.checked; applySettings(); TT.Save.write(); };
    b.querySelector('#pMus').onchange = e => { d.settings.music = e.target.checked; applySettings(); TT.Save.write(); };
    b.querySelector('#pQuit').onclick = () => { closeModal(); TT.Game.quit(); go('menu'); };
  };
  function levelTable(s) {
    const net = s.income + s.tips - s.fines - s.fuel - s.repairs;
    const pend = s.pend || 0;
    return `<table class="ltable"><tr><td>💵 ${t('أجرة وعملات', 'Fares & coins')}</td><td class="in">+${fmt(s.income)}</td></tr><tr><td>🎁 ${t('بقشيش', 'Tips')}</td><td class="in">+${fmt(s.tips)}</td></tr>
      <tr><td>⛽ ${t('وقود', 'Fuel')}</td><td class="out">-${fmt(s.fuel)}</td></tr><tr><td>🚨 ${t('مدفوعات مرور', 'Paid to police')}</td><td class="out">-${fmt(s.fines)}</td></tr>${pend ? `<tr class="pend"><td>🧾 ${t('مخالفات اتسجلت', 'Fines recorded')} (${s.violations}) <small>${t('بتتدفع في المرور', 'paid at traffic unit')}</small></td><td>${fmt(pend)}</td></tr>` : ''}<tr><td>🛠️ ${t('إنقاذ وإصلاح', 'Tow & repairs')}</td><td class="out">-${fmt(s.repairs)}</td></tr>
      <tr class="net"><td>${t('الصافي', 'Net')}</td><td>${net >= 0 ? '+' : ''}${fmt(net)}</td></tr></table>`;
  }
  UI.levelEnd = function (r) {
    const L = r.L, s = r.stats, d = S();
    const nextOpen = L.li + 1 < L.W.levels && r.stars >= 1;
    const b = openModal(`<div class="lvl-end"><h3>${r.reason === 'owner' ? '😭 ' + t('صاحب التوكتوك خده منك — المهمة فشلت', 'The owner took the tuk — mission failed') : r.reason === 'jail' ? '🔒 ' + t('اترحّلت على القسم — المهمة فشلت', 'Taken to the station — mission failed') : r.failed ? '💥 ' + t('المركبة فرقعت — الرحلة انتهت', 'Vehicle exploded — trip over') : r.stars ? '🏁 ' + t('وصلت نهاية الخط!', 'You reached the finish!') : '😕 ' + t('المهمة ما اكتملتش', 'Mission incomplete')}</h3>
      ${r.reason === 'owner' ? `<p class="hint">${t('رد على صاحب التوكتوك لما يتصل، ولو تجاهلته مرتين هيستناك في المحطة الجاية وياخده.', 'Answer the owner — ignore him twice and he takes the tuk.')}</p>` : r.reason === 'jail' ? `<p class="hint">${t('اقف للكمين دايمًا، والهروب من الشرطة آخرته القسم.', 'Always stop at checkpoints — running ends at the station.')}</p>` : ''}
      ${r.failed && !r.reason ? `<p class="hint">${t('روح الورشة وصلّح المحرك والهيكل قبل ما تطلع تاني.', 'Repair engine and body in the garage before driving again.')}</p>` : ''}
      <div class="le-grid"><div class="le-a"><div class="big-stars">${[1, 2, 3].map(i => `<span class="${i <= r.stars ? 'on' : ''}">★</span>`).join('')}</div>
      <div class="checks"><div class="${r.st1 ? 'ok' : ''}">${r.st1 ? '✅' : '❌'} ${r.vendor ? t('بعت', 'Sold') : t('وصّلت', 'Delivered')} ${s.delivered}/${L.required}</div><div class="${r.st2 ? 'ok' : ''}">${r.st2 ? '✅' : '❌'} ${t('الأجرة', 'Fares')} ${fmt(s.income + s.tips)}/${L.target}</div><div class="${r.st3 ? 'ok' : ''}">${r.st3 ? '✅' : '❌'} ${t('مخالفات', 'Fines')} ${s.violations} · ${t('انقلاب', 'Flips')} ${s.flips}</div></div>
      ${r.ch ? `<div class="checks"><div class="${r.ch.done ? 'ok' : ''}">${r.ch.done ? '✅' : '❌'} 🎯 ${esc(r.ch.text)}${r.ch.done ? ' (+' + r.ch.bonus + ')' : ''}</div></div>` : ''}
      ${r.rate ? `<div class="le-rate">${t('تقييم المرحلة', 'Level rating')}: <span>${'★'.repeat(r.rate)}<i>${'★'.repeat(5 - r.rate)}</i></span> ${r.rate}/5</div>` : ''}
      </div><div class="le-b">${levelTable(s)}</div></div><div class="meta">⭐ ${t('متوسط التقييم', 'Avg rating')} ${r.avg ? r.avg.toFixed(1) : '-'} · 🪙 ${s.coins} · 💰 ${t('رصيدك', 'Balance')} ${fmt(d.money)}</div>
      ${(d.license || { left: 5 }).left <= 0 ? `<div class="lic-due">🏛️ ${t('خلّصت 5 مراحل — لازم تعدّي على المرور تجدد الرخصة قبل المرحلة الجاية', 'You finished 5 levels — renew your license at the traffic unit before the next level')}</div>` : `<div class="lic-left">🪪 ${t('باقي على تجديد الرخصة', 'Levels until license renewal')}: <b>${(d.license || { left: 5 }).left}</b></div>`}
      <div class="row center sticky">${nextOpen ? `<button class="btn big gold" id="eNext">${t('المرحلة الجاية', 'Next level')} ▶</button>` : ''}<button class="btn" id="eRetry">⟲ ${t('إعادة', 'Retry')}</button><button class="btn" id="eGarage">🔧 ${t('المرآب', 'Garage')}</button><button class="btn" id="eMap">🗺️ ${t('الخريطة', 'Map')}</button></div></div>`, 'wide', 'end');
    if (nextOpen) b.querySelector('#eNext').onclick = () => { closeModal(); tryStart(L.wi, L.li + 1); };
    b.querySelector('#eRetry').onclick = () => { closeModal(); tryStart(L.wi, L.li); };
    b.querySelector('#eGarage').onclick = () => { closeModal(); G().mode = 'menu'; G().L = null; go('garage'); };
    b.querySelector('#eMap').onclick = () => { closeModal(); G().mode = 'menu'; G().L = null; UI.selWorld = L.wi; go('map'); };
  };

  /* ---------------- touch controls (multi-touch, hold) ---------------- */
  function bindHold(el, key) {
    const set = v => { UI.touch[key] = v; el.classList.toggle('down', v); TT.syncTouchInput(); };
    el.addEventListener('pointerdown', e => { e.preventDefault(); try { el.setPointerCapture(e.pointerId); } catch (er) { } set(true); TT.Audio.init(); });
    ['pointerup', 'pointercancel', 'lostpointercapture'].forEach(ev => el.addEventListener(ev, () => set(false)));
    el.addEventListener('contextmenu', e => e.preventDefault());
  }
  function bindTap(el, fn) { el.addEventListener('pointerdown', e => { e.preventDefault(); TT.Audio.init(); fn(); }); el.addEventListener('contextmenu', e => e.preventDefault()); }

  UI.init = function () {
    applyLang();
    document.querySelectorAll('[data-hold]').forEach(el => bindHold(el, el.dataset.hold));
    bindTap($('#btnHorn'), () => TT.horn());
    bindTap($('#btnAction'), () => TT.doAction());
    bindTap($('#btnExit'), () => { if (G().driver) TT.enterTuk(); else TT.exitTuk(); });
    bindTap($('#btnLights'), () => TT.toggleLights());
    bindTap($('#btnSub'), () => TT.toggleSub());
    bindTap($('#btnParty'), () => TT.toggleParty());
    bindTap($('#btnKick'), () => TT.kickOut());
    bindTap($('#btnJerry'), () => TT.useJerry());
    bindTap($('#btnKey'), () => TT.ignition());
    bindTap($('#btnCall'), () => TT.vendorCall());
    document.querySelector('#hud .route').addEventListener('pointerdown', e => { e.preventDefault(); UI.toggleBigMap(); });
    document.querySelector('#hud .route').style.pointerEvents = 'auto';
    bindTap($('#btnMode'), () => UI.setMode(TT.cycleMode()));
    bindTap($('#btnPause'), () => UI.togglePause());
    bindTap($('#fPush'), () => TT.fightAction('push'));
    bindTap($('#fDodge'), () => TT.fightAction('dodge'));
    bindTap($('#fPeace'), () => TT.fightAction('peace'));
    bindTap($('#flipSelf'), () => TT.flipAction('self'));
    bindTap($('#flipTow'), () => TT.flipAction('tow'));
    $('#flipSelf').textContent = '💪 ' + t('عدّله بنفسك (اضغط كذا مرة)', 'Push it back (tap repeatedly)');
    $('#flipTow').textContent = '🚛 ' + t('اطلب الونش (80 ج)', 'Call tow truck (80 EGP)');
    $('#flipTitle').textContent = '🙃 ' + t('التوكتوك مقلوب!', 'Tuk tuk flipped!');
    $('#fPush').innerHTML = '👐<br>' + t('زق', 'Push'); $('#fDodge').innerHTML = '↩️<br>' + t('تفادى', 'Dodge'); $('#fPeace').innerHTML = '🤝<br>' + t('صالح', 'Make peace');
    $('#fWarn').textContent = '❗ ' + t('خد بالك! هيزق — تفادى!', 'Watch out! Dodge!');
    $('#rotateMsg').textContent = t('لف الموبايل بالعرض عشان تلعب أحسن', 'Rotate your phone to landscape');
    $('#rotateOk').textContent = t('كمّل كده', 'Continue anyway');
    $('#rotateOk').onclick = () => { $('#rotate').classList.add('dismissed'); };
    // prevent page gestures on the game
    document.addEventListener('touchmove', e => { if (document.body.classList.contains('in-game')) e.preventDefault(); }, { passive: false });
    document.addEventListener('dblclick', e => e.preventDefault());
    applySettings();
    go('menu');
  };
})();
