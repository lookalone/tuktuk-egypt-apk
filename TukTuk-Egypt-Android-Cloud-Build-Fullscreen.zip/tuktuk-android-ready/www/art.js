/* =====================================================================
   art.js — كل الرسومات المؤقتة (Procedural Canvas art)
   كل الرسم هنا بالكود، ويمكن استبداله بصور PNG من مجلد assets لاحقًا
   (انظر TT.Assets في game.js و README.md).
   الإحداثيات: بكسل افتراضي، 1 متر = TT.PX بكسل. الاتجاه الأمامي = +x
   ===================================================================== */
(function () {
  const TT = window.TT;
  const PX = TT.PX = 48;            // pixels per meter
  const A = TT.Art = {};

  /* ---------------- helpers ---------------- */
  const hash = A.hash = function (n) { n = (n | 0) * 374761393 + 668265263; n = (n ^ (n >>> 13)) * 1274126177; n = n ^ (n >>> 16); return ((n >>> 0) % 100000) / 100000; };
  function rr(c, x, y, w, h, r) { r = Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2); c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  A.rr = rr;
  function shade(hex, f) { // f<0 darker, f>0 lighter
    let c = hex.replace('#', ''); if (c.length === 3) c = c.split('').map(ch => ch + ch).join('');
    let r = parseInt(c.substr(0, 2), 16), g = parseInt(c.substr(2, 2), 16), b = parseInt(c.substr(4, 2), 16);
    if (f < 0) { r *= 1 + f; g *= 1 + f; b *= 1 + f; } else { r += (255 - r) * f; g += (255 - g) * f; b += (255 - b) * f; }
    return 'rgb(' + (r | 0) + ',' + (g | 0) + ',' + (b | 0) + ')';
  }
  A.shade = shade;
  const FONT = '"Segoe UI", Tahoma, "Noto Sans Arabic", "DejaVu Sans", Arial, sans-serif';
  A.FONT = FONT;
  function text(c, s, x, y, size, color, align, bold, stroke) {
    c.font = (bold === false ? '' : 'bold ') + size + 'px ' + FONT;
    c.textAlign = align || 'center'; c.textBaseline = 'middle';
    c.direction = /[؀-ۿ]/.test(s) ? 'rtl' : 'ltr';
    if (stroke) { c.lineWidth = stroke; c.strokeStyle = 'rgba(0,0,0,.65)'; c.strokeText(s, x, y); }
    c.fillStyle = color || '#fff'; c.fillText(s, x, y);
  }
  A.text = text;
  function ell(c, x, y, rx, ry, fill) { c.beginPath(); c.ellipse(x, y, Math.abs(rx), Math.abs(ry), 0, 0, Math.PI * 2); if (fill) { c.fillStyle = fill; c.fill(); } }
  function line(c, x1, y1, x2, y2, w, col) { c.beginPath(); c.moveTo(x1, y1); c.lineTo(x2, y2); c.lineWidth = w; c.strokeStyle = col; c.lineCap = 'round'; c.stroke(); }

  /* =================================================================
     PEOPLE — هيكل عظمي كرتوني بزوايا مفاصل، نفس الملامح في كل الأوضاع
     ================================================================= */
  const P = Math.PI;
  // زوايا: 0 = لأسفل، موجب = لقدّام
  const POSES = {
    idle:      t => ({ hipL: 0.05, kneeL: 0, hipR: -0.05, kneeR: 0, shL: 0.1 + Math.sin(t * 2) * 0.03, elL: 0.15, shR: -0.1, elR: 0.15, lean: 0, head: Math.sin(t * 1.3) * 0.04 }),
    sit:       t => ({ hipL: P / 2, kneeL: -P / 2, hipR: P / 2 - 0.1, kneeR: -P / 2 + 0.1, shL: 0.5, elL: 0.6, shR: 0.4, elR: 0.6, lean: 0.03, head: Math.sin(t * 1.1) * 0.05, seated: true }),
    drive:     (t, o) => { const st = (o && o.steer) || 0; return { hipL: P / 2, kneeL: -P / 2, hipR: P / 2 - 0.1, kneeR: -P / 2 + 0.15, shL: 1.15 + st * 0.15, elL: 0.35, shR: 1.05 - st * 0.15, elR: 0.45, lean: 0.12 + st * 0.06, head: Math.sin(t * 0.7) * 0.06 + (o && o.look || 0), seated: true }; },
    walk:      t => { const s = Math.sin(t * 8); return { hipL: s * 0.5, kneeL: -Math.max(0, -s) * 0.7, hipR: -s * 0.5, kneeR: -Math.max(0, s) * 0.7, shL: -s * 0.45, elL: 0.3, shR: s * 0.45, elR: 0.3, lean: 0.05, bob: Math.abs(Math.cos(t * 8)) * 2 }; },
    run:       t => { const s = Math.sin(t * 13); return { hipL: s * 0.9, kneeL: -0.4 - Math.max(0, -s) * 1.1, hipR: -s * 0.9, kneeR: -0.4 - Math.max(0, s) * 1.1, shL: -s * 0.9, elL: 1.2, shR: s * 0.9, elR: 1.2, lean: 0.25, bob: Math.abs(Math.cos(t * 13)) * 4 }; },
    point:     t => ({ hipL: 0.05, kneeL: 0, hipR: -0.05, kneeR: 0, shL: 2.0 + Math.sin(t * 6) * 0.08, elL: 0.05, shR: -0.1, elR: 0.2, lean: 0, head: 0 }),
    wave:      t => ({ hipL: 0.05, kneeL: 0, hipR: -0.05, kneeR: 0, shL: 2.6, elL: 0.4 + Math.sin(t * 10) * 0.5, shR: -0.1, elR: 0.2, lean: 0, head: 0.05 }),
    talk:      t => ({ hipL: 0.05, kneeL: 0, hipR: -0.05, kneeR: 0, shL: 0.6 + Math.sin(t * 5) * 0.3, elL: 0.9 + Math.sin(t * 7) * 0.3, shR: 0.1, elR: 0.3, lean: 0.03, head: Math.sin(t * 4) * 0.06, talk: true }),
    angry:     t => ({ hipL: 0.25, kneeL: 0, hipR: -0.25, kneeR: 0, shL: 0.5 + Math.sin(t * 14) * 0.25, elL: 1.6, shR: 0.3 + Math.sin(t * 14 + 1) * 0.2, elR: 1.6, lean: 0.12, head: Math.sin(t * 12) * 0.05, talk: true }),
    apologize: t => ({ hipL: 0.05, kneeL: 0, hipR: -0.05, kneeR: 0, shL: 1.1, elL: 1.3, shR: 1.0, elR: 1.4, lean: 0.35 + Math.sin(t * 3) * 0.05, head: 0.25 }),
    argue:     t => { const s = Math.sin(t * 9); return { hipL: 0.2, kneeL: 0, hipR: -0.2, kneeR: 0, shL: 1.2 + s * 0.6, elL: 0.8 - s * 0.4, shR: 0.6 - s * 0.5, elR: 1.0, lean: 0.1 + s * 0.05, head: s * 0.08, talk: true }; },
    windup:    t => ({ hipL: 0.35, kneeL: -0.2, hipR: -0.35, kneeR: 0, shL: -1.2, elL: 1.4, shR: 0.4, elR: 1.2, lean: -0.2, head: -0.05 }),
    push:      t => ({ hipL: 0.5, kneeL: -0.3, hipR: -0.45, kneeR: 0, shL: 1.55, elL: 0.05, shR: 1.45, elR: 0.1, lean: 0.35, head: 0.05 }),
    dodge:     t => ({ hipL: -0.3, kneeL: -0.6, hipR: -0.7, kneeR: -0.4, shL: 1.2, elL: 1.6, shR: 2.4, elR: 1.0, lean: -0.55, head: -0.25, crouch: 8 }),
    stumble:   t => ({ hipL: -0.5, kneeL: -0.2, hipR: 0.3, kneeR: -0.5, shL: 2.4 + Math.sin(t * 15) * 0.4, elL: 0.3, shR: -2.2 + Math.sin(t * 15) * 0.4, elR: 0.3, lean: -0.3, head: -0.2 }),
    celebrate: t => ({ hipL: 0.2, kneeL: -Math.abs(Math.sin(t * 8)) * 0.4, hipR: -0.2, kneeR: -Math.abs(Math.sin(t * 8)) * 0.4, shL: 2.8, elL: 0.3, shR: 2.7, elR: 0.3, lean: 0, head: -0.1, bob: Math.abs(Math.sin(t * 8)) * 8 }),
    surprised: t => ({ hipL: 0.15, kneeL: 0, hipR: -0.15, kneeR: 0, shL: 2.3, elL: 0.6, shR: 2.2, elR: 0.6, lean: -0.15, head: -0.1 }),
    dizzy:     t => ({ hipL: 0.15 + Math.sin(t * 3) * 0.1, kneeL: -0.1, hipR: -0.15, kneeR: -0.1, shL: 0.6, elL: 0.5, shR: -0.5, elR: 0.5, lean: Math.sin(t * 3) * 0.2, head: Math.sin(t * 3.4) * 0.25 }),
    fallen:    t => ({ hipL: 0.4, kneeL: -0.6, hipR: 0.1, kneeR: -0.2, shL: 2.6, elL: 0.3, shR: 1.8, elR: 0.5, lean: 0, head: 0.1, rot: -P / 2, ox: 46 }),
    pedal:     (t, o) => { const ph = (o && o.pedal != null) ? o.pedal : t * 6, a = Math.sin(ph), b = Math.cos(ph); return { hipL: 1.0 + a * 0.4, kneeL: -1.25 + b * 0.45, hipR: 1.0 - a * 0.4, kneeR: -1.25 - b * 0.45, shL: 1.25, elL: 0.25, shR: 1.15, elR: 0.35, lean: 0.38, head: -0.2, seated: true }; },
    skate:     t => ({ hipL: 0.28, kneeL: -0.38, hipR: -0.32, kneeR: -0.22, shL: 1.5 + Math.sin(t * 2) * 0.1, elL: 0.25, shR: -1.1 + Math.sin(t * 2 + 1) * 0.1, elR: 0.35, lean: 0.14, head: -0.08, crouch: 4 }),
    cheer:     t => ({ hipL: 0.1, kneeL: 0, hipR: -0.1, kneeR: 0, shL: 2.7 + Math.sin(t * 9) * 0.25, elL: 0.3, shR: 0.4, elR: 1.2, lean: 0, head: Math.sin(t * 5) * 0.08, talk: true }),
    repair:    t => ({ hipL: P / 2.2, kneeL: -P / 1.6, hipR: P / 3, kneeR: -P / 1.8, shL: 1.4 + Math.sin(t * 12) * 0.3, elL: 0.5, shR: 1.1, elR: 0.8, lean: 0.6, head: 0.3, crouch: 16 })
  };
  A.POSES = POSES;

  function limb(c, x, y, a1, a2, l1, l2, w, col, f) {
    const jx = x + Math.sin(a1) * l1 * f, jy = y + Math.cos(a1) * l1;
    const ex = jx + Math.sin(a1 + a2) * l2 * f, ey = jy + Math.cos(a1 + a2) * l2;
    c.strokeStyle = col; c.lineWidth = w; c.lineCap = 'round'; c.lineJoin = 'round';
    c.beginPath(); c.moveTo(x, y); c.lineTo(jx, jy); c.lineTo(ex, ey); c.stroke();
    return { jx, jy, ex, ey, ang: a1 + a2 };
  }

  /** draw a person. (x,y) = feet on ground. look = TT.PASSENGER_TYPES.look / TT.DRIVERS.look */
  A.person = function (c, x, y, look, poseName, t, o) {
    o = o || {};
    const s = o.scale || 1, f = 1; // facing handled by scale
    const facing = o.facing || 1;
    let p = (POSES[poseName] || POSES.idle)(t || 0, o);
    if (o.blend && POSES[o.blend.from]) { // linear blend for smooth transitions
      const q = POSES[o.blend.from](t, o), k = o.blend.k;
      const m = {}; for (const key in p) m[key] = typeof p[key] === 'number' && typeof q[key] === 'number' ? q[key] + (p[key] - q[key]) * k : p[key];
      p = m;
    }
    const L = look || {};
    if (L.sheet && !o.procedural && drawSheet(c, x, y, L, poseName, t || 0, o)) return;
    const small = L.small || 1;
    c.save();
    c.translate(x, y - (p.bob || 0) * s);
    c.scale(s * small * facing, s * small);
    if (p.ox) c.translate(p.ox, 0);
    if (p.rot) { c.translate(0, -6); c.rotate(p.rot); c.translate(0, 6); }
    if (!p.seated && !o.noShadow) { c.globalAlpha = 0.25; ell(c, 0, 1, 16, 3.5, '#000'); c.globalAlpha = 1; }
    const crouch = p.crouch || 0;
    const hipX = 0, hipY = -34 + crouch;
    const lean = p.lean || 0;
    const shX = hipX + Math.sin(lean) * 28, shY = hipY - Math.cos(lean) * 28;
    const skin = L.skin || '#c98f62', shirt = L.shirt || '#888', pants = L.pants || '#333';
    const dark = shade(pants, -0.25), shirtD = shade(shirt, -0.2), skinD = shade(skin, -0.15);
    const shoe = L.astro ? '#ddd' : '#2b1d14';
    const longRobe = L.galabeya || L.dress;
    // back leg + arm
    const lb = limb(c, hipX - 2, hipY, p.hipR, p.kneeR, 17, 17, 9, longRobe ? shade(shirt, -0.3) : dark, f);
    ell(c, lb.ex + 3, lb.ey + 1, 6, 3.4, shoe);
    const ab = limb(c, shX - 2, shY + 3, p.shR, p.elR, 13, 12, 7, shirtD, f);
    ell(c, ab.ex, ab.ey, 3.6, 3.6, skinD);
    // front leg
    const lf = limb(c, hipX + 2, hipY, p.hipL, p.kneeL, 17, 17, 9.5, longRobe ? shade(shirt, -0.15) : pants, f);
    ell(c, lf.ex + 3, lf.ey + 1, 6.3, 3.6, shoe);
    if (L.shorts) { limb(c, hipX + 2, hipY, p.hipL, 0, 9, 0, 10.5, pants, f); limb(c, hipX - 2, hipY, p.hipR, 0, 9, 0, 10, dark, f); }
    // robe (galabeya / dress)
    if (longRobe) {
      const hem = p.seated ? hipY + 4 : Math.min(-5, Math.max(lf.jy, lb.jy) + 8);
      const fx = p.seated ? hipX + 20 : (lf.jx + lb.jx) / 2 + 3;
      c.fillStyle = shirt; c.beginPath();
      c.moveTo(shX - 10, shY + 2); c.lineTo(shX + 10, shY + 2);
      c.lineTo(fx + 14, hem); c.lineTo(fx - 14, hem); c.closePath(); c.fill();
      c.strokeStyle = shirtD; c.lineWidth = 1; c.stroke();
    }
    // torso
    c.save(); c.translate(hipX, hipY); c.rotate(lean);
    c.fillStyle = shirt; rr(c, -10, -30, 20, 32, 7); c.fill();
    if (L.belly) { ell(c, 6, -10, 11, 12, shirt); }
    if (L.vest) { c.fillStyle = L.vest; rr(c, -10, -29, 9, 26, 4); c.fill(); rr(c, 2, -29, 8, 26, 4); c.fill(); }
    if (L.stripes) { c.fillStyle = '#fff'; c.fillRect(-10, -18, 20, 2.2); c.fillRect(-10, -12, 20, 2.2); }
    if (L.tie) { c.fillStyle = L.tie; c.beginPath(); c.moveTo(4, -28); c.lineTo(8, -28); c.lineTo(7, -12); c.lineTo(5, -10); c.closePath(); c.fill(); }
    if (L.bag) { c.fillStyle = L.bag; rr(c, -18, -27, 9, 20, 3); c.fill(); }
    if (L.astro) { c.fillStyle = '#9aa7b6'; rr(c, -17, -27, 8, 20, 3); c.fill(); c.fillStyle = '#f26a3c'; c.fillRect(-3, -22, 6, 4); }
    if (!longRobe && !p.seated) { c.fillStyle = dark; c.fillRect(-10, -2, 20, 4); }
    c.restore();
    // front arm
    const af = limb(c, shX + 2, shY + 3, p.shL, p.elL, 13, 12, 7.5, shirt, f);
    ell(c, af.ex, af.ey, 4, 4, skin);
    if (L.camera && poseName !== 'drive') { c.fillStyle = '#222'; rr(c, af.ex - 2, af.ey - 4, 9, 6, 1.5); c.fill(); }
    if (L.sack) { c.fillStyle = '#c9a76b'; ell(c, ab.ex - 2, ab.ey + 7, 7, 9); c.fill(); }
    if (L.stick && !p.seated) { line(c, af.ex, af.ey, af.ex + 4, 0, 2.5, '#6b4423'); }
    // head
    const hx = shX + Math.sin(lean) * 4, hy = shY - 4;
    c.save(); c.translate(hx, hy); c.rotate((p.head || 0) + lean * 0.4);
    const hr = L.alien ? 13 : 12;
    // neck
    c.fillStyle = skinD; c.fillRect(-3, -4, 6, 6);
    const cy = -13;
    if (L.astro) { ell(c, 1, cy, 15, 15, 'rgba(200,230,255,.35)'); }
    ell(c, 0, cy, hr, hr * (L.alien ? 1.15 : 1), skin);
    if (L.hijab) {
      c.fillStyle = L.hijab; c.beginPath(); c.arc(0, cy, hr + 3, P * 0.62, P * 2.32, false); c.lineTo(-4, cy + hr + 6); c.closePath(); c.fill();
      ell(c, 3, cy + 1, 8, 9.5, skin);
    } else if (!L.alien && !L.astro) {
      // hair
      c.fillStyle = L.hair || '#1b1410'; c.beginPath(); c.arc(0, cy, hr, P * 1.05, P * 1.95); c.closePath(); c.fill();
      c.fillRect(-hr, cy - 3, 5, 9);
    }
    // ear
    if (!L.hijab && !L.alien) ell(c, -2, cy + 1, 3, 4, skinD);
    // face
    const ex = 6, ey = cy - 2;
    const expr = o.expr || (poseName === 'angry' || poseName === 'argue' || poseName === 'windup' || poseName === 'push' ? 'angry' : poseName === 'celebrate' ? 'happy' : poseName === 'surprised' || poseName === 'stumble' || poseName === 'dodge' ? 'surprised' : poseName === 'dizzy' || poseName === 'fallen' ? 'dizzy' : poseName === 'apologize' ? 'sad' : 'normal');
    if (L.alien) {
      ell(c, 4, cy - 3, 4.5, 5.5, '#111'); ell(c, 11, cy - 3, 3.5, 5, '#111'); ell(c, 5, cy - 4.5, 1.4, 1.6, '#fff');
      line(c, -2, cy - hr, -6, cy - hr - 10, 1.6, skinD); ell(c, -6, cy - hr - 11, 2.5, 2.5, '#ff5ab0');
      line(c, 4, cy - hr, 6, cy - hr - 11, 1.6, skinD); ell(c, 6, cy - hr - 12, 2.5, 2.5, '#ff5ab0');
    } else if (expr === 'dizzy') {
      c.strokeStyle = '#222'; c.lineWidth = 1.2; c.beginPath();
      for (let i = 0; i < 12; i++) { const a = i * 0.8 + t * 8, r = i * 0.33; c.lineTo(ex + Math.cos(a) * r, ey + Math.sin(a) * r); }
      c.stroke();
    } else {
      ell(c, ex, ey, 2.6, expr === 'surprised' ? 3.6 : 3, '#fff'); ell(c, ex + 0.9, ey + 0.3, 1.5, 1.7, '#111');
      if (L.glasses) { c.strokeStyle = '#222'; c.lineWidth = 1.1; c.strokeRect(ex - 3.5, ey - 3, 7, 6); }
      if (L.shades) { c.fillStyle = '#111'; rr(c, ex - 4, ey - 3, 10, 5, 2); c.fill(); }
      // brows
      c.strokeStyle = '#1b1410'; c.lineWidth = 1.8; c.beginPath();
      if (expr === 'angry') { c.moveTo(ex - 3, ey - 6); c.lineTo(ex + 4, ey - 3.5); }
      else if (expr === 'sad') { c.moveTo(ex - 3, ey - 3.8); c.lineTo(ex + 4, ey - 6); }
      else if (expr === 'surprised') { c.moveTo(ex - 3, ey - 7.5); c.lineTo(ex + 4, ey - 7.5); }
      else { c.moveTo(ex - 3, ey - 5.5); c.lineTo(ex + 4, ey - 5.5); }
      c.stroke();
    }
    // nose
    if (!L.alien) { ell(c, hr - 0.5, cy + 1.5, 3.4, 3, shade(skin, -0.08)); }
    if (L.mustache) { c.fillStyle = '#1b1410'; c.beginPath(); c.ellipse(hr - 3, cy + 5.4, 6, 2.3, -0.1, 0, P * 2); c.fill(); }
    if (L.beard) { c.fillStyle = 'rgba(40,30,25,.85)'; c.beginPath(); c.arc(3, cy + 4, 9.5, 0.1, P * 0.9); c.fill(); }
    // mouth
    const talking = p.talk || o.talk;
    const mo = talking ? Math.abs(Math.sin(t * 14)) * 3 : 0;
    c.fillStyle = '#5a1f1f';
    if (expr === 'happy') { c.beginPath(); c.arc(hr - 5, cy + 7, 4, 0.1, P - 0.1); c.fill(); }
    else if (expr === 'surprised') { ell(c, hr - 5, cy + 8.5, 2.2, 3, '#5a1f1f'); }
    else if (expr === 'angry' || talking) { ell(c, hr - 5, cy + 8.5, 3.4, 1 + mo, '#5a1f1f'); }
    else if (!L.alien) { line(c, hr - 8, cy + 8.5, hr - 3, cy + 8, 1.4, '#5a1f1f'); }
    // headwear
    if (L.taqiya) { c.fillStyle = L.taqiya; c.beginPath(); c.arc(0, cy - 3, hr + 0.5, P, 0); c.closePath(); c.fill(); c.strokeStyle = shade(L.taqiya, -0.2); c.lineWidth = 1; c.stroke(); }
    if (L.cap) { c.fillStyle = L.cap; c.beginPath(); c.arc(0, cy - 4, hr, P, 0); c.closePath(); c.fill(); }
    if (L.capBack) { c.fillStyle = L.capBack; c.beginPath(); c.arc(0, cy - 3, hr + 0.5, P, 0); c.closePath(); c.fill(); rr(c, -hr - 8, cy - 5, 11, 3.5, 1.5); c.fill(); }
    if (L.beret) { c.fillStyle = L.beret; c.beginPath(); c.ellipse(1, cy - 8, hr + 2, 6, -0.1, 0, P * 2); c.fill(); }
    if (L.turban) { c.fillStyle = L.turban; c.beginPath(); c.ellipse(0, cy - 8, hr + 2, 7, 0, 0, P * 2); c.fill(); c.strokeStyle = shade(L.turban, -0.25); c.lineWidth = 1; c.beginPath(); c.moveTo(-hr, cy - 7); c.quadraticCurveTo(0, cy - 12, hr, cy - 6); c.stroke(); }
    if (L.hat) { c.fillStyle = L.hat; ell(c, 0, cy - 7, hr + 9, 3.5); c.fill(); c.beginPath(); c.arc(0, cy - 7, hr - 2, P, 0); c.fill(); c.fillStyle = '#b03a2e'; c.fillRect(-hr + 2, cy - 10, (hr - 2) * 2, 2.2); }
    if (L.astro) { c.strokeStyle = 'rgba(255,255,255,.7)'; c.lineWidth = 2; c.beginPath(); c.arc(1, cy, 15, P * 1.2, P * 1.6); c.stroke(); }
    c.restore();
    // kid next to mom
    if (L.kid && !p.seated && !o.noKid) {
      c.restore(); c.save();
      A.person(c, x - 18 * s * facing, y, TT.KID_LOOK, poseName === 'walk' ? 'walk' : 'idle', t + 0.4, { scale: s, facing: facing });
    }
    c.restore();
    // dizzy stars
    if ((expr === 'dizzy' || o.stars) && !o.noStars) {
      for (let i = 0; i < 3; i++) { const a = t * 4 + i * 2.1; A.star(c, x + Math.cos(a) * 14 * s, y - 92 * s + Math.sin(a) * 4 * s, 4 * s, '#ffd400'); }
    }
  };

  /* ---------- sprite sheets: صف لكل وضع، وأعمدة = frames ---------- */
  function drawSheet(c, x, y, L, poseName, t, o) {
    const Ly = (TT.ASSET_MANIFEST || {}).sheetLayout; if (!Ly) return false;
    const img = A.img(A.P.sheet(L.sheet)); if (!img) return false;
    const row = Ly.poses.indexOf(poseName); if (row < 0) return false;
    const per = (Ly.periods && Ly.periods[poseName]) || 1;
    const col = Math.floor((((t % per) + per) % per) / per * Ly.frames) % Ly.frames;
    const s = (o.scale || 1), facing = o.facing || 1, seated = poseName === 'sit' || poseName === 'drive';
    c.save(); c.translate(x, y);
    if (!seated && !o.noShadow) { c.globalAlpha = 0.25; ell(c, 0, 1, 16 * s * (L.small || 1), 3.5 * s, '#000'); c.globalAlpha = 1; }
    c.scale(s * facing * Ly.scale, s * Ly.scale);
    c.drawImage(img, col * Ly.cellW, row * Ly.cellH, Ly.cellW, Ly.cellH, -Ly.anchorX, -Ly.anchorY, Ly.cellW, Ly.cellH);
    c.restore();
    if (L.kid && !seated && !o.noKid) A.person(c, x - 18 * s * facing, y, TT.KID_LOOK, poseName === 'walk' ? 'walk' : 'idle', t + 0.4, { scale: s, facing });
    if (poseName === 'dizzy' || poseName === 'fallen' || o.stars) for (let i = 0; i < 3; i++) { const a = t * 4 + i * 2.1; A.star(c, x + Math.cos(a) * 14 * s, y - 92 * s + Math.sin(a) * 4 * s, 4 * s, '#ffd400'); }
    return true;
  }

  A.star = function (c, x, y, r, col) {
    c.beginPath();
    for (let i = 0; i < 10; i++) { const a = -P / 2 + i * P / 5, rr2 = i % 2 ? r * 0.45 : r; c.lineTo(x + Math.cos(a) * rr2, y + Math.sin(a) * rr2); }
    c.closePath(); c.fillStyle = col; c.fill(); c.strokeStyle = 'rgba(0,0,0,.4)'; c.lineWidth = 0.8; c.stroke();
  };

  /* =================================================================
     TUKTUK — منظر جانبي. الأصل (0,0) = مركز الكتلة. العجلات تُرسم منفصلة
     ================================================================= */
  A.TUK = { rearX: -0.85, frontX: 0.95, H0: 0.62, wheelR: 0.3 };
  A.tuktukBody = function (c, o) {
    const col = o.color || '#1f8f3a', trim = o.trim || '#f2c230', space = o.space;
    const roofCol = space ? '#5b6878' : '#111';
    const dmg = o.damage || 0;
    // interior back wall
    if (o.layer !== 'front') {
    c.fillStyle = space ? '#2a3442' : '#2a1d16';
    rr(c, -62, -48, 98, 48, 6); c.fill();
    // bench
    c.fillStyle = '#6b3d22'; rr(c, -60, -12, 54, 8, 3); c.fill(); rr(c, -62, -44, 8, 36, 3); c.fill();
    }
    if (o.layer === 'back') return;
    // passengers + driver (drawn by caller callback so they sit between layers)
    if (o.inside) o.inside(c);
    // lower body panel
    const g = c.createLinearGradient(0, -20, 0, 14);
    g.addColorStop(0, shade(col, 0.18)); g.addColorStop(1, shade(col, -0.25));
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(-70, -16); c.lineTo(-8, -16); c.quadraticCurveTo(4, -16, 8, -8);
    c.lineTo(34, -8); c.quadraticCurveTo(52, -10, 62, 2); c.lineTo(62, 8);
    // front wheel arch
    c.lineTo(62, 10); c.lineTo(64, 12); c.lineTo(58, 12); c.arc(46, 15, 13, -0.2, P + 0.2, true);
    c.lineTo(-24, 12);
    // rear wheel arch
    c.arc(-41, 15, 15, -0.1, P + 0.1, true); c.lineTo(-70, 12); c.closePath(); c.fill();
    c.strokeStyle = shade(col, -0.45); c.lineWidth = 1.5; c.stroke();
    // trim stripe
    c.fillStyle = trim; c.fillRect(-70, -6, 78, 3.5); c.beginPath(); c.moveTo(8, -1); c.lineTo(56, -1); c.lineTo(58, 2); c.lineTo(8, 2); c.fill();
    // front cowl & windshield
    c.fillStyle = shade(col, 0.05);
    c.beginPath(); c.moveTo(30, -10); c.lineTo(38, -50); c.lineTo(44, -50); c.quadraticCurveTo(58, -26, 63, -2); c.lineTo(34, -8); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = space ? 'rgba(120,230,255,.45)' : 'rgba(170,215,240,.55)';
    c.beginPath(); c.moveTo(40, -46); c.lineTo(45, -46); c.quadraticCurveTo(55, -28, 57, -16); c.lineTo(36, -16); c.closePath(); c.fill();
    c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.moveTo(43, -42); c.lineTo(46, -42); c.lineTo(40, -22); c.lineTo(38, -22); c.fill();
    // rear panel
    c.fillStyle = g; rr(c, -72, -50, 14, 50, 4); c.fill(); c.stroke();
    c.fillStyle = 'rgba(170,215,240,.5)'; rr(c, -70, -44, 9, 14, 2); c.fill();
    // decal on rear lower panel
    A.decal(c, o.decal, -40, -10, trim);
    // pillars
    c.fillStyle = '#222'; c.fillRect(8, -50, 3, 36); c.fillRect(-60, -50, 3, 34);
    // roof
    if (!o.noRoof) {
    c.fillStyle = roofCol; rr(c, -76, -58, 124, 10, 5); c.fill();
    c.fillStyle = trim; c.fillRect(-74, -50, 120, 2.5);
    } else { c.strokeStyle = '#555'; c.lineWidth = 2; c.beginPath(); c.moveTo(8, -50); c.lineTo(14, -56); c.moveTo(-60, -50); c.lineTo(-54, -57); c.stroke(); }
    // fringe tassels (حلية)
    if (!o.noRoof) for (let i = -72; i < 44; i += 7) { const sw = Math.sin((o.t || 0) * 9 + i) * (o.shake || 0) * 2; c.fillStyle = i % 14 === 0 ? '#e53935' : '#fbc02d'; c.beginPath(); c.moveTo(i, -48); c.lineTo(i + 4, -48); c.lineTo(i + 2 + sw, -42); c.fill(); }
    // headlight + mirror
    ell(c, 60, -8, 4, 5, o.lights ? '#fff9c4' : '#f5f1d0'); c.strokeStyle = '#555'; c.lineWidth = 1; c.stroke();
    line(c, 44, -46, 54, -54, 1.5, '#333'); ell(c, 55, -56, 4, 3, '#555');
    // plate
    c.fillStyle = '#fff'; rr(c, -79, -12, 13, 9, 1.5); c.fill(); c.fillStyle = '#2b6cd4'; c.fillRect(-79, -12, 13, 2.6);
    c.fillStyle = '#111'; c.font = 'bold 5px ' + FONT; c.textAlign = 'center'; c.fillText('٧٢٥', -72.5, -5);
    ell(c, -73, -24, 2.5, 3, '#d32f2f'); // tail light
    if (space) { line(c, -66, -58, -70, -74, 1.5, '#9aa'); ell(c, -70, -76, 3, 3, '#38d9ff'); c.globalAlpha = 0.5; ell(c, -10, 14, 60, 4, '#38d9ff'); c.globalAlpha = 1; }
    // damage marks
    if (dmg > 0.3) { c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-50, -12); c.lineTo(-44, -6); c.lineTo(-47, 0); c.moveTo(20, -6); c.lineTo(26, 0); c.stroke(); }
    if (dmg > 0.6) { c.fillStyle = 'rgba(80,50,30,.5)'; ell(c, -20, 4, 8, 4); c.fill(); ell(c, 52, -4, 5, 3); c.fill(); }
    // seat for driver
    // handlebar
    line(c, 33, -14, 38, -30, 2.5, '#333'); line(c, 36, -30, 40, -30, 4, '#111');
  };
  A.decal = function (c, id, x, y, trim) {
    if (!id || id === 'none') return;
    c.save(); c.translate(x, y);
    if (id === 'eye') { c.strokeStyle = '#111'; c.lineWidth = 1.6; c.beginPath(); c.ellipse(0, 0, 8, 4, 0, 0, P * 2); c.stroke(); ell(c, 0, 0, 2.6, 2.6, '#1565c0'); c.beginPath(); c.moveTo(-2, 4); c.lineTo(-4, 9); c.moveTo(3, 4); c.quadraticCurveTo(7, 9, 4, 10); c.stroke(); }
    if (id === 'crown') { c.fillStyle = '#ffd54f'; c.beginPath(); c.moveTo(-8, 4); c.lineTo(-8, -4); c.lineTo(-4, 0); c.lineTo(0, -6); c.lineTo(4, 0); c.lineTo(8, -4); c.lineTo(8, 4); c.fill(); c.strokeStyle = '#8d6e00'; c.lineWidth = 0.8; c.stroke(); }
    if (id === 'flag') { c.fillStyle = '#ce1126'; c.fillRect(-9, -5, 18, 3.4); c.fillStyle = '#fff'; c.fillRect(-9, -1.6, 18, 3.4); c.fillStyle = '#000'; c.fillRect(-9, 1.8, 18, 3.4); ell(c, 0, 0, 1.4, 1.4, '#c09300'); }
    if (id === 'pharaoh') { c.fillStyle = '#1565c0'; c.beginPath(); c.moveTo(-8, 7); c.lineTo(-7, -4); c.quadraticCurveTo(0, -11, 7, -4); c.lineTo(8, 7); c.fill(); c.fillStyle = '#ffd54f'; for (let i = -6; i < 8; i += 3) c.fillRect(i, -3, 1.5, 9); ell(c, 0, 0, 4, 5, '#c98f62'); }
    c.restore();
  };
  A.wheel = function (c, x, y, r, rot, col) {
    ell(c, x, y, r, r, '#1a1a1a');
    ell(c, x, y, r * 0.55, r * 0.55, col || '#b0b6bd');
    c.strokeStyle = '#555'; c.lineWidth = 1.6;
    for (let i = 0; i < 4; i++) { const a = rot + i * P / 2; c.beginPath(); c.moveTo(x, y); c.lineTo(x + Math.cos(a) * r * 0.55, y + Math.sin(a) * r * 0.55); c.stroke(); }
    ell(c, x, y, r * 0.15, r * 0.15, '#333');
    c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 1.5; c.beginPath(); c.arc(x, y, r - 2, -2.4, -1.2); c.stroke();
  };


  /* =================================================================
     PLAYER VEHICLES — توكتوك / سكوتر / عجلة / سكيت / ميكروباص
     الأصل (0,0) = مركز الثقل، +x لقدام. layer: 'back' | 'front' | undefined (الكل)
     o.inside(c) بيرسم السواق والركاب بين الطبقتين. العجل بيترسم من game.js
     ================================================================= */
  A.OUTLINE = {
    tuktuk: [[-74, 10], [-74, -58], [46, -58], [62, -4], [62, 10]],
    scooter: [[-38, 8], [-38, -14], [-6, -20], [18, -10], [24, -40], [32, -40], [34, 8]],
    bike: [[-25, 14], [-9, -20], [20, -20], [26, 14]],
    skate: [[-24, 2], [24, 2]],
    microbus: [[-122, 12], [-122, -84], [70, -84], [112, -38], [118, -30], [118, 12]],
    sport: [[-100, 6], [-100, -16], [-40, -24], [-18, -34], [14, -35], [40, -20], [104, -8], [106, 6]]
  };
  A.playerBody = function (c, kind, o) {
    if (kind === 'tuktuk') return A.tuktukBody(c, o);
    const col = o.color || '#e53935', trim = o.trim || '#fff', lay = o.layer;
    const back = lay !== 'front', front = lay !== 'back';
    if (kind === 'scooter') {
      if (back) {
        c.fillStyle = '#333'; rr(c, -34, 4, 60, 7, 3); c.fill();                       // deck
        const g = c.createLinearGradient(0, -20, 0, 10); g.addColorStop(0, shade(col, 0.2)); g.addColorStop(1, shade(col, -0.25));
        c.fillStyle = g; c.beginPath(); c.moveTo(-40, 8); c.quadraticCurveTo(-44, -12, -30, -16); c.lineTo(-6, -16); c.quadraticCurveTo(0, -4, -4, 8); c.closePath(); c.fill();
        c.strokeStyle = shade(col, -0.45); c.lineWidth = 1.2; c.stroke();
        c.fillStyle = '#212121'; rr(c, -36, -22, 30, 7, 3); c.fill();                   // seat
        c.fillStyle = trim; c.fillRect(-38, -4, 30, 3);
        ell(c, -42, -6, 2.5, 3, '#d32f2f');                                              // tail light
        c.fillStyle = '#fff'; rr(c, -46, -2, 9, 6, 1); c.fill();                         // plate
      }
      if (o.inside) o.inside(c);
      if (front) {
        const g = c.createLinearGradient(0, -40, 0, 10); g.addColorStop(0, shade(col, 0.2)); g.addColorStop(1, shade(col, -0.25));
        c.fillStyle = g; c.beginPath(); c.moveTo(14, 8); c.lineTo(20, -12); c.lineTo(28, -36); c.lineTo(34, -34); c.lineTo(30, -8); c.quadraticCurveTo(40, 0, 40, 8); c.closePath(); c.fill();
        c.strokeStyle = shade(col, -0.45); c.lineWidth = 1.2; c.stroke();
        line(c, 30, -36, 24, -44, 3, '#333'); line(c, 20, -44, 30, -44, 4, '#111');      // handlebar
        ell(c, 34, -30, 3.5, 4, o.lights ? '#fff9c4' : '#f5f1d0');                        // headlight
        c.fillStyle = trim; c.fillRect(22, -22, 8, 3);
      }
      return;
    }
    if (kind === 'bike') {
      if (back) {
        c.strokeStyle = col; c.lineWidth = 3.4; c.lineCap = 'round'; c.lineJoin = 'round';
        c.beginPath(); c.moveTo(-25, 14); c.lineTo(0, 12); c.lineTo(-9, -18); c.lineTo(-25, 14); c.moveTo(-9, -18); c.lineTo(19, -16); c.lineTo(0, 12); c.stroke();
        c.beginPath(); c.moveTo(19, -16); c.lineTo(26, 14); c.stroke();
        c.strokeStyle = '#777'; c.lineWidth = 2; c.beginPath(); c.moveTo(-30, -6); c.lineTo(-10, -6); c.moveTo(-28, -6); c.lineTo(-25, 14); c.stroke(); // rack
        c.fillStyle = '#212121'; rr(c, -15, -24, 14, 5, 2); c.fill();                   // saddle
        ell(c, 0, 12, 4, 4, '#555');
      }
      if (o.inside) o.inside(c);
      if (front) { line(c, 19, -16, 21, -28, 3, '#333'); line(c, 16, -29, 26, -27, 3.5, '#111'); ell(c, 24, -20, 2.5, 2.5, o.lights ? '#fff9c4' : '#eee'); }
      return;
    }
    if (kind === 'skate') {
      if (back) {
        c.fillStyle = col; c.beginPath(); c.moveTo(-26, -2); c.quadraticCurveTo(-30, -6, -28, -8); c.lineTo(-22, -1); c.lineTo(22, -1); c.lineTo(28, -8); c.quadraticCurveTo(30, -6, 26, -2); c.lineTo(22, 3); c.lineTo(-22, 3); c.closePath(); c.fill();
        c.fillStyle = trim; c.fillRect(-22, -1, 44, 1.6);
        c.fillStyle = '#9e9e9e'; c.fillRect(-18, 3, 6, 2); c.fillRect(12, 3, 6, 2);
      }
      if (o.inside) o.inside(c);
      return;
    }
    if (kind === 'sport') {
      // عربية سباق واطية: style = gt | super | hyper
      const st = o.style || 'gt', glassPath = () => { c.beginPath(); c.moveTo(-36, -21); c.lineTo(-17, -31); c.lineTo(12, -32); c.lineTo(34, -19); c.closePath(); };
      if (back) { c.fillStyle = '#15171c'; glassPath(); c.fill(); c.fillStyle = '#2b2f38'; rr(c, -34, -20, 66, 18, 4); c.fill(); }
      if (o.inside) o.inside(c);
      if (front) {
        const g = c.createLinearGradient(0, -36, 0, 10); g.addColorStop(0, shade(col, 0.28)); g.addColorStop(0.45, col); g.addColorStop(1, shade(col, -0.35));
        c.fillStyle = g; c.beginPath();
        if (st === 'super') { c.moveTo(-100, 4); c.lineTo(-100, -14); c.lineTo(-44, -22); c.lineTo(-20, -33); c.lineTo(10, -34); c.lineTo(44, -18); c.lineTo(106, -4); c.lineTo(108, 4); }
        else { c.moveTo(-100, 4); c.lineTo(-100, -12); c.quadraticCurveTo(-98, -18, -86, -19); c.lineTo(-40, -22); c.quadraticCurveTo(-26, -34, -14, -34); c.lineTo(14, -34); c.quadraticCurveTo(30, -26, 42, -18); c.quadraticCurveTo(90, -14, 102, -8); c.quadraticCurveTo(108, -4, 106, 4); }
        c.lineTo(80, 6); c.arc(62, 10, 18, -0.15, Math.PI + 0.15, true); c.lineTo(-42, 6); c.arc(-60, 10, 18, -0.15, Math.PI + 0.15, true); c.lineTo(-100, 6); c.closePath();
        // فتحة الإزاز
        c.moveTo(-36, -21); c.lineTo(34, -19); c.lineTo(12, -32); c.lineTo(-17, -31); c.closePath();
        c.fill('evenodd'); c.strokeStyle = 'rgba(0,0,0,.45)'; c.lineWidth = 1.3; c.stroke();
        c.fillStyle = 'rgba(120,180,220,.32)'; glassPath(); c.fill();
        c.fillStyle = 'rgba(255,255,255,.35)'; c.beginPath(); c.moveTo(14, -30); c.lineTo(19, -30); c.lineTo(28, -21); c.lineTo(24, -21); c.fill();
        line(c, -2, -32, -2, -20, 2, shade(col, -0.45));
        // خطوط وزينة
        if (st === 'gt') { c.fillStyle = trim; c.fillRect(-98, -9, 200, 3); c.fillRect(-98, -4, 200, 2); }
        if (st === 'super') { c.fillStyle = trim; c.beginPath(); c.moveTo(-20, -6); c.lineTo(40, -14); c.lineTo(40, -10); c.lineTo(-20, -2); c.fill(); c.fillStyle = '#111'; for (let i = 0; i < 3; i++) c.fillRect(-60 + i * 9, -14, 6, 6); }
        if (st === 'hyper') { c.fillStyle = trim; c.fillRect(-98, -6, 200, 2); c.globalAlpha = 0.55; ell(c, 2, 12, 98, 4, trim); c.globalAlpha = 1; }
        // جناح خلفي
        const wingH = st === 'hyper' ? -38 : st === 'super' ? -30 : -26;
        c.fillStyle = '#16181d'; c.fillRect(-94, wingH + 4, 4, -wingH - 18); c.fillRect(-80, wingH + 4, 4, -wingH - 20);
        c.fillStyle = st === 'gt' ? '#16181d' : trim; rr(c, -104, wingH, 36, 6, 2); c.fill();
        // نور وأرقام
        c.fillStyle = o.lights ? '#ffffe0' : '#e3f2fd'; c.beginPath(); c.moveTo(92, -11); c.lineTo(104, -7); c.lineTo(102, -4); c.lineTo(90, -7); c.fill();
        c.fillStyle = '#e53935'; rr(c, -101, -13, 5, 5, 1.5); c.fill();
        ell(c, 30, -6, 9, 9, '#fff'); text(c, st === 'gt' ? '21' : st === 'super' ? '07' : '99', 30, -6, 10, '#111');
        c.fillStyle = '#111'; rr(c, 84, 0, 20, 5, 2); c.fill(); rr(c, -100, 0, 16, 5, 2); c.fill();
        if (o.damage > 0.4) { c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-70, -12); c.lineTo(-62, -4); c.moveTo(60, -12); c.lineTo(68, -4); c.stroke(); }
      }
      return;
    }
    if (kind === 'microbus') {
      if (back) { c.fillStyle = '#2a2f3a'; rr(c, -118, -80, 228, 76, 6); c.fill(); }
      if (o.inside) o.inside(c);
      if (front) {
        const g = c.createLinearGradient(0, -84, 0, 12); g.addColorStop(0, shade(col, 0.05)); g.addColorStop(1, shade(col, -0.18));
        c.fillStyle = g; c.beginPath();
        c.moveTo(-122, 12); c.lineTo(-122, -78); c.quadraticCurveTo(-122, -84, -114, -84); c.lineTo(70, -84); c.lineTo(110, -40); c.lineTo(118, -30); c.lineTo(118, 12);
        c.lineTo(88, 12); c.arc(70, 21, 18, -0.1, Math.PI + 0.1, true); c.lineTo(-56, 12); c.arc(-74, 21, 18, -0.1, Math.PI + 0.1, true); c.closePath();
        const wins = [[-114, -76, 36, 26], [-72, -76, 36, 26], [-30, -76, 36, 26], [12, -76, 36, 26], [54, -76, 26, 26]];
        for (const w of wins) c.rect(w[0] + w[2], w[1], -w[2], w[3]);
        c.moveTo(84, -76); c.lineTo(106, -44); c.lineTo(84, -44); c.closePath();
        c.fill('evenodd'); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1.2; c.stroke();
        c.fillStyle = 'rgba(160,210,240,.28)'; for (const w of wins) c.fillRect(w[0], w[1], w[2], w[3]);
        c.beginPath(); c.moveTo(84, -76); c.lineTo(106, -44); c.lineTo(84, -44); c.closePath(); c.fill();
        c.fillStyle = trim; c.fillRect(-122, -34, 240, 7);
        c.fillStyle = '#fff59d'; rr(c, 110, -22, 8, 7, 2); c.fill(); ell(c, -120, -24, 2.5, 4, '#d32f2f');
        c.fillStyle = '#fff'; rr(c, -128, -10, 12, 8, 1.5); c.fill(); c.fillStyle = '#2b6cd4'; c.fillRect(-128, -10, 12, 2.4);
        A.decal(c, o.decal, -40, -16, trim);
        if (o.damage > 0.4) { c.strokeStyle = 'rgba(0,0,0,.5)'; c.lineWidth = 1.2; c.beginPath(); c.moveTo(-90, -20); c.lineTo(-82, -12); c.moveTo(40, -16); c.lineTo(48, -6); c.stroke(); }
      }
      return;
    }
  };
  /* ---------- زينة مركبات السباق ---------- */
  A.raceDeco = function (c, kind, t) {
    const out = A.OUTLINE[kind]; let minX = 1e9, maxX = -1e9; for (const p of out) { minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); }
    c.save(); c.globalAlpha = 0.9; c.fillStyle = '#fff';
    if (kind === 'tuktuk') { c.fillRect(-70, -14, 128, 3); c.fillRect(-70, -9, 128, 2); ell(c, -30, -2, 9, 9, '#fff'); text(c, '77', -30, -2, 10, '#111'); c.fillStyle = '#111'; rr(c, -78, -66, 30, 6, 2); c.fill(); c.fillRect(-70, -60, 3, 4); c.fillRect(-56, -60, 3, 4); }
    else if (kind === 'scooter') { c.fillRect(-38, -10, 30, 2.5); ell(c, -22, -4, 6, 6, '#fff'); text(c, '7', -22, -4, 8, '#111'); c.fillStyle = 'rgba(120,200,255,.6)'; c.beginPath(); c.moveTo(26, -40); c.lineTo(34, -52); c.lineTo(36, -40); c.fill(); }
    c.restore();
    // ريحة سرعة
    for (let i = 0; i < 3; i++) { c.globalAlpha = 0.25; c.fillStyle = '#fff'; c.fillRect(minX - 30 - ((t * 200 + i * 40) % 60), -20 + i * 10, 20, 2); } c.globalAlpha = 1;
  };
  /* ---------- حمولة البيّاع على المركبة ---------- */
  A.vendorLoad = function (c, kind, gid, t, stockFrac) {
    const pos = { tuktuk: [-38, -6, 1], microbus: [-80, -6, 1.4], scooter: [-32, -18, 0.6], bike: [-22, -8, 0.55], skate: [-14, -2, 0.5] }[kind] || [-30, -6, 1];
    c.save(); c.translate(pos[0], pos[1]); c.scale(pos[2], pos[2]);
    if (gid === 'potato') {
      c.fillStyle = '#263238'; rr(c, -18, -34, 36, 34, 6); c.fill(); c.fillStyle = '#37474f'; c.fillRect(-18, -24, 36, 4);
      const glow = 0.6 + Math.sin(t * 6) * 0.2; c.fillStyle = 'rgba(255,120,0,' + glow + ')'; rr(c, -10, -16, 20, 10, 3); c.fill();
      c.fillStyle = '#455a64'; c.fillRect(8, -58, 6, 26); c.fillStyle = '#212121'; c.fillRect(6, -60, 10, 4);
      for (let i = 0; i < 3 * stockFrac + 1; i++) ell(c, -10 + i * 7, -38, 5, 3, '#8d4a2b');
    } else if (gid === 'corn') {
      c.fillStyle = '#5d4037'; c.fillRect(-20, -14, 40, 14); c.fillStyle = '#212121'; c.fillRect(-20, -18, 40, 5);
      c.fillStyle = 'rgba(255,87,34,' + (0.6 + Math.sin(t * 8) * 0.25) + ')'; c.fillRect(-18, -16, 36, 2);
      for (let i = 0; i < Math.max(1, Math.round(5 * stockFrac)); i++) { c.save(); c.translate(-14 + i * 7, -24); c.rotate(-0.3); c.fillStyle = '#fbc02d'; rr(c, -2.5, -9, 5, 16, 2.5); c.fill(); c.fillStyle = '#7cb342'; c.fillRect(-3, 5, 6, 3); c.restore(); }
    } else if (gid === 'termes') {
      c.fillStyle = '#b0bec5'; c.beginPath(); c.ellipse(0, -14, 18, 14, 0, 0, 7); c.fill(); c.fillStyle = '#cfd8dc'; c.fillRect(-18, -30, 36, 6);
      c.fillStyle = '#fdd835'; for (let i = 0; i < 4 * stockFrac + 1; i++) ell(c, -12 + i * 6, -32, 3, 3, '#fdd835');
      c.fillStyle = '#c62828'; ell(c, 14, -36, 4, 4, '#c62828'); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(-26, -24); c.lineTo(-20, -40); c.lineTo(-32, -40); c.fill();
    } else if (gid === 'bread') {
      c.fillStyle = '#8d6e63'; c.fillRect(-20, -40, 4, 40); c.fillRect(16, -40, 4, 40); c.fillRect(-20, -26, 40, 3); c.fillRect(-20, -12, 40, 3); c.fillRect(-22, -42, 44, 3);
      for (let r2 = 0; r2 < 2; r2++) for (let i = 0; i < Math.max(1, Math.round(4 * stockFrac)); i++) { ell(c, -12 + i * 8, -29 + r2 * 14, 4.5, 2.6, '#d7a35c'); }
    }
    c.restore();
  };

  /* ---------- عربيات البيع: لكل بضاعة عربية، وكل عربية 3 مستويات (خشب / ستانلس / محل متنقل) ----------
     مبنية على شاسيه التوكتوك: كابينة السواق قدام (x من 0 لـ 62) والعربية ورا (x من -80 لـ 0) */
  A.CART_COL = { potato: '#8d3b1f', corn: '#2e7d32', termes: '#f9a825', bread: '#a1662f' };
  A.vendorCart = function (c, gid, tier, o) {
    o = o || {}; const t = o.t || 0, sf = o.stockFrac == null ? 1 : o.stockFrac, accent = A.CART_COL[gid] || '#c62828';
    const top = tier === 2 ? -82 : tier === 1 ? -66 : -60;
    if (o.exploded) c.filter = 'brightness(0.35) saturate(0.3)';
    // ---- العربية ورا ----
    const box = (x, y, w, h) => {
      if (tier === 0) { // خشب
        c.fillStyle = '#9c6b3c'; rr(c, x, y, w, h, 3); c.fill(); c.strokeStyle = '#5d3a1a'; c.lineWidth = 1.4; c.stroke();
        c.strokeStyle = 'rgba(70,40,15,.55)'; c.lineWidth = 1; for (let yy = y + 6; yy < y + h; yy += 6) { c.beginPath(); c.moveTo(x + 1, yy); c.lineTo(x + w - 1, yy); c.stroke(); }
        for (const xx of [x + 4, x + w - 4]) { c.fillStyle = '#5d3a1a'; c.fillRect(xx - 1.5, y, 3, h); }
        for (const [xx, yy] of [[x + 4, y + 3], [x + w - 4, y + 3], [x + 4, y + h - 3], [x + w - 4, y + h - 3]]) ell(c, xx, yy, 1.2, 1.2, '#333');
      } else if (tier === 1) { // ستانلس
        const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, '#f5f7f8'); g.addColorStop(0.45, '#b9c2c8'); g.addColorStop(0.55, '#d9e0e4'); g.addColorStop(1, '#8a959c');
        c.fillStyle = g; rr(c, x, y, w, h, 4); c.fill(); c.strokeStyle = '#6b767d'; c.lineWidth = 1.4; c.stroke();
        c.fillStyle = 'rgba(255,255,255,.55)'; c.fillRect(x + 3, y + 2, w - 6, 2);
        c.fillStyle = accent; c.fillRect(x, y + h - 7, w, 3);
      } else { // محل متنقل
        const g = c.createLinearGradient(0, y, 0, y + h); g.addColorStop(0, shade(accent, 0.25)); g.addColorStop(1, shade(accent, -0.3));
        c.fillStyle = g; rr(c, x, y, w, h, 5); c.fill(); c.strokeStyle = shade(accent, -0.5); c.lineWidth = 1.6; c.stroke();
        c.fillStyle = '#fafafa'; c.fillRect(x, y + h - 9, w, 3);
      }
    };
    // الصندوق السفلي
    box(-80, -18, 78, 30);
    // عجلة مغطّاة
    c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.arc(-41, 15, 15, P, 0); c.fill();
    if (tier === 2) {
      // كشك: جسم عالي + شباك بيع + ستارة حديد مرفوعة + تندة مقلمة + يافطة نيون
      box(-82, top + 10, 82, -18 - (top + 10) + 2);
      c.fillStyle = '#1b1b1b'; rr(c, -74, top + 26, 64, 34, 3); c.fill();
      const wg = c.createLinearGradient(0, top + 26, 0, top + 60); wg.addColorStop(0, '#fff6d5'); wg.addColorStop(1, '#ffcc80'); c.fillStyle = wg; rr(c, -72, top + 28, 60, 30, 2); c.fill();
      c.fillStyle = '#9e9e9e'; for (let i = 0; i < 3; i++) c.fillRect(-74, top + 18 + i * 3, 64, 1.6);
      c.fillStyle = '#5d4037'; c.fillRect(-78, top + 58, 72, 4);
      const nS = 7; for (let i = 0; i < nS; i++) { c.fillStyle = i % 2 ? '#fff' : accent; c.beginPath(); c.moveTo(-86 + i * 13, top + 12); c.lineTo(-73 + i * 13, top + 12); c.lineTo(-71 + i * 13, top + 22); c.lineTo(-84 + i * 13, top + 22); c.fill(); }
      c.fillStyle = '#111'; rr(c, -78, top - 4, 74, 15, 4); c.fill();
      c.save(); c.shadowColor = '#ffeb3b'; c.shadowBlur = 8 + Math.sin(t * 5) * 3; c.fillStyle = '#ffee58'; c.font = 'bold 10px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(o.sign || '', -41, top + 4); c.restore();
      const cols = ['#ff1744', '#ffea00', '#00e676', '#2979ff', '#d500f9']; for (let i = 0; i < 10; i++) ell(c, -80 + i * 8, top + 24 + Math.sin(i) * 1.5, 1.8, 1.8, (i + Math.floor(t * 4)) % 3 ? cols[i % 5] : '#555');
      // البضاعة جوه الشباك
      goods(c, gid, -42, top + 56, 0.85, t, sf, tier);
    } else {
      // أعمدة + تندة قماش (خشب) أو صاج (ستانلس)
      const ax = -78, aw = 76;
      c.fillStyle = tier ? '#78909c' : '#5d3a1a'; c.fillRect(ax + 2, top + 8, 3, -18 - (top + 8)); c.fillRect(ax + aw - 5, top + 8, 3, -18 - (top + 8));
      if (tier === 0) { const n = 6; for (let i = 0; i < n; i++) { c.fillStyle = i % 2 ? '#fff3e0' : accent; c.beginPath(); c.moveTo(ax - 2 + i * (aw + 4) / n, top + 2); c.lineTo(ax - 2 + (i + 1) * (aw + 4) / n, top + 2); c.lineTo(ax - 2 + (i + 1) * (aw + 4) / n + Math.sin(t * 3 + i) * 0.8, top + 12); c.lineTo(ax - 2 + i * (aw + 4) / n, top + 12); c.fill(); } }
      else { const g = c.createLinearGradient(0, top, 0, top + 10); g.addColorStop(0, '#eceff1'); g.addColorStop(1, '#90a4ae'); c.fillStyle = g; rr(c, ax - 4, top + 1, aw + 8, 9, 3); c.fill(); c.strokeStyle = '#607d8b'; c.lineWidth = 1; c.stroke(); c.fillStyle = accent; c.fillRect(ax - 4, top + 8, aw + 8, 2.5); }
      // اليافطة
      c.fillStyle = tier ? '#fff' : '#f3e2c0'; rr(c, -72, -16, 60, 13, 2); c.fill(); c.strokeStyle = tier ? accent : '#5d3a1a'; c.lineWidth = 1.2; c.stroke();
      c.fillStyle = tier ? accent : '#4e2a0d'; c.font = 'bold 8.5px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(o.sign || '', -42, -9.5);
      // البضاعة فوق الصندوق
      goods(c, gid, -40, -18, 1, t, sf, tier);
    }
    // ---- كابينة السواق ----
    c.fillStyle = '#2a1d16'; rr(c, 0, -48, 40, 48, 4); c.fill();
    if (o.inside) o.inside(c);
    const col = o.color || '#1f8f3a', g2 = c.createLinearGradient(0, -20, 0, 14); g2.addColorStop(0, shade(col, 0.18)); g2.addColorStop(1, shade(col, -0.25));
    c.fillStyle = g2; c.beginPath(); c.moveTo(-2, -16); c.lineTo(8, -16); c.quadraticCurveTo(14, -12, 14, -8); c.lineTo(34, -8); c.quadraticCurveTo(52, -10, 62, 2); c.lineTo(62, 10); c.lineTo(64, 12); c.lineTo(58, 12); c.arc(46, 15, 13, -0.2, P + 0.2, true); c.lineTo(-2, 12); c.closePath(); c.fill(); c.strokeStyle = shade(col, -0.45); c.lineWidth = 1.5; c.stroke();
    c.fillStyle = shade(col, 0.05); c.beginPath(); c.moveTo(30, -10); c.lineTo(38, -50); c.lineTo(44, -50); c.quadraticCurveTo(58, -26, 63, -2); c.lineTo(34, -8); c.closePath(); c.fill(); c.stroke();
    c.fillStyle = 'rgba(170,215,240,.55)'; c.beginPath(); c.moveTo(40, -46); c.lineTo(45, -46); c.quadraticCurveTo(55, -28, 57, -16); c.lineTo(36, -16); c.closePath(); c.fill();
    c.fillStyle = '#222'; c.fillRect(2, -50, 3, 36);
    if (!o.noRoof) { c.fillStyle = tier === 1 ? '#90a4ae' : tier === 2 ? shade(accent, -0.2) : '#111'; rr(c, -2, -58, 50, 9, 4); c.fill(); }
    ell(c, 60, -8, 4, 5, o.lights ? '#fff9c4' : '#f5f1d0');
    line(c, 33, -14, 38, -30, 2.5, '#333'); line(c, 36, -30, 40, -30, 4, '#111');
    c.fillStyle = '#fff'; rr(c, -85, -12, 9, 8, 1.5); c.fill(); c.fillStyle = '#2b6cd4'; c.fillRect(-85, -12, 9, 2.4);
    ell(c, -80, -22, 2.2, 2.8, '#d32f2f');
    c.filter = 'none';
  };
  // البضاعة نفسها (فرن بطاطا / شوّاية درة / حلّة ترمس / رفوف عيش)
  function goods(c, gid, x, y, s, t, sf, tier) {
    c.save(); c.translate(x, y); c.scale(s, s);
    const metal = tier ? '#b0bec5' : '#37474f';
    if (gid === 'potato') {
      c.fillStyle = '#212121'; rr(c, -24, -26, 34, 26, 8); c.fill(); c.fillStyle = '#424242'; c.fillRect(-24, -18, 34, 3);
      c.fillStyle = 'rgba(255,110,0,' + (0.6 + Math.sin(t * 6) * 0.25) + ')'; rr(c, -18, -10, 22, 7, 3); c.fill();
      c.fillStyle = '#455a64'; c.fillRect(0, -50, 6, 26); c.fillStyle = '#212121'; c.fillRect(-2, -52, 10, 4);
      for (let i = 0; i < Math.round(5 * sf) + 1; i++) ell(c, 16 + (i % 3) * 6, -4 - Math.floor(i / 3) * 5, 5, 3, '#8d4a2b');
    } else if (gid === 'corn') {
      c.fillStyle = metal; c.fillRect(-28, -10, 44, 10); c.fillStyle = '#212121'; c.fillRect(-28, -14, 44, 5);
      c.fillStyle = 'rgba(255,87,34,' + (0.6 + Math.sin(t * 8) * 0.25) + ')'; c.fillRect(-26, -12, 40, 2);
      for (let i = 0; i < Math.max(1, Math.round(6 * sf)); i++) { c.save(); c.translate(-22 + i * 7, -20); c.rotate(-0.3); c.fillStyle = '#fbc02d'; rr(c, -2.5, -9, 5, 16, 2.5); c.fill(); c.fillStyle = '#7cb342'; c.fillRect(-3, 5, 6, 3); c.restore(); }
      c.fillStyle = '#7cb342'; for (let i = 0; i < 3; i++) { c.save(); c.translate(22 + i * 4, -6); c.rotate(-0.6); c.fillRect(-2, -10, 4, 12); c.restore(); }
    } else if (gid === 'termes') {
      const g = c.createLinearGradient(-20, 0, 20, 0); g.addColorStop(0, '#90a4ae'); g.addColorStop(0.5, '#eceff1'); g.addColorStop(1, '#78909c');
      c.fillStyle = g; rr(c, -22, -30, 36, 30, 6); c.fill(); c.fillStyle = '#cfd8dc'; c.fillRect(-24, -32, 40, 4);
      for (let i = 0; i < Math.round(5 * sf) + 1; i++) ell(c, -16 + i * 6, -33, 3, 2.6, '#fdd835');
      ell(c, -4, -36, 3, 3, '#7cb342');
      for (let i = 0; i < 3; i++) { c.fillStyle = '#f5f5f5'; c.beginPath(); c.moveTo(20 + i * 7, -2); c.lineTo(17 + i * 7, -16); c.lineTo(23 + i * 7, -16); c.fill(); ell(c, 20 + i * 7, -17, 3, 1.5, '#fdd835'); }
      ell(c, 30, -24, 4, 3.5, '#fff176'); line(c, 30, -27, 31, -29, 1, '#558b2f');
    } else if (gid === 'bread') {
      if (tier) { c.fillStyle = '#5d4037'; c.beginPath(); c.arc(-14, 0, 15, P, 0); c.fill(); c.fillStyle = 'rgba(255,120,0,' + (0.55 + Math.sin(t * 5) * 0.25) + ')'; c.beginPath(); c.arc(-14, 0, 7, P, 0); c.fill(); }
      const sx = tier ? 4 : -26, n = tier ? 3 : 5;
      c.fillStyle = '#8d6e63'; c.fillRect(sx, -36, 3, 36); c.fillRect(sx + n * 9 + 2, -36, 3, 36);
      for (let r2 = 0; r2 < 3; r2++) { c.fillStyle = '#8d6e63'; c.fillRect(sx, -34 + r2 * 12, n * 9 + 5, 2); for (let i = 0; i < n; i++) if (i + r2 * n < Math.ceil(n * 3 * sf) + 1) ell(c, sx + 6 + i * 9, -37 + r2 * 12 + 9, 4.2, 2.4, '#d7a35c'); }
    }
    c.restore();
  }

  /* ---------- اكسسوارات فوق المركبة ---------- */
  A.accessories = function (c, kind, acc, t, opts) {
    const out = A.OUTLINE[kind]; if (!out) return;
    let minX = 1e9, maxX = -1e9, minY = 1e9; for (const p of out) { minX = Math.min(minX, p[0]); maxX = Math.max(maxX, p[0]); minY = Math.min(minY, p[1]); }
    if (acc.neon) { const hue = (t * 80) % 360; c.save(); c.globalAlpha = 0.55; const g = c.createRadialGradient((minX + maxX) / 2, 22, 4, (minX + maxX) / 2, 22, (maxX - minX) / 1.6); g.addColorStop(0, 'hsla(' + hue + ',100%,60%,.9)'); g.addColorStop(1, 'hsla(' + hue + ',100%,60%,0)'); c.fillStyle = g; c.fillRect(minX - 30, 8, maxX - minX + 60, 30); c.restore(); }
    if (acc.spoiler && (kind === 'tuktuk' || kind === 'microbus')) { const x = minX + 6, y = minY; c.fillStyle = '#212121'; c.fillRect(x, y - 4, 4, 6); c.fillRect(x + 18, y - 4, 4, 6); c.fillStyle = '#e53935'; rr(c, x - 6, y - 10, 34, 6, 2); c.fill(); }
    if (acc.flag) { const x = kind === 'skate' || kind === 'bike' ? minX + 4 : minX + 14, y = kind === 'skate' ? -60 : kind === 'bike' ? -10 : minY; line(c, x, y, x, y - 30, 1.6, '#666'); const wv = k => Math.sin(t * 8 + k) * 2; c.fillStyle = '#ce1126'; c.beginPath(); c.moveTo(x, y - 30); c.lineTo(x - 20, y - 30 + wv(0)); c.lineTo(x - 20, y - 25 + wv(0)); c.lineTo(x, y - 25); c.fill(); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x, y - 25); c.lineTo(x - 20, y - 25 + wv(1)); c.lineTo(x - 20, y - 20 + wv(1)); c.lineTo(x, y - 20); c.fill(); c.fillStyle = '#000'; c.beginPath(); c.moveTo(x, y - 20); c.lineTo(x - 20, y - 20 + wv(2)); c.lineTo(x - 20, y - 15 + wv(2)); c.lineTo(x, y - 15); c.fill(); }
    if (acc.sub && opts.subOn && (kind === 'tuktuk' || kind === 'microbus')) { const x = minX + 10, y = -8; c.fillStyle = '#212121'; rr(c, x, y - 14, 18, 14, 2); c.fill(); const p = 4 + Math.abs(Math.sin(t * 16)) * 2; ell(c, x + 9, y - 7, p, p, '#555'); ell(c, x + 9, y - 7, 2, 2, '#999'); }
    if (acc.party && opts.partyOn) {
      // لمبات زينة على حدود المركبة — بتنور وتطفي، وبتجري أسرع وقت الاحتفال
      const cols = ['#ff1744', '#ffea00', '#00e676', '#2979ff', '#d500f9', '#ff9100'];
      const speed = opts.celebrate ? 14 : 4, ph = Math.floor(t * speed);
      let idx = 0;
      for (let i = 0; i < out.length - 1; i++) {
        const [x1, y1] = out[i], [x2, y2] = out[i + 1], len = Math.hypot(x2 - x1, y2 - y1), n = Math.max(1, Math.floor(len / 9));
        for (let k = 0; k < n; k++, idx++) {
          const x = x1 + (x2 - x1) * k / n, y = y1 + (y2 - y1) * k / n;
          const on = opts.celebrate ? ((idx + ph) % 2 === 0) : ((idx + ph) % 3 !== 0);
          const cl = cols[(idx + (opts.celebrate ? ph : 0)) % cols.length];
          if (on) { c.globalAlpha = 0.35; ell(c, x, y, 5, 5, cl); c.globalAlpha = 1; ell(c, x, y, 2.2, 2.2, cl); }
          else ell(c, x, y, 1.8, 1.8, 'rgba(80,80,80,.8)');
        }
      }
    }
    if (opts.dirt > 0.05) { c.save(); c.globalAlpha = Math.min(0.75, opts.dirt * 0.8); c.fillStyle = '#6d5436'; for (let i = 0; i < 14; i++) { const x = minX + hash(i * 7) * (maxX - minX), y = -6 + hash(i * 13) * 16; if (hash(i) < opts.dirt + 0.2) ell(c, x, y, 4 + hash(i * 3) * 7, 2 + hash(i * 5) * 4, '#6d5436'); } c.restore(); }
    if (opts.clamped) { const wx = kind === 'microbus' ? -74 : kind === 'tuktuk' ? -41 : -26; c.fillStyle = '#fdd835'; rr(c, wx - 8, 4, 16, 22, 3); c.fill(); c.strokeStyle = '#212121'; c.lineWidth = 2; c.strokeRect(wx - 8, 4, 16, 22); ell(c, wx, 15, 3, 3, '#e53935'); text(c, 'كلبش', wx, -4, 8, '#fdd835', 'center', true, 2); }
  };
  /* =================================================================
     VEHICLES — x = الطرف الخلفي، y = خط الأرض
     ================================================================= */
  A.VEH = {
    car: { len: 4.2, col: ['#c62828', '#1565c0', '#eceff1', '#424242', '#2e7d32', '#f9a825'] },
    microbus: { len: 5.0, col: ['#f5f5f5'] }, tuktuk: { len: 2.8, col: ['#1f8f3a', '#151515', '#c62828', '#1e5bb8'] },
    bus: { len: 8, col: ['#1e5bb8', '#2e7d32'] }, police: { len: 4.4, col: ['#f5f5f5'] }, moto: { len: 1.9, col: ['#b71c1c', '#212121'] },
    box: { len: 5.0, col: ['#eceff1'] }, tractor: { len: 3.6, col: ['#c62828', '#2e7d32'] }, cart: { len: 3.6, col: ['#8d6e63'] }, jeep: { len: 4.4, col: ['#c2a26b', '#5d6b3b'] },
    truck: { len: 6.6, col: ['#e65100', '#455a64'] }, rover: { len: 4.0, col: ['#eceff1'] }
  };
  A.vehicle = function (c, type, x, y, o) {
    o = o || {};
    const t = o.t || 0, col = o.color || A.VEH[type].col[0];
    const L = A.VEH[type].len * PX;
    const vimg = !o.procedural && A.img(A.P.vehicle(type, Math.max(0, A.VEH[type].col.indexOf(col))));
    if (vimg) { c.save(); c.translate(x, y); if (o.scale) c.scale(o.scale, o.scale); c.drawImage(vimg, -A.VEH_IMG.anchorX, -A.VEH_IMG.anchorY); if (o.label) text(c, o.label, L / 2, -110, 12, '#fff', 'center', true, 3); c.restore(); return; }
    c.save(); c.translate(x, y);
    if (o.scale) c.scale(o.scale, o.scale);
    c.globalAlpha = 0.25; ell(c, L / 2, 2, L / 2, 4, '#000'); c.globalAlpha = 1;
    const wr = o.wr || 0;
    const body = (pts, fill) => { c.beginPath(); c.moveTo(pts[0], pts[1]); for (let i = 2; i < pts.length; i += 2) c.lineTo(pts[i], pts[i + 1]); c.closePath(); c.fillStyle = fill; c.fill(); c.strokeStyle = 'rgba(0,0,0,.35)'; c.lineWidth = 1.2; c.stroke(); };
    const win = (x1, y1, w, h) => { c.fillStyle = 'rgba(150,200,230,.85)'; rr(c, x1, y1, w, h, 3); c.fill(); c.fillStyle = 'rgba(255,255,255,.3)'; c.fillRect(x1 + 3, y1 + 2, 3, h - 4); };
    if (type === 'car' || type === 'police') {
      body([0, -10, 4, -30, 40, -32, 62, -56, 140, -56, 168, -32, L - 4, -28, L, -12, L - 2, -8, 0, -8], col);
      win(68, -52, 32, 20); win(105, -52, 32, 20);
      c.fillStyle = '#fff59d'; rr(c, L - 8, -26, 7, 6, 2); c.fill(); c.fillStyle = '#e53935'; rr(c, 1, -26, 5, 7, 2); c.fill();
      if (type === 'police') { c.fillStyle = '#1e3a8a'; c.fillRect(4, -24, L - 8, 7); if (!o.noText) text(c, 'شرطة', L / 2, -21, 8, '#fff'); c.fillStyle = Math.sin(t * 12) > 0 ? '#e53935' : '#1565c0'; rr(c, 95, -63, 18, 7, 2); c.fill(); }
      A.wheel(c, 40, -14, 14, wr); A.wheel(c, L - 40, -14, 14, wr);
    } else if (type === 'microbus') {
      body([0, -10, 0, -84, 8, -92, L - 50, -92, L - 18, -60, L - 2, -54, L, -12, 0, -10], col);
      c.fillStyle = '#1565c0'; c.fillRect(0, -40, L - 4, 6);
      for (let i = 0; i < 4; i++) win(12 + i * 42, -84, 34, 24);
      c.fillStyle = 'rgba(150,200,230,.85)'; c.beginPath(); c.moveTo(L - 48, -86); c.lineTo(L - 22, -60); c.lineTo(L - 40, -60); c.lineTo(L - 52, -86); c.fill();
      c.fillStyle = '#fff59d'; rr(c, L - 8, -26, 7, 6, 2); c.fill();
      A.wheel(c, 44, -14, 15, wr); A.wheel(c, L - 46, -14, 15, wr);
    } else if (type === 'bus') {
      body([0, -10, 0, -130, 6, -136, L - 10, -136, L, -126, L, -12], col);
      for (let i = 0; i < 7; i++) win(14 + i * 50, -122, 42, 36);
      c.fillStyle = '#fff'; c.fillRect(0, -76, L, 6); if (!o.noText) text(c, 'هيئة النقل العام', L / 2, -56, 13, '#fff', 'center', true, 2);
      A.wheel(c, 60, -15, 17, wr); A.wheel(c, L - 70, -15, 17, wr);
    } else if (type === 'truck') {
      body([0, -14, 0, -120, L - 92, -120, L - 92, -14], '#8d6e63');
      c.strokeStyle = 'rgba(0,0,0,.25)'; for (let i = 10; i < L - 92; i += 22) { c.beginPath(); c.moveTo(i, -118); c.lineTo(i, -16); c.stroke(); }
      body([L - 88, -12, L - 88, -96, L - 30, -96, L, -60, L, -12], col);
      win(L - 70, -88, 38, 26);
      A.wheel(c, 40, -16, 16, wr); A.wheel(c, 80, -16, 16, wr); A.wheel(c, L - 50, -16, 16, wr);
    } else if (type === 'tuktuk') {
      c.translate(70, -30);
      A.tuktukBody(c, { color: col, trim: '#f2c230', t: t, inside: cc => A.person(cc, 22, 28, { skin: '#a8714a', shirt: '#795548', pants: '#333', hair: '#111', mustache: true }, 'drive', t, {}) });
      A.wheel(c, -41, 15, 15, wr); A.wheel(c, 46, 15, 15, wr);
    } else if (type === 'moto') {
      line(c, 18, -16, 70, -16, 6, col); body([30, -22, 70, -26, 78, -36, 40, -34], col);
      A.person(c, 50, -6, { skin: '#c48a5c', shirt: '#37474f', pants: '#263238', hair: '#111', capBack: '#e53935' }, 'drive', t, {});
      A.wheel(c, 16, -14, 14, wr, '#777'); A.wheel(c, L - 14, -14, 14, wr, '#777');
    } else if (type === 'tractor') {
      body([30, -16, 30, -50, 110, -50, 120, -30, L, -30, L, -14], col);
      c.fillStyle = '#333'; c.fillRect(48, -100, 4, 50); c.fillRect(96, -100, 4, 50); c.fillStyle = col; c.fillRect(44, -104, 60, 6);
      A.person(c, 78, -40, TT.PASSENGER_TYPES.farmer.look, 'drive', t, {});
      line(c, 128, -48, 128, -70, 4, '#333');
      A.wheel(c, 60, -30, 30, wr, '#f9a825'); A.wheel(c, L - 24, -18, 17, wr, '#f9a825');
    } else if (type === 'cart') {
      // donkey cart (كارو) — donkey in front
      c.fillStyle = '#8d6e63'; rr(c, 0, -46, 92, 14, 2); c.fill(); c.fillStyle = '#a1887f'; c.fillRect(0, -60, 92, 4);
      for (let i = 0; i < 4; i++) ell(c, 16 + i * 20, -62, 10, 8, i % 2 ? '#ff7043' : '#7cb342');
      line(c, 92, -40, 120, -40, 3, '#5d4037');
      A.animal(c, 'donkey', 132, 0, t, 1);
      A.person(c, 60, -46, TT.PASSENGER_TYPES.farmer.look, 'sit', t, {});
      A.wheel(c, 46, -22, 22, wr, '#8d6e63');
    } else if (type === 'jeep') {
      body([0, -16, 0, -60, 70, -62, 110, -86, 160, -86, 172, -60, L, -56, L, -16], col);
      win(116, -82, 40, 20); c.fillStyle = '#333'; c.fillRect(-6, -56, 6, 30);
      A.wheel(c, 44, -18, 18, wr); A.wheel(c, L - 42, -18, 18, wr);
    } else if (type === 'box') {
      // البوكس: بيك أب شرطة بقفص
      body([0, -14, 0, -62, 150, -62, 150, -14], '#eceff1');
      c.fillStyle = '#1e3a8a'; c.fillRect(0, -40, L - 4, 8); if (!o.noText) text(c, 'شرطة', 75, -26, 11, '#1e3a8a');
      c.strokeStyle = '#37474f'; c.lineWidth = 3; c.strokeRect(6, -112, 138, 50); for (let i = 14; i < 144; i += 12) { c.beginPath(); c.moveTo(i, -112); c.lineTo(i, -62); c.stroke(); }
      if (o.inCage) o.inCage(c);
      body([150, -12, 150, -100, 200, -100, L - 6, -62, L, -58, L, -12], '#eceff1');
      win(160, -94, 34, 26); c.fillStyle = Math.sin(t * 12) > 0 ? '#e53935' : '#1565c0'; rr(c, 165, -108, 26, 8, 3); c.fill();
      c.fillStyle = '#1e3a8a'; c.fillRect(150, -40, L - 154, 8);
      A.wheel(c, 44, -16, 17, wr); A.wheel(c, L - 44, -16, 17, wr);
    } else if (type === 'rover') {
      body([10, -40, 10, -70, 150, -70, 180, -46, 180, -36, 10, -36], col);
      c.fillStyle = 'rgba(100,220,255,.6)'; rr(c, 120, -68, 40, 22, 6); c.fill();
      line(c, 40, -70, 30, -110, 2, '#90a4ae'); ell(c, 30, -112, 10, 4, '#cfd8dc');
      c.fillStyle = '#f26a3c'; c.fillRect(20, -54, 80, 5);
      for (let i = 0; i < 3; i++) { line(c, 30 + i * 60, -36, 30 + i * 60, -16, 3, '#78909c'); A.wheel(c, 30 + i * 60, -14, 14, wr, '#cfd8dc'); }
    }
    if (o.label) text(c, o.label, L / 2, -110, 12, '#fff', 'center', true, 3);
    c.restore();
  };

  /* =================================================================
     ANIMALS
     ================================================================= */
  A.animal = function (c, type, x, y, t, s, facing, procedural) {
    const aimg = !procedural && A.img(A.P.animal(type));
    if (aimg) { c.save(); c.translate(x, y); c.scale((s || 1) * (facing || 1), s || 1); c.drawImage(aimg, -A.ANIMAL_IMG.anchorX, -A.ANIMAL_IMG.anchorY); c.restore(); return; }
    c.save(); c.translate(x, y); c.scale((s || 1) * (facing || 1), s || 1);
    const leg = (lx, ph) => { const a = Math.sin(t * 6 + ph) * 0.3; line(c, lx, -26, lx + Math.sin(a) * 10, 0, 5, '#3e2723'); };
    c.globalAlpha = 0.25; ell(c, 0, 1, 34, 4, '#000'); c.globalAlpha = 1;
    if (type === 'cow' || type === 'buffalo') {
      const col = type === 'cow' ? '#f5f5f5' : '#37373d';
      leg(-24, 0); leg(-16, 2); leg(18, 1); leg(26, 3);
      ell(c, 0, -38, 36, 18, col);
      if (type === 'cow') { ell(c, -10, -42, 9, 7, '#4e342e'); ell(c, 14, -34, 7, 6, '#4e342e'); }
      ell(c, 38, -46, 12, 10, col); ell(c, 46, -42, 6, 5, '#f8bbd0');
      c.strokeStyle = type === 'cow' ? '#bdbdbd' : '#ccc'; c.lineWidth = 3; c.beginPath(); c.arc(36, -60, 8, P, P * 1.8); c.stroke();
      ell(c, 41, -49, 1.8, 1.8, '#000');
      line(c, -36, -40, -44, -20, 2, col);
    } else if (type === 'camel') {
      leg(-18, 0); leg(-10, 2); leg(16, 1); leg(24, 3);
      c.translate(0, -12);
      ell(c, 0, -34, 32, 14, '#c8a165'); ell(c, -4, -48, 13, 12, '#c8a165');
      c.beginPath(); c.moveTo(24, -36); c.quadraticCurveTo(44, -40, 40, -70); c.lineWidth = 9; c.strokeStyle = '#c8a165'; c.stroke();
      ell(c, 46, -72, 10, 6, '#c8a165'); ell(c, 48, -74, 1.6, 1.6, '#000');
    } else if (type === 'donkey') {
      leg(-16, 0); leg(-8, 2); leg(14, 1); leg(20, 3);
      ell(c, 0, -34, 24, 11, '#8d8d8d'); line(c, 18, -38, 30, -56, 8, '#8d8d8d'); ell(c, 34, -58, 9, 6, '#8d8d8d');
      line(c, 28, -62, 26, -76, 3, '#8d8d8d'); ell(c, 36, -60, 1.5, 1.5, '#000');
    } else if (type === 'chicken') {
      ell(c, 0, -10, 9, 7, '#fff'); ell(c, 8, -16, 4.5, 4.5, '#fff'); c.fillStyle = '#e53935'; c.fillRect(6, -22, 4, 3);
      c.fillStyle = '#ff9800'; c.beginPath(); c.moveTo(12, -16); c.lineTo(16, -15); c.lineTo(12, -14); c.fill();
      line(c, -1, -4, -1 + Math.sin(t * 15) * 2, 0, 1.2, '#ff9800'); line(c, 2, -4, 2 - Math.sin(t * 15) * 2, 0, 1.2, '#ff9800');
    }
    c.restore();
  };

  /* =================================================================
     OBSTACLES & ROAD OBJECTS (y = road line at that x)
     ================================================================= */
  A.obstacle = function (c, ob, y, t, procedural) {
    const x = ob.x * PX, w = ob.w * PX;
    const oimg = !procedural && ob.type !== 'chicken' && A.img(A.P.ob(ob.type));
    if (oimg) {
      const def = TT.OBSTACLES[ob.type] || {}, I = A.OB_IMG;
      c.save();
      if (ob.hit) { c.translate(x + ob.dx * PX, y - ob.dy * PX); c.rotate(ob.rot); } else c.translate(x, y);
      if (def.kind === 'surface' && def.w) c.scale(ob.w / def.w, 1);
      c.drawImage(oimg, -I.anchorX, -I.anchorY); c.restore(); return;
    }
    switch (ob.type) {
      case 'bump': {
        c.beginPath(); c.moveTo(x - w / 2, y);
        for (let i = 0; i <= 12; i++) { const u = i / 12; c.lineTo(x - w / 2 + u * w, y - ob.h * PX * (1 - Math.cos(u * P * 2)) / 2); }
        c.closePath(); c.fillStyle = '#f2c230'; c.fill();
        c.save(); c.clip(); c.fillStyle = '#222'; for (let i = -2; i < 6; i++) c.fillRect(x - w / 2 + i * 12, y - 10, 6, 12); c.restore();
        c.fillStyle = 'rgba(0,0,0,.25)'; c.fillRect(x - w / 2, y, w, 18);
        break;
      }
      case 'pothole': case 'crater': {
        c.fillStyle = ob.type === 'crater' ? '#5d1f12' : '#2a2522';
        c.beginPath(); c.ellipse(x, y + 4, w / 2, 10, 0, 0, P * 2); c.fill();
        c.fillStyle = ob.type === 'crater' ? '#3e1209' : '#151210'; c.beginPath(); c.ellipse(x, y + 5, w / 2 - 4, 6, 0, 0, P * 2); c.fill();
        c.strokeStyle = 'rgba(255,255,255,.12)'; c.lineWidth = 1; c.beginPath(); c.ellipse(x, y + 4, w / 2, 10, 0, P, P * 2); c.stroke();
        if (ob.type === 'crater') { c.fillStyle = '#8a3a22'; ell(c, x - w / 2, y + 2, 10, 5); c.fill(); ell(c, x + w / 2, y + 2, 10, 5); c.fill(); }
        break;
      }
      case 'ramp': {
        c.fillStyle = '#7a5a3a'; c.beginPath(); c.moveTo(x - w / 2, y);
        c.lineTo(x + w / 2, y - ob.h * PX); c.lineTo(x + w / 2, y); c.closePath(); c.fill();
        c.strokeStyle = '#4e342e'; c.lineWidth = 2; c.stroke();
        break;
      }
      case 'rock': {
        c.fillStyle = ob.mars ? '#7a2e1a' : '#7d746b'; c.beginPath(); c.moveTo(x - w / 2, y); c.lineTo(x - w / 3, y - ob.h * PX * 0.9); c.lineTo(x + w / 6, y - ob.h * PX); c.lineTo(x + w / 2, y - 2); c.closePath(); c.fill();
        c.fillStyle = 'rgba(255,255,255,.15)'; c.beginPath(); c.moveTo(x - w / 3, y - ob.h * PX * 0.9); c.lineTo(x + w / 6, y - ob.h * PX); c.lineTo(x, y - 4); c.fill();
        break;
      }
      case 'tire': {
        ell(c, x, y - ob.h * PX / 2, w / 2, ob.h * PX / 2, '#1a1a1a'); ell(c, x, y - ob.h * PX / 2, w / 4, ob.h * PX / 4.5, '#444');
        break;
      }
      case 'water': case 'oil': case 'sand': {
        const g = c.createLinearGradient(x - w / 2, 0, x + w / 2, 0);
        if (ob.type === 'water') { g.addColorStop(0, 'rgba(80,160,230,.0)'); g.addColorStop(0.2, 'rgba(80,160,230,.75)'); g.addColorStop(0.8, 'rgba(110,190,240,.75)'); g.addColorStop(1, 'rgba(80,160,230,0)'); }
        else if (ob.type === 'oil') { g.addColorStop(0, 'rgba(20,20,30,0)'); g.addColorStop(0.3, 'rgba(30,25,45,.9)'); g.addColorStop(0.5, 'rgba(70,40,110,.8)'); g.addColorStop(0.7, 'rgba(25,60,60,.9)'); g.addColorStop(1, 'rgba(20,20,30,0)'); }
        else { g.addColorStop(0, 'rgba(225,190,120,0)'); g.addColorStop(0.15, 'rgba(225,190,120,.95)'); g.addColorStop(0.85, 'rgba(225,190,120,.95)'); g.addColorStop(1, 'rgba(225,190,120,0)'); }
        c.fillStyle = g; c.beginPath(); c.ellipse(x, y + 6, w / 2, ob.type === 'sand' ? 14 : 9, 0, 0, P * 2); c.fill();
        if (ob.type === 'water') { c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 1; c.beginPath(); c.moveTo(x - 20 + Math.sin(t * 2) * 4, y + 4); c.lineTo(x + Math.sin(t * 2) * 4, y + 4); c.stroke(); }
        if (ob.type === 'sand') { c.fillStyle = 'rgba(160,120,60,.5)'; for (let i = 0; i < 6; i++) ell(c, x - w / 2 + 20 + i * (w - 40) / 5, y - 2, 12, 4); c.fill(); }
        break;
      }
      case 'cone': {
        if (ob.hit) { c.save(); c.translate(x + ob.dx * PX, y - ob.dy * PX); c.rotate(ob.rot); }
        else { c.save(); c.translate(x, y); }
        c.fillStyle = '#ff6d00'; c.beginPath(); c.moveTo(-9, 0); c.lineTo(-3, -24); c.lineTo(3, -24); c.lineTo(9, 0); c.fill();
        c.fillStyle = '#fff'; c.fillRect(-6, -14, 12, 4); c.fillStyle = '#333'; c.fillRect(-11, -2, 22, 3); c.restore();
        break;
      }
      case 'box': {
        c.save(); if (ob.hit) { c.translate(x + ob.dx * PX, y - ob.dy * PX); c.rotate(ob.rot); } else c.translate(x, y);
        c.fillStyle = '#b07a3e'; c.fillRect(-19, -36, 38, 36); c.strokeStyle = '#6d4520'; c.lineWidth = 2; c.strokeRect(-19, -36, 38, 36);
        c.beginPath(); c.moveTo(-19, -36); c.lineTo(19, 0); c.moveTo(19, -36); c.lineTo(-19, 0); c.stroke(); c.restore();
        break;
      }
      case 'chicken': {
        if (ob.hit) { A.animal(c, 'chicken', x + ob.dx * PX, y - ob.dy * PX, t, 1.4); for (let i = 0; i < 3; i++) ell(c, x + ob.dx * PX + Math.sin(t * 5 + i) * 20, y - ob.dy * PX - 20 - i * 6, 3, 1.5, '#fff'); }
        else A.animal(c, 'chicken', x + Math.sin(t * 1.5 + ob.x) * 10, y, t, 1.4, Math.cos(t * 1.5 + ob.x) > 0 ? 1 : -1);
        break;
      }
    }
  };

  /* ---------- signs & structures (drawn on back sidewalk) ---------- */
  function pole(c, x, y, h) { c.fillStyle = '#8a8f96'; c.fillRect(x - 2, y - h, 4, h); }
  A.sign = function (c, s, y, t, light) {
    const x = s.x * PX;
    switch (s.type) {
      case 'speed': pole(c, x, y, 70); ell(c, x, y - 78, 15, 15, '#fff'); c.lineWidth = 4; c.strokeStyle = '#d32f2f'; c.stroke(); text(c, String(s.limit), x, y - 77, 13, '#111'); if (s.zone) text(c, s.zone, x, y - 101, 10, '#fff', 'center', true, 3); break;
      case 'warnBump': case 'warnHole': pole(c, x, y, 64); c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x, y - 98); c.lineTo(x + 17, y - 68); c.lineTo(x - 17, y - 68); c.closePath(); c.fill(); c.lineWidth = 3; c.strokeStyle = '#d32f2f'; c.stroke(); text(c, s.type === 'warnBump' ? 'مطب' : 'حفر', x, y - 76, 9, '#111'); break;
      case 'quiet': pole(c, x, y, 70); ell(c, x, y - 80, 15, 15, '#1565c0'); text(c, '📯', x, y - 80, 13); line(c, x - 10, y - 90, x + 10, y - 70, 3, '#d32f2f'); text(c, s.end ? 'نهاية المنطقة الهادئة' : 'منطقة هادئة', x, y - 104, 10, '#fff', 'center', true, 3); break;
      case 'noPark': pole(c, x, y, 70); ell(c, x, y - 80, 15, 15, '#1565c0'); c.lineWidth = 3; c.strokeStyle = '#d32f2f'; c.stroke(); text(c, 'P', x, y - 80, 14, '#fff'); line(c, x - 10, y - 90, x + 10, y - 70, 3, '#d32f2f'); break;
      case 'village': pole(c, x - 20, y, 60); pole(c, x + 20, y, 60); c.fillStyle = '#2e7d32'; rr(c, x - 44, y - 92, 88, 34, 4); c.fill(); text(c, s.end ? 'نهاية القرية' : s.name, x, y - 82, 10, '#fff'); if (!s.end) text(c, 'السرعة ' + s.limit, x, y - 67, 9, '#ffeb3b'); break;
      case 'storm': pole(c, x, y, 60); c.fillStyle = '#f9a825'; rr(c, x - 36, y - 88, 72, 28, 4); c.fill(); text(c, s.end ? 'نهاية العاصفة' : 'عاصفة ترابية', x, y - 74, 10, '#111'); break;
      case 'tunnel': break;
      case 'radarWarn': pole(c, x, y, 66); c.fillStyle = '#fff'; rr(c, x - 24, y - 100, 48, 34, 5); c.fill(); c.strokeStyle = '#d32f2f'; c.lineWidth = 3; c.stroke(); text(c, '📸', x, y - 89, 14); text(c, 'رادار', x, y - 73, 9, '#d32f2f'); break;
    }
  };
  A.station = function (c, st, y, t, highlight) {
    const x = st.x * PX;
    // shelter
    c.fillStyle = 'rgba(0,0,0,.2)'; c.fillRect(x - 60, y - 2, 120, 4);
    c.fillStyle = '#546e7a'; c.fillRect(x - 56, y - 74, 4, 74); c.fillRect(x + 52, y - 74, 4, 74);
    c.fillStyle = highlight ? '#ffb300' : '#1565c0'; rr(c, x - 64, y - 88, 128, 18, 4); c.fill();
    text(c, st.name, x, y - 79, 10.5, '#fff');
    c.fillStyle = 'rgba(180,220,240,.35)'; c.fillRect(x - 52, y - 70, 104, 40);
    c.fillStyle = '#795548'; c.fillRect(x - 40, y - 22, 80, 5);
    // stop sign
    pole(c, x + 72, y, 76); c.fillStyle = '#1565c0'; rr(c, x + 60, y - 100, 24, 24, 4); c.fill(); text(c, '🚏', x + 72, y - 88, 13);
  };
  A.trafficLight = function (c, x, y, state) {
    c.fillStyle = '#37474f'; c.fillRect(x - 3, y - 120, 6, 120);
    rr(c, x - 11, y - 160, 22, 50, 5); c.fillStyle = '#212121'; c.fill();
    ell(c, x, y - 150, 6, 6, state === 'red' ? '#ff1744' : '#4a1010');
    ell(c, x, y - 135, 6, 6, state === 'yellow' ? '#ffd600' : '#4a3f10');
    ell(c, x, y - 120 + 0, 6, 6, state === 'green' ? '#00e676' : '#0f3a1f');
    if (state === 'red') { c.globalAlpha = 0.25; ell(c, x, y - 150, 14, 14, '#ff1744'); c.globalAlpha = 1; }
  };
  A.stopLine = function (c, x, y) { c.fillStyle = '#fff'; c.fillRect(x - 3, y - 18, 6, 36); };
  A.crosswalk = function (c, x, y) { c.fillStyle = 'rgba(255,255,255,.85)'; for (let i = 0; i < 5; i++) { c.save(); c.translate(x, y - 22 + i * 12); c.transform(1, 0, -0.5, 1, 0, 0); c.fillRect(-28, 0, 56, 6); c.restore(); } };
  A.radar = function (c, x, y, flash) {
    c.fillStyle = '#607d8b'; c.fillRect(x - 3, y - 110, 6, 110);
    c.fillStyle = '#eceff1'; rr(c, x - 4, y - 124, 30, 18, 3); c.fill(); ell(c, x + 22, y - 115, 5, 5, '#263238');
    if (flash > 0) { c.globalAlpha = flash; ell(c, x + 22, y - 115, 40, 40, '#fff'); c.globalAlpha = 1; }
    text(c, 'رادار', x + 11, y - 134, 9, '#fff', 'center', true, 3);
  };
  A.checkpoint = function (c, x, y, t, open) {
    c.fillStyle = '#d32f2f'; c.fillRect(x - 70, y - 40, 10, 40);
    c.save(); c.translate(x - 65, y - 36); c.rotate(open ? -1.3 : 0);
    for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#fff' : '#d32f2f'; c.fillRect(i * 14, -4, 14, 7); }
    c.restore();
    A.person(c, x + 40, y - 6, { skin: '#a8714a', shirt: '#1a237e', pants: '#1a237e', hair: '#111', cap: '#1a237e', mustache: true }, open ? 'wave' : 'point', t, { facing: -1 });
    text(c, 'كمين مرور', x, y - 120, 11, '#fff', 'center', true, 3);
  };
  A.gasStation = function (c, x, y, t, name) {
    c.fillStyle = '#eceff1'; c.fillRect(x - 90, y - 130, 180, 14); c.fillStyle = '#e53935'; c.fillRect(x - 90, y - 118, 180, 6);
    c.fillStyle = '#90a4ae'; c.fillRect(x - 80, y - 116, 6, 116); c.fillRect(x + 74, y - 116, 6, 116);
    c.fillStyle = '#e53935'; rr(c, x - 14, y - 60, 28, 60, 4); c.fill(); c.fillStyle = '#fff'; c.fillRect(x - 9, y - 52, 18, 12);
    line(c, x + 14, y - 40, x + 26, y - 20, 2.5, '#222');
    text(c, name || 'بنزينة', x, y - 124, 10, '#d32f2f');
  };
  // استراحة على الطريق: مبنى صغير وتندة وترابيزات وشاي
  A.restStop = function (c, x, y, t, name) {
    c.fillStyle = '#d7ccc8'; c.fillRect(x - 80, y - 90, 160, 90); c.fillStyle = '#a1887f'; c.fillRect(x - 84, y - 96, 168, 8);
    c.fillStyle = '#4e342e'; rr(c, x - 20, y - 56, 34, 56, 3); c.fill(); c.fillStyle = '#ffe082'; c.fillRect(x - 64, y - 70, 30, 22); c.fillRect(x + 34, y - 70, 30, 22);
    for (let i = 0; i < 8; i++) { c.fillStyle = i % 2 ? '#fff' : '#2e7d32'; c.beginPath(); c.moveTo(x - 92 + i * 23, y - 96); c.lineTo(x - 69 + i * 23, y - 96); c.lineTo(x - 66 + i * 23, y - 80); c.lineTo(x - 89 + i * 23, y - 80); c.fill(); }
    c.fillStyle = '#1b5e20'; rr(c, x - 62, y - 128, 124, 26, 6); c.fill(); text(c, '☕ ' + (name || 'استراحة'), x, y - 115, 12, '#fff');
    for (const tx of [x - 120, x + 110]) { c.fillStyle = '#795548'; c.fillRect(tx - 14, y - 22, 28, 4); c.fillRect(tx - 2, y - 18, 4, 18); ell(c, tx - 6, y - 26, 3, 4, '#fff'); ell(c, tx + 6, y - 26, 3, 4, '#ffcc80'); if (Math.sin(t * 2 + tx) > 0) { c.globalAlpha = 0.4; ell(c, tx - 6, y - 34 - (t * 10 % 8), 2, 3, '#eee'); c.globalAlpha = 1; } }
  };
  // ورشة على الطريق: جراج بباب صاج وعدة
  A.roadShop = function (c, x, y, t, name) {
    c.fillStyle = '#90a4ae'; c.fillRect(x - 76, y - 100, 152, 100); c.fillStyle = '#546e7a'; c.fillRect(x - 80, y - 106, 160, 8);
    c.fillStyle = '#263238'; c.fillRect(x - 56, y - 74, 112, 74); c.fillStyle = '#b0bec5'; for (let i = 0; i < 6; i++) c.fillRect(x - 56, y - 74 + i * 5, 112, 2.5);
    c.fillStyle = '#ffb300'; rr(c, x - 64, y - 132, 128, 26, 6); c.fill(); text(c, '🔧 ' + (name || 'ورشة'), x, y - 119, 12, '#212121');
    c.fillStyle = '#424242'; ell(c, x + 96, y - 10, 12, 12); c.fill(); ell(c, x + 96, y - 10, 5, 5, '#9e9e9e'); ell(c, x + 104, y - 26, 10, 10, '#424242');
    const sw = Math.sin(t * 6) * 0.4; c.save(); c.translate(x - 96, y - 30); c.rotate(sw); line(c, 0, 0, 14, -14, 3, '#9e9e9e'); c.restore();
    if (Math.random() < 0.3) { c.fillStyle = '#ffeb3b'; c.fillRect(x - 96 + Math.random() * 6, y - 40 + Math.random() * 6, 2, 2); }
  };
  // معلم كوبري (زي كوبري طلخا): نهر + كوبري عربيات بأقواس + كوبري سكة حديد وقطر معدّي
  A.bridgeLandmark = function (c, x, y, t, name) {
    const W = 760, L = x - W / 2;
    // النهر
    const wg = c.createLinearGradient(0, y - 60, 0, y); wg.addColorStop(0, '#4f9fd6'); wg.addColorStop(1, '#2f78b4');
    c.fillStyle = wg; c.fillRect(L - 60, y - 58, W + 120, 58);
    c.strokeStyle = 'rgba(255,255,255,.35)'; c.lineWidth = 1.5; for (let i = 0; i < 10; i++) { const wx = L + ((i * 97 + t * 20) % (W + 60)) - 30, wy = y - 48 + (i % 4) * 11; c.beginPath(); c.moveTo(wx, wy); c.quadraticCurveTo(wx + 8, wy - 3, wx + 16, wy); c.stroke(); }
    // كوبري السكة الحديد (ورا): جمالون حديد
    const ry = y - 128; c.fillStyle = '#546e7a'; c.fillRect(L, ry, W, 7);
    c.strokeStyle = '#37474f'; c.lineWidth = 3; c.beginPath();
    for (let i = 0; i <= 16; i++) { const px = L + i * W / 16; c.moveTo(px, ry); c.lineTo(px, ry - 26); if (i < 16) { c.moveTo(px, ry); c.lineTo(px + W / 16, ry - 26); } }
    c.moveTo(L, ry - 26); c.lineTo(L + W, ry - 26); c.stroke();
    for (const px of [L + 120, L + W / 2, L + W - 120]) { c.fillStyle = '#607d8b'; c.fillRect(px - 8, ry + 7, 16, y - ry - 7); }
    // القطر: بيعدّي كل شوية
    const per = 14, ph = (t % per) / per, tx = L - 520 + ph * (W + 1100);
    if (ph < 0.85) {
      const cars = 6, cw = 86;
      for (let k = 0; k < cars; k++) {
        const cx = tx - k * (cw + 4); if (cx < L - 140 || cx - cw > L + W + 140) continue;
        c.fillStyle = k === 0 ? '#c62828' : '#1565c0'; A.rr(c, cx - cw, ry - 24, cw, 22, 4); c.fill();
        c.fillStyle = '#e3f2fd'; for (let w = 0; w < 5; w++) c.fillRect(cx - cw + 8 + w * 15, ry - 20, 10, 7);
        c.fillStyle = '#fbc02d'; c.fillRect(cx - cw, ry - 9, cw, 2.5);
        c.fillStyle = '#212121'; for (const wx of [cx - cw + 14, cx - 14]) { c.beginPath(); c.arc(wx, ry - 1, 4, 0, 7); c.fill(); }
        if (k === 0) { c.fillStyle = '#fff59d'; c.beginPath(); c.arc(cx - 3, ry - 13, 3, 0, 7); c.fill(); }
      }
      c.globalAlpha = 0.35; c.fillStyle = '#eee'; for (let k = 0; k < 4; k++) { c.beginPath(); c.arc(tx - 40 - k * 18 - (t * 30 % 18), ry - 34 - k * 4, 6 + k * 2, 0, 7); c.fill(); } c.globalAlpha = 1;
    }
    // كوبري العربيات (قدّام): أقواس خرسانة وسور
    const dy = y - 74; c.fillStyle = '#d7ccc8'; c.fillRect(L - 30, dy, W + 60, 12);
    c.fillStyle = '#bcaaa4'; for (let i = 0; i < 5; i++) { const ax = L + i * W / 5, aw = W / 5; c.beginPath(); c.moveTo(ax, dy + 12); c.lineTo(ax + aw, dy + 12); c.lineTo(ax + aw, y - 58); c.quadraticCurveTo(ax + aw / 2, dy + 22, ax, y - 58); c.closePath(); c.fill(); }
    c.fillStyle = '#8d6e63'; for (let i = 0; i <= 5; i++) c.fillRect(L + i * W / 5 - 7, dy + 10, 14, y - dy - 10);
    c.strokeStyle = '#6d4c41'; c.lineWidth = 2; c.beginPath(); c.moveTo(L - 30, dy - 10); c.lineTo(L + W + 30, dy - 10); for (let px = L - 30; px <= L + W + 30; px += 14) { c.moveTo(px, dy); c.lineTo(px, dy - 10); } c.stroke();
    for (let i = 0; i < 6; i++) { const lx = L + i * W / 5; c.strokeStyle = '#455a64'; c.lineWidth = 2; c.beginPath(); c.moveTo(lx, dy - 10); c.lineTo(lx, dy - 34); c.stroke(); c.fillStyle = '#ffe082'; c.beginPath(); c.arc(lx, dy - 36, 3.5, 0, 7); c.fill(); }
    // يافطة

    return { trainX: tx, show: ph < 0.85 };
  };
  A.finish = function (c, x, y, label) {
    c.fillStyle = '#5d4037'; c.fillRect(x - 6, y - 150, 8, 150); c.fillRect(x + 140, y - 150, 8, 150);
    c.fillStyle = '#1b5e20'; rr(c, x - 10, y - 170, 162, 30, 6); c.fill();
    text(c, label || 'نهاية الخط', x + 71, y - 155, 14, '#fff');
    for (let i = 0; i < 12; i++) { c.fillStyle = i % 2 ? '#111' : '#fff'; c.fillRect(x + 4 + i * 11.3, y - 140, 11.3, 6); }
  };
  A.workZone = function (c, x, y, t) {
    for (let i = 0; i < 3; i++) { c.fillStyle = '#ffeb3b'; c.fillRect(x - 40 + i * 40, y - 30, 30, 8); c.fillStyle = '#111'; for (let k = 0; k < 3; k++) c.fillRect(x - 38 + i * 40 + k * 10, y - 30, 5, 8); c.fillStyle = '#555'; c.fillRect(x - 36 + i * 40, y - 22, 3, 22); c.fillRect(x - 16 + i * 40, y - 22, 3, 22); }
    A.person(c, x + 70, y, { skin: '#9b6640', shirt: '#ff6f00', pants: '#37474f', hair: '#111', cap: '#ffeb3b' }, 'repair', t, {});
    text(c, 'أعمال صيانة — هدّي السرعة', x, y - 54, 10, '#ffeb3b', 'center', true, 3);
  };

  /* ---------- props on the back sidewalk (world space) ---------- */
  A.prop = function (c, p, y, t, theme) {
    const x = p.x * PX;
    switch (p.type) {
      case 'lamp': c.fillStyle = '#455a64'; c.fillRect(x - 2, y - 140, 4, 140); c.fillRect(x - 2, y - 140, 26, 4); ell(c, x + 24, y - 134, 7, 4, '#fff8c4'); break;
      case 'palm': {
        c.strokeStyle = '#7b5a3a'; c.lineWidth = 8; c.beginPath(); c.moveTo(x, y); c.quadraticCurveTo(x + 10, y - 80, x + 4, y - 150); c.stroke();
        for (let i = 0; i < 7; i++) { const a = -P / 2 + (i - 3) * 0.45 + Math.sin(t + i) * 0.04; c.strokeStyle = i % 2 ? '#2e7d32' : '#388e3c'; c.lineWidth = 6; c.beginPath(); c.moveTo(x + 4, y - 150); c.quadraticCurveTo(x + 4 + Math.cos(a) * 30, y - 150 + Math.sin(a) * 30 - 10, x + 4 + Math.cos(a) * 54, y - 150 + Math.sin(a) * 40 + 18); c.stroke(); }
        break;
      }
      case 'tree': c.fillStyle = '#6d4c41'; c.fillRect(x - 4, y - 70, 8, 70); ell(c, x, y - 90, 32, 28, '#43a047'); ell(c, x - 14, y - 78, 20, 16, '#388e3c'); ell(c, x + 16, y - 82, 18, 16, '#2e7d32'); break;
      case 'kiosk': {
        c.fillStyle = '#c62828'; rr(c, x - 34, y - 70, 68, 70, 3); c.fill(); c.fillStyle = '#ffeb3b'; c.fillRect(x - 38, y - 80, 76, 12); text(c, p.label || 'كشك', x, y - 74, 9, '#c62828');
        c.fillStyle = '#ffe082'; c.fillRect(x - 28, y - 60, 56, 26); for (let i = 0; i < 6; i++) { c.fillStyle = ['#e53935', '#1e88e5', '#43a047', '#fdd835'][i % 4]; c.fillRect(x - 26 + i * 9, y - 58, 7, 10); }
        break;
      }
      case 'fruit': {
        c.fillStyle = '#795548'; c.fillRect(x - 40, y - 36, 80, 8); A.wheel(c, x - 26, y - 12, 12, 0, '#8d6e63'); A.wheel(c, x + 26, y - 12, 12, 0, '#8d6e63');
        for (let i = 0; i < 8; i++) ell(c, x - 34 + i * 9.5, y - 42, 6, 6, i % 3 === 0 ? '#ff9800' : i % 3 === 1 ? '#e53935' : '#7cb342');
        c.fillStyle = '#fff3e0'; c.fillRect(x - 44, y - 82, 88, 4); line(c, x - 40, y - 80, x - 40, y - 36, 2, '#555'); line(c, x + 40, y - 80, x + 40, y - 36, 2, '#555');
        A.person(c, x + 54, y, { skin: '#9b6640', shirt: '#5d4037', pants: '#5d4037', galabeya: true, taqiya: '#fff', mustache: true }, 'talk', t + p.x, { facing: -1, talk: Math.sin(t * 0.7 + p.x) > 0.5 });
        break;
      }
      case 'cafe': {
        c.fillStyle = '#6d4c41'; c.fillRect(x - 6, y - 30, 12, 4); line(c, x, y - 26, x, y, 2, '#4e342e');
        for (const dx of [-24, 24]) { c.fillStyle = '#8d6e63'; c.fillRect(x + dx - 7, y - 18, 14, 3); line(c, x + dx - 5, y - 15, x + dx - 5, y, 1.5, '#5d4037'); line(c, x + dx + 5, y - 15, x + dx + 5, y, 1.5, '#5d4037'); }
        ell(c, x + 2, y - 34, 3, 3, '#fff'); c.globalAlpha = 0.4; ell(c, x + 2 + Math.sin(t * 2) * 2, y - 44, 2, 4, '#fff'); c.globalAlpha = 1;
        A.person(c, x - 24, y - 14, { skin: '#a8714a', shirt: '#90a4ae', pants: '#37474f', hair: '#222', mustache: true }, 'sit', t, { facing: 1 });
        // shisha
        c.fillStyle = '#26a69a'; ell(c, x + 40, y - 8, 7, 8); c.fill(); line(c, x + 40, y - 16, x + 40, y - 38, 2.5, '#b0bec5'); ell(c, x + 40, y - 40, 5, 3, '#8d6e63');
        break;
      }
      case 'hay': ell(c, x, y - 18, 34, 22, '#d4a84b'); c.strokeStyle = '#a07a2a'; c.lineWidth = 1; for (let i = -2; i <= 2; i++) { c.beginPath(); c.moveTo(x + i * 12, y - 36); c.lineTo(x + i * 14, y - 2); c.stroke(); } break;
      case 'rockSmall': c.fillStyle = theme === 'mars' ? '#8b3a22' : '#a1887f'; c.beginPath(); c.moveTo(x - 30, y); c.lineTo(x - 18, y - 26); c.lineTo(x + 8, y - 32); c.lineTo(x + 30, y); c.fill(); break;
      case 'cactus': c.fillStyle = '#558b2f'; rr(c, x - 7, y - 60, 14, 60, 7); c.fill(); rr(c, x - 22, y - 44, 10, 24, 5); c.fill(); rr(c, x + 12, y - 52, 10, 28, 5); c.fill(); break;
      case 'tent': c.fillStyle = '#8d6e63'; c.beginPath(); c.moveTo(x - 50, y); c.lineTo(x, y - 60); c.lineTo(x + 50, y); c.fill(); c.fillStyle = '#4e342e'; c.beginPath(); c.moveTo(x - 10, y); c.lineTo(x, y - 34); c.lineTo(x + 10, y); c.fill(); break;
      case 'bench': c.fillStyle = '#795548'; c.fillRect(x - 30, y - 22, 60, 5); c.fillRect(x - 30, y - 36, 60, 4); line(c, x - 26, y - 17, x - 26, y, 3, '#333'); line(c, x + 26, y - 17, x + 26, y, 3, '#333'); break;
      case 'modernLamp': c.fillStyle = '#b0bec5'; c.fillRect(x - 2, y - 150, 4, 150); c.fillStyle = '#eceff1'; rr(c, x - 20, y - 154, 40, 6, 3); c.fill(); break;
      case 'crystal': c.fillStyle = '#7e57c2'; c.beginPath(); c.moveTo(x - 10, y); c.lineTo(x - 4, y - 40); c.lineTo(x + 4, y - 46); c.lineTo(x + 12, y); c.fill(); c.fillStyle = 'rgba(255,255,255,.3)'; c.beginPath(); c.moveTo(x - 4, y - 40); c.lineTo(x + 4, y - 46); c.lineTo(x, y); c.fill(); break;
      case 'solar': c.fillStyle = '#90a4ae'; c.fillRect(x - 2, y - 40, 4, 40); c.save(); c.translate(x, y - 44); c.rotate(-0.3); c.fillStyle = '#1a237e'; c.fillRect(-34, -8, 68, 16); c.strokeStyle = '#64b5f6'; c.lineWidth = 1; for (let i = -34; i < 34; i += 11) { c.beginPath(); c.moveTo(i, -8); c.lineTo(i, 8); c.stroke(); } c.restore(); break;
      case 'billboard': c.fillStyle = '#607d8b'; c.fillRect(x - 3, y - 160, 6, 160); c.fillStyle = '#263238'; c.fillRect(x - 60, y - 210, 120, 56); c.fillStyle = p.c || '#ff7043'; c.fillRect(x - 56, y - 206, 112, 48); text(c, p.label || 'عروض', x, y - 182, 14, '#fff', 'center', true, 3); break;
      case 'sign': pole(c, x, y, 60); c.fillStyle = '#2e7d32'; rr(c, x - 40, y - 84, 80, 26, 3); c.fill(); text(c, p.label, x, y - 71, 9.5, '#fff'); break;
    }
  };

  /* =================================================================
     BACKGROUNDS — طبقات Parallax تُرسم مرة واحدة كـ tiles وتتخزن
     ================================================================= */
  const SHOPS = ['فول وطعمية', 'كشري التحرير', 'عصير قصب', 'حلاق الشباب', 'صيدلية الشفاء', 'بقالة الأمانة', 'موبايلات', 'مكوجي', 'فطاطري', 'حلويات النجمة', 'قهوة الحرية', 'جزارة'];
  const PAL = {
    streets: { sky: ['#7cc4f2', '#cfe9f7'], haze: '#d9c7a4', far: ['#c9b48f', '#bfa784', '#d1bd98'], mid: ['#d9a066', '#c48a5c', '#e3c08f', '#b77a5a', '#d7b98d', '#a8805f', '#e0a98a'], ground: '#a68b6d', road: '#4a4a4f', curb: '#bdbdbd', side: '#c8b496', fore: '#8d7b62' },
    country: { sky: ['#6ec2f0', '#d4f0fb'], haze: '#b9d8a8', far: ['#7fb069', '#6a9c56'], mid: ['#c9a27a', '#b88d64', '#d8b48a'], ground: '#7cb342', road: '#6b5b4a', curb: '#8d7b62', side: '#9ccc65', fore: '#558b2f' },
    desert: { sky: ['#f6b26b', '#fde3b8'], haze: '#f0c987', far: ['#e9b872', '#dba45f'], mid: ['#e3a857', '#d69a4a'], ground: '#e4b46a', road: '#5a5048', curb: '#c99a5a', side: '#e8c07a', fore: '#d39d55' },
    city: { sky: ['#4f9de0', '#bfe3ff'], haze: '#a9c6df', far: ['#7f9db8', '#8eabc4', '#6f8fab'], mid: ['#cfd8dc', '#90a4ae', '#4fc3f7', '#b0bec5', '#78909c'], ground: '#90a4ae', road: '#37393d', curb: '#cfd8dc', side: '#b0bec5', fore: '#78909c' },
    alex: { sky: ['#5fb3e8', '#d9f0fb'], haze: '#d4e7f0', far: ['#9fb7c9', '#b5c8d6', '#c3d3de'], mid: ['#efe3cf', '#e2cfb0', '#d5bd97', '#f4ead8', '#c9b48f'], ground: '#9db8c4', road: '#45474d', curb: '#d6d6d6', side: '#cfc3ac', fore: '#9a8c74' },
    saeed: { sky: ['#78c4ee', '#f7e6bd'], haze: '#ead39f', far: ['#d9b77a', '#c9a464'], mid: ['#c48a52', '#d6a56a', '#b87c48', '#e0b47a'], ground: '#cfa86a', road: '#5c5046', curb: '#b89462', side: '#d8b57e', fore: '#a9874f' },
    mars: { sky: ['#2a0f2e', '#c8553d'], haze: '#d06a4a', far: ['#8e2f1d', '#a33b22'], mid: ['#b0452a', '#9a3a22'], ground: '#b5492c', road: '#6e2a1b', curb: '#8e3a24', side: '#c0563a', fore: '#7c2c19' }
  };
  A.PAL = PAL;
  A.HORIZON = 300; // y where back sidewalk starts

  function tileFar(c, theme, v, W, H) {
    const pal = PAL[theme], base = A.HORIZON;
    const r = i => hash(v * 977 + i * 31);
    if (theme === 'streets') {
      for (let i = 0; i < 22; i++) { const w = 30 + r(i) * 50, h = 40 + r(i + 50) * 90, x = i * (W / 20) + r(i + 9) * 20; c.fillStyle = pal.far[i % 3]; c.fillRect(x, base - h - 30, w, h + 30); c.fillStyle = 'rgba(0,0,0,.08)'; for (let k = 0; k < h / 12; k++) c.fillRect(x + 4, base - h - 24 + k * 12, w - 8, 3); }
      for (let m = 0; m < 2; m++) { const x = 150 + m * 600 + r(m + 99) * 200; // mosque
        c.fillStyle = '#c4ad86'; ell(c, x, base - 120, 46, 40); c.fill(); c.fillRect(x - 50, base - 120, 100, 90);
        c.fillRect(x + 62, base - 230, 12, 200); ell(c, x + 68, base - 236, 9, 12); c.fill(); c.fillRect(x + 59, base - 196, 18, 6);
        c.fillRect(x - 74, base - 200, 12, 170); ell(c, x - 68, base - 206, 9, 12); c.fill(); }
    } else if (theme === 'country') {
      c.fillStyle = pal.far[0]; c.beginPath(); c.moveTo(0, base - 30); for (let x = 0; x <= W; x += 40) c.lineTo(x, base - 34 - Math.sin(x * 0.01 + v) * 8); c.lineTo(W, base); c.lineTo(0, base); c.fill();
      for (let i = 0; i < 18; i++) { const x = r(i) * W, h = 50 + r(i + 7) * 40; c.strokeStyle = '#4e6b3a'; c.lineWidth = 4; c.beginPath(); c.moveTo(x, base - 30); c.lineTo(x + 2, base - 30 - h); c.stroke(); for (let k = 0; k < 5; k++) { c.beginPath(); c.moveTo(x + 2, base - 30 - h); c.quadraticCurveTo(x + (k - 2) * 12, base - 40 - h, x + (k - 2) * 20, base - 20 - h); c.stroke(); } }
      c.fillStyle = '#c9b48f'; c.fillRect(W * 0.6, base - 90, 10, 60); ell(c, W * 0.6 + 5, base - 94, 7, 9); c.fill();
    } else if (theme === 'desert') {
      for (let k = 0; k < 2; k++) { c.fillStyle = pal.far[k]; c.beginPath(); c.moveTo(0, base); for (let x = 0; x <= W; x += 30) c.lineTo(x, base - 40 - k * -20 - Math.sin(x * 0.006 + v * 2 + k) * 30 - Math.sin(x * 0.017) * 10); c.lineTo(W, base); c.fill(); }
      if (v % 2 === 0) { for (let p = 0; p < 3; p++) { const x = 200 + p * 130, s = 1 - p * 0.25; c.fillStyle = p === 1 ? '#c8924a' : '#d9a35a'; c.beginPath(); c.moveTo(x - 110 * s, base - 30); c.lineTo(x, base - 30 - 120 * s); c.lineTo(x + 110 * s, base - 30); c.fill(); c.fillStyle = 'rgba(0,0,0,.12)'; c.beginPath(); c.moveTo(x, base - 30 - 120 * s); c.lineTo(x + 110 * s, base - 30); c.lineTo(x + 20 * s, base - 30); c.fill(); } }
    } else if (theme === 'city') {
      for (let i = 0; i < 18; i++) { const w = 40 + r(i) * 50, h = 120 + r(i + 40) * 160, x = i * (W / 16); c.fillStyle = pal.far[i % 3]; c.fillRect(x, base - h, w, h); c.fillStyle = 'rgba(255,255,255,.18)'; for (let k = 0; k < h / 14; k++) c.fillRect(x + 4, base - h + 6 + k * 14, w - 8, 4); if (r(i + 3) > 0.7) { c.fillStyle = '#6f8fab'; c.fillRect(x + w / 2 - 1, base - h - 30, 2, 30); } }
    } else if (theme === 'alex') {
      c.fillStyle = '#3f8fc4'; c.fillRect(0, base - 70, W, 70); c.fillStyle = 'rgba(255,255,255,.4)'; for (let k = 0; k < 30; k++) c.fillRect(r(k) * W, base - 65 + r(k + 3) * 55, 14 + r(k + 7) * 20, 2);
      for (let k = 0; k < 3; k++) { const x = r(k + 40) * W, y = base - 50 + r(k + 41) * 20; c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x, y); c.lineTo(x + 16, y - 26); c.lineTo(x + 16, y); c.fill(); c.fillStyle = '#6d4c41'; c.fillRect(x - 6, y, 26, 4); }
      if (v % 2 === 0) { const x = 300 + r(9) * 400; c.fillStyle = '#d8c7a6'; c.fillRect(x, base - 120, 150, 50); c.fillRect(x + 50, base - 160, 50, 40); for (let i = 0; i < 6; i++) c.fillRect(x + i * 26, base - 128, 14, 8); c.fillStyle = '#c4b08c'; c.fillRect(x - 30, base - 90, 30, 20); c.fillRect(x + 150, base - 90, 30, 20); }
      else { const x = 500 + r(11) * 300; c.fillStyle = '#e8e2d6'; c.fillRect(x, base - 190, 22, 120); c.fillStyle = '#c62828'; c.fillRect(x, base - 160, 22, 12); c.fillStyle = '#ffeb3b'; c.fillRect(x + 3, base - 202, 16, 12); }
    } else if (theme === 'saeed') {
      c.fillStyle = pal.far[0]; c.beginPath(); c.moveTo(0, base - 40); for (let x = 0; x <= W; x += 60) c.lineTo(x, base - 110 - (r(x) > 0.6 ? 20 : 0) - Math.sin(x * 0.004 + v) * 15); c.lineTo(W, base - 40); c.closePath(); c.fill();
      c.fillStyle = '#4b9fc9'; c.fillRect(0, base - 45, W, 18); c.fillStyle = 'rgba(255,255,255,.4)'; for (let k = 0; k < 20; k++) c.fillRect(r(k) * W, base - 40, 16, 2);
      for (let k = 0; k < 2; k++) { const x = r(k + 20) * W; c.fillStyle = '#fff'; c.beginPath(); c.moveTo(x, base - 46); c.lineTo(x + 20, base - 100); c.lineTo(x + 36, base - 46); c.fill(); c.fillStyle = '#5d4037'; c.fillRect(x - 8, base - 46, 50, 5); }
      for (let i = 0; i < 12; i++) { const x = r(i + 60) * W; c.strokeStyle = '#4e6b3a'; c.lineWidth = 4; c.beginPath(); c.moveTo(x, base - 28); c.lineTo(x + 2, base - 90); c.stroke(); for (let k = 0; k < 5; k++) { c.beginPath(); c.moveTo(x + 2, base - 90); c.quadraticCurveTo(x + (k - 2) * 12, base - 100, x + (k - 2) * 20, base - 80); c.stroke(); } }
    } else if (theme === 'mars') {
      for (let k = 0; k < 2; k++) { c.fillStyle = pal.far[k]; c.beginPath(); c.moveTo(0, base); for (let x = 0; x <= W; x += 24) c.lineTo(x, base - 60 + k * 30 - Math.abs(Math.sin(x * 0.005 + v + k * 2)) * 110 - r(x) * 8); c.lineTo(W, base); c.fill(); }
    }
  }
  function tileMid(c, theme, v, W, H) {
    const pal = PAL[theme], base = A.HORIZON;
    const r = i => hash(v * 1543 + i * 17 + 5);
    if (theme === 'streets') {
      let x = 0, i = 0;
      while (x < W) {
        const w = 90 + r(i) * 70, h = 120 + r(i + 20) * 110, col = pal.mid[(r(i + 3) * pal.mid.length) | 0];
        c.fillStyle = col; c.fillRect(x, base - h, w, h);
        c.fillStyle = shade(col, -0.2); c.fillRect(x, base - h, w, 6);
        // windows & balconies
        const floors = Math.floor((h - 50) / 34);
        for (let f = 0; f < floors; f++) {
          const wy = base - h + 14 + f * 34;
          for (let k = 0; k < Math.floor(w / 32); k++) {
            const wx = x + 10 + k * 32;
            c.fillStyle = r(i * 9 + f * 3 + k) > 0.3 ? '#4b3a2c' : '#8fc3e0'; c.fillRect(wx, wy, 16, 20);
            c.fillStyle = shade(col, 0.25); c.fillRect(wx - 3, wy + 20, 22, 3);
            if (r(i + f + k * 7) > 0.65) { c.strokeStyle = '#333'; c.lineWidth = 1; c.strokeRect(wx - 4, wy + 10, 24, 12); }
            if (r(i * 3 + f + k) > 0.8) { c.fillStyle = '#e0e0e0'; c.fillRect(wx + 18, wy + 2, 9, 7); } // AC
            if (r(i * 5 + f * 2 + k) > 0.82) { line(c, wx - 4, wy + 12, wx + 22, wy + 12, 1, '#666'); c.fillStyle = ['#e53935', '#1e88e5', '#fdd835'][k % 3]; c.fillRect(wx + 2, wy + 12, 6, 8); c.fillStyle = '#fff'; c.fillRect(wx + 10, wy + 12, 6, 6); }
          }
        }
        if (r(i + 77) > 0.5) { c.strokeStyle = '#ddd'; c.lineWidth = 2; c.beginPath(); c.arc(x + w - 18, base - h - 4, 9, P * 0.9, P * 2.1); c.stroke(); } // dish
        // shop front
        c.fillStyle = shade(col, -0.35); c.fillRect(x + 4, base - 44, w - 8, 44);
        c.fillStyle = ['#c62828', '#1565c0', '#2e7d32', '#f9a825', '#6a1b9a'][(r(i + 5) * 5) | 0]; c.fillRect(x + 2, base - 60, w - 4, 16);
        text(c, SHOPS[(r(i + 11) * SHOPS.length) | 0], x + w / 2, base - 52, 10, '#fff');
        c.fillStyle = 'rgba(255,255,255,.15)'; for (let k = 0; k < 6; k++) { c.beginPath(); c.moveTo(x + 4 + k * (w - 8) / 6, base - 44); c.lineTo(x + 4 + (k + 1) * (w - 8) / 6, base - 44); c.lineTo(x + 4 + (k + 0.5) * (w - 8) / 6, base - 34); c.fill(); }
        x += w + 2; i++;
      }
    } else if (theme === 'country') {
      // canal (ترعة)
      c.fillStyle = '#4ba3c7'; c.fillRect(0, base - 22, W, 10); c.fillStyle = 'rgba(255,255,255,.35)'; for (let k = 0; k < 20; k++) c.fillRect(r(k) * W, base - 19, 20, 2);
      c.fillStyle = '#8bc34a'; c.fillRect(0, base - 12, W, 12);
      for (let i = 0; i < 5; i++) {
        const x = i * W / 5 + r(i) * 60, w = 80 + r(i + 4) * 40, h = 50 + r(i + 8) * 30; const col = pal.mid[i % 3];
        if (r(i + 30) > 0.35) { c.fillStyle = col; c.fillRect(x, base - 22 - h, w, h); c.fillStyle = '#5d4037'; c.fillRect(x + w / 2 - 8, base - 22 - 30, 16, 30); c.fillStyle = '#3e2723'; c.fillRect(x + 10, base - 22 - h + 12, 12, 12); c.fillRect(x + w - 22, base - 22 - h + 12, 12, 12); c.fillStyle = '#d4a84b'; c.fillRect(x - 4, base - 26 - h, w + 8, 6); }
        else { c.fillStyle = '#7b5a3a'; c.fillRect(x + 20, base - 30, w, 6); line(c, x + 22, base - 24, x + 22, base - 12, 3, '#5d4037'); line(c, x + w + 16, base - 24, x + w + 16, base - 12, 3, '#5d4037'); } // small bridge
        const px = x + w + 30; c.strokeStyle = '#6d4c41'; c.lineWidth = 6; c.beginPath(); c.moveTo(px, base - 20); c.quadraticCurveTo(px + 6, base - 70, px + 2, base - 120); c.stroke();
        for (let k = 0; k < 6; k++) { const a = -P / 2 + (k - 2.5) * 0.5; c.strokeStyle = '#2e7d32'; c.lineWidth = 5; c.beginPath(); c.moveTo(px + 2, base - 120); c.quadraticCurveTo(px + Math.cos(a) * 26, base - 130 + Math.sin(a) * 20, px + Math.cos(a) * 44, base - 110 + Math.sin(a) * 30); c.stroke(); }
      }
    } else if (theme === 'desert') {
      c.fillStyle = pal.mid[0]; c.beginPath(); c.moveTo(0, base); for (let x = 0; x <= W; x += 20) c.lineTo(x, base - 18 - Math.sin(x * 0.012 + v) * 14); c.lineTo(W, base); c.fill();
      for (let i = 0; i < 4; i++) { const x = r(i) * W; if (r(i + 9) > 0.5) { c.fillStyle = '#795548'; c.beginPath(); c.moveTo(x - 40, base - 10); c.lineTo(x, base - 60); c.lineTo(x + 40, base - 10); c.fill(); } else { c.fillStyle = '#8d6e63'; c.beginPath(); c.moveTo(x - 30, base - 10); c.lineTo(x - 10, base - 40); c.lineTo(x + 20, base - 44); c.lineTo(x + 36, base - 10); c.fill(); } }
    } else if (theme === 'city') {
      let x = 0, i = 0;
      while (x < W) {
        const w = 100 + r(i) * 80, h = 160 + r(i + 20) * 120, col = pal.mid[(r(i + 3) * pal.mid.length) | 0];
        const g = c.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, shade(col, 0.15)); g.addColorStop(1, shade(col, -0.15)); c.fillStyle = g; c.fillRect(x, base - h, w, h);
        c.fillStyle = 'rgba(20,40,60,.35)'; for (let f = 0; f < h / 18 - 1; f++) c.fillRect(x + 6, base - h + 8 + f * 18, w - 12, 10);
        c.fillStyle = 'rgba(255,255,255,.25)'; c.fillRect(x + 8, base - h + 8, 6, h - 16);
        x += w + 20 + r(i + 1) * 30; i++;
      }
      // monorail
      c.fillStyle = '#90a4ae'; c.fillRect(0, base - 150, W, 10); for (let k = 0; k < W; k += 200) c.fillRect(k + 40, base - 140, 10, 140);
    } else if (theme === 'alex') {
      const AS = ['سمك وجمبري', 'آيس كريم عزة', 'فول محمد أحمد', 'بسبوسة', 'قهوة فاروق', 'كبدة إسكندراني', 'حلواني', 'ترام الرمل'];
      let x = 0, i = 0;
      while (x < W) {
        const w = 110 + r(i) * 60, h = 150 + r(i + 20) * 90, col = pal.mid[(r(i + 3) * pal.mid.length) | 0];
        c.fillStyle = col; c.fillRect(x, base - h, w, h); c.fillStyle = shade(col, -0.18); c.fillRect(x - 3, base - h - 6, w + 6, 8);
        const floors = Math.floor((h - 60) / 36);
        for (let f = 0; f < floors; f++) for (let k = 0; k < Math.floor(w / 34); k++) {
          const wx = x + 10 + k * 34, wy = base - h + 16 + f * 36;
          c.fillStyle = '#2e5d4b'; c.beginPath(); c.moveTo(wx, wy + 24); c.lineTo(wx, wy + 8); c.arc(wx + 9, wy + 8, 9, Math.PI, 0); c.lineTo(wx + 18, wy + 24); c.fill();
          c.fillStyle = shade(col, 0.3); c.fillRect(wx - 4, wy + 24, 26, 3); c.strokeStyle = '#555'; c.lineWidth = 1; c.strokeRect(wx - 4, wy + 14, 26, 10);
        }
        c.fillStyle = shade(col, -0.35); c.fillRect(x + 4, base - 44, w - 8, 44);
        c.fillStyle = ['#0277bd', '#00897b', '#c62828', '#f9a825'][(r(i + 5) * 4) | 0]; c.fillRect(x + 2, base - 60, w - 4, 16);
        text(c, AS[(r(i + 11) * AS.length) | 0], x + w / 2, base - 52, 10, '#fff');
        x += w + 4; i++;
      }
    } else if (theme === 'saeed') {
      let x = 0, i = 0;
      while (x < W) {
        if (r(i + 90) > 0.55) { // temple: pylon + columns
          const w = 220; c.fillStyle = '#d9b77a'; c.beginPath(); c.moveTo(x, base); c.lineTo(x + 14, base - 150); c.lineTo(x + 76, base - 150); c.lineTo(x + 90, base); c.fill();
          c.fillStyle = 'rgba(120,80,30,.35)'; for (let k = 0; k < 5; k++) c.fillRect(x + 22, base - 135 + k * 24, 46, 3);
          for (let k = 0; k < 5; k++) { const cx = x + 100 + k * 24; c.fillStyle = '#e0c088'; c.fillRect(cx, base - 120, 16, 120); c.fillStyle = '#c9a464'; c.beginPath(); c.moveTo(cx - 5, base - 120); c.lineTo(cx + 21, base - 120); c.lineTo(cx + 16, base - 132); c.lineTo(cx, base - 132); c.fill(); c.fillStyle = 'rgba(90,60,20,.3)'; c.fillRect(cx + 4, base - 100, 2, 70); c.fillRect(cx + 9, base - 90, 2, 50); }
          c.fillStyle = '#c9a464'; c.fillRect(x + 94, base - 140, 124, 10);
          x += w + 20;
        } else {
          const w = 80 + r(i) * 40, h = 50 + r(i + 5) * 40, col = pal.mid[i % pal.mid.length];
          c.fillStyle = col; c.fillRect(x, base - h, w, h); c.fillStyle = '#3e2723'; c.fillRect(x + w / 2 - 8, base - 30, 16, 30); c.fillRect(x + 10, base - h + 12, 12, 12);
          c.fillStyle = '#1565c0'; c.fillRect(x + w / 2 - 10, base - 34, 20, 4);
          const px = x + w + 18; c.strokeStyle = '#6d4c41'; c.lineWidth = 6; c.beginPath(); c.moveTo(px, base); c.quadraticCurveTo(px + 6, base - 60, px + 2, base - 120); c.stroke();
          for (let k = 0; k < 6; k++) { const a = -Math.PI / 2 + (k - 2.5) * 0.5; c.strokeStyle = '#2e7d32'; c.lineWidth = 5; c.beginPath(); c.moveTo(px + 2, base - 120); c.quadraticCurveTo(px + Math.cos(a) * 26, base - 130 + Math.sin(a) * 20, px + Math.cos(a) * 44, base - 110 + Math.sin(a) * 30); c.stroke(); }
          x += w + 50;
        }
        i++;
      }
    } else if (theme === 'mars') {
      c.fillStyle = pal.mid[0]; c.beginPath(); c.moveTo(0, base); for (let x = 0; x <= W; x += 20) c.lineTo(x, base - 20 - Math.abs(Math.sin(x * 0.01 + v)) * 30); c.lineTo(W, base); c.fill();
      for (let i = 0; i < 3; i++) { const x = 100 + i * 380 + r(i) * 80; if (r(i + 3) > 0.4) { c.fillStyle = 'rgba(220,240,255,.75)'; c.beginPath(); c.arc(x, base - 20, 60, P, 0); c.fill(); c.strokeStyle = 'rgba(255,255,255,.6)'; c.lineWidth = 1; for (let k = 1; k < 4; k++) { c.beginPath(); c.arc(x, base - 20, 60, P + k * 0.75, P + k * 0.75 + 0.01); c.lineTo(x, base - 20); c.stroke(); } c.fillStyle = '#eceff1'; c.fillRect(x - 70, base - 22, 140, 6); } else { c.fillStyle = '#eceff1'; c.beginPath(); c.moveTo(x, base - 170); c.quadraticCurveTo(x + 16, base - 120, x + 14, base - 40); c.lineTo(x - 14, base - 40); c.quadraticCurveTo(x - 16, base - 120, x, base - 170); c.fill(); c.fillStyle = '#e53935'; c.fillRect(x - 14, base - 60, 28, 8); c.beginPath(); c.moveTo(x - 14, base - 50); c.lineTo(x - 26, base - 20); c.lineTo(x - 14, base - 30); c.fill(); c.beginPath(); c.moveTo(x + 14, base - 50); c.lineTo(x + 26, base - 20); c.lineTo(x + 14, base - 30); c.fill(); } }
    }
  }
  const tileCache = {};
  A.clearCache = function () { for (const k in tileCache) delete tileCache[k]; };
  function getTile(theme, layer, v, W, H, scale) {
    const key = theme + layer + v + '_' + scale.toFixed(3);
    if (tileCache[key]) return tileCache[key];
    const cv = document.createElement('canvas'); cv.width = Math.ceil(W * scale); cv.height = Math.ceil(H * scale);
    const c = cv.getContext('2d'); c.scale(scale, scale);
    const bimg = A.img(A.P.bg(theme, layer, v));
    if (bimg) c.drawImage(bimg, 0, 0, W, H);
    else (layer === 'far' ? tileFar : tileMid)(c, theme, v, W, H);
    tileCache[key] = cv; return cv;
  }
  A.TILE_W = 1200;
  A.background = function (c, theme, camX, W, H, t, scale, quality, env) {
    const pal = PAL[theme], sky = env && env.sky;
    const g = c.createLinearGradient(0, 0, 0, A.HORIZON);
    g.addColorStop(0, sky ? sky.top : pal.sky[0]); g.addColorStop(1, sky ? sky.bot : pal.sky[1]); c.fillStyle = g; c.fillRect(0, 0, W, A.HORIZON + 4);
    if (env && env.cloud > 0.05) { c.fillStyle = 'rgba(95,105,120,' + env.cloud * 0.55 + ')'; c.fillRect(0, 0, W, A.HORIZON + 4); }
    const dk = env ? env.dark : 0, hr = env ? env.clock : 12;
    if (dk > 0.25) { for (let i = 0; i < 60; i++) { c.fillStyle = 'rgba(255,255,255,' + (dk - 0.2) * (0.4 + hash(i + 3) * 0.6) * (1 - (env.cloud || 0)) + ')'; c.fillRect(hash(i * 3 + 1) * W, hash(i * 7 + 2) * 170, 1.6, 1.6); } }
    if (env && theme !== 'mars') {
      // الشمس والقمر بيلفّوا مع الساعة
      const sunK = (hr - 6) / 12, sx = W * (0.1 + 0.8 * sunK), syy = 160 - Math.sin(Math.PI * Math.min(1, Math.max(0, sunK))) * 120;
      if (hr > 5.5 && hr < 19) { const sc2 = hr > 17 || hr < 7 ? '#ffb070' : '#fff8d6'; c.globalAlpha = 1 - (env.cloud || 0) * 0.8; ell(c, sx, syy, 30, 30, sc2); c.globalAlpha = 0.25 * (1 - (env.cloud || 0)); ell(c, sx, syy, 52, 52, '#fff'); c.globalAlpha = 1; }
      else { const mk = ((hr + 24 - 19) % 24) / 10, mx = W * (0.1 + 0.8 * mk), my = 150 - Math.sin(Math.PI * Math.min(1, mk)) * 110; c.globalAlpha = 1 - (env.cloud || 0) * 0.7; ell(c, mx, my, 20, 20, '#f4f1de'); ell(c, mx + 8, my - 4, 17, 17, sky ? sky.top : '#000'); c.globalAlpha = 1; }
      if (theme !== 'desert') for (let i = 0; i < 5 + Math.round((env.cloud || 0) * 6); i++) { const cx = ((hash(i) * 2000 - camX * 0.03 + t * 6) % (W + 300) + W + 300) % (W + 300) - 150, cy = 40 + hash(i + 5) * 80; const cc = env.cloud > 0.5 ? 'rgba(120,128,140,.9)' : 'rgba(255,255,255,' + (0.85 - dk) + ')'; c.fillStyle = cc; ell(c, cx, cy, 40, 14); c.fill(); ell(c, cx + 20, cy - 8, 26, 14); c.fill(); ell(c, cx - 22, cy - 2, 22, 11); c.fill(); }
    } else
    // sun / planets / clouds
    if (env && theme !== 'mars') { /* اترسمت فوق */ }
    else if (theme === 'mars') {
      for (let i = 0; i < 40; i++) { c.fillStyle = 'rgba(255,255,255,' + (0.3 + hash(i) * 0.6) + ')'; c.fillRect(hash(i * 3) * W, hash(i * 7) * 140, 1.5, 1.5); }
      ell(c, W * 0.78, 80, 46, 46, '#e0704f'); ell(c, W * 0.78 - 10, 72, 46, 46, 'rgba(255,200,170,.25)'); ell(c, W * 0.2, 60, 12, 12, '#d8c8b8');
    } else {
      ell(c, W * 0.82, 70, 30, 30, theme === 'desert' ? '#fff3c4' : '#fff8d6');
      c.globalAlpha = 0.25; ell(c, W * 0.82, 70, 50, 50, '#fff'); c.globalAlpha = 1;
      if (theme !== 'desert') for (let i = 0; i < 5; i++) { const cx = ((hash(i) * 2000 - camX * 0.03 + t * 6) % (W + 300) + W + 300) % (W + 300) - 150, cy = 40 + hash(i + 5) * 80; c.fillStyle = 'rgba(255,255,255,.85)'; ell(c, cx, cy, 40, 14); c.fill(); ell(c, cx + 20, cy - 8, 26, 14); c.fill(); ell(c, cx - 22, cy - 2, 22, 11); c.fill(); }
    }
    // haze band
    c.fillStyle = pal.haze; c.globalAlpha = 0.35; c.fillRect(0, A.HORIZON - 70, W, 70); c.globalAlpha = 1;
    const layers = quality === 'low' ? [['mid', 0.35]] : [['far', 0.12], ['mid', 0.35]];
    for (const [layer, f] of layers) {
      const off = camX * f; const tw = A.TILE_W;
      const i0 = Math.floor(off / tw);
      for (let i = i0; i <= i0 + Math.ceil(W / tw) + 1; i++) {
        const v = Math.floor(hash(i * 13 + (layer === 'far' ? 1 : 2)) * 4);
        const img = getTile(theme, layer, v, tw, A.HORIZON + 10, scale);
        c.drawImage(img, i * tw - off, 0, tw, A.HORIZON + 10);
      }
    }
    if (dk > 0.02) { c.fillStyle = 'rgba(8,12,35,' + dk * 0.75 + ')'; c.fillRect(0, 0, W, A.HORIZON + 10); }
    if (dk > 0.3) for (let i = 0; i < 26; i++) { const wx = ((hash(i * 17) * 3000 - camX * 0.35) % (W + 100) + W + 100) % (W + 100) - 50, wy = A.HORIZON - 30 - hash(i * 19) * 120; c.fillStyle = 'rgba(255,214,120,' + (dk - 0.25) * 1.4 * (hash(i * 23) > 0.3 ? 1 : 0) + ')'; c.fillRect(wx, wy, 4, 5); }
  };

  /* ---------- particles ---------- */
  A.particle = function (c, p) {
    c.globalAlpha = Math.max(0, p.life / p.max) * (p.a || 1);
    if (p.kind === 'dust' || p.kind === 'smoke' || p.kind === 'sand') ell(c, p.x, p.y, p.r, p.r, p.col);
    else if (p.kind === 'fire') { const g = c.createRadialGradient(p.x, p.y, 1, p.x, p.y, p.r); g.addColorStop(0, '#fff59d'); g.addColorStop(0.4, '#ff9800'); g.addColorStop(1, 'rgba(213,0,0,0)'); c.fillStyle = g; c.beginPath(); c.arc(p.x, p.y, p.r, 0, 7); c.fill(); }
    else if (p.kind === 'splash') ell(c, p.x, p.y, p.r * 0.6, p.r, p.col);
    else if (p.kind === 'star') A.star(c, p.x, p.y, p.r, p.col);
    else if (p.kind === 'coin') text(c, p.txt, p.x, p.y, 13, p.col, 'center', true, 3);
    else if (p.kind === 'spark') { c.fillStyle = p.col; c.fillRect(p.x, p.y, 2, 2); }
    c.globalAlpha = 1;
  };
  A.coin = function (c, x, y, t, cosmic) {
    const w = Math.abs(Math.cos(t * 4 + x * 0.01)) * 9 + 2;
    const cimg = A.img(A.P.coin(cosmic));
    if (cimg) { c.drawImage(cimg, x - w, y - 10, w * 2, 20); return; }
    ell(c, x, y, w, 10, cosmic ? '#7ee8ff' : '#ffca28'); c.strokeStyle = cosmic ? '#0097a7' : '#c79100'; c.lineWidth = 1.5; c.stroke();
    if (w > 6) text(c, cosmic ? '✦' : 'ج', x, y + 0.5, 9, cosmic ? '#006064' : '#8d6e00');
  };
  /* =================================================================
     ASSETS — الصور الخارجية في مجلد assets. أي صورة موجودة بتتستخدم،
     ولو ناقصة أو مقفولة في assets/manifest.js اللعبة بترسم بالكود.
     ================================================================= */
  const IM = {};
  A.img = p => { const i = IM[p]; return i && i.naturalWidth ? i : null; };
  A.P = {
    sheet: n => 'assets/characters/' + n + '_sheet.png',
    animal: t => 'assets/characters/animal_' + t + '.png',
    tuk: (id, layer) => 'assets/tuktuk/tuktuk_' + id + '_' + layer + '.png',
    vehicle: (t, i) => 'assets/tiles/vehicle_' + t + '_' + i + '.png',
    ob: t => 'assets/tiles/tile_' + t + '.png',
    bg: (th, l, v) => 'assets/tiles/bg_' + th + '_' + l + '_' + v + '.png',
    coin: cosmic => 'assets/ui/ui_' + (cosmic ? 'coin_cosmic' : 'coin') + '.png'
  };
  // نقاط الارتكاز داخل الصور (لازم الصورة البديلة تحافظ عليها)
  A.TUK_IMG = { anchorX: 115, anchorY: 112, scale: 1 / 1.4 };
  // مقاس صور المركبات (طبقة back/front) ونقطة مركز الثقل جواها، الرسم متكبر 1.4
  A.PIMG = { tuktuk: { w: 220, h: 160, ax: 115, ay: 112 }, scooter: { w: 140, h: 120, ax: 70, ay: 80 }, bike: { w: 140, h: 120, ax: 70, ay: 80 }, skate: { w: 120, h: 50, ax: 60, ay: 30 }, microbus: { w: 380, h: 170, ax: 190, ay: 135 }, sport: { w: 320, h: 120, ax: 160, ay: 80 } };
  A.VEH_IMG = { anchorX: 20, anchorY: 190 };
  A.ANIMAL_IMG = { anchorX: 70, anchorY: 120 };
  A.OB_IMG = { anchorX: 140, anchorY: 90 };
  A.allAssetPaths = function () {
    const M = TT.ASSET_MANIFEST || {}, on = M.use || {}, out = [];
    if (on.characters !== false) {
      for (const d of TT.DRIVERS) if (d.look.sheet) out.push(A.P.sheet(d.look.sheet));
      for (const id in TT.PASSENGER_TYPES) out.push(A.P.sheet(TT.PASSENGER_TYPES[id].look.sheet));
      for (const l of TT.NPC_LOOKS) out.push(A.P.sheet(l.sheet));
      out.push(A.P.sheet(TT.KID_LOOK.sheet));
    }
    if (on.animals !== false) for (const a of ['cow', 'buffalo', 'camel', 'donkey', 'chicken']) out.push(A.P.animal(a));
    if (on.tuktuks !== false) for (const m of TT.TUKTUKS) out.push(A.P.tuk(m.id, 'back'), A.P.tuk(m.id, 'front'));
    if (on.vehicles !== false) for (const v in A.VEH) A.VEH[v].col.forEach((_, i) => out.push(A.P.vehicle(v, i)));
    if (on.obstacles !== false) for (const k in TT.OBSTACLES) if (k !== 'chicken') out.push(A.P.ob(k));
    if (on.backgrounds !== false) for (const th in PAL) for (const l of ['far', 'mid']) for (let v = 0; v < 4; v++) out.push(A.P.bg(th, l, v));
    if (on.ui !== false) out.push(A.P.coin(false), A.P.coin(true));
    return out;
  };
  A.loadAssets = function () {
    const M = TT.ASSET_MANIFEST || {}; if (M.enabled === false) return;
    let missing = 0;
    for (const p of A.allAssetPaths()) {
      const im = new Image();
      im.onload = () => { IM[p] = im; if (p.indexOf('/bg_') > 0) A.clearCache(); };
      im.onerror = () => { missing++; if (missing === 1) console.info('Some images in assets/ were not found — using built-in drawings for those.'); };
      im.src = (TT.ASSET_DATA && TT.ASSET_DATA[p]) || p;
    }
  };
  A._tileFar = (c, th, v) => tileFar(c, th, v, A.TILE_W, A.HORIZON + 10);
  A._tileMid = (c, th, v) => tileMid(c, th, v, A.TILE_W, A.HORIZON + 10);

  // فقاعة كلام واضحة بلون حسب المزاج: فرحان / متضايق / خايف / السواق / عادي
  const MOODS = { happy: ['#e8f5e9', '#43a047', '😄'], angry: ['#ffebee', '#e53935', '😠'], scared: ['#fff3e0', '#fb8c00', '😨'], driver: ['#fffde7', '#f9a825', '🧔'], neutral: ['#ffffff', '#90a4ae', '💬'] };
  A.bubble = function (c, x, y, s, col, mood, pop) {
    const M = MOODS[mood] || MOODS.neutral, fs = 16;
    c.save(); c.font = 'bold ' + fs + 'px ' + FONT; c.direction = 'rtl';
    // تقسيم السطر لو طويل
    const maxW = 260, words = String(s).split(' '), lines = []; let cur = '';
    for (const w of words) { const tt = cur ? cur + ' ' + w : w; if (c.measureText(tt).width > maxW && cur) { lines.push(cur); cur = w; } else cur = tt; }
    if (cur) lines.push(cur);
    const tw = Math.max(...lines.map(l => c.measureText(l).width)), w = tw + 40, h = lines.length * (fs + 4) + 10;
    const sc = 0.7 + 0.3 * (pop == null ? 1 : pop); c.translate(x, y); c.scale(sc, sc);
    c.shadowColor = 'rgba(0,0,0,.35)'; c.shadowBlur = 6; c.shadowOffsetY = 2;
    c.fillStyle = col || M[0]; rr(c, -w / 2, -h - 6, w, h, 10); c.fill();
    c.shadowColor = 'transparent';
    c.beginPath(); c.moveTo(-6, -7); c.lineTo(6, -7); c.lineTo(0, 2); c.closePath(); c.fill();
    c.strokeStyle = M[1]; c.lineWidth = 2.2; rr(c, -w / 2, -h - 6, w, h, 10); c.stroke();
    c.beginPath(); c.moveTo(-6, -6); c.lineTo(0, 2); c.lineTo(6, -6); c.stroke();
    ell(c, w / 2 - 2, -h - 6, 11, 11, M[1]); c.font = '13px ' + FONT; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#fff'; c.fillText(M[2], w / 2 - 2, -h - 5);
    lines.forEach((l, i) => text(c, l, -6, -h - 6 + 5 + (fs + 4) * (i + 0.5) + 1, fs, '#1b1f2a'));
    c.restore();
  };
})();
