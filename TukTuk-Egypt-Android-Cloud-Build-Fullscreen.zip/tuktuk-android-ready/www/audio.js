/* =====================================================================
   audio.js — مؤثرات صوتية برمجية (WebAudio) — بدون ملفات خارجية.
   لإضافة ملفات صوت حقيقية: ضع الملف في assets/audio وأضف اسمه في
   TT.Audio.files — لو الملف اتحمّل هيتشغل بدل الصوت البرمجي.
   ===================================================================== */
(function () {
  const TT = window.TT;
  const S = TT.Audio = { sfx: true, music: false, ctx: null, files: { /* horn: 'assets/audio/horn.mp3' */ }, buffers: {} };
  let engOsc, engOsc2, engGain, engFilter, musicTimer = null, master, fx;

  S.init = function () {
    if (S.ctx) { if (S.ctx.state === 'suspended') S.ctx.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    S.ctx = new AC(); master = S.ctx.createGain(); master.gain.value = 0.55; master.connect(S.ctx.destination); fx = S.ctx.createGain(); fx.connect(master);
    // engine: two detuned saws through lowpass
    engOsc = S.ctx.createOscillator(); engOsc.type = 'sawtooth';
    engOsc2 = S.ctx.createOscillator(); engOsc2.type = 'square';
    engFilter = S.ctx.createBiquadFilter(); engFilter.type = 'lowpass'; engFilter.frequency.value = 500;
    engGain = S.ctx.createGain(); engGain.gain.value = 0;
    engOsc.connect(engFilter); engOsc2.connect(engFilter); engFilter.connect(engGain); engGain.connect(master);
    engOsc.start(); engOsc2.start();
    for (const k in S.files) loadFile(k, S.files[k]);
    if (S.music) S.startMusic();
  };
  function loadFile(name, url) {
    fetch(url).then(r => r.arrayBuffer()).then(b => S.ctx.decodeAudioData(b)).then(buf => { S.buffers[name] = buf; }).catch(() => {});
  }
  function playBuf(name) { if (!S.buffers[name]) return false; const s = S.ctx.createBufferSource(); s.buffer = S.buffers[name]; s.connect(fx || master); s.start(); return true; }

  S.engine = function (rpm, on) { // rpm 0..1
    if (!S.ctx || !engGain) return;
    const now = S.ctx.currentTime;
    const v = S.sfx && on ? 0.08 + rpm * 0.07 : 0;
    engGain.gain.setTargetAtTime(v, now, 0.08);
    engOsc.frequency.setTargetAtTime(38 + rpm * 90, now, 0.05);
    engOsc2.frequency.setTargetAtTime(19 + rpm * 45, now, 0.05);
    engFilter.frequency.setTargetAtTime(300 + rpm * 900, now, 0.05);
  };
  function tone(type, f1, f2, dur, vol, delay) {
    if (!S.ctx || !S.sfx) return;
    const t = S.ctx.currentTime + (delay || 0);
    const o = S.ctx.createOscillator(), g = S.ctx.createGain();
    o.type = type; o.frequency.setValueAtTime(f1, t); if (f2) o.frequency.exponentialRampToValueAtTime(f2, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(g); g.connect(fx || master); o.start(t); o.stop(t + dur + 0.02);
  }
  function noise(dur, vol, freq, q) {
    if (!S.ctx || !S.sfx) return;
    const len = Math.floor(S.ctx.sampleRate * dur), b = S.ctx.createBuffer(1, len, S.ctx.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
    const s = S.ctx.createBufferSource(); s.buffer = b;
    const f = S.ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = freq || 800; f.Q.value = q || 0.7;
    const g = S.ctx.createGain(); g.gain.value = vol;
    s.connect(f); f.connect(g); g.connect(fx || master); s.start();
  }
  S.play = function (name) {
    if (!S.ctx || !S.sfx) return;
    if (playBuf(name)) return;
    switch (name) {
      case 'horn': tone('square', 420, 0, 0.32, 0.12); tone('square', 520, 0, 0.32, 0.1); tone('square', 420, 0, 0.18, 0.12, 0.38); tone('square', 520, 0, 0.18, 0.1, 0.38); break;
      case 'coin': tone('square', 988, 0, 0.07, 0.08); tone('square', 1319, 0, 0.18, 0.08, 0.07); break;
      case 'bump': noise(0.18, 0.5, 120, 1); tone('sine', 90, 40, 0.18, 0.3); break;
      case 'crash': noise(0.5, 0.7, 500, 0.5); tone('sawtooth', 200, 40, 0.4, 0.2); break;
      case 'brake': noise(0.35, 0.18, 3200, 6); break;
      case 'board': tone('sine', 660, 0, 0.1, 0.12); tone('sine', 880, 0, 0.15, 0.12, 0.1); break;
      case 'cash': tone('triangle', 1200, 0, 0.08, 0.12); tone('triangle', 1600, 0, 0.08, 0.12, 0.08); tone('triangle', 2000, 0, 0.2, 0.12, 0.16); break;
      case 'whistle': tone('sine', 2200, 2600, 0.25, 0.12); tone('sine', 2600, 2200, 0.35, 0.12, 0.28); break;
      case 'flip': tone('sawtooth', 300, 60, 0.7, 0.15); noise(0.6, 0.5, 300, 0.6); break;
      case 'splash': noise(0.3, 0.35, 1800, 0.8); break;
      case 'pop': tone('sine', 300, 600, 0.08, 0.15); break;
      case 'punch': noise(0.08, 0.6, 900, 1.2); tone('sine', 160, 60, 0.12, 0.3); break;
      case 'fuel': for (let i = 0; i < 4; i++) tone('sine', 300 + i * 80, 0, 0.12, 0.08, i * 0.13); break;
      case 'click': tone('square', 700, 0, 0.03, 0.05); break;
      case 'win': [523, 659, 784, 1047].forEach((f, i) => tone('triangle', f, 0, 0.25, 0.12, i * 0.14)); break;
      case 'hornMusic': [659, 784, 880, 784, 659, 523].forEach((f, i) => tone('square', f, 0, 0.13, 0.09, i * 0.12)); break;
      case 'siren': tone('sawtooth', 700, 1100, 0.4, 0.06); tone('sawtooth', 1100, 700, 0.4, 0.06, 0.4); break;
      case 'wash': noise(1.2, 0.25, 2500, 0.6); break;
      case 'crank': for (let i = 0; i < 5; i++) { tone('sawtooth', 70 + i * 6, 0, 0.12, 0.12, i * 0.15); noise(0.08, 0.15, 400, 1); } break;
      case 'ring': tone('square', 880, 0, 0.12, 0.05); tone('square', 660, 0, 0.12, 0.05, 0.15); tone('square', 880, 0, 0.12, 0.05, 0.3); tone('square', 660, 0, 0.12, 0.05, 0.45); break;
      case 'train': tone('sawtooth', 330, 0, 0.7, 0.07); tone('sawtooth', 415, 0, 0.7, 0.06); tone('sawtooth', 330, 0, 1.1, 0.07, 0.9); tone('sawtooth', 415, 0, 1.1, 0.06, 0.9); break;
      case 'thunder': noise(2.6, 0.55, 90, 0.3); noise(1.4, 0.3, 260, 0.4); tone('sine', 55, 30, 2.2, 0.22); break;
      case 'boom': noise(1.2, 0.9, 120, 0.4); tone('sine', 80, 25, 1, 0.5); noise(0.5, 0.5, 900, 0.5); break;
      case 'beep': tone('sine', 1320, 0, 0.09, 0.1); tone('sine', 1320, 0, 0.09, 0.1, 0.14); break;
      case 'error': tone('square', 200, 150, 0.2, 0.08); break;
    }
  };
  // simple looping maqam-style tune
  const NOTES = [293.7, 311.1, 370, 392, 440, 466.2, 554.4, 587.3]; // hijaz on D
  const SEQ = [0, 2, 3, 4, 3, 2, 1, 0, 4, 5, 6, 7, 6, 5, 4, 3];
  S.startMusic = function () {
    S.stopMusic(); if (!S.ctx || !S.music) return;
    let i = 0;
    musicTimer = setInterval(() => {
      if (!S.music) return;
      const n = NOTES[SEQ[i % SEQ.length]];
      tone('triangle', n, 0, 0.22, 0.04); if (i % 4 === 0) tone('sine', n / 2, 0, 0.4, 0.05);
      if (i % 2 === 0) noise(0.05, 0.08, 4000, 3);
      i++;
    }, 240);
  };
  // سماعة الصب: إيقاع مهرجانات بسيط (kick + bass)
  let bassTimer = null;
  S.bass = function (on) {
    if (bassTimer) { clearInterval(bassTimer); bassTimer = null; }
    if (!on || !S.ctx) return;
    const line = [55, 55, 65.4, 55, 73.4, 55, 65.4, 49];
    let i = 0;
    bassTimer = setInterval(() => {
      if (!S.sfx) return;
      if (i % 2 === 0) tone('sine', 120, 40, 0.18, 0.5);
      tone('sawtooth', line[i % line.length], 0, 0.2, 0.12);
      if (i % 4 === 2) noise(0.06, 0.2, 2000, 1);
      i++;
    }, 220);
  };
  // مطر: لوب نويز متفلتر، شدته بتتغير
  let rainSrc = null, rainGain = null;
  S.rain = function (vol) {
    if (!S.ctx) return;
    if (!rainSrc) {
      const len = S.ctx.sampleRate * 2, b = S.ctx.createBuffer(1, len, S.ctx.sampleRate), d = b.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      rainSrc = S.ctx.createBufferSource(); rainSrc.buffer = b; rainSrc.loop = true;
      const f = S.ctx.createBiquadFilter(); f.type = 'bandpass'; f.frequency.value = 2600; f.Q.value = 0.5;
      rainGain = S.ctx.createGain(); rainGain.gain.value = 0;
      rainSrc.connect(f); f.connect(rainGain); rainGain.connect(master); rainSrc.start();
    }
    rainGain.gain.setTargetAtTime(S.sfx ? Math.min(0.035, vol * 0.035) : 0, S.ctx.currentTime, 0.4);
  };
  // إيقاف كل أصوات المركبة والمؤثرات فورًا (نهاية المرحلة / الانفجار / الخروج)
  S.stopAll = function (keepFx) {
    if (!S.ctx) return;
    S.engine(0, false); if (engGain) engGain.gain.cancelScheduledValues(S.ctx.currentTime), engGain.gain.setValueAtTime(0, S.ctx.currentTime);
    S.rain && S.rain(0); S.bass(false);
    if (!keepFx && fx) { try { fx.disconnect(); } catch (e) { } fx = S.ctx.createGain(); fx.connect(master); }
  };
  S.stopMusic = function () { if (musicTimer) clearInterval(musicTimer); musicTimer = null; };
})();
