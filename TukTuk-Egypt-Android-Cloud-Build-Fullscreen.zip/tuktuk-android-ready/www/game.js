/* =====================================================================
   توك توك مصر – game.js
   محرك اللعبة: الحالة، الفيزياء، التصادم، الركاب، الأجرة، الوقود،
   المخالفات، الانقلاب، النزول على الأقدام، الخناقات، الحفظ، الرسم والتحكم.
   - منطق اللعب (update) منفصل عن الرسم (render) وعن واجهة DOM (ui.js)
   - خطوة فيزياء ثابتة 1/120 ثانية عبر requestAnimationFrame + accumulator
   ===================================================================== */
(function () {
  'use strict';
  const TT = window.TT, A = TT.Art, PX = TT.PX;
  const ROAD_Y = 352, VH = 540, DT = 1 / 120;
  const TUK = A.TUK; // legacy (tuktuk geometry)
  function geom() { const m = TT.Save && TT.Save.data ? TT.Save.model() : null; return TT.GEOM[(m && m.kind) || 'tuktuk']; }
  function comShift() { const m = Save.model(), g = geom(); return 0.3 * seatsUsed() / (m.seats || 3) * (g.len / 2.8); }
  TT.geom = geom;

  /* ============================ utils ============================ */
  function mulberry32(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const lerp = (a, b, t) => a + (b - a) * t;
  const smooth = t => t * t * (3 - 2 * t);
  const pick = (r, arr) => arr[Math.floor(r() * arr.length) % arr.length];
  const kmh = v => Math.round(Math.abs(v) * 3.6);
  function weighted(r, obj) { let s = 0; for (const k in obj) s += obj[k]; let x = r() * s; for (const k in obj) { x -= obj[k]; if (x <= 0) return k; } return Object.keys(obj)[0]; }
  TT.util = { clamp, lerp, kmh, mulberry32, hashStr };

  /* ============================ i18n ============================ */
  TT.lang = 'ar';
  TT.t = function (ar, en) { return TT.lang === 'en' && en ? en : ar; };

  /* ============================ SAVE ============================ */
  const SAVE_KEY = 'tuktukEgypt.save.v1';
  function freshVehicle(id) { const m = TT.TUKTUKS.find(t => t.id === id); return { fuel: m.tank || 1, dirt: 0, damage: { engine: 0, tires: 0, suspension: 0, brakes: 0, body: 0 } }; }
  function defaultSave() {
    return {
      v: 1, money: 200, rep: 60, xp: 0, stars: {}, best: {},
      upgrades: { engine: 0, speed: 0, brakes: 0, suspension: 0, tires: 0, fuel: 0, lights: 0 },
      tireType: 'std', ownedTires: ['std'], paint: 'green', ownedPaints: ['green'], decal: 'none', ownedDecals: ['none'],
      tuktuk: 'basic', ownedTuktuks: ['basic'], ownedDrivers: ['sayed', 'hamo', 'adel'], ownedOutfits: ['default'], outfitOn: {}, vehicles: { basic: freshVehicle('basic') }, driver: 'sayed',
      stats: { deliveries: 0, earned: 0, cleanLevels: 0, recoveries: 0, peace: 0, coins: 0, marsRides: 0, violations: 0, fights: 0, flips: 0, stars: 0 },
      ledger: [], violationsLog: [],
      settings: { sfx: true, music: false, quality: 'high', lang: 'ar', hints: true, pedalsLeft: false, vibrate: true, obstacles: 'normal', bumps: 'normal', traffic: 'normal', fines: 'on', checkpoints: 'on', mode: 'taxi', goods: 'potato' },
      carts: { potato: 0, corn: 0, termes: 0, bread: 0 },
      license: { left: 5 }, pendingFines: [], record: { crashes: 0, flips: 0, explosions: 0, fights: 0, levels: 0, animals: 0 },
      jerry: 1,
      last: { world: 0, level: 0 }, snapshot: null, unlocks: { all: false, levels: [] }, accessories: [], accOn: {}
    };
  }
  function deepMerge(base, src) {
    if (!src || typeof src !== 'object') return base;
    for (const k in src) {
      if (src[k] && typeof src[k] === 'object' && !Array.isArray(src[k]) && base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) deepMerge(base[k], src[k]);
      else base[k] = src[k];
    }
    return base;
  }
  const Save = TT.Save = {
    data: null,
    load() {
      let raw = null;
      try { raw = JSON.parse(localStorage.getItem(SAVE_KEY)); } catch (e) { raw = null; }
      this.data = deepMerge(defaultSave(), raw);
      for (const id of this.data.ownedTuktuks) if (!this.data.vehicles[id]) this.data.vehicles[id] = freshVehicle(id);
      if (this.data.license.left > 5) this.data.license.left = 5;
      TT.lang = this.data.settings.lang;
      return this.data;
    },
    write() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(this.data)); return true; } catch (e) { return false; } },
    reset() { try { localStorage.removeItem(SAVE_KEY); } catch (e) { } this.data = defaultSave(); this.write(); },
    veh() { return this.data.vehicles[this.data.tuktuk]; },
    model() { return TT.TUKTUKS.find(t => t.id === this.data.tuktuk); },
    totalStars() { let s = 0; for (const k in this.data.stars) s += this.data.stars[k]; return s; },
    driverLevel() { return Math.floor(Math.sqrt(this.data.xp / 120)) + 1; },
    ledger(label, amount, kind) {
      const d = this.data; d.money = Math.round(d.money + amount);
      d.ledger.unshift({ t: Date.now(), label, amount: Math.round(amount), kind: kind || (amount >= 0 ? 'in' : 'out') });
      if (d.ledger.length > 80) d.ledger.length = 80;
      if (amount > 0) d.stats.earned += amount;
      // تقسيط الدين: 25% من أي فلوس بتدخل بتروح للأسطى لحد ما الدين يخلص
      if (amount > 0 && d.debt > 0 && kind !== 'debt') { const pay = Math.min(d.debt, Math.max(1, Math.round(amount * 0.25))); d.debt -= pay; d.money -= pay; d.ledger.unshift({ t: Date.now(), label: TT.t('قسط دين الورشة', 'Workshop debt installment'), amount: -pay, kind: 'repair' }); if (d.debt <= 0 && TT.UI && TT.UI.toast) TT.UI.toast(TT.t('🎉 خلّصت دين الورشة!', '🎉 Workshop debt paid off!'), 'good'); }
    },
    debtLimit() { return 1500 + this.driverLevel() * 500; },
    repairOnDebt(cost, label) { const d = this.data; d.debt = d.debt || 0; if (d.debt + cost > this.debtLimit()) return false; d.debt += cost; d.ledger.unshift({ t: Date.now(), label: (label || '') + TT.t(' (بالدين)', ' (on credit)'), amount: 0, kind: 'repair' }); return true; }
  };

  /* vehicle parameters derived from model + upgrades + damage */
  function vehParams() {
    const d = Save.data, m = Save.model(), u = d.upgrades, dm = Save.veh().damage;
    const tire = TT.TIRE_TYPES.find(t => t.id === d.tireType) || TT.TIRE_TYPES[0];
    const drv = TT.DRIVERS.find(x => x.id === d.driver) || TT.DRIVERS[0];
    return {
      accel: 3.1 * m.power * (1 + 0.12 * u.engine) * (1 - 0.35 * dm.engine),
      vmax: m.vmax * (1 + 0.06 * u.speed + 0.06 * u.engine),
      brake: 7.2 * (1 + 0.07 * u.brakes) * (1 - 0.5 * dm.brakes) * (1 + (drv.perk.brake || 0)) * (1 - 0.15 * ((G.env && G.env.wet) || 0)),
      grip: (1 + 0.05 * u.tires) * (1 - 0.4 * dm.tires) * (1 - 0.2 * ((G.env && G.env.wet) || 0)),
      k: 85 * (1 + 0.04 * u.suspension), c: 7.5 * (1 + 0.1 * u.suspension) * (1 - 0.55 * dm.suspension),
      travel: 0.17 + 0.012 * u.suspension - 0.05 * dm.suspension,
      fuelEff: (1 - 0.08 * u.fuel) * (drv.perk.fuel || 1), tank: m.fuel === false ? 1 : m.tank, lights: u.lights, human: m.fuel === false,
      sand: tire.sand, farm: tire.farm, spaceTires: !!tire.space, space: m.space, style: m.style,
      dmgMult: (drv.perk.dmg || 1) * (1 - 0.06 * u.suspension), satBonus: drv.perk.sat || 0,
      sputter: dm.engine > 0.7
    };
  }
  TT.vehParams = vehParams;

  /* ======================= LEVEL GENERATION =======================
     كل مرحلة تتولد من seed ثابت (العالم + رقم المرحلة) فتتكرر بنفس الشكل */
  function genLevel(wi, li, opts) {
    const W = TT.WORLDS[wi], free = !!(opts && opts.free);
    const r = mulberry32(hashStr(W.id) + li * 7919 + 17 + (free ? (opts.seed || 0) * 104729 : 0));
    const len = free ? Math.round(3200 + r() * 900) : Math.round(850 + Math.min(li, 25) * 75 + (li % 4) * 50 + (W.id === 'desert' ? 250 : 0));
    const L = {
      wi, li, W, len, r, free, ph1: r() * 6, ph2: r() * 6, rests: [], shops: [],
      obstacles: [], coins: [], stations: [], signs: [], props: [], lights: [], radars: [], checkpoints: [], gas: [],
      zones: { quiet: [], noPark: [], village: [], storm: [], tunnel: [], work: [], bridge: [], jam: [] }, crosswalks: [], herds: [], blockers: [],
      npcs: [], passengers: [], flats: [], occupied: [], finish: len, buckets: {}, sBuckets: {}
    };
    const occ = (a, b) => L.occupied.some(o => a < o[1] && b > o[0]);
    const take = (a, b) => L.occupied.push([a, b]);
    const F = W.features || {};
    const ST0 = (Save.data && Save.data.settings) || {}, AMT0 = { none: 0, few: 0.45, normal: 1, many: 1.7 };
    const polM = AMT0[ST0.police] != null ? AMT0[ST0.police] : 1, aniM = AMT0[ST0.animals] != null ? AMT0[ST0.animals] : 1;
    // ---- stations ----
    const names = W.stations.slice(); for (let i = names.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [names[i], names[j]] = [names[j], names[i]]; }
    let x = 28, si = 0;
    while (x < len - 45) {
      L.stations.push({ id: 'st' + si, idx: si, x, name: names[si % names.length], waiting: [] });
      take(x - 14, x + 14); L.flats.push(x);
      si++; x += 150 + r() * 90;
    }
    const lastX = len - 32; L.stations.push({ id: 'st' + si, idx: si, x: lastX, name: names[si % names.length], waiting: [] }); take(lastX - 14, len + 30); L.flats.push(lastX, len);
    L.flats.push(0); take(-50, 20);
    // ---- passengers ----
    const N = L.stations.length; let pid = 0, totalFare = 0;
    for (let i = 0; i < N - 1; i++) {
      const rr = r(); let count = i === 0 ? 1 : (rr < 0.15 ? 0 : rr < 0.62 ? 1 : 2);
      if (i > 0 && L.passengers.length < i) count = Math.max(count, 1);
      for (let k = 0; k < count; k++) {
        const to = Math.min(N - 1, i + 1 + Math.floor(r() * Math.min(3, N - 1 - i)));
        const typeId = i === 0 && k === 0 ? W.passengers[0] : pick(r, W.passengers);
        const T = TT.PASSENGER_TYPES[typeId];
        const dist = L.stations[to].x - L.stations[i].x;
        const fare = Math.round((30 + dist / 1000 * 140 + (T.tips ? 12 : 0)) / 5) * 5; // الأجرة على قد المشوار
        const p = {
          id: 'p' + (pid++), type: typeId, T, look: T.look, from: i, to, dist, fare, seats: T.seats || 1,
          timeLimit: Math.round(dist / 7.2 + 20 * (T.patience || 1)), state: 'waiting', sat: 70, t: 0, nego: false, nameLine: T.name
        };
        L.passengers.push(p); L.stations[i].waiting.push(p); totalFare += fare;
      }
    }
    L.required = Math.min(L.passengers.length, 2 + Math.floor(Math.min(li, 30) * 0.2));
    L.target = Math.round(totalFare * 0.62 / 5) * 5;
    // ---- gas stations ----
    const gasN = free ? Math.floor(len / 750) : Math.max(F.fuelStations || 1, Math.floor(len / 650));
    for (let g = 0; g < gasN; g++) {
      let gx = len * (g + 1) / (gasN + 1) + (r() - 0.5) * 60, tries = 0;
      while (occ(gx - 16, gx + 16) && tries++ < 40) gx += 13;
      L.gas.push({ id: 'gas' + g, x: gx, name: W.id === 'mars' ? 'محطة طاقة' : 'بنزينة' }); take(gx - 16, gx + 16); L.flats.push(gx);
    }
    // ---- السواقة الحرة: استراحات وورش على الطريق ----
    if (free) {
      const RN = ['استراحة الأمانة', 'استراحة الطريق', 'كافتيريا الصحبة', 'استراحة أبو علي', 'قهوة المسافرين'], SN = ['ورشة الأسطى حسن', 'ورشة النور', 'ورشة الطريق السريع', 'ميكانيكي الأمانة'];
      for (let k = 0; k < 2; k++) { let rx = len * (0.28 + k * 0.42) + (r() - 0.5) * 120, tries = 0; while (occ(rx - 18, rx + 18) && tries++ < 40) rx += 15; L.rests.push({ id: 'rest' + k, x: rx, name: pick(r, RN) }); take(rx - 18, rx + 18); L.flats.push(rx); }
      for (let k = 0; k < 2; k++) { let wx = len * (0.18 + k * 0.5) + (r() - 0.5) * 120, tries = 0; while (occ(wx - 16, wx + 16) && tries++ < 40) wx += 15; L.shops.push({ id: 'shop' + k, x: wx, name: pick(r, SN) }); take(wx - 16, wx + 16); L.flats.push(wx); }
    }
    function place(minGap, w, from, to) {
      for (let t = 0; t < 60; t++) { const px = (from || 40) + r() * ((to || len - 40) - (from || 40)); if (!occ(px - w / 2 - minGap, px + w / 2 + minGap)) return px; }
      return null;
    }
    L.accidents = []; if (W.id !== 'mars' && li >= 2 && r() < 0.6 && ST0.traffic !== 'none') { const ax = place(2, 34, 180, len - 100); if (ax != null) { L.accidents.push({ id: 'a0', x: ax, state: 'active' }); take(ax - 30, ax + 25); } }
    // ---- village zones (country) ----
    if (F.villageZones) { for (let i = 0; i < 1 + (li >= 2 ? 1 : 0); i++) { const vx = place(2, 130); if (vx == null) continue; const nm = 'قرية ' + pick(r, ['ميت غمر', 'الشيخ زايد', 'كفر الزيات', 'منية النصر', 'تلا']); L.zones.village.push({ id: 'vz' + i, a: vx - 65, b: vx + 65, limit: 40, name: nm }); L.signs.push({ type: 'village', x: vx - 65, name: nm, limit: 40 }, { type: 'village', x: vx + 65, end: true }); } }
    // ---- storms (desert) ----
    if (F.storms && li >= 1) { const sx = place(0, 170, 150); if (sx != null) { L.zones.storm.push({ id: 'sz0', a: sx - 85, b: sx + 85 }); L.signs.push({ type: 'storm', x: sx - 95 }, { type: 'storm', x: sx + 85, end: true }); } }
    // ---- tunnels (city) ----
    if (W.id !== 'mars') { const nt = (F.tunnels || li >= 1 ? 1 : 0) + (len > 1800 && r() < 0.5 ? 1 : 0); for (let i = 0; i < nt; i++) { if (!F.tunnels && r() > 0.7) continue; const tx = place(4, 110); if (tx != null) { L.zones.tunnel.push({ id: 'tn' + i, a: tx - 55, b: tx + 55 }); take(tx - 56, tx + 56); } } }
    // ---- bridges (كباري) — عشوائي ----
    if (W.id !== 'mars') { const nb = (li === 0 ? 0 : 1) + (r() < 0.5 ? 1 : 0) + (len > 1800 && r() < 0.6 ? 1 : 0); for (let i = 0; i < nb; i++) { const bx = place(6, 140); if (bx == null) continue; L.zones.bridge.push({ id: 'br' + i, a: bx - 70, b: bx + 70, h: 2.2 + r() * 0.8, river: r() < 0.6 }); take(bx - 72, bx + 72); } }
    // ---- traffic jams (زحمة) — عشوائي ----
    if (W.id !== 'mars' && li >= 2 && W.traffic >= 0.5 && r() < 0.5) { const jx = place(2, 120); if (jx != null) { L.zones.jam.push({ id: 'jm0', a: jx - 60, b: jx + 60, spawned: false }); } }
    // ---- quiet zones ----
    if (F.quiet && li >= 1) { const qx = place(4, 70); if (qx != null) { L.zones.quiet.push({ id: 'q0', a: qx - 35, b: qx + 35 }); L.signs.push({ type: 'quiet', x: qx - 35 }, { type: 'quiet', x: qx + 35, end: true }); take(qx - 36, qx + 36); } }
    // ---- traffic lights ----
    const nLights = F.lights && polM > 0 ? Math.round(Math.min(3, (F.lights === 2 ? 2 : 1) + Math.floor(li / 8)) * Math.min(1.4, polM)) : 0;
    for (let i = 0; i < nLights; i++) {
      const lx = place(10, 20); if (lx == null) continue;
      L.lights.push({ id: 'tl' + i, x: lx, phase: r() * 13 }); take(lx - 18, lx + 8); L.flats.push(lx);
    }
    // ---- radars ----
    const nRad = F.radars && polM > 0 ? Math.max(1, Math.round(((F.radars === 2 ? 2 : 1) + (li >= 10 ? 1 : 0)) * polM)) : 0;
    for (let i = 0; i < nRad; i++) {
      const rx = place(6, 6, 90); if (rx == null) continue;
      L.radars.push({ id: 'rad' + i, x: rx, limit: W.speedLimit, flash: 0 }); take(rx - 4, rx + 4);
      L.signs.push({ type: 'radarWarn', x: rx - 60 });
    }
    // ---- no parking ----
    const nNP = F.noParking ? (F.noParking === 2 ? 2 : 1) : 0;
    for (let i = 0; i < nNP; i++) { const nx = place(4, 34); if (nx == null) continue; L.zones.noPark.push({ id: 'np' + i, a: nx - 17, b: nx + 17 }); L.signs.push({ type: 'noPark', x: nx - 15 }); take(nx - 18, nx + 18); }
    // ---- checkpoint ----
    if (W.id !== 'mars' && li >= 2 && polM > 0 && ST0.checkpoints !== 'off' && r() < Math.min(0.95, (F.checkpoints ? 0.65 : 0.3) * polM)) { const cx = place(10, 24); if (cx != null) { L.checkpoints.push({ id: 'cp0', x: cx, state: 'closed', stopT: 0, done: false }); take(cx - 22, cx + 8); L.flats.push(cx); } }
    // ---- work zone ----
    if (F.works && li >= 1) { const wx = place(4, 30); if (wx != null) { L.zones.work.push({ id: 'wk0', a: wx - 14, b: wx + 14, x: wx }); L.signs.push({ type: 'speed', x: wx - 30, limit: 20, zone: 'أعمال' }); for (let k = 0; k < 4; k++) L.obstacles.push({ type: 'cone', x: wx - 8 + k * 5, w: 0.45 }); take(wx - 15, wx + 15); } }
    // ---- crosswalks / herds ----
    if (F.crosswalks) { for (let i = 0; i < 1 + Math.min(2, Math.floor(li / 2)); i++) { const cx = place(5, 6); if (cx == null) continue; L.crosswalks.push({ id: 'cw' + i, x: cx, spawned: 0, cool: 0 }); take(cx - 4, cx + 4); } }
    if ((W.peds || []).some(p => p !== 'ped')) { for (let i = 0; i < Math.round((1 + Math.floor(li / 2)) * aniM); i++) { const hx = place(6, 8, 120); if (hx == null) continue; L.herds.push({ id: 'hd' + i, x: hx, spawned: 0, cool: 0 }); take(hx - 5, hx + 5); } }
    // ---- blockers (double-parked car) ----
    if (F.blockers && li >= 1 && (li % 2 === 1 || li >= 4)) {
      const bx = place(8, 8, 160); if (bx != null) {
        const temper = pick(r, ['calm', 'stubborn', 'hothead', 'coward']);
        L.blockers.push({ id: 'bk0', x: bx, temper }); take(bx - 10, bx + 8);
      }
    }
    // ---- obstacles ----
    const density = 1 / Math.max(20, 48 - Math.min(li, 30) * 1.0);
    const ST = (Save.data && Save.data.settings) || {};
    const AMT = { none: 0, few: 0.45, normal: 1, many: 1.7 };
    const obMult = AMT[ST.obstacles] != null ? AMT[ST.obstacles] : 1, bumpMult = AMT[ST.bumps] != null ? AMT[ST.bumps] : 1;
    const weights = Object.assign({}, W.obstacles);
    if (weights.bump != null) weights.bump *= bumpMult;
    if (weights.ramp != null) weights.ramp *= bumpMult;
    if (!Object.values(weights).some(v => v > 0)) weights.water = 1;
    const nOb = Math.round((len - 80) * density * obMult * (bumpMult === 0 && W.obstacles.bump ? 0.85 : 1));
    L.amounts = { obstacles: ST.obstacles || 'normal', bumps: ST.bumps || 'normal' };
    for (let i = 0; i < nOb; i++) {
      const type = weighted(r, weights), def = TT.OBSTACLES[type];
      if (li === 0 && (type === 'oil' || type === 'ramp')) continue;
      const w = def.w * (def.kind === 'surface' ? 0.8 + r() * 0.6 : 1);
      const ox = place(3, w, 60); if (ox == null) continue;
      const o = { id: 'ob' + i, type, x: ox, w, h: def.h, kind: def.kind, grip: def.grip, drag: def.drag, sandy: def.sandy, mars: W.id === 'mars' };
      L.obstacles.push(o); take(ox - w / 2 - 1, ox + w / 2 + 1);
      if (def.warn && r() < 0.6) L.signs.push({ type: type === 'bump' ? 'warnBump' : 'warnHole', x: ox - 30 });
      if (type === 'pothole' && r() < 0.35) { const o2 = Object.assign({}, o, { id: o.id + 'b', x: ox + 1.6 + r() * 0.8 }); if (!occ(o2.x - 0.6, o2.x + 0.6)) { L.obstacles.push(o2); take(o2.x - 0.6, o2.x + 0.6); } }
    }
    // ---- coins ----
    let cid = 0;
    for (let cx = 45; cx < len - 40; cx += 26 + r() * 30) {
      const n = 3 + Math.floor(r() * 4), arc = r() < 0.3;
      for (let k = 0; k < n; k++) L.coins.push({ id: 'c' + (cid++), x: cx + k * 1.4, h: 0.55 + (arc ? Math.sin(k / (n - 1) * Math.PI) * 1.0 : 0), taken: false });
    }
    // ---- props ----
    const propTypes = { streets: ['lamp', 'kiosk', 'fruit', 'cafe', 'tree', 'lamp'], country: ['palm', 'hay', 'tree', 'palm', 'sign'], desert: ['rockSmall', 'cactus', 'tent', 'rockSmall', 'sign'], city: ['modernLamp', 'tree', 'bench', 'billboard', 'modernLamp'], mars: ['rockSmall', 'crystal', 'solar', 'crystal'], alex: ['lamp', 'palm', 'bench', 'kiosk', 'fruit', 'cafe'], saeed: ['palm', 'hay', 'palm', 'rockSmall', 'sign', 'tent'] }[W.theme] || ['lamp', 'tree'];
    const kioskNames = ['سجاير وحاجة ساقعة', 'كشك الأمل', 'جرايد ومجلات', 'شحن كروت'];
    for (let px = 8; px < len + 20; px += 9 + r() * 16) {
      if (L.stations.some(s => Math.abs(s.x - px) < 5) || L.gas.some(g => Math.abs(g.x - px) < 5) || L.checkpoints.some(c => Math.abs(c.x - px) < 4)) continue;
      const tp = pick(r, propTypes);
      L.props.push({ type: tp, x: px, label: tp === 'kiosk' ? pick(r, kioskNames) : tp === 'sign' ? pick(r, W.stations) + ' ←' : tp === 'billboard' ? pick(r, ['عروض الصيف', 'شقق للبيع', 'اشحن واكسب']) : null, c: pick(r, ['#ff7043', '#7e57c2', '#26a69a']) });
    }
    // ---- bystanders (NPCs) ----
    const temps = ['calm', 'stubborn', 'hothead', 'coward'];
    L.stations.forEach((s, i) => { if (r() < 0.7) L.npcs.push(makeNPC('by' + i, s.x + 7 + r() * 3, 'bystander', pick(r, temps), r, W)); });
    // ناس واقفة في الشارع — تقدر تنزل تكلمهم (أو تتخانق معاهم)
    let sk = 0; for (let px = 50; px < len - 30; px += 55 + r() * 60) { if (L.stations.some(s => Math.abs(s.x - px) < 12) || L.zones.bridge.some(b => px > b.a && px < b.b)) continue; L.npcs.push(makeNPC('sn' + (sk++), px, 'bystander', pick(r, temps), r, W)); }
    // ---- buckets for fast lookup ----
    for (const o of L.obstacles) {
      const map = o.kind === 'profile' ? L.buckets : o.kind === 'surface' ? L.sBuckets : null; if (!map) continue;
      for (let b = Math.floor((o.x - o.w / 2) / 8); b <= Math.floor((o.x + o.w / 2) / 8); b++) (map[b] = map[b] || []).push(o);
    }
    L.flats.sort((a, b) => a - b);
    // ---- حدود سرعة مختلفة على طول الطريق ----
    const LIMT = { streets: [60, 70, 80], country: [60, 70, 80], alex: [60, 80, 90], desert: [100, 120, 140], saeed: [60, 80, 90], city: [80, 90, 120], mars: [60, 90] }, LIM = LIMT[W.id] || LIMT[W.theme] || [60, 80];
    L.speedZones = []; for (let zx = 0; zx < len + 50;) { const seg = 160 + r() * 260, lim = zx === 0 ? W.speedLimit : pick(r, LIM); L.speedZones.push({ a: zx, b: zx + seg, limit: zx === 0 ? LIM[0] : lim }); if (zx > 0) L.signs.push({ type: 'speed', x: zx, limit: lim }); zx += seg; }
    for (const rd of L.radars) rd.limit = (L.speedZones.find(z => rd.x >= z.a && rd.x < z.b) || { limit: W.speedLimit }).limit;
    // دورية متحركة بتوقفك في نص الطريق (مرة في المرحلة)
    L.patrolAt = W.id !== 'mars' && li >= 2 && polM > 0 && ST0.checkpoints !== 'off' && r() < Math.min(0.9, 0.55 * polM) ? 200 + r() * (len - 400) : null;
    L.signs.sort((a, b) => a.x - b.x);
    return L;
  }
  function makeNPC(id, x, kind, temper, r, W) {
    const looks = W.id === 'mars' ? [TT.PASSENGER_TYPES.alien.look, TT.PASSENGER_TYPES.astro.look] : TT.NPC_LOOKS;
    const names = ['أبو حمادة', 'الحاج محمود', 'كابتن شريف', 'عم رمضان', 'سعيد الجن', 'المعلم زكي', 'أستاذ ممدوح'];
    return { id, x, kind, temper, look: pick(r, looks), name: pick(r, names), mood: kind === 'bystander' ? 0 : 60, state: 'idle', facing: -1, greeted: false, t: r() * 10, line: null, lineT: 0 };
  }
  TT.genLevel = genLevel;
  TT.limitAt = function (L, x) {
    const vz = L.zones.village.find(z => x > z.a && x < z.b); if (vz) return vz.limit;
    const wz = L.zones.work.find(z => x > z.a - 30 && x < z.b); if (wz) return 20;
    if (L.zones.jam.some(z => x > z.a - 20 && x < z.b)) return 20;
    const z = (L.speedZones || []).find(z => x >= z.a && x < z.b); return z ? z.limit : L.W.speedLimit;
  };

  /* ===================== GROUND / TERRAIN ===================== */
  function flatFactor(L, x) {
    // distance to nearest flat point (stations, gas, lights...) → 0 near, 1 far
    const f = L.flats; let lo = 0, hi = f.length - 1;
    while (lo < hi) { const m = (lo + hi) >> 1; if (f[m] < x) lo = m + 1; else hi = m; }
    let d = Infinity; for (let i = Math.max(0, lo - 1); i <= Math.min(f.length - 1, lo); i++) d = Math.min(d, Math.abs(f[i] - x));
    return smooth(clamp((d - 14) / 26, 0, 1));
  }
  function terrain(L, x) {
    const W = L.W; if (!W.terrain) return bridgeH(L, x);
    let h = W.terrain * (Math.sin(x * 0.03 + L.ph1) * 0.65 + Math.sin(x * 0.071 + L.ph2) * 0.35);
    if (W.roughness) h += W.roughness * 0.4 * Math.sin(x * 7.1 + L.ph1) * (0.6 + 0.4 * Math.sin(x * 0.21));
    return h * flatFactor(L, x) + bridgeH(L, x);
  }
  function bridgeH(L, x) {
    const z = L.zones.bridge; if (!z || !z.length) return 0;
    for (const b of z) { if (x <= b.a || x >= b.b) continue; const ramp = 35, u = Math.min(x - b.a, b.b - x); return b.h * smooth(clamp(u / ramp, 0, 1)); }
    return 0;
  }
  function shapeOf(o, u) {
    switch (o.type) {
      case 'bump': return o.h * (1 - Math.cos(u * Math.PI * 2)) / 2;
      case 'pothole': case 'crater': return o.h * Math.pow(Math.sin(u * Math.PI), 0.45);
      case 'ramp': return u < 0.9 ? o.h * u / 0.9 : o.h * (1 - (u - 0.9) / 0.1);
      default: return o.h * Math.pow(Math.sin(u * Math.PI), 0.6);
    }
  }
  function groundAt(L, x) {
    let h = terrain(L, x);
    const b = L.buckets[Math.floor(x / 8)];
    if (b) for (let i = 0; i < b.length; i++) { const o = b[i], u = (x - (o.x - o.w / 2)) / o.w; if (u > 0 && u < 1) h += shapeOf(o, u); }
    return h;
  }
  function surfaceAt(L, x) {
    const b = L.sBuckets[Math.floor(x / 8)];
    if (b) for (const o of b) if (Math.abs(x - o.x) < o.w / 2) return o;
    return null;
  }
  // wheel contact height: max over the wheel footprint (a wheel can't fall into a narrow hole)
  function wheelGround(L, x, r) {
    let best = -1e9;
    for (let i = -3; i <= 3; i++) { const s = i / 3 * r * 0.92; const g = groundAt(L, x + s) + Math.sqrt(r * r - s * s) - r; if (g > best) best = g; }
    return best;
  }
  TT.groundAt = groundAt;

  /** draws the player's driver (uses its sprite sheet from assets/characters when loaded) */
  function drawDriver(c, x, y, pose, t, o) {
    let look = driverLook();
    if (G.anger > 0 && G.mode === 'play') { look = Object.assign({}, look, { skin: '#d9534f', sheet: undefined }); o = Object.assign({}, o, { expr: 'angry' }); }
    else if (G.phone && G.phone.state === 'talk') o = Object.assign({}, o, { expr: 'talk' });
    A.person(c, x, y, look, pose, t, o);
  }
  TT.drawDriver = drawDriver;

  /* ============================ GAME STATE ============================ */
  const G = TT.G = {
    mode: 'menu', // menu | play | end
    paused: false, modal: null, L: null, time: 0,
    tuk: null, driver: null, cam: { x: 0, z: 1, shake: 0 },
    traffic: [], peds: [], particles: [], bubbles: [], toastsQueue: [], crowd: [],
    stats: null, vkeys: new Set(), riding: [], ui: {}, fight: null, flip: null,
    input: { gas: 0, brake: 0, left: 0, right: 0, hand: 0, run: 0 }
  };

  function newTuk(x) {
    const vp = vehParams();
    return {
      x, y: geom().H0 - 9.8 / (2 * vp.k), pedal: 0, engineOn: false, vx: 0, vy: 0, a: 0, av: 0, wheelRot: 0,
      comp: [0, 0], pen: [null, null], contact: [false, false], grounded: true, airT: 0,
      reverseHold: 0, revDist: 0, lean: 0, steerVis: 0, lights: false, mode: 'normal',
      surface: null, throttle: 0, braking: 0, impactCool: 0, sputter: 0, honkT: 0, honks: [],
      occupied: 'driver' // 'driver' | 'empty'
    };
  }

  /* =========================== START LEVEL =========================== */
  function startLevel(wi, li, resume, opts) {
    const d = Save.data;
    G.free = !!(opts && opts.free); if (opts && opts.first) G.env = null;
    const L = genLevel(wi, li, opts);
    G.L = L; G.mode = 'play'; G.paused = false; G.modal = null; G.time = 0;
    G.tuk = newTuk(8); G.driver = null; G.fight = null; G.flip = null;
    G.traffic = []; G.peds = []; G.particles = []; G.bubbles = []; G.riding = []; G.vkeys = new Set();
    G.stats = { income: 0, tips: 0, fines: 0, fuel: 0, repairs: 0, delivered: 0, violations: 0, flips: 0, coins: 0, ratings: [], fights: 0, left: 0 };
    G.cam.x = G.tuk.x; G.cam.z = 1;
    G.trafficSeed = mulberry32(hashStr(L.W.id + 't') + li);
    G.npcTalk = null; G.lastSnap = 0; G.stuckT = 0; G.noParkT = 0; G.villageT = 0; G.darkT = 0;
    G.vis = 1; G.boardingLock = false; G.walkers = []; G.activeChat = null; G.chatCool = null; G.driverOut = false; G.fuelWarned = false; G.driverPose = null; G.inDark = null; G.crowd = []; G.arrest = null; G.clamped = false; G.pendingMediation = null; G.autoDone = null; G.celebrate = 0; G.partyOn = !!accOpts().party; if (G.subOn) TT.Audio.bass(false); G.subOn = false; G.exploded = null; G.pour = null; G.chase = null; G.cine = null; G.ownerMiss = 0; G.ownerAt = null; G.failReason = null; G.dmgStart = Math.max(Save.veh().damage.engine, Save.veh().damage.body); G.smokeWarned = false; G.critWarned = false; G.roofFly = null; G.lastDriverLine = -99; G.chatterT = null; G.stopAtSt = 0; G.radarAhead = null;
    if (G.free) G.vendor = null; else setupVendor(L);
    initEnv(L, resume); setupChallenge(L); G.race = null; G.raceCool = 25 + Math.random() * 20; G.rival = null; G.phone = null; G.phoneT = 35 + Math.random() * 40; G.anger = 0;
    if (G.free) { G.fatigue = (d.free && d.free.fatigue) || 0; G.dozeT = 0; } else G.fatigue = null;
    // blockers become a parked car + an NPC driver standing next to it
    for (const b of L.blockers) {
      const col = pick(L.r, A.VEH.car.col);
      const veh = { id: b.id, type: 'car', x: b.x, v: 0, len: A.VEH.car.len, color: col, state: 'blocker', lane: 0, laneT: 0, wr: 0 };
      G.traffic.push(veh);
      const npc = makeNPC('npc_' + b.id, b.x + A.VEH.car.len + 1.2, 'blocker', b.temper, L.r, L.W);
      npc.vehicleId = b.id; npc.mood = 45; L.npcs.push(npc); b.npc = npc; b.veh = veh;
    }
    if (G.free) { Save.write(); TT.Audio.init(); TT.UI.onLevelStart(L, false, { free: true, first: !!(opts && opts.first) }); return; }
    d.last = { world: wi, level: li };
    if (resume && d.snapshot && d.snapshot.world === wi && d.snapshot.level === li) applySnapshot(d.snapshot);
    else d.snapshot = null;
    Save.write();
    TT.Audio.init();
    TT.UI.onLevelStart(L, !!resume);
  }

  /* ---------- snapshot (save mid-level & resume) ---------- */
  function makeSnapshot() {
    if (G.mode !== 'play' || !G.L) return null;
    const L = G.L;
    return {
      world: L.wi, level: L.li, x: G.tuk.x, time: G.time, stats: G.stats, vkeys: [...G.vkeys],
      pass: L.passengers.map(p => ({ id: p.id, state: p.state === 'boarding' ? 'riding' : p.state === 'alighting' ? 'delivered' : p.state, sat: p.sat, t: p.t, fare: p.fare, nego: p.nego, seat: p.seat })),
      coins: L.coins.filter(c => c.taken).map(c => c.id),
      blockers: L.blockers.filter(b => b.resolved).map(b => b.id),
      cps: L.checkpoints.filter(c => c.done).map(c => c.id),
      lights: G.tuk.lights, mode: G.tuk.mode
    };
  }
  function applySnapshot(s) {
    const L = G.L;
    G.tuk.x = Math.max(8, s.x - 3); G.tuk.y = groundAt(L, G.tuk.x) + geom().H0 - 0.06; G.time = s.time; G.stats = s.stats; G.vkeys = new Set(s.vkeys);
    G.tuk.lights = s.lights; G.tuk.mode = s.mode || 'normal';
    for (const sp of s.pass) {
      const p = L.passengers.find(q => q.id === sp.id); if (!p) continue;
      Object.assign(p, { state: sp.state, sat: sp.sat, t: sp.t, fare: sp.fare, nego: sp.nego, seat: sp.seat });
      if (p.state !== 'waiting') { const st = L.stations[p.from]; st.waiting = st.waiting.filter(q => q !== p); }
      if (p.state === 'riding') G.riding.push(p);
    }
    for (const id of s.coins) { const c = L.coins.find(q => q.id === id); if (c) c.taken = true; }
    for (const id of s.blockers) { const b = L.blockers.find(q => q.id === id); if (b) resolveBlocker(b, true); }
    for (const id of s.cps) { const c = L.checkpoints.find(q => q.id === id); if (c) { c.done = true; c.state = 'open'; } }
    G.cam.x = G.tuk.x;
  }
  function saveSnapshot() { if (G.free) { saveFree(); return; } const s = makeSnapshot(); if (s) { Save.data.snapshot = s; Save.write(); } }
  TT.saveSnapshot = saveSnapshot;

  /* ============================ MESSAGES ============================ */
  function toast(msg, kind, dur) { TT.UI.toast(msg, kind, dur); }
  function say(ent, line, dur, mood) { if (!line) return; G.bubbles = G.bubbles.filter(b => b.ent !== ent); G.bubbles.push({ ent, line, t: dur || 2.6, max: dur || 2.6, mood }); }
  function vibrate(ms) { if (Save.data.settings.vibrate && navigator.vibrate) try { navigator.vibrate(ms); } catch (e) { } }
  function seatsUsed() { return G.riding.reduce((s, p) => s + p.seats, 0); }
  function nearPolice(x) { return G.traffic.some(v => v.type === 'police' && Math.abs(v.x - x) < 60 && v.state !== 'gone'); }

  /* ============================ VIOLATIONS ============================
     تُسجَّل مرة واحدة فقط لكل (نوع + مكان) عبر G.vkeys — لا تتكرر كل frame */
  function violation(kind, key, reason) {
    if (G.vkeys.has(key)) return false;
    G.vkeys.add(key);
    const V = TT.VIOLATIONS[kind];
    if (Save.data.settings.fines === 'off') { toast('⚠️ ' + TT.t(V.name, V.en) + ' — ' + reason + TT.t(' (تنبيه بس)', ' (warning only)'), 'warn', 3); TT.Audio.play('beep'); return false; }
    const mult = nearPolice(G.tuk.x) ? 1.5 : 1;
    const fine = V.fine; // المخالفات ثابتة: 50 أو 100 (وصدم المشاة 350)
    const d = Save.data;
    // الغرامة مش بتتخصم على طول: بتتسجل وتتدفع عند الفحص (كمين) أو في المرور عند تجديد الرخصة
    d.pendingFines = d.pendingFines || []; d.pendingFines.push({ kind, fine, reason, t: Date.now(), where: TT.t(G.L.W.name, G.L.W.en) + ' ' + (G.L.li + 1) });
    G.stats.pend = (G.stats.pend || 0) + fine;
    d.rep = clamp(d.rep - V.rep, 0, 100);
    d.stats.violations++;
    d.violationsLog.unshift({ t: Date.now(), kind, fine, reason, world: G.L.W.id });
    if (d.violationsLog.length > 40) d.violationsLog.length = 40;
    G.stats.violations++;
    for (const p of G.riding) p.sat -= 5;
    TT.Audio.play('whistle'); vibrate(80);
    TT.UI.violation(TT.t(V.name, V.en), fine, reason + (mult > 1 ? TT.t(' — الدورية كانت قريبة (×1.5)', ' — patrol nearby (x1.5)') : ''));
    return true;
  }

  function rec(k) { const d = Save.data; d.record = d.record || {}; d.record[k] = (d.record[k] || 0) + 1; }
  TT.pendingTotal = () => (Save.data.pendingFines || []).reduce((a, f) => a + f.fine, 0);
  TT.payFines = function () {
    const d = Save.data, list = d.pendingFines || [], total = TT.pendingTotal(); if (!total) return { count: 0, total: 0 };
    Save.ledger(TT.t('دفع مخالفات المرور (' + list.length + ')', 'Paid traffic fines (' + list.length + ')'), -total, 'fine');
    if (G.stats && G.mode === 'play') G.stats.fines += total;
    d.pendingFines = []; TT.Audio.play('cash'); Save.write(); return { count: list.length, total };
  };
  TT.LICENSE_FEE = 100;
  TT.renewLicense = function () {
    const d = Save.data, total = TT.pendingTotal() + TT.LICENSE_FEE;
    if (TT.pendingTotal()) TT.payFines();
    Save.ledger(TT.t('رسوم تجديد الرخصة', 'License renewal fee'), -TT.LICENSE_FEE, 'fine');
    d.license = { left: 5, renewed: (d.license && d.license.renewed || 0) + 1 }; d.record = { crashes: 0, flips: 0, explosions: 0, fights: 0, levels: 0, animals: 0 };
    TT.Audio.play('cash'); Save.write(); return total;
  };

  /* ============================ DAMAGE ============================ */
  function damage(part, amt) {
    const dm = Save.veh().damage, vp = G.vp;
    dm[part] = clamp(dm[part] + amt * vp.dmgMult, 0, 1);
  }
  function conditionPct() { const dm = Save.veh().damage; return 1 - (dm.engine + dm.tires + dm.suspension + dm.brakes + dm.body) / 5; }
  TT.conditionPct = conditionPct;

  /* ============================ PHYSICS ============================ */
  function physicsStep(dt) {
    const T = G.tuk, L = G.L, vp = G.vp, I = G.input;
    const g = L.W.gravity;
    const nPass = seatsUsed();
    const GM = geom(), cs = comShift(), seatsMax = Save.model().seats || 3;
    const dx = [GM.rearX + cs, GM.frontX + cs];
    const H0 = GM.H0, R = GM.wheelR;
    const ca = Math.cos(T.a), sa = Math.sin(T.a);
    let Fy = -g, tau = 0;
    const travel = Math.max(0.08, vp.travel);
    T.contact[0] = T.contact[1] = false;
    let impact = 0;
    for (let i = 0; i < 2; i++) {
      // wheel attach point (bottom of wheel at zero compression), y-up world
      const rx = dx[i] * ca + H0 * sa, ry = dx[i] * sa - H0 * ca;
      const wx = T.x + rx, wy = T.y + ry;
      const gy = wheelGround(L, wx, R);
      const pen = gy - wy;
      // compression rate (includes ground moving under the wheel → bumps hit hard at speed)
      const prev = T.pen[i] == null ? pen : T.pen[i];
      const rate = clamp((pen - prev) / dt, -12, 12);
      T.pen[i] = pen;
      T.comp[i] = clamp(pen, 0, travel);
      if (pen > -0.005) T.contact[i] = true;
      if (pen > 0) {
        let F = vp.k * pen + vp.c * rate;
        if (pen > travel) { F += 1400 * (pen - travel) + 30 * Math.max(0, rate); if (rate > impact) impact = rate; }
        if (F < 0) F = 0;
        Fy += F; tau += rx * F;
      }
    }
    // roof / body scrape → flip trigger
    for (const lx of [-GM.back, GM.front]) {
      const px = T.x + lx * ca - GM.roof * sa, py = T.y + lx * sa + GM.roof * ca;
      if (py < groundAt(L, px) + 0.05) { startFlip(); return; }
    }
    if (Math.abs(T.a) > 0.95) { startFlip(); return; }
    // body edge (bumper) hitting ground hard counts as impact too
    const grounded = T.contact[0] || T.contact[1];
    T.grounded = grounded; T.airT = grounded ? 0 : T.airT + dt;

    // ---- longitudinal ----
    const surf = surfaceAt(L, T.x); T.surface = surf;
    let grip = vp.grip, drag = 0;
    if (surf) {
      if (surf.sandy) { grip *= lerp(surf.grip, 0.95, vp.sand); drag += surf.drag * (1 - vp.sand * 0.85); }
      else { grip *= surf.grip; drag += surf.drag || 0; }
    }
    if (L.W.roughness && L.W.id === 'country') grip *= lerp(0.85, 1, vp.farm);
    if (L.W.id === 'mars' && !vp.spaceTires) grip *= 0.75;
    grip = clamp(grip, 0.1, 1.2);
    const modeF = T.mode === 'eco' ? { p: 0.8, v: 0.88, f: 0.72 } : T.mode === 'sport' ? { p: 1.15, v: 1.06, f: 1.35 } : { p: 1, v: 1, f: 1 };
    const vmax = vp.vmax * modeF.v;
    const massEff = 1 + 0.42 * nPass / seatsMax;
    const fuelOk = Save.veh().fuel > 0 && (T.engineOn || vp.human);
    let throttle = (T.occupied === 'driver' && fuelOk && !G.boardingLock && !G.clamped) ? I.gas : 0;
    if (I.gas && T.occupied === 'driver' && !T.engineOn && !vp.human && !T.cranking && G.time - (G.keyNag || -9) > 3) { G.keyNag = G.time; toast(TT.t('🔑 المحرك مقفول — دوس على المفتاح (I) عشان تشغّل', '🔑 Engine is off — tap the key (I) to start'), 'warn', 2.2); }
    if (vp.sputter && Math.sin(G.time * 7) > 0.85) throttle *= 0.2;
    if (G.dozeT > 0) throttle = 0;
    let acc = 0, brakeDec = 0;
    const brakeIn = T.occupied === 'driver' ? I.brake : 0;
    // reverse logic: hold brake while stopped → reverse
    if (brakeIn && T.vx < 0.3) T.reverseHold += dt; else if (!brakeIn) T.reverseHold = 0;
    const reversing = T.reverseHold > 0.45 && fuelOk && !G.clamped;
    if (T.contact[0] && throttle > 0) {
      if (T.vx < -0.05) brakeDec = vp.brake * grip; // gas while rolling back = brake first
      else acc += Math.min(throttle * vp.accel * modeF.p * Math.pow(clamp(1 - T.vx / vmax, 0, 1), 0.55), grip * 7) / massEff;
    }
    if (grounded && brakeIn && !reversing) { if (T.vx > 0.02) brakeDec = Math.max(brakeDec, vp.brake * grip); }
    if (grounded && reversing && T.contact[0]) { if (T.vx > -3) acc -= Math.min(1.6 * grip, 2) / massEff; }
    if (grounded && (I.hand || T.occupied !== 'driver')) brakeDec = Math.max(brakeDec, 5.5 * grip + (Math.abs(T.vx) < 0.5 ? 20 : 0));
    // slope
    if (grounded) { const sl = (groundAt(L, T.x + 0.6) - groundAt(L, T.x - 0.6)) / 1.2; acc -= g * sl * 0.95; }
    // drag
    const v0 = T.vx;
    acc -= Math.sign(T.vx) * ((grounded ? 0.12 + drag : 0) + 0.0045 * T.vx * T.vx);
    T.vx += acc * dt;
    if (brakeDec > 0) { const dv = brakeDec * dt; if (Math.abs(T.vx) <= dv) T.vx = 0; else T.vx -= Math.sign(T.vx) * dv; }
    if (Math.abs(T.vx) < 0.01 && !throttle && !reversing) T.vx = 0;
    const aLong = (T.vx - v0) / dt;
    // pitch torque from accel/braking + lean control
    if (grounded) tau += clamp(aLong, -9, 9) * 0.26;
    const lean = (I.right ? 1 : 0) - (I.left ? 1 : 0); // right = lean forward (nose down)
    T.lean = lean;
    if (T.occupied === 'driver') tau += -lean * (grounded ? 1.4 : 4.2);
    // integrate
    T.vy += Fy * dt;
    T.av += tau / GM.inertia * dt;
    T.av *= grounded ? 1 - 0.8 * dt : 1 - 0.25 * dt;
    if (T.contact[0] && T.contact[1]) T.av = clamp(T.av, -2.6, 2.6); // العجلتين على الأرض: الحفر/المطبات ما تقلبش التوكتوك لوحدها بسرعة بطيئة
    T.y += T.vy * dt; T.a += T.av * dt; T.x += T.vx * dt;
    T.wheelRot += T.vx / R * dt;
    T.throttle = throttle; T.braking = brakeDec > 0 ? 1 : 0;
    // ---- impacts → damage, comfort, sound ----
    T.impactCool -= dt;
    if (impact > 1.4 && T.impactCool <= 0) {
      T.impactCool = 0.35;
      const sev = impact - 1.4;
      damage('suspension', sev * 0.018); damage('tires', sev * 0.011); damage('body', sev * 0.012); damage('engine', sev * 0.004); if (sev > 0.6) driverSay('bump');
      G.cam.shake = Math.min(14, 3 + sev * 5);
      TT.Audio.play('bump'); vibrate(30 + sev * 25);
      for (const p of G.riding) { const k = p.T.smooth ? 1.7 : 1; p.sat -= (3 + sev * 6) * k; if (sev > 0.8 && Math.random() < 0.5) say(p, pick(Math.random, TT.LINES.angry)); }
      dust(T.x, 6 + sev * 6, '#7a6a55');
      if (sev > 1.4) toast(TT.t('خبطة جامدة! هدّي على المطبات', 'Hard hit! Slow down for bumps'), 'warn', 1.6);
    }
    // landing at speed in the air — measured via airT
    // ---- wear ----
    damage('engine', throttle * dt * 0.00005);
    if (brakeDec > 0 && Math.abs(T.vx) > 2) damage('brakes', dt * 0.00035);
    // ---- fuel ----
    const veh = Save.veh();
    T.pedal = (T.pedal || 0) + T.vx * dt * 2.4;
    // اتساخ المركبة (المية والرمل والطين بيوسخوها أسرع)
    veh.dirt = clamp((veh.dirt || 0) + Math.abs(T.vx) * dt * (surf && (surf.type === 'water' || surf.sandy) ? 0.0016 : 0.00004) * ((veh.wax || 0) > 0 ? 0.4 : 1), 0, 1);
    if (veh.wax > 0) veh.wax = Math.max(0, veh.wax - Math.abs(T.vx) * dt * 0.00012);
    if (vp.human) veh.fuel = 1;
    else if (T.occupied === 'driver' || throttle) {
      const use = (0.015 + throttle * 0.6 * (0.55 + 0.45 * Math.abs(T.vx) / vmax)) * modeF.f * vp.fuelEff * dt;
      veh.fuel = Math.max(0, veh.fuel - use);
    }
    // ---- reverse distance → wrong way ----
    if (T.vx < -0.2) T.revDist += -T.vx * dt; else if (T.vx > 0.5) T.revDist = 0;
    if (T.revDist > 40) violation('wrongWay', 'ww' + Math.floor(T.x / 60), TT.t('رجعت لورا أكتر من 40 متر في اتجاه عكسي', 'Reversed more than 40 m'));
    if (T.x < 2) { T.x = 2; T.vx = Math.max(0, T.vx); }
  }

  /* ============================ FLIP ============================ */
  function startFlip() {
    const T = G.tuk;
    if (G.flip) return;
    G.flip = { t: 0, from: T.a, dir: T.a >= 0 ? 1 : -1, y0: T.y, phase: 'tumble', progress: 0 };
    T.vx *= 0.2; T.vy = 0; T.av = 0;
    G.stats.flips++; Save.data.stats.flips++; rec('flips');
    damage('body', 0.15); damage('suspension', 0.08);
    TT.Audio.play('flip'); vibrate([100, 60, 160]); G.cam.shake = 16;
    toast(TT.t('التوكتوك اتقلب!', 'The tuk tuk flipped!'), 'bad', 2.5);
    // passengers get out dizzy, pay only for distance covered (half rate)
    for (const p of G.riding.slice()) {
      const st = G.L.stations[p.from];
      const covered = clamp((T.x - st.x) / p.dist, 0, 1);
      const pay = Math.round(p.fare * covered * 0.4);
      passengerLeaves(p, pay, 'dizzy');
    }
  }
  function updateFlip(dt) {
    const F = G.flip, T = G.tuk;
    F.t += dt;
    if (F.phase === 'tumble') {
      const k = clamp(F.t / 0.9, 0, 1);
      T.a = lerp(F.from, F.dir * Math.PI, smooth(k));
      const gy = groundAt(G.L, T.x);
      T.y = gy + lerp(F.y0 - gy, 1.15, k) + Math.sin(k * Math.PI) * 0.8;
      T.x += T.vx * dt; T.vx *= 1 - 2 * dt;
      if (k >= 1) { F.phase = 'down'; G.driverOut = true; T.occupied = 'empty'; G.driver = { x: T.x - 2.3, facing: 1, t: 0, vx: 0 }; TT.UI.showFlipPanel(true); }
      if (F.t > 0.35 && F.t < 0.5) dust(T.x, 10, '#8a7a65');
    } else if (F.phase === 'righting') {
      if (F.rt === 0) { F.x0 = T.x; F.x1 = safeX(T.x); }
      F.rt += dt;
      T.x = lerp(F.x0, F.x1, smooth(clamp(F.rt / 1.1, 0, 1)));
      const k = clamp(F.rt / 1.1, 0, 1);
      T.a = lerp(F.dir * Math.PI, 0, smooth(k));
      const gy = groundAt(G.L, T.x);
      T.y = gy + lerp(1.15, geom().H0 - 0.06, k) + Math.sin(k * Math.PI) * 0.9;
      if (k >= 1) {
        T.a = 0; T.av = 0; T.vy = 0; T.vx = 0; T.y = gy + geom().H0 - 0.06; T.pen = [null, null]; T.impactCool = 1;
        G.flip = null; G.driverOut = false; G.driver = null; T.occupied = 'driver';
        Save.data.stats.recoveries++;
        toast(TT.t('التوكتوك رجع على عجله 👍', 'Back on its wheels 👍'), 'good');
        TT.UI.showFlipPanel(false);
      }
    }
  }
  // nearest spot with no profile obstacle under the tuktuk and gentle slope
  function safeX(x) {
    const L = G.L;
    for (let i = 0; i <= 40; i++) {
      const c = x + (i % 2 ? -1 : 1) * Math.ceil(i / 2) * 0.75;
      if (c < 3) continue;
      const clear = !L.obstacles.some(o => o.kind === 'profile' && Math.abs(o.x - c) < o.w / 2 + 2.4);
      const slope = Math.abs(groundAt(L, c + 1.2) - groundAt(L, c - 1.2));
      if (clear && slope < 0.35) return c;
    }
    return x;
  }
  TT.flipAction = function (kind) {
    const F = G.flip; if (!F || F.phase !== 'down') return;
    if (kind === 'self') {
      F.pushes = (F.pushes || 0) + 1; TT.Audio.play('punch');
      G.cam.shake = 3;
      if (F.pushes >= 6) { F.phase = 'righting'; F.rt = 0; TT.UI.showFlipPanel(false); }
      return F.pushes / 6;
    }
    if (kind === 'tow') {
      const cost = 80;
      Save.ledger(TT.t('ونش الإنقاذ', 'Tow truck'), -cost, 'repair'); G.stats.repairs += cost;
      F.phase = 'righting'; F.rt = 0; TT.UI.showFlipPanel(false); F.tow = true;
      toast(TT.t('الونش وصل — دفعت 80 جنيه', 'Tow arrived — paid 80'), 'warn');
    }
  };

  /* ============================ PASSENGERS ============================ */
  function passengerLeaves(p, pay, why) {
    if (p.state === 'left' || p.state === 'delivered') return; // never double count
    p.state = 'left'; p.paid = pay;
    G.riding = G.riding.filter(q => q !== p);
    G.stats.left++;
    if (pay > 0) { Save.ledger(TT.t('أجرة جزئية: ', 'Partial fare: ') + p.T.name, pay, 'fare'); G.stats.income += pay; }
    p.exitAnim = { t: 0, x: G.tuk.x - 0.5, kind: why };
    G.walkers.push(p);
    say(p, why === 'dizzy' ? pick(Math.random, TT.LINES.dizzy) : pick(Math.random, TT.LINES.angry), 3);
    if (why === 'kicked') return;
    toast((why === 'dizzy' ? TT.t('الراكب نزل وهو دايخ', 'Passenger got off dizzy') : TT.t('الراكب زهق ونزل', 'Passenger gave up and left')) + (pay ? ` (+${pay} ج)` : TT.t(' — من غير ما يدفع', ' — no pay')), 'bad');
  }
  G.walkers = [];

  TT.boardPassenger = function (p, negotiate) {
    if (p.state !== 'waiting') return { ok: false };
    if (seatsUsed() + p.seats > (Save.model().seats || 3)) return { ok: false, msg: TT.t('مفيش مكان كفاية', 'Not enough seats') };
    let res = { ok: true };
    if (negotiate && !p.nego) {
      p.nego = true;
      const rep = Save.data.rep;
      const chance = clamp(p.T.negotiate * (0.6 + rep / 100), 0.05, 0.95);
      if (Math.random() < chance) { const add = Math.max(3, Math.round(p.fare * 0.3)); p.fare += add; res = { ok: false, nego: 'yes', msg: TT.t('ماشي يا عم، اتفقنا على ' + p.fare + ' جنيه', 'Fine, ' + p.fare + ' it is') }; }
      else if (p.T.offended && Math.random() < p.T.offended) { p.state = 'gone'; const st = G.L.stations[p.from]; st.waiting = st.waiting.filter(q => q !== p); res = { ok: false, nego: 'gone', msg: TT.t('انت بتستغلني؟! أنا ماشي', 'Ripping me off?! I\'m leaving') }; }
      else res = { ok: false, nego: 'no', msg: TT.t('لا يا اسطى هي دي الأجرة', 'No, that\'s the fare') };
      return res;
    }
    const st = G.L.stations[p.from];
    st.waiting = st.waiting.filter(q => q !== p);
    p.state = 'boarding'; p.t = 0; p.sat = 70 + G.vp.satBonus + (Save.data.rep - 50) * 0.1 - (Save.veh().dirt || 0) * 15;
    if ((Save.veh().dirt || 0) > 0.5) setTimeout(() => say(p, pick(Math.random, ['إيه الوساخة دي يا اسطى؟', 'ما تغسل العربية يا ريس!', 'هدومي هتتوسخ!']), 2.4), 600);
    p.boardAnim = { t: 0, x0: st.x - 2 + Math.random() * 3 };
    G.boardingLock = true;
    // assign seat
    const used = new Set(); G.riding.forEach(q => { used.add(q.seat); if (q.seats > 1) used.add(q.seat + 1); });
    const fs = [0, 1, 2].find(s => s + p.seats - 1 <= 2 && !used.has(s) && (p.seats < 2 || !used.has(s + 1)));
    p.seat = fs == null ? 0 : fs;
    G.riding.push(p);
    TT.Audio.play('board');
    say(p, pick(Math.random, TT.LINES.board), 2.4);
    return res;
  };

  function deliver(p) {
    if (p.state !== 'riding') return;
    p.state = 'delivered'; G.riding = G.riding.filter(q => q !== p);
    const onTime = p.t <= p.timeLimit;
    const sat = clamp(p.sat, 0, 100);
    const base = Math.round(p.fare * (0.7 + 0.3 * sat / 100));
    const bonus = onTime ? Math.round(p.fare * 0.1) : 0;
    const tip = sat > 80 ? Math.round(p.fare * 0.15 * (p.T.tips || 1) * ((((TT.DRIVERS.find(x => x.id === Save.data.driver) || {}).perk || {}).tips) || 1)) : 0;
    const total = base + bonus + tip;
    const stars = clamp(Math.ceil(sat / 20), 1, 5);
    Save.ledger(TT.t('أجرة: ', 'Fare: ') + TT.t(p.T.name, p.T.en), base + bonus, 'fare');
    if (tip) Save.ledger(TT.t('بقشيش', 'Tip'), tip, 'tip');
    G.stats.income += base + bonus; G.stats.tips += tip; G.stats.delivered++; G.stats.ratings.push(stars); if (onTime) G.stats.onTime = (G.stats.onTime || 0) + 1;
    const d = Save.data; d.stats.deliveries++; d.xp += total; d.rep = clamp(d.rep + (stars >= 4 ? 1 : stars <= 2 ? -1 : 0), 0, 100);
    if (G.L.W.id === 'mars') d.stats.marsRides++;
    p.exitAnim = { t: 0, x: G.tuk.x - 0.5, kind: 'happy' }; G.walkers.push(p);
    say(p, stars >= 4 ? pick(Math.random, TT.LINES.happy) : stars <= 2 ? pick(Math.random, TT.LINES.angry) : TT.t('شكرًا يا اسطى', 'Thanks'), 2.6);
    TT.Audio.play('cash'); burst(G.tuk.x, 1.6, '+' + total + ' ج', '#ffd54f'); G.celebrate = 3; if (Math.random() < 0.5) setTimeout(() => driverSay('money'), 1500);
    TT.UI.tripSummary({ name: TT.t(p.T.name, p.T.en), fare: p.fare, base, bonus, tip, total, stars, late: !onTime, time: Math.round(p.t), limit: p.timeLimit });
  }

  /* ============================ CONTEXT ACTIONS ============================ */
  function stationHere() { const T = G.tuk; return G.L.stations.find(s => Math.abs(s.x - T.x) < 7); }
  function gasHere() { const T = G.tuk; return G.L.gas.find(g => Math.abs(g.x - T.x) < 5); }
  function contextAction() {
    if (!G.L || G.flip || G.fight || G.arrest) return null;
    const T = G.tuk;
    if (G.driver) { // on foot
      const n = nearestNPC(); const nearTuk = Math.abs(G.driver.x - T.x) < 2;
      const acc = (G.L.accidents || []).find(a => a.state === 'active' && a.spawned && Math.abs(G.driver.x - (a.x + 4)) < 7);
      return { talk: !acc && n && Math.abs(n.x - G.driver.x) < 1.8 ? n : null, enter: nearTuk, accident: acc };
    }
    if (G.clamped && Math.abs(T.vx) < 0.6) return { id: 'unclamp', label: TT.t('فك الكلبش (' + TT.unclampCost + ' ج)', 'Remove clamp (' + TT.unclampCost + ')') };
    if (Math.abs(T.vx) > 0.6 || !T.grounded || G.boardingLock) return null;
    const st = stationHere();
    if (st) {
      const drop = G.riding.filter(p => p.to === st.idx && p.state === 'riding');
      if (drop.length) return { id: 'drop', label: TT.t('نزّل الركاب', 'Drop off'), st, drop };
      if (st.waiting.length) return { id: 'pickup', label: TT.t('ركّب', 'Pick up'), st };
    }
    if (G.free) { const rs = G.L.rests.find(q => Math.abs(q.x - T.x) < 7); if (rs) return { id: 'rest', label: TT.t('☕ استريّح', '☕ Rest'), rs }; const sh = G.L.shops.find(q => Math.abs(q.x - T.x) < 7); if (sh) return { id: 'shop', label: TT.t('🔧 الورشة', '🔧 Workshop'), sh }; }
    const gs = gasHere();
    if (gs && !G.vp.human && Save.veh().fuel < G.vp.tank - 1) return { id: 'refuel', label: TT.t('موّن', 'Refuel'), gs };
    return null;
  }
  TT.contextAction = contextAction;
  TT.doAction = function () {
    const c = contextAction(); if (!c) return;
    if (G.driver) { if (c.accident) TT.UI.openAccident(c.accident); else if (c.talk) TT.UI.openTalk(c.talk); else if (c.enter) TT.enterTuk(); return; }
    if (c.id === 'unclamp') { TT.unclamp(); return; }
    if (c.id === 'drop') { c.drop.forEach(deliver); }
    else if (c.id === 'pickup') { TT.UI.openOffer(c.st); }
    else if (c.id === 'refuel') TT.UI.openFuel(c.gs);
    else if (c.id === 'rest') TT.UI.openRest(c.rs);
    else if (c.id === 'shop') TT.UI.openRoadShop(c.sh);
  };
  TT.fuelPrice = () => G.L ? G.L.W.fuelPrice : 1;
  TT.JERRY = { size: 30, priceStation: 40, priceGarage: 50, emergency: 80 };
  TT.buyJerry = function (price) {
    if (Save.data.money < price) { toast(TT.t('مفيش فلوس كفاية!', 'Not enough money!'), 'bad'); return false; }
    Save.ledger(TT.t('جركن بنزين', 'Fuel can'), -price, 'fuel'); if (G.stats && G.mode === 'play') G.stats.fuel += price;
    Save.data.jerry = (Save.data.jerry || 0) + 1; TT.Audio.play('cash'); Save.write(); return true;
  };
  function updatePour(dt) {
    const P = G.pour; if (!P) return; const veh = Save.veh();
    P.t += dt; const k = Math.min(1, Math.max(0, (P.t - 0.5) / (P.dur - 0.8))), want = P.amt * k;
    veh.fuel += want - P.given; P.given = want; G.tuk.vx *= 0.9;
    if (P.t >= P.dur) { G.pour = null; toast(TT.t('🛢️ فضّيت الجركن في التانك ⛽', '🛢️ Fuel can poured ⛽'), 'good'); Save.write(); if (TT.UI.fuelEmpty) TT.UI.fuelEmpty(veh.fuel <= 0); }
  }
  TT.useJerry = function () {
    const veh = Save.veh(), vp = G.vp || vehParams();
    if (vp.human) return;
    if (!(Save.data.jerry > 0)) { toast(TT.t('معندكش جراكن — اشتري من البنزينة أو المرآب', 'No fuel cans — buy at a station or garage'), 'warn'); return; }
    if (G.tuk && Math.abs(G.tuk.vx) > 0.6) { toast(TT.t('اقف الأول عشان تفضّي الجركن', 'Stop first to pour the can'), 'warn'); return; }
    if (veh.fuel >= vp.tank - 1) { toast(TT.t('التانك مليان', 'Tank is full'), 'warn'); return; }
    if (G.pour) return;
    Save.data.jerry--; G.pour = { t: 0, dur: 2.2, amt: Math.min(vp.tank - veh.fuel, vp.tank * TT.JERRY.size / 100), given: 0 };
    TT.Audio.play('fuel'); setTimeout(() => TT.Audio.play('fuel'), 900); Save.write();
  };
  TT.refuel = function (frac) { refuel(frac); };
  function refuel(frac) {
    const veh = Save.veh(), want = frac ? G.vp.tank * frac : G.vp.tank, need = Math.max(0, Math.min(G.vp.tank, want) - veh.fuel);
    const price = G.L.W.fuelPrice;
    let liters = need, cost = Math.ceil(need * price);
    if (Save.data.money < cost) { liters = Math.max(0, Save.data.money / price); cost = Math.floor(liters * price); }
    if (cost <= 0) { toast(TT.t('مفيش فلوس كفاية للبنزين!', 'Not enough money for fuel!'), 'bad'); return; }
    veh.fuel += liters; Save.ledger(TT.t('تموين ', 'Fuel ') + TT.t(G.L.W.fuelName, 'refill'), -cost, 'fuel'); G.stats.fuel += cost;
    TT.Audio.play('fuel'); toast(TT.t('اتموّنت ب ', 'Refueled for ') + cost + TT.t(' جنيه', ' EGP'), 'good');
  }
  TT.emergencyFuel = function () {
    if (Save.data.jerry > 0) { const v = G.tuk.vx; G.tuk.vx = 0; TT.useJerry(); G.tuk.vx = v; return; }
    const veh = Save.veh(); const cost = TT.JERRY.emergency;
    Save.ledger(TT.t('حد جابلك جركن بنزين', 'Emergency fuel delivery'), -cost, 'fuel'); G.stats.fuel += cost;
    veh.fuel = Math.min(G.vp.tank, veh.fuel + 30); TT.Audio.play('fuel');
    toast(TT.t('واحد جابلك جركن بالموتوسيكل — دفعت ' + cost + ' جنيه', 'Someone brought a fuel can — paid ' + cost), 'warn');
  };
  TT.horn = function () {
    if (G.stats) G.stats.horns = (G.stats.horns || 0) + 1;
    const T = G.tuk; if (!G.L || G.driver || G.flip) return;
    TT.Audio.play(accOpts().musicHorn ? 'hornMusic' : 'horn'); T.honkT = 0.4;
    const now = G.time; T.honks = T.honks.filter(h => now - h < 5); T.honks.push(now);
    if (T.honks.length > 3) for (const p of G.riding) { p.sat -= 2; }
    const q = G.L.zones.quiet.find(z => T.x > z.a && T.x < z.b);
    if (q) violation('quietHorn', 'qh' + q.id + Math.floor(G.time / 20), TT.t('استخدمت الكلاكس جوه منطقة هادئة', 'Used horn in a quiet zone'));
    for (const v of G.traffic) {
      if (v.lane === 0 && v.x > T.x && v.x - T.x < 18 && (v.state === 'drive' || v.state === 'stopped')) {
        if (v.angryNpc) { v.angryNpc.mood += 8; say(v.angryNpc, TT.t('بتزمرلي كمان؟!', 'You honk at me?!')); continue; }
        if (v.jam && G.tuk.x > v.jam.a - 20 && G.tuk.x < v.jam.b) { if (Math.random() < 0.3) say({ x: v.x + v.len / 2, h: 2.2 }, pick(Math.random, ['هروح فين يعني؟!', 'الدنيا واقفة يا عم!', 'زمّر براحتك!']), 1.8); continue; }
        if (Math.random() < 0.55) { v.state = 'pullover'; v.pullT = 0; }
      }
      if (v.state === 'blocker') { const b = G.L.blockers.find(b => b.id === v.id); if (b && !b.resolved && v.x - T.x < 22) { b.honks = (b.honks || 0) + 1; say(b.npc, pick(Math.random, ['حاضر حاضر... دقيقة', 'ما تستنى شوية!', 'انت مستعجل على إيه؟'])); b.npc.mood += 6; if (b.honks >= 3 && Math.random() < (b.temper === 'coward' ? 0.7 : b.temper === 'calm' ? 0.45 : 0.18)) resolveBlocker(b); } }
    }
    for (const pd of G.peds) if (pd.state === 'cross' && Math.abs(pd.x - T.x) < 25) { pd.hurry = true; if (!pd.honked) { pd.honked = true; if (pd.human) say(pd, pick(Math.random, TT.LINES.honkPed), 1.8); } }
  };
  /* ---------- تعليقات السواق ---------- */
  function driverSay(kind, force) {
    const lines = TT.LINES.driver[kind]; if (!lines || !G.L) return;
    if (!force && G.time - (G.lastDriverLine || -99) < 7) return;
    G.lastDriverLine = G.time;
    const ent = G.driver ? { x: G.driver.x, h: 2.1 } : { x: G.tuk.x + 0.4, h: 2.3, isDriver: true };
    say(Object.assign(ent, { isDriver: true, follow: !G.driver }), pick(Math.random, lines), 2.6);
  }
  TT.driverSay = driverSay;

  /* ---------- حالة المركبة: دخان → سقف طاير → فرقعة ---------- */
  function updateHealth(dt) {
    const T = G.tuk, veh = Save.veh(), dm = veh.damage, kind = Save.model().kind || 'tuktuk';
    const worst = Math.max(dm.engine, dm.body);
    // السقف بيطير من كتر الخبطات
    if ((kind === 'tuktuk' || kind === 'microbus') && dm.body > 0.55 && !veh.roofOff) {
      veh.roofOff = true; G.roofFly = { x: T.x, y: T.y + 1.2, vx: T.vx + 2, vy: 6, rot: 0, t: 0 };
      TT.Audio.play('crash'); G.cam.shake = 10;
      for (const p of G.riding) { p.sat -= 20; p.scared = 6; say(p, pick(Math.random, TT.LINES.scared), 2.6); }
      toast(TT.t('💨 سقف المركبة طار من كتر الخبطات!', '💨 The roof flew off!'), 'bad', 3);
    }
    if (G.roofFly) { const R = G.roofFly; R.t += dt; R.x += R.vx * dt; R.y += R.vy * dt; R.vy -= 9.8 * dt; R.rot += dt * 5; if (R.t > 3) G.roofFly = null; }
    // دخان
    if (worst > 0.6 && !G.exploded && Math.random() < dt * (worst > 0.8 ? 14 : 6)) G.particles.push({ kind: 'smoke', x: (T.x + (geom().front - 0.6)) * PX, y: ROAD_Y - (T.y + 0.4) * PX, vx: -10 - T.vx * 6, vy: -30, r: 5, life: 1.8, max: 1.8, col: worst > 0.8 ? '#333' : '#777', a: 0.6, world: true, grow: 14 });
    if (worst > 0.6 && !G.smokeWarned) { G.smokeWarned = true; driverSay('smoke', true); toast(TT.t('⚠️ المركبة بتطلّع دخان — صلّحها في الورشة قبل ما تولّع', '⚠️ Smoking — repair before it blows up'), 'warn', 3.5); }
    if (worst > 0.82 && !G.critWarned) { G.critWarned = true; TT.Audio.play('whistle'); toast(TT.t('🔥 حالة حرجة! خبطة كمان والمركبة هتفرقع', '🔥 Critical! One more hit and it explodes'), 'bad', 3.5); }
    // بتفرقع بس لو الخبط حصل في المرحلة دي (مش من أول ما تبدأ)
    if (worst >= 0.95 && worst > G.dmgStart + 0.03 && G.time > 3 && !G.exploded && !G.flip) explode();
  }
  function explode() {
    const T = G.tuk; G.exploded = { t: 0 }; rec('explosions');
    TT.Audio.stopAll(); if (G.subOn) G.subOn = false; TT.Audio.play('boom'); G.cam.shake = 22; vibrate([200, 80, 300]);
    for (let i = 0; i < 40; i++) G.particles.push({ kind: i % 3 ? 'smoke' : 'fire', x: T.x * PX + (Math.random() - 0.5) * 60, y: ROAD_Y - (T.y + 0.3) * PX, vx: (Math.random() - 0.5) * 260, vy: -60 - Math.random() * 220, r: 6 + Math.random() * 10, life: 1.6, max: 1.6, col: i % 3 ? '#424242' : '#ff6d00', a: 0.85, world: true, grow: 20, g: 120 });
    for (const p of G.riding.slice()) passengerLeaves(p, 0, 'dizzy');
    T.vx = 0; T.engineOn = false; Save.veh().damage.engine = 1; Save.veh().damage.body = 1;
    toast(TT.t('💥 المركبة فرقعت! الرحلة خلصت', '💥 The vehicle blew up! Trip over'), 'bad', 4);
    setTimeout(() => { if (G.mode === 'play') endLevel(true); }, 2600);
  }

  /* ---------- تحدي إضافي لكل مرحلة (بيصعب شوية مع كل مستوى) + تذكير بالمهام ---------- */
  function setupChallenge(L) {
    G.ch = null; G.nagT = 75; if (G.free) return;
    const li = L.li, h = A.hash(L.wi * 131 + li * 17 + 3), vp = vehParams(), V = G.vendor;
    const coinsN = L.coins.length, pool = [];
    if (!V && L.required >= 1) pool.push('ontime');
    pool.push('nocrash', 'nospeed');
    if (coinsN >= 8) pool.push('coins');
    pool.push('time');
    if (!V && li >= 3) pool.push('rating');
    if (li >= 6) pool.push('condition');
    if (li >= 2) pool.push('quiet');
    const id = li === 0 ? 'coins' : pool[Math.floor(h * pool.length)];
    const k = Math.min(1, li / 40); let goal = 0, text = '', tip = '';
    if (id === 'ontime') { goal = Math.min(L.required, 1 + Math.floor(li / 8)); text = TT.t('وصّل ' + goal + ' ركاب في الميعاد ⏱️', 'Deliver ' + goal + ' riders on time'); tip = TT.t('بص على شريط الوقت جنب كل راكب، وروح لمحطته الأول. متقفش كتير.', 'Watch each rider\'s time bar and go to their stop first.'); }
    if (id === 'nocrash') { text = TT.t('خلّص من غير ولا حادثة (عربيات أو بهايم) 🛡️', 'Finish with zero crashes'); tip = TT.t('هدّي ورا العربيات واستنى الحيوانات تعدّي، وزمّر قبلها.', 'Slow down behind cars and let animals cross.'); }
    if (id === 'nospeed') { text = TT.t('ولا مخالفة سرعة طول المرحلة 🚦', 'No speeding tickets'); tip = TT.t('بص على علامة الحد فوق على الشمال، وهدّي قبل الرادار 📸.', 'Watch the limit sign and slow down before radars.'); }
    if (id === 'coins') { goal = Math.max(3, Math.min(40, Math.round(coinsN * (0.25 + 0.2 * k)))); text = TT.t('اجمع ' + goal + ' عملة 🪙', 'Collect ' + goal + ' coins'); tip = TT.t('العملات بتبقى فوق المطبات والطريق — عدّي عليها بسرعة مناسبة.', 'Coins sit over bumps and the road — drive through them.'); }
    if (id === 'time') { const stops = V ? 6 : L.required * 9; goal = Math.round((L.len / (vp.vmax * (0.62 + 0.12 * k)) + stops + 25) / 5) * 5; text = TT.t('خلّص المرحلة في أقل من ' + goal + ' ثانية ⏰', 'Finish within ' + goal + ' s'); tip = TT.t('استخدم الوضع الرياضي 🔥 ومتقفش غير في المحطات المهمة.', 'Use Sport mode and only stop where needed.'); }
    if (id === 'rating') { goal = 4; text = TT.t('متوسط تقييم الركاب 4 نجوم أو أكتر ⭐', 'Average rider rating 4+'); tip = TT.t('سوق بهدوء فوق المطبات، ووصّلهم في الميعاد، وردّ عليهم بلطف.', 'Drive smoothly, be on time and be polite.'); }
    if (id === 'condition') { goal = Math.round(85 - 15 * k); text = TT.t('خلّي حالة المركبة فوق ' + goal + '% لآخر الخط 🔧', 'Keep vehicle condition above ' + goal + '%'); tip = TT.t('هدّي قبل الحفر والمطبات — الخبط بيبوّظ التعليق والإطارات.', 'Slow down for potholes and bumps.'); }
    if (id === 'quiet') { goal = Math.max(2, 8 - Math.floor(li / 6)); text = TT.t('متزمّرش أكتر من ' + goal + ' مرات 🤫', 'Honk at most ' + goal + ' times'); tip = TT.t('الكلاكس بس لما حد قافل الطريق.', 'Only honk when someone blocks the road.'); }
    G.ch = { id, goal, text, tip, done: false, failed: false, prog: 0, bonus: 30 + li * 4, cond0: conditionPct() };
  }
  function updateChallenge(dt) {
    const C = G.ch, s = G.stats; if (!C) return;
    if (!C.done && !C.failed) {
      if (C.id === 'ontime') { C.prog = s.onTime || 0; if (C.prog >= C.goal) C.done = true; }
      if (C.id === 'coins') { C.prog = s.coins; if (C.prog >= C.goal) C.done = true; }
      if (C.id === 'nocrash' && (s.crashes || 0) > 0) C.failed = true;
      if (C.id === 'nospeed' && [...G.vkeys].some(k => /^(sp|rad|speed|vz)/.test(k))) C.failed = true;
      if (C.id === 'time') { C.prog = Math.floor(G.time); if (G.time > C.goal) C.failed = true; }
      if (C.id === 'condition') { C.prog = Math.round(conditionPct() * 100); if (C.prog < C.goal) C.failed = true; }
      if (C.id === 'quiet') { C.prog = s.horns || 0; if (C.prog > C.goal) C.failed = true; }
      if (C.done) { toast(TT.t('🎯 التحدي اتحقق! +' + C.bonus + ' ج في آخر المرحلة', '🎯 Challenge complete! +' + C.bonus + ' at the end'), 'good', 3); TT.Audio.play('coin'); }
      if (C.failed) toast(TT.t('🎯 التحدي ما اتحققش المرة دي — جرّب تاني', '🎯 Challenge failed this time'), 'warn', 2.6);
    }
    // تذكير لو فضلت وقت طويل والمهمة ما خلصتش
    G.nagT -= dt;
    if (G.nagT <= 0) {
      G.nagT = 60; const L = G.L, need = [];
      if (s.delivered < L.required) need.push(G.vendor ? TT.t('بيع ' + (L.required - s.delivered) + ' كمان', 'Sell ' + (L.required - s.delivered) + ' more') : TT.t('وصّل ' + (L.required - s.delivered) + ' ركاب كمان', 'Deliver ' + (L.required - s.delivered) + ' more riders'));
      if (C && !C.done && !C.failed && ['ontime', 'coins', 'rating'].includes(C.id)) need.push(C.text);
      if (need.length) TT.UI.nag(need);
    }
  }
  function challengeEnd(stats) {
    const C = G.ch; if (!C) return null;
    if (!C.done && !C.failed) {
      if (C.id === 'nocrash') C.done = !(stats.crashes > 0);
      if (C.id === 'nospeed' || C.id === 'quiet' || C.id === 'condition') C.done = true;
      if (C.id === 'time') C.done = G.time <= C.goal;
      if (C.id === 'rating') { const avg = stats.ratings.length ? stats.ratings.reduce((a, b) => a + b, 0) / stats.ratings.length : 0; C.done = avg >= C.goal; }
    }
    if (C.done) { Save.ledger(TT.t('مكافأة التحدي', 'Challenge bonus'), C.bonus, 'fare'); stats.income += C.bonus; }
    return C;
  }

  /* ---------- التليفون بيرن وانت سايق ---------- */
  function updatePhone(dt) {
    const T = G.tuk;
    // عصبية السواق: وش أحمر وشرار من راسه، والركاب يهدّوه
    if (G.anger > 0) {
      G.anger -= dt;
      if (Math.random() < dt * 14) G.particles.push({ kind: 'spark', x: (T.x + 0.45) * PX + (Math.random() - 0.5) * 14, y: ROAD_Y - (T.y + 1.55) * PX, vx: (Math.random() - 0.5) * 90, vy: -60 - Math.random() * 80, r: 2.2, life: 0.5, max: 0.5, col: Math.random() < 0.5 ? '#ffeb3b' : '#ff5722', world: true });
      if (Math.random() < dt * 3) G.particles.push({ kind: 'smoke', x: (T.x + 0.45) * PX, y: ROAD_Y - (T.y + 1.6) * PX, vx: (Math.random() - 0.5) * 20, vy: -40, r: 3, life: 0.9, max: 0.9, col: '#eeeeee', a: 0.6, world: true, grow: 8 });
      if (!G.calmSaid && G.riding.some(p => p.state === 'riding')) { G.calmSaid = true; const p = pick(Math.random, G.riding.filter(q => q.state === 'riding')); setTimeout(() => G.mode === 'play' && say(p, TT.calmLine(), 3.2, 'scared'), 900); for (const q of G.riding) q.sat -= 4; }
    } else G.calmSaid = false;
    const P = G.phone;
    if (!P) {
      G.phoneT -= dt;
      if (G.phoneT <= 0 && !G.driver && !G.fight && !G.race && T.occupied === 'driver' && Math.abs(T.vx) > 1) {
        const CL = TT.CALLERS.concat(G.ownerAt ? [] : [TT.OWNER]), tot = CL.reduce((a, c) => a + c.w, 0); let r = Math.random() * tot, c = CL[0]; for (const q of CL) { r -= q.w; if (r <= 0) { c = q; break; } }
        if (G.ownerMiss === 1 && !G.ownerAt && Math.random() < 0.6) c = TT.OWNER;
        G.phone = { c, state: 'ring', t: 0, rings: 0 }; G.phoneT = (G.ownerMiss ? 25 : 60) + Math.random() * (G.ownerMiss ? 20 : 60); TT.UI.phone(G.phone);
      }
      return;
    }
    P.t += dt;
    if (P.state === 'ring') { if (P.t - P.rings * 1.2 > 0) { P.rings++; TT.Audio.play('ring'); } if (P.t > 9) TT.phoneIgnore(true); }
    else if (P.state === 'talk') {
      const step = Math.floor(P.t / 2.6);
      if (step !== P.step && step < P.lines.length * 2) { P.step = step; const ln = P.lines[Math.floor(step / 2)], who = step % 2; P.cur = { who, text: ln[who] }; if (who === 1) say({ x: T.x + 0.4, h: 2.3, isDriver: true, follow: true }, '📱 ' + ln[1], 2.4, G.anger > 0 ? 'angry' : 'driver'); TT.UI.phone(P); }
      if (step >= P.lines.length * 2) { if (P.c.mechanic) { P.state = 'offer'; TT.UI.phone(P); } else TT.phoneHang(); }
    }
  }
  TT.phoneAnswer = function () {
    const P = G.phone; if (!P || P.state !== 'ring') return; const T = G.tuk;
    P.state = 'talk'; P.t = 0; P.step = -1;
    if (P.c.mechanic) { const mp = pick(Math.random, TT.MECH_PARTS); P.mp = mp; P.lines = [['ألو يا اسطى! أنا سيد', 'أيوه يا سيد… خير؟'], ['التوكتوك محتاج ' + mp.name + ' ضروري', 'تاني يا سيد؟! ما لسه مغيّرين!'], ['ده لو مغيّرتهوش هيسيبك في نص الطريق', 'يا ساتر… الفلوس بتطير طيران!']]; G.anger = 7; driverSay('engine', true); }
    else { P.lines = pick(Math.random, P.c.talks); if (P.c.annoy) G.anger = 4; }
    if (Math.abs(T.vx) > 1) {
      for (const p of G.riding) { if (p.state === 'riding') { p.sat -= 10; } }
      const p = G.riding.find(q => q.state === 'riding'); if (p) say(p, pick(Math.random, ['ركّز في الطريق يا اسطى!', 'اقفل التليفون الله يخليك', 'إحنا عاوزين نوصل بالسلامة!']), 2.8, 'angry');
      if (nearPolice(T.x) || G.L.checkpoints.some(c => Math.abs(c.x - T.x) < 60)) violation('phone', 'ph' + Math.round(G.time), TT.t('بتكلّم في الموبايل وانت سايق قدام المرور', 'Using the phone while driving near police'));
    }
    TT.UI.phone(P);
  };
  TT.phoneIgnore = function (timeout) { const P = G.phone; if (!P) return; G.phone = null; TT.UI.phone(null); if (P.c.id === 'owner') ownerMissed(); toast((timeout ? '📵 ' + TT.t('مكالمة فائتة من ', 'Missed call from ') : '🔕 ' + TT.t('تجاهلت ', 'Ignored ')) + TT.t(P.c.name, P.c.en), 'info', 2); if (P.c.id === 'wife' && !timeout) G.phoneT = Math.min(G.phoneT, 18); };
  TT.phoneHang = function () { const P = G.phone; G.phone = null; TT.UI.phone(null); if (P && P.c.id === 'mom') { Save.data.rep = clamp(Save.data.rep + 1, 0, 100); toast(TT.t('🤲 دعوة أمك فتحت نفسك للشغل (+سمعة)', '🤲 Mom\'s blessing (+rep)'), 'good', 2.4); } };
  TT.phoneMech = function (pay) {
    const P = G.phone; if (!P || !P.mp) return; const mp = P.mp;
    if (pay) { if (Save.data.money < mp.cost) { toast(TT.t('مفيش فلوس كفاية!', 'Not enough money!'), 'bad'); return; } Save.ledger(TT.t('سيد الميكانيكي: ', 'Mechanic: ') + mp.name, -mp.cost, 'repair'); G.stats.repairs += mp.cost; const dm = Save.veh().damage; dm[mp.part] = Math.max(0, dm[mp.part] - 0.5); toast(TT.t('🔧 سيد هيظبط ' + mp.name + ' — الحالة اتحسنت', '🔧 Sayed will fix it — condition improved'), 'good', 2.6); TT.Audio.play('cash'); }
    else { const dm = Save.veh().damage; dm[mp.part] = Math.min(1, dm[mp.part] + 0.08); toast(TT.t('⚠️ أجّلت التصليح… ' + mp.name + ' هيتعب أكتر', '⚠️ Postponed… it will get worse'), 'warn', 2.6); G.anger = Math.max(G.anger, 3); }
    G.phone = null; TT.UI.phone(null);
  };
  TT.forcePhone = id => { const c = id === 'owner' ? TT.OWNER : TT.CALLERS.find(q => q.id === id) || TT.CALLERS[0]; G.phone = { c, state: 'ring', t: 0, rings: 0 }; TT.UI.phone(G.phone); };

  /* ---------- دردشة بين الراكب والسواق ---------- */
  function updateBanter(dt) {
    const T = G.tuk; G.banterT = (G.banterT == null ? 9 : G.banterT) - dt;
    if (G.banter) { const B = G.banter; B.t -= dt; if (B.t <= 0 && !B.replied) { B.replied = true; say({ x: T.x + 0.4, h: 2.3, isDriver: true, follow: true }, B.pair[1], 3, 'driver'); } if (B.t < -3.2) G.banter = null; return; }
    if (G.banterT > 0 || G.activeChat || G.driver || G.fight) return;
    const ps = G.riding.filter(p => p.state === 'riding'); if (!ps.length || Math.abs(T.vx) < 1.5) return;
    const gr = ps.find(q => q.type === 'granny' && !q.quranAsked);
    if (gr) { gr.quranAsked = true; const pr = G.subOn ? ['اطفي الأغاني دي يا ابني وشغّل القرآن!', 'حاضر يا حاجة… أهو القرآن 📿'] : pick(Math.random, TT.GRANNY_QURAN); say(gr, pr[0], 3.2, 'neutral'); G.banter = { p: gr, pair: pr, t: 2.8 }; G.banterT = 14; if (G.subOn) { TT.toggleSub(); } G.quranT = 30; gr.sat = Math.min(100, gr.sat + 12); return; }
    const p = pick(Math.random, ps), mood = p.sat > 70 ? 'happy' : p.sat < 40 ? 'angry' : 'neutral', pair = pick(Math.random, TT.BANTER[mood]);
    say(p, pair[0], 3, mood); G.banter = { p, pair, t: 2.6 }; G.banterT = 16 + Math.random() * 14;
  }
  TT.calmLine = () => pick(Math.random, TT.BANTER.calm);

  /* =================== السواقة الحرة ===================
     رحلة طويلة بين البلاد (القاهرة ← الريف ← إسكندرية ← الصحرا ← الصعيد ← المدينة الحديثة ← ...)
     فيها ركاب وبنزينات واستراحات وورش، وتحديات سباق بفلوس */
  TT.FREE_ROUTE = ['streets', 'city', 'suez', 'hurghada', 'aswan', 'luxor', 'saeed', 'minya', 'fayoum', 'giza', 'desert', 'siwa', 'matrouh', 'alex', 'country', 'tanta', 'mansoura', 'damietta', 'portsaid', 'ismailia'];
  const freeWi = seg => TT.WORLDS.findIndex(W => W.id === TT.FREE_ROUTE[seg % TT.FREE_ROUTE.length]);
  function freeData() { const d = Save.data; d.free = d.free || { seg: 0, km: 0, streak: 0, best: 0, wins: 0, races: 0, bestEarn: 0, trip: null }; return d.free; }
  TT.freeData = freeData;
  function saveFree() { if (!G.free || !G.L) return; const F = freeData(); F.clock = G.env ? G.env.clock : 9; F.fatigue = G.fatigue || 0; F.pos = G.tuk.x; Save.write(); }
  TT.Game_startFree = function (newTrip) {
    const F = freeData(), d = Save.data;
    if (newTrip || !F.trip) { F.trip = { money0: d.money, km: 0, wins: 0, races: 0, segs: 0, startSeg: F.seg % TT.FREE_ROUTE.length }; F.fatigue = 0; F.clock = 6.5 + Math.random() * 3; }
    d.snapshot = null;
    startLevel(freeWi(F.seg), 30 + (F.seg % 20), false, { free: true, first: true, seed: F.seg });
    if (F.pos && !newTrip && F.pos < G.L.finish - 50) { G.tuk.x = F.pos; G.tuk.y = groundAt(G.L, F.pos) + geom().H0; G.cam.x = G.tuk.x; }
  };
  function nextFreeSegment() {
    const F = freeData(), T = G.tuk, v = T.vx, lights = T.lights, eng = T.engineOn;
    F.km += G.L.len / 1000; F.trip.km += G.L.len / 1000; F.trip.segs++; F.seg++; F.pos = 0;
    for (const p of G.riding.slice()) passengerLeaves(p, 0, 'late');
    saveFree();
    startLevel(freeWi(F.seg), 30 + (F.seg % 20), false, { free: true, seed: F.seg });
    G.tuk.vx = Math.min(v, 6); G.tuk.lights = lights; G.tuk.engineOn = eng;
    TT.Audio.play('coin');
  }
  function endFree(failed) {
    const F = freeData(), d = Save.data, tr = F.trip || { money0: d.money, km: 0, wins: 0, races: 0, segs: 0 };
    const km = tr.km + (G.tuk ? G.tuk.x / 1000 : 0), earned = d.money - tr.money0;
    F.bestEarn = Math.max(F.bestEarn || 0, earned); F.trip = null; F.pos = 0; F.fatigue = 0;
    G.mode = 'end'; G.subOn = false; TT.Audio.stopAll();
    Save.write();
    TT.UI.freeSummary({ failed, km, earned, wins: tr.wins, races: tr.races, segs: tr.segs, streak: F.streak, best: F.best });
  }
  TT.endFree = () => endFree(false);
  // ---- التعب ----
  function updateFatigue(dt) {
    const T = G.tuk, moving = Math.abs(T.vx) > 1 && T.occupied === 'driver';
    G.fatigue = clamp(G.fatigue + dt * (moving ? 0.085 : 0.01) * (G.env && G.env.dark > 0.35 ? 1.5 : 1), 0, 100);
    if (G.fatigue > 70 && !G.tiredWarned) { G.tiredWarned = true; driverSay('tired', true); toast(TT.t('😴 السواق تعبان — اقف في أقرب استراحة', '😴 You\'re tired — stop at the next rest area'), 'warn', 3.2); }
    if (G.fatigue < 50) G.tiredWarned = false;
    G.dozeT = Math.max(0, G.dozeT - dt);
    if (G.fatigue > 88 && moving && G.dozeT <= 0 && Math.random() < dt * 0.12) { G.dozeT = 0.9 + Math.random() * 0.8; toast(TT.t('😪 عينك غفلت! ريّح بسرعة', '😪 You dozed off! Rest now'), 'bad', 2); }
  }
  TT.rest = function (kind) {
    const prices = { tea: 10, meal: 35, sleep: 0 }, c = prices[kind];
    if (Save.data.money < c) { toast(TT.t('مفيش فلوس كفاية!', 'Not enough money!'), 'bad'); return false; }
    if (c) { Save.ledger(kind === 'tea' ? TT.t('شاي في الاستراحة', 'Tea at rest stop') : TT.t('أكلة في الاستراحة', 'Meal at rest stop'), -c, 'fuel'); G.stats.fuel += c; }
    if (kind === 'tea') G.fatigue = Math.max(0, G.fatigue - 45);
    if (kind === 'meal') { G.fatigue = 0; Save.data.rep = clamp(Save.data.rep + 1, 0, 100); }
    if (kind === 'sleep') { G.fatigue = 0; if (G.env) { G.env.clock += 3; if (G.env.clock >= 24) { G.env.clock -= 24; G.env.day++; } } }
    TT.Audio.play('cash'); Save.write(); return true;
  };
  // ---- السباقات ----
  const RIVALS = ['زيزو الطيارة', 'حمادة توربو', 'الكابتن شيكو', 'ميدو نيترو', 'سمسم البرق', 'عم صلاح الصاروخ', 'بيبو الفرملة', 'كوكو الإكسبريس'];
  const RIVAL_COL = [['#d50000', '#fff'], ['#2962ff', '#ffd600'], ['#00c853', '#111'], ['#ff6d00', '#111'], ['#aa00ff', '#fff'], ['#212121', '#ff1744']];
  TT.raceBets = () => { const k = (Save.model().kind || 'tuktuk'); const m = k === 'sport' ? 5 : k === 'microbus' ? 2 : k === 'bike' || k === 'skate' ? 0.5 : 1; return [100, 300, 1000].map(b => Math.round(b * m)); };
  function spawnRival(mode) {
    const T = G.tuk, kind = Save.model().kind || 'tuktuk', rk = kind === 'skate' ? 'bike' : kind, col = pick(Math.random, RIVAL_COL), F = freeData();
    const style = rk === 'sport' ? pick(Math.random, ['gt', 'super', 'hyper']) : undefined;
    const vmax = G.vp.vmax * (0.86 + 0.025 * Math.min(F.streak, 6) + Math.random() * 0.08) * (((TT.DRIVERS.find(x => x.id === Save.data.driver) || {}).perk || {}).race || 1);
    G.rival = { name: pick(Math.random, RIVALS), look: pick(Math.random, TT.NPC_LOOKS), kind: rk, color: col[0], trim: col[1], style, vmax, acc: G.vp.accel * 1.05, seed: Math.random() * 6,
      h: 2.0, x: mode === 'npc' ? T.x - 22 : T.x + 70, v: mode === 'npc' ? Math.max(T.vx, 0) + 5 : vmax * 0.45, state: mode === 'npc' ? 'approach' : 'cruise', initiator: mode, t: 0,
      bet: mode === 'npc' ? pick(Math.random, TT.raceBets()) : 0 };
  }
  TT.raceAccept = function (bet) {
    const R = G.rival; if (!R || R.state !== 'offer') return;
    bet = bet || R.bet; if (Save.data.money < bet) { toast(TT.t('فلوسك مش مكفية الرهان!', 'Not enough money for the bet!'), 'bad'); return; }
    const T = G.tuk, room = G.L.finish - T.x - 80; if (room < 450) { toast(TT.t('الطريق مش هيكفي سباق… استنى المدينة الجاية', 'Not enough road left — wait for the next town'), 'warn'); return; }
    R.bet = bet; Save.ledger(TT.t('رهان سباق مع ', 'Race bet vs ') + R.name, -bet, 'fine');
    const dist = Math.round(Math.min(room, Math.max(400, Math.min(1400, G.vp.vmax * (30 + Math.random() * 12)))) / 50) * 50;
    G.race = { R, bet, t: 0, count: 3.2, dist, startX: 0, finishX: 0, state: 'count' };
    R.state = 'count'; R.x = T.x - 0.3; R.v = Math.max(0, T.vx);
    TT.Audio.play('whistle'); driverSay('race', true); freeData().trip.races++; freeData().races++; Save.write();
  };
  TT.raceDecline = function () { const R = G.rival; if (!R) return; R.state = 'leave'; R.t = 0; say(R, pick(Math.random, ['جبان يا معلم 😏', 'خليها مرة تانية', 'خايف ولا إيه؟']), 2); G.raceCool = 30 + Math.random() * 30; };
  function finishRace(win) {
    const RC = G.race, R = RC.R, F = freeData(), d = Save.data;
    if (win) {
      F.streak++; F.best = Math.max(F.best, F.streak); F.wins++; F.trip.wins++;
      const prize = RC.bet + Math.round(RC.bet * (0.8 + 0.2 * Math.min(F.streak - 1, 10)));
      Save.ledger(TT.t('كسبت سباق ضد ', 'Won race vs ') + R.name + (F.streak > 1 ? ' (x' + F.streak + ')' : ''), prize, 'fare'); G.stats.income += prize - RC.bet;
      TT.Audio.play('cash'); G.celebrate = 4; burst(G.tuk.x, 2, '+' + prize + ' ج', '#ffd54f');
      toast(TT.t('🏆 كسبت السباق! +' + prize + ' ج' + (F.streak > 1 ? ' — سلسلة فوز ×' + F.streak : ''), '🏆 You won! +' + prize + (F.streak > 1 ? ' — streak ×' + F.streak : '')), 'good', 4);
      say(R, pick(Math.random, ['ماشي يا عم… المرة الجاية', 'إنت شيطان يا جدع!', 'العربية دي فيها إيه؟!']), 2.4);
    } else {
      F.streak = 0; G.stats.fines += RC.bet; TT.Audio.play('error');
      toast(TT.t('😞 خسرت السباق — راح الرهان ' + RC.bet + ' ج', '😞 You lost the race — bet lost'), 'bad', 3.5);
      say(R, pick(Math.random, ['هههه سلامات يا كابتن 😎', 'اتعلم السواقة الأول', 'باي باي!']), 2.4);
    }
    TT.UI.raceResult && TT.UI.raceResult(win, RC);
    R.state = 'leave'; R.t = 0; G.race = null; G.raceCool = 35 + Math.random() * 30; Save.write();
  }
  function updateRace(dt) {
    const T = G.tuk, L = G.L;
    if (!G.rival) {
      G.raceCool -= dt;
      if (G.raceCool <= 0 && L.finish - T.x > 700 && T.x > 60 && !G.driver && T.occupied === 'driver') { spawnRival(Math.random() < 0.55 ? 'npc' : 'cruise'); G.raceCool = 999; }
      return;
    }
    const R = G.rival, RC = G.race; R.t += dt;
    if (R.state === 'approach') { R.v = Math.max(T.vx, 0) + 9; if (R.x >= T.x - 1.5) { R.state = 'offer'; R.t = 0; say(R, TT.t('تتسابق يا معلم؟ 🏁', 'Wanna race? 🏁'), 3); TT.Audio.play('horn'); } }
    else if (R.state === 'cruise') { R.v += (R.vmax * 0.45 - R.v) * dt; if (Math.abs(R.x - T.x) < 10) { R.state = 'offer'; R.t = 0; } if (R.x < T.x - 60) { G.rival = null; G.raceCool = 20; return; } }
    else if (R.state === 'offer') { R.v += (Math.max(0, T.vx) - R.v) * Math.min(1, dt * 2); if (R.initiator === 'npc') R.x += (T.x - 1.5 - R.x) * Math.min(1, dt); if (R.t > 12) TT.raceDecline(); }
    else if (R.state === 'count') { R.v = Math.max(0, T.vx); R.x = T.x - 0.3; RC.count -= dt; if (RC.count <= 0) { RC.state = 'race'; RC.startX = T.x; RC.finishX = T.x + RC.dist; R.state = 'race'; TT.Audio.play('whistle'); } }
    else if (R.state === 'race') {
      const lead = R.x - T.x; let tgt = R.vmax * (0.92 + 0.08 * Math.sin(G.time * 0.7 + R.seed));
      if (lead > 35) tgt *= 0.9; if (lead < -35) tgt *= 1.07;
      R.v += clamp(tgt - R.v, -6 * dt, R.acc * dt);
      if (G.flip || G.exploded) finishRace(false);
      else if (T.x >= RC.finishX) finishRace(true);
      else if (R.x >= RC.finishX) finishRace(false);
    } else if (R.state === 'leave') { R.v += (R.vmax * 1.1 - R.v) * dt * 0.8; if (R.x - T.x > 90 || R.t > 12) { G.rival = null; G.raceCool = Math.max(G.raceCool, 30); return; } }
    R.x += R.v * dt;
  }
  TT.forceRival = mode => { G.raceCool = 0; G.rival = null; spawnRival(mode || 'npc'); };
  function drawRival(t) {
    const R = G.rival; if (!R) return; const g = TT.GEOM[R.kind] || TT.GEOM.tuktuk, gy = groundAt(G.L, R.x);
    const X = R.x * PX, Y = sy(gy + g.H0) - 16;
    ctx.save(); ctx.translate(X, Y); ctx.scale(0.94, 0.94);
    const wr = g.wheelR * PX, wy = (g.H0 - g.wheelR) * PX, rot = R.x / g.wheelR;
    A.wheel(ctx, g.rearX * PX, wy, wr, rot); A.wheel(ctx, g.frontX * PX, wy, wr, rot);
    const S2 = SEATS[R.kind] || SEATS.tuktuk;
    A.playerBody(ctx, R.kind, { color: R.color, trim: R.trim, style: R.style, t, inside: c => A.person(c, S2.drv[0], S2.drv[1], R.look, S2.drv[3], t, { scale: S2.drv[2], noShadow: true }) });
    if (R.kind !== 'sport' && R.kind !== 'microbus') A.raceDeco(ctx, R.kind, t);
    ctx.restore();
    const lbl = (R.state === 'race' ? '🏁 ' : R.state === 'offer' || R.state === 'cruise' ? '🏁❔ ' : '') + R.name;
    A.text(ctx, lbl, X, Y - (g.roof + 0.3) * PX, 12, R.state === 'race' ? '#ffeb3b' : '#fff', 'center', true, 3);
  }

  /* =================== مشاهد: مطاردة الشرطة، السجن، صاحب التوكتوك، الحادثة =================== */
  const OWNER_LOOK = { skin: '#8d5a3b', shirt: '#4e342e', pants: '#3e2723', hair: '#1b1b1b', mustache: true, belly: true, glasses: true };
  const OFFICER_LOOK = { skin: '#a8714a', shirt: '#1a237e', pants: '#1a237e', hair: '#111', cap: '#1a237e', mustache: true };
  function sayAt(x, h, line, dur, mood) { say({ x, h: h || 2.1 }, line, dur || 2.8, mood); }
  function driverX() { return G.driver ? G.driver.x : G.tuk.x + 0.4; }
  // ---- مطاردة: لو عدّيت الكمين من غير ما توقف ----
  function startChase(c) {
    if (G.chase || G.cine) return; const T = G.tuk;
    G.chase = { x: T.x - 50, v: Math.max(T.vx, 5), t: 0, sir: 0, c };
    toast(TT.t('🚓 عربية شرطة وراك! هتهرب ولا تقف؟', '🚓 Police are chasing you! Run or stop?'), 'radar', 3.5); TT.Audio.play('siren'); driverSay('police', true);
  }
  function updateChase(dt) {
    const C = G.chase; if (!C) return; const T = G.tuk;
    C.t += dt; C.sir -= dt; if (C.sir <= 0) { C.sir = 1.1; TT.Audio.play('siren'); }
    if (G.driver) { // نزل يجري
      C.v = Math.max(0, C.v - 10 * dt); C.x += C.v * dt;
      if (!C.cop && C.v < 0.5) { C.cop = { x: C.x + 4.5 }; sayAt(C.x + 4, 2.3, TT.t('استنى عندك يا ابني!', 'Stop right there!'), 2); }
      if (C.cop) { const dir = Math.sign(G.driver.x - C.cop.x); C.cop.x += dir * 7.2 * dt; if (Math.abs(G.driver.x - C.cop.x) < 0.8) caught(); }
      return;
    }
    const tgt = Math.max(G.vp.vmax * 1.18, 9);
    C.v = Math.min(tgt, C.v + 3.2 * dt); C.x += C.v * dt;
    if (C.t > 1.5 && Math.random() < dt * 0.3) sayAt(C.x + 3, 2.4, pick(Math.random, TT.LINES.cops), 1.8);
    if (C.x + 4.6 >= T.x - geom().back) { T.vx = Math.min(T.vx, C.v * 0.5); caught(); }
  }
  function caught() {
    const C = G.chase; if (!C) return;
    G.chase = null; G.tuk.vx = 0;
    startCine('jail', { reason: 'chase', fine: 600, carX: C.x, copX: C.cop ? C.cop.x : null });
  }
  TT.policeArrest = function (reason) { startCine('jail', { reason: reason || 'drugs', fine: 800, carX: G.tuk.x - 8 }); };
  // ---- صاحب التوكتوك ----
  TT.OWNER = { id: 'owner', name: 'الحاج عبده صاحب التوكتوك 😠', en: 'Hag Abdo, the tuk owner', icon: '🧔', bg: '#4e342e', imp: 3, w: 2,
    talks: [[['فين الإيراد يا ابني؟ النهارده آخر يوم!', 'حاضر يا حاج، بالليل هيبقى عندك'], ['ومتجيش متأخر زي امبارح', 'من عينيا يا حاج']], [['إنت مغيّر الزيت ولا لأ؟', 'غيّرته يا حاج والله'], ['التوكتوك ده أمانة معاك', 'في عينيا يا حاج عبده']]] };
  function ownerMissed() {
    G.ownerMiss = (G.ownerMiss || 0) + 1;
    if (G.ownerMiss === 1) toast(TT.t('⚠️ صاحب التوكتوك اتصل ومردّتش… لو تجاهلته تاني هيزعل', '⚠️ The owner called — ignore him again and he\'ll be angry'), 'warn', 3.4);
    if (G.ownerMiss >= 2 && !G.ownerAt) {
      const T = G.tuk, st = G.L.stations.find(s => s.x > T.x + 45) || null;
      G.ownerAt = st ? st.x + 4 : T.x + 70;
      toast(TT.t('😡 صاحب التوكتوك قفش منك — هتلاقيه مستنيك قدام!', '😡 The owner is furious — he\'s waiting ahead!'), 'bad', 3.6);
    }
  }
  function updateOwner() {
    const T = G.tuk; if (!G.ownerAt || G.cine) return;
    if (T.x > G.ownerAt - 16 && !G.driver) { T.vx = Math.min(T.vx, 3); }
    if (T.x > G.ownerAt - 9 && !G.driver) startCine('owner', {});
  }
  // ---- المشاهد ----
  function startCine(kind, data) {
    G.cine = Object.assign({ kind, t: 0, step: 0 }, data);
    G.phone = null; TT.UI.phone && TT.UI.phone(null); G.race = null; G.rival = null;
    if (G.subOn) TT.toggleSub();
    const T = G.tuk; T.vx = 0; T.throttle = 0; TT.Audio.engine(0, false);
    if (kind === 'owner') { G.cine.ox = G.ownerAt || T.x + 3; }
    if (kind === 'jail') { if (!G.driver) { G.driver = { x: T.x - 1.2, facing: -1, pose: 'walk', t: 0, vx: 0 }; T.occupied = 'empty'; T.engineOn = false; } }
  }
  function cineAt(C, time) { if (C.t >= time && C.step < time + 1000 && !C['s' + time]) { C['s' + time] = true; return true; } return false; }
  function updateCine(dt) {
    const C = G.cine, T = G.tuk; C.t += dt;
    if (C.kind === 'owner') {
      if (cineAt(C, 0.2)) { sayAt(C.ox, 2.3, TT.t('إنت فين يا ابني؟! مش بترد على التليفون ليه؟', 'Why aren\'t you answering your phone?!'), 2.6, 'angry'); }
      if (cineAt(C, 2.8)) { say({ x: T.x + 0.4, h: 2.3, isDriver: true, follow: true }, TT.t('والله يا حاج كنت سايق ومش سامع…', 'I swear I was driving and didn\'t hear…'), 2.4, 'scared'); }
      if (cineAt(C, 5.2)) {
        sayAt(C.ox, 2.3, TT.t('هات المفتاح! التوكتوك بتاعي ومش عاوزك تاني!', 'Give me the keys! You\'re done!'), 2.8, 'angry');
        for (const p of G.riding.slice()) passengerLeaves(p, 0, 'late');
        G.driver = { x: T.x - 1.6, facing: 1, pose: 'idle', t: 0, vx: 0 }; T.occupied = 'owner'; C.ownerIn = true; TT.Audio.play('pop');
      }
      if (C.t > 7.5) { C.v = Math.min(7, (C.v || 0) + 3 * dt); T.x += C.v * dt; T.y = groundAt(G.L, T.x) + geom().H0; T.a = 0; T.wheelRot = (T.wheelRot || 0) + C.v * dt / geom().wheelR; TT.Audio.engine(0.4, true); }
      if (cineAt(C, 8)) sayAt(G.driver.x, 2.1, TT.t('يا حاج استنى! طب أعمل إيه دلوقتي؟!', 'Wait! What do I do now?!'), 2.6, 'scared');
      if (cineAt(C, 11)) { TT.Audio.engine(0, false); G.driverPose = { name: 'apologize', t: 99 }; sayAt(G.driver.x, 2.1, TT.t('اتقطع عيشي… على الله التساهيل يا رب', 'There goes my living… God help me'), 3, 'scared'); }
      if (cineAt(C, 14.2)) { G.driverPose = { name: 'talk', t: 99 }; TT.Audio.play('ring'); sayAt(G.driver.x, 2.1, TT.t('📱 ألو… صوّتي يا حاجة! صاحب التكتك طردني 😭', '📱 Hello… cry for me, dear! The owner fired me 😭'), 3.6, 'scared'); }
      if (C.t > 18.2) { G.cine = null; G.failReason = 'owner'; G.ownerAt = null; endLevel(true); }
    }
    if (C.kind === 'jail') {
      const D = G.driver;
      if (C.carX == null) C.carX = T.x - 8;
      C.copX = C.copX == null ? C.carX + 4.5 : C.copX + Math.sign(D.x - 0.8 - C.copX) * Math.min(Math.abs(D.x - 0.8 - C.copX), 4 * dt);
      if (cineAt(C, 0.1)) { TT.Audio.play('siren'); sayAt(C.copX, 2.3, C.reason === 'drugs' ? TT.t('التحليل إيجابي… اتفضل معانا على البوكس!', 'Positive test… into the truck!') : TT.t('مسكناك! هتهرب مننا فين؟ على القسم!', 'Got you! Off to the station!'), 2.8, 'angry'); }
      if (cineAt(C, 2.2)) { G.driverPose = { name: 'apologize', t: 99 }; sayAt(D.x, 2.1, pick(Math.random, TT.LINES.jail), 2.6, 'scared'); }
      if (cineAt(C, 4.6)) { D.hidden = true; C.caged = true; TT.Audio.play('pop'); }
      if (C.t > 5) C.carX += Math.min(9, (C.t - 5) * 4) * dt;
      if (cineAt(C, 7.2)) { TT.UI.jailScene({ reason: C.reason, fine: C.fine }); }
    }
    if (C.kind === 'accidentPolice') { /* بيتعالج في updateAccidents */ }
    // كاميرا
    const fx = C.kind === 'owner' && C.t > 7.5 ? (G.driver ? G.driver.x + 2 : T.x) : C.kind === 'jail' ? (C.caged ? C.carX + 3 : G.driver.x) : T.x;
    G.cam.x = lerp(G.cam.x, fx, 1 - Math.exp(-dt * 3)); G.cam.z = lerp(G.cam.z, 1.08, 1 - Math.exp(-dt * 1.5)); G.cam.shake = Math.max(0, G.cam.shake - dt * 30);
  }
  TT.jailPay = function (fine) { Save.ledger(TT.t('غرامة القسم والإفراج', 'Police station fine & release'), -fine, 'fine'); G.stats.fines += fine; Save.data.record = Save.data.record || {}; Save.data.record.jail = (Save.data.record.jail || 0) + 1; Save.data.rep = clamp(Save.data.rep - 10, 0, 100); G.cine = null; G.failReason = 'jail'; for (const p of G.riding.slice()) passengerLeaves(p, 0, 'late'); endLevel(true); };
  // ---- الحادثة اللي قافلة الطريق ----
  function updateAccidents(dt) {
    const L = G.L, T = G.tuk;
    for (const a of L.accidents || []) {
      if (!a.spawned && T.x > a.x - 160 && T.x < a.x - 30) {
        a.spawned = true; const r = G.trafficSeed;
        a.car = { id: 'acc' + a.id, type: 'car', x: a.x, v: 0, len: A.VEH.car.len, color: pick(r, A.VEH.car.col), state: 'crashed', lane: 0, laneT: 0, wr: 0 };
        G.traffic = G.traffic.filter(v => !(v.x > T.x + 5 && v.x < a.x + 10)); G.traffic.push(a.car);
        for (let i = 0, x = a.x - 2.5; i < 4 && x > T.x + 30; i++) { const type = pick(r, L.W.vehicles.filter(v => v !== 'bus')); x -= A.VEH[type].len + 2; G.traffic.push({ id: 'aq' + i + a.id, type, x, v: 0, vt: 4, len: A.VEH[type].len, color: pick(r, A.VEH[type].col), state: 'drive', lane: 0, laneT: 0, wr: 0, accQ: a }); }
        a.hurt = { x: a.x + a.car.len + 1.6, look: pick(r, TT.NPC_LOOKS), up: 0 }; a.drv = { x: a.x + a.car.len + 3.4, look: pick(r, TT.NPC_LOOKS) };
        addCrowd(a.x + a.car.len + 2.4, 4);
        toast(TT.t('🚨 حادثة قدام والطريق واقف! انزل شوف إيه اللي حصل', '🚨 Accident ahead — traffic stopped! Go and see'), 'radar', 4); driverSay('jam', true);
      }
      if (a.state === 'police') { a.pt += dt; if (!a.pcar) a.pcar = { x: T.x - 40 }; a.pcar.x = Math.min(a.pcar.x + 12 * dt, a.x - 0.5); if (a.pcar.x >= a.x - 0.6 && !a.pSaid) { a.pSaid = true; sayAt(a.x + 2, 2.4, TT.t('وسّعوا يا جماعة… الإسعاف جاي والعربية هتتسحب', 'Clear the way — ambulance coming'), 2.6); } if (a.pt > 6) resolveAccident(a); }
      if (a.state === 'calm') { a.pt += dt; if (a.pt > 2.6) resolveAccident(a); }
      if (a.state === 'done') { if (a.hurt) { a.hurt.up = Math.min(1, a.hurt.up + dt); a.hurt.x += a.hurt.up >= 1 ? 1.2 * dt : 0; } if (a.pcar) a.pcar.x += 10 * dt; }
    }
  }
  function resolveAccident(a) {
    a.state = 'done'; if (a.car) { a.car.state = 'leaving'; a.car.leaveT = 0; a.car.v = 2; }
    for (const v of G.traffic) if (v.accQ === a) v.accQ = null;
    dispersCrowd(); Save.data.rep = clamp(Save.data.rep + (a.how === 'calm' ? 5 : 3), 0, 100);
    toast(TT.t('✅ الطريق اتفتح والمرور ماشي تمام — +سمعة', '✅ Road cleared — traffic moving (+rep)'), 'good', 3);
  }
  TT.accidentAct = function (a, how) {
    if (a.state !== 'active') return;
    if (how === 'police') { a.state = 'police'; a.how = how; a.pt = 0; TT.Audio.play('siren'); toast(TT.t('📞 كلّمت البوليس — جايين حالًا', '📞 Called the police — on their way'), 'info', 2.5); }
    if (how === 'calm') { if (Save.data.money < 100) { toast(TT.t('محتاج 100 ج عشان تدفع للمصاب يروح المستشفى', 'Need 100 EGP for the injured man'), 'bad'); return false; } Save.ledger(TT.t('ساعدت مصاب في حادثة', 'Helped an accident victim'), -100, 'repair'); a.state = 'calm'; a.how = how; a.pt = 0; sayAt(a.drv.x, 2.2, TT.t('خلاص يا جماعة اتصالحنا، هوصّله المستشفى بنفسي', 'Okay, we settled it — I\'ll take him to hospital'), 2.6); }
    return true;
  }
  function drawCine(t) {
    const L = G.L;
    const gy = x => sy(groundAt(L, x));
    if (G.chase) { const C = G.chase; A.vehicle(ctx, 'police', C.x * PX, gy(C.x), { t, wr: C.x * 3 }); if (Math.sin(t * 14) > 0) { ctx.fillStyle = 'rgba(255,40,40,.35)'; ctx.beginPath(); ctx.arc((C.x + 2.2) * PX, gy(C.x) - 70, 30, 0, 7); ctx.fill(); } else { ctx.fillStyle = 'rgba(40,120,255,.35)'; ctx.beginPath(); ctx.arc((C.x + 2.2) * PX, gy(C.x) - 70, 30, 0, 7); ctx.fill(); } if (C.cop) A.person(ctx, C.cop.x * PX, gy(C.cop.x) + 2, OFFICER_LOOK, 'run', t * 1.5, {}); }
    if (G.ownerAt && !G.cine) { A.person(ctx, G.ownerAt * PX, gy(G.ownerAt) + 2, OWNER_LOOK, 'angry', t, {}); A.text(ctx, TT.t('😠 صاحب التوكتوك', '😠 Tuk owner'), G.ownerAt * PX, gy(G.ownerAt) - 120, 12, '#ff8a80', 'center', true, 3); }
    const C = G.cine;
    if (C && C.kind === 'owner' && !C.ownerIn) A.person(ctx, C.ox * PX, gy(C.ox) + 2, OWNER_LOOK, C.t < 5 ? 'argue' : 'point', t, {});
    if (C && C.kind === 'jail') { A.vehicle(ctx, 'box', C.carX * PX, gy(C.carX) + 2, { t, wr: C.carX * 3, inCage: C.caged ? (c => A.person(c, 60, -62, TT.driverLook(), 'apologize', t, { scale: 0.75, noShadow: true })) : null }); if (!C.caged) A.person(ctx, C.copX * PX, gy(C.copX) + 2, OFFICER_LOOK, 'point', t, {}); }
    for (const a of L.accidents || []) {
      if (!a.spawned) continue;
      if (a.hurt && a.state !== 'done') { A.person(ctx, a.hurt.x * PX, gy(a.hurt.x) + 4, a.hurt.look, 'fallen', t, {}); }
      else if (a.hurt) A.person(ctx, a.hurt.x * PX, gy(a.hurt.x) + 2, a.hurt.look, a.hurt.up >= 1 ? 'walk' : 'idle', t, {});
      if (a.drv && a.state !== 'done') A.person(ctx, a.drv.x * PX, gy(a.drv.x) + 2, a.drv.look, a.state === 'active' ? 'argue' : 'talk', t, {});
      if (a.state === 'active') A.text(ctx, '🚨 ' + TT.t('حادثة', 'Accident'), (a.x + 3) * PX, gy(a.x) - 130, 13, '#ff5252', 'center', true, 3);
      if (a.pcar) A.vehicle(ctx, 'police', (a.pcar.x - 5) * PX, gy(a.pcar.x) - 18, { t, wr: a.pcar.x * 3 });
    }
  }

  /* =================== الوقت والطقس (في كل الأوضاع) ===================
     الساعة بتمشي: صباحًا → ظهرًا → عصرًا → مغرب → عشاء/ليل. الطقس: صافي / غيم / مطر / عاصفة رعدية
     بالليل والمطر لازم الكشافات، والمطر بيقلل التماسك والفرامل */
  const SKY_KEYS = [ // ساعة، سما فوق، سما تحت، ضلمة
    [0, '#050816', '#141c36', 0.62], [4.6, '#0a0f26', '#1d2645', 0.6], [5.6, '#3a4a7c', '#f2a46b', 0.3], [7, '#79aee0', '#ffe1b0', 0.05],
    [8.5, null, null, 0], [15.8, null, null, 0], [17, '#7fa5d0', '#ffd38a', 0.06], [18.2, '#36406e', '#ff7a45', 0.26],
    [19.2, '#151a38', '#3b3560', 0.48], [20.4, '#060a1c', '#151d38', 0.62], [24, '#050816', '#141c36', 0.62]];
  const RAIN_CHANCE = { streets: 0.28, country: 0.3, alex: 0.5, desert: 0.05, saeed: 0.08, city: 0.28, mars: 0 };
  TT.PHASES = [[5, 11, '🌅', 'الصبح', 'Morning'], [11, 14, '☀️', 'الضهر', 'Noon'], [14, 17, '🌤️', 'العصر', 'Afternoon'], [17, 19, '🌇', 'المغرب', 'Sunset'], [19, 29, '🌙', 'العشا', 'Night']];
  TT.phaseOf = h => { h = ((h % 24) + 24) % 24; const hh = h < 5 ? h + 24 : h; return TT.PHASES.find(p => hh >= p[0] && hh < p[1]) || TT.PHASES[4]; };
  const hx = c => [parseInt(c.slice(1, 3), 16), parseInt(c.slice(3, 5), 16), parseInt(c.slice(5, 7), 16)];
  const mix = (a, b, k) => { const A1 = hx(a), B1 = hx(b); return 'rgb(' + A1.map((v, i) => Math.round(v + (B1[i] - v) * k)).join(',') + ')'; };
  function skyAt(h, pal) {
    h = ((h % 24) + 24) % 24; let i = 0; while (i < SKY_KEYS.length - 2 && SKY_KEYS[i + 1][0] <= h) i++;
    const a = SKY_KEYS[i], b = SKY_KEYS[i + 1], k = (h - a[0]) / (b[0] - a[0]);
    const top = mix(a[1] || pal.sky[0], b[1] || pal.sky[0], k), bot = mix(a[2] || pal.sky[1], b[2] || pal.sky[1], k);
    return { top, bot, dark: a[3] + (b[3] - a[3]) * k };
  }
  function initEnv(L, resume) {
    const free = G.free, prev = G.env;
    const winter = [11, 12, 1, 2, 3].includes(new Date().getMonth() + 1);
    let clock;
    if (free && prev) clock = prev.clock;
    else if (free && Save.data.free && Save.data.free.clock != null) clock = Save.data.free.clock;
    else { const opts = [7.5, 9, 12, 15.5, 17.8, 20.5, 22]; clock = L.li < 2 ? 9 : opts[Math.floor(A.hash(L.wi * 97 + L.li * 13) * opts.length)]; }
    G.env = { clock, day: prev && free ? prev.day : 0, winter, rainChance: (RAIN_CHANCE[L.W.theme] || 0) * (winter ? 1.8 : 1),
      weather: prev && free ? prev.weather : 'clear', rain: prev && free ? prev.rain : 0, target: prev && free ? prev.target : 0, cloud: prev && free ? prev.cloud : 0,
      wet: prev && free ? prev.wet : 0, nextT: 8 + Math.random() * 20, flash: 0, thunderT: 0, drops: [], lastPhase: null, dark: 0 };
    const STw = Save.data.settings || {}, TIMES = { morning: 8, noon: 12.5, afternoon: 15.5, sunset: 17.9, night: 21.5 };
    if (!(free && prev) && TIMES[STw.timeOfDay]) G.env.clock = TIMES[STw.timeOfDay];
    if (STw.weather && STw.weather !== 'auto') { G.env.locked = true; setWeather(STw.weather, true); }
    else if (!free && Math.random() < G.env.rainChance * 0.6) setWeather(Math.random() < 0.3 ? 'storm' : 'rain', true);
  }
  function setWeather(kind, instant) {
    const E = G.env; if (G.L.W.theme === 'mars' && kind !== 'clear') kind = 'cloudy';
    E.weather = kind; E.target = kind === 'storm' ? 1 : kind === 'rain' ? 0.6 : 0; E.cloudT = kind === 'clear' ? 0 : kind === 'cloudy' ? 0.45 : kind === 'fog' ? 0.3 : kind === 'rain' ? 0.75 : 1; E.fogT = kind === 'fog' ? 0.75 : 0;
    if (instant) { E.rain = E.target; E.cloud = E.cloudT; E.fog = E.fogT; E.wet = E.target ? 0.8 : 0; }
    if (!instant && kind === 'fog') toast(TT.t('🌫️ شبورة! شغّل الكشافات وهدّي', '🌫️ Fog! Lights on and slow down'), 'warn', 3);
    if (!instant) { if (kind === 'rain' || kind === 'storm') driverSay('rain', true); if (kind === 'rain') toast(TT.t('🌧️ الدنيا بتمطر — هدّي السرعة، الطريق بيزحلق', '🌧️ It\'s raining — slow down, the road is slippery'), 'warn', 3); if (kind === 'storm') toast(TT.t('⛈️ عاصفة رعدية! شغّل الكشافات وخلّي بالك', '⛈️ Thunderstorm! Lights on and take care'), 'warn', 3.2); if (kind === 'clear' && E.wasRain) toast(TT.t('🌤️ المطر وقف', '🌤️ The rain stopped'), 'good', 2); }
    E.wasRain = kind === 'rain' || kind === 'storm';
  }
  TT.setWeather = (k) => setWeather(k, true);
  TT.setClock = h => { if (G.env) G.env.clock = h; };
  function updateEnv(dt) {
    const E = G.env; if (!E) return;
    const rate = G.free ? 1 / 30 : 1 / 45; // ساعة لعبة كل 30/45 ثانية
    E.clock += dt * rate; if (E.clock >= 24) { E.clock -= 24; E.day++; }
    const sk = skyAt(E.clock, A.PAL[G.L.W.theme]); E.sky = sk;
    E.rain += (E.target - E.rain) * Math.min(1, dt * 0.25); E.fog = (E.fog || 0) + ((E.fogT || 0) - (E.fog || 0)) * Math.min(1, dt * 0.2); E.cloud += ((E.cloudT || 0) - E.cloud) * Math.min(1, dt * 0.25);
    E.wet = clamp(E.wet + (E.rain > 0.1 ? dt * 0.08 : -dt * 0.02), 0, 1);
    E.dark = clamp(sk.dark + E.cloud * 0.18, 0, 0.7);
    // تغيير الطقس
    E.nextT -= dt;
    if (E.nextT <= 0 && !E.locked) {
      E.nextT = 35 + Math.random() * 55; const r = Math.random(), ch = E.rainChance;
      setWeather(E.weather === 'storm' ? (r < 0.6 ? 'rain' : 'cloudy') : r < ch * 0.35 ? 'storm' : r < ch ? 'rain' : r < ch + 0.12 ? 'fog' : r < ch + 0.3 ? 'cloudy' : 'clear');
    }
    // برق ورعد
    E.flash = Math.max(0, E.flash - dt * 3);
    if (E.weather === 'storm' && E.rain > 0.5 && Math.random() < dt * 0.12) { E.flash = 1; E.thunderT = 0.4 + Math.random() * 1.2; }
    if (E.thunderT > 0) { E.thunderT -= dt; if (E.thunderT <= 0) { TT.Audio.play('thunder'); G.cam.shake = Math.max(G.cam.shake, 4); if (!G.driver && G.mode === 'play') setTimeout(() => { if (G.mode === 'play') say({ x: G.tuk.x + 0.4, h: 2.3, isDriver: true, follow: true }, pick(Math.random, TT.LINES.driver.thunder), 3.4, 'driver'); }, 500); } }
    TT.Audio.rain && TT.Audio.rain(G.paused ? 0 : E.rain);
    // إعلان الفترة
    const ph = TT.phaseOf(E.clock);
    if (E.lastPhase && E.lastPhase !== ph[3]) { toast(ph[2] + ' ' + TT.t('دخلنا على ' + ph[3], ph[4] + ' now'), 'info', 2.4); if (ph[3] === 'المغرب' || ph[3] === 'العشا') driverSay('night', true); }
    E.lastPhase = ph[3];
  }
  function drawEnv(ctx, VW, VH, pivotX, camPx, z, inTunnel) {
    const E = G.env; if (!E) return; const T = G.tuk, q = Save.data.settings.quality, t = G.time;
    const sxT = pivotX + (T.x * PX - camPx) * z, syT = ROAD_Y - (T.y + 0.5) * PX * z;
    const on = T.lights && !G.driver, hx = sxT + 55 * z, hy = syT + 10 * z, LM = T.lightMode || 'low';
    // ---- الليل: ضلمة خفيفة، والتوكتوك نفسه دايمًا منوّر وباين ----
    const dk = Math.min(0.48, E.dark * 0.78);
    if (dk > 0.02 && !inTunnel) {
      const R = 110 * z, grd = ctx.createRadialGradient(sxT, syT, R * 0.55, sxT, syT, Math.max(VW, VH));
      grd.addColorStop(0, 'rgba(8,14,40,0)'); grd.addColorStop(0.18, 'rgba(8,14,40,' + dk * 0.55 + ')'); grd.addColorStop(1, 'rgba(8,14,40,' + dk + ')');
      ctx.fillStyle = grd; ctx.fillRect(0, 0, VW, VH);
      // نور الشارع
      if (E.dark > 0.3 && G.L.W.theme !== 'desert' && G.L.W.theme !== 'mars') for (let i = 0; i < 6; i++) { const lx = ((i * 260 - camPx * z) % (VW + 260) + VW + 260) % (VW + 260) - 130; const g2 = ctx.createRadialGradient(lx, ROAD_Y - 60, 4, lx, ROAD_Y - 40, 130); g2.addColorStop(0, 'rgba(255,214,120,' + 0.28 * E.dark + ')'); g2.addColorStop(1, 'rgba(255,214,120,0)'); ctx.fillStyle = g2; ctx.fillRect(lx - 140, ROAD_Y - 200, 280, 280); }
    }
    // ---- شبورة ----
    const fog = (E.fog || 0) * (on ? (LM === 'fog' ? 0.5 : LM === 'high' ? 1.15 : 0.9) : 1);
    if (fog > 0.02) {
      const fg = ctx.createRadialGradient(sxT, syT, 70 * z, sxT, syT, VW * 0.9);
      fg.addColorStop(0, 'rgba(225,230,238,0)'); fg.addColorStop(0.35, 'rgba(225,230,238,' + fog * 0.45 + ')'); fg.addColorStop(1, 'rgba(225,230,238,' + fog * 0.8 + ')');
      ctx.fillStyle = fg; ctx.fillRect(0, 0, VW, VH);
      if (q !== 'low') for (let i = 0; i < 5; i++) { const fx = ((i * 330 - camPx * z * 0.6 + t * 12) % (VW + 400) + VW + 400) % (VW + 400) - 200, fy = ROAD_Y - 60 + (i % 3) * 30; ctx.fillStyle = 'rgba(240,243,248,' + fog * 0.18 + ')'; ctx.beginPath(); ctx.ellipse(fx, fy, 180, 26, 0, 0, 7); ctx.fill(); }
    }
    // ---- كشافات قدام التوكتوك (بالليل وفي الشبورة والمطر) ----
    const glow = Math.max(dk * 2, fog * 1.3, (E.rain || 0) * 0.6);
    if (on && glow > 0.05) {
      const k2 = Math.min(1, glow), lr = (300 + 40 * G.vp.lights) * z * (LM === 'high' ? 1.55 : LM === 'fog' ? 0.6 : 0.85), C = LM === 'fog' ? '255,215,90,' : LM === 'high' ? '235,245,255,' : '255,240,180,', spread = LM === 'fog' ? 1.7 : LM === 'high' ? 0.8 : 1;
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      const beam = ctx.createLinearGradient(hx, 0, hx + lr, 0);
      beam.addColorStop(0, 'rgba(' + C + 0.42 * k2 + ')'); beam.addColorStop(0.5, 'rgba(' + C + (LM === 'high' ? 0.22 : 0.16) * k2 + ')'); beam.addColorStop(1, 'rgba(' + C + '0)');
      ctx.fillStyle = beam; ctx.beginPath(); ctx.moveTo(hx, hy - 6 * z); ctx.lineTo(hx + lr, hy - lr * 0.24 * spread * (LM === 'high' ? 1.3 : 1)); ctx.lineTo(hx + lr, hy + lr * 0.2 * spread); ctx.lineTo(hx, hy + 4 * z); ctx.closePath(); ctx.fill();
      const pool = ctx.createRadialGradient(hx + lr * 0.45, hy + 30 * z, 4, hx + lr * 0.45, hy + 30 * z, lr * 0.45); pool.addColorStop(0, 'rgba(255,240,190,' + 0.2 * k2 + ')'); pool.addColorStop(1, 'rgba(255,240,190,0)'); ctx.fillStyle = pool; ctx.fillRect(hx, hy - lr * 0.4, lr, lr * 0.8);
      const bulb = ctx.createRadialGradient(hx, hy, 1, hx, hy, 16 * z); bulb.addColorStop(0, 'rgba(255,255,230,' + 0.9 * k2 + ')'); bulb.addColorStop(1, 'rgba(255,255,230,0)'); ctx.fillStyle = bulb; ctx.fillRect(hx - 30 * z, hy - 30 * z, 60 * z, 60 * z);
      // نور خلفي أحمر
      const tl = ctx.createRadialGradient(sxT - 70 * z, hy - 8 * z, 1, sxT - 70 * z, hy - 8 * z, 22 * z); tl.addColorStop(0, 'rgba(255,40,40,' + 0.6 * k2 + ')'); tl.addColorStop(1, 'rgba(255,40,40,0)'); ctx.fillStyle = tl; ctx.fillRect(sxT - 95 * z, hy - 32 * z, 50 * z, 50 * z);
      ctx.restore();
    }
    // غيم خفيف
    if (E.cloud > 0.05) { ctx.fillStyle = 'rgba(70,80,95,' + E.cloud * 0.08 + ')'; ctx.fillRect(0, 0, VW, VH); }
    // ---- مطر كرتوني: نقط صغيرة وقليلة ومش بتحجب الرؤية ----
    if (E.rain > 0.03) {
      const n = Math.round((q === 'low' ? 26 : 55) * E.rain), slant = 0.18 + Math.min(0.35, Math.abs(T.vx) * 0.02);
      ctx.save(); ctx.fillStyle = 'rgba(170,215,255,.75)'; ctx.strokeStyle = 'rgba(255,255,255,.55)'; ctx.lineWidth = 0.8;
      for (let i = 0; i < n; i++) {
        const sp = 380 + A.hash(i * 3) * 160, x = (A.hash(i) * (VW + 100) - (t * sp * slant + camPx * 0.3) % (VW + 100) + (VW + 100) * 2) % (VW + 100) - 50, y = (A.hash(i * 7) * VH + t * sp) % (VH + 20) - 10;
        if (Math.abs(x - sxT) < 75 * z && Math.abs(y - syT) < 55 * z) continue; // متغطّيش التوكتوك
        const s2 = 2.8 + A.hash(i * 5) * 1.6; ctx.beginPath(); ctx.moveTo(x, y - s2 * 2.2); ctx.quadraticCurveTo(x + s2, y, x, y + s2); ctx.quadraticCurveTo(x - s2, y, x, y - s2 * 2.2); ctx.fill(); ctx.stroke();
      }
      // رشّ صغير على الطريق
      for (let i = 0; i < n / 5; i++) { const x = A.hash(i * 11 + Math.floor(t * 4)) * VW, y = ROAD_Y + 8 + A.hash(i * 13) * 36, ph = (t * 4 + A.hash(i)) % 1; ctx.strokeStyle = 'rgba(220,235,255,' + (1 - ph) * 0.6 + ')'; ctx.beginPath(); ctx.ellipse(x, y, 2 + ph * 7, 1 + ph * 2, 0, 0, 7); ctx.stroke(); }
      ctx.restore();
    }
    if (E.wet > 0.2) { ctx.fillStyle = 'rgba(150,180,220,' + E.wet * 0.05 + ')'; ctx.fillRect(0, ROAD_Y - 30, VW, 80); }
    if (E.flash > 0) { ctx.fillStyle = 'rgba(235,240,255,' + E.flash * 0.5 + ')'; ctx.fillRect(0, 0, VW, VH); }
  }


  /* ---------- تنبيه الرادار ---------- */
  function radarWarn() {
    const T = G.tuk;
    for (const r of G.L.radars) { const d = r.x - T.x; if (d > 0 && d < 160 && !r.warned) { r.warned = true; TT.Audio.play('beep'); toast(TT.t('📸 رادار بعد ' + Math.round(d) + ' م — الحد ' + r.limit + ' كم/س', '📸 Speed camera in ' + Math.round(d) + ' m — limit ' + r.limit), 'radar', 3); if (kmh(T.vx) > r.limit) driverSay('radar', true); G.radarAhead = r; } if (d < -5) r.warned = r.warned && d > -200; }
    G.radarAhead = G.L.radars.find(r => r.x - T.x > 0 && r.x - T.x < 160) || null;
  }

  function updateDriverChatter(dt) {
    const T = G.tuk; G.chatterT = (G.chatterT == null ? 20 : G.chatterT) - dt;
    if (G.chatterT <= 0) { G.chatterT = 25 + Math.random() * 25; const inJam = G.traffic.some(v => v.jam && Math.abs(v.x - T.x) < 15); driverSay(inJam ? 'jam' : (Save.veh().fuel / G.vp.tank < 0.25 && !G.vp.human) ? 'lowFuel' : 'idle'); }
  }

  /* ---------- دورية متحركة ---------- */
  function updatePatrol() {
    const L = G.L, T = G.tuk;
    if (L.patrolAt && !L.patrolSpawned && T.x > L.patrolAt - 70) {
      L.patrolSpawned = true;
      const px = T.x + 55;
      L.checkpoints.push({ id: 'patrol', x: px, state: 'closed', stopT: 0, done: false, patrol: true });
      L.flats.push(px); L.flats.sort((a, b) => a - b);
      toast(TT.t('🚓 دورية مرور قدامك — اقف على جنب!', '🚓 Police patrol ahead — pull over!'), 'radar', 3.5); TT.Audio.play('siren'); driverSay('police', true);
    }
  }

  /* ---------- مفتاح التشغيل ---------- */
  TT.ignition = function () {
    const T = G.tuk; if (!G.L || G.driver || G.flip || G.vp && G.vp.human) return;
    if (T.engineOn) { T.engineOn = false; TT.Audio.play('click'); toast(TT.t('🔑 قفلت المحرك', '🔑 Engine off'), 'warn', 1.4); return; }
    if (T.cranking) return;
    if (Save.veh().fuel <= 0) { TT.Audio.play('error'); toast(TT.t('مفيش بنزين يدور!', 'No fuel to start!'), 'bad'); return; }
    T.cranking = true; TT.Audio.play('crank');
    const bad = Save.veh().damage.engine > 0.7 && Math.random() < 0.5;
    setTimeout(() => { T.cranking = false; if (bad) { TT.Audio.play('error'); toast(TT.t('المحرك مش راضي يدور… جرّب تاني', 'Engine won\'t start… try again'), 'warn'); driverSay('engine'); return; } T.engineOn = true; TT.Audio.play('pop'); }, 900);
  };
  // الكشافات: مقفولة ← واطي ← عالي ← شبورة ← مقفولة
  TT.LIGHT_MODES = ['low', 'high', 'fog'];
  TT.toggleLights = function () {
    const T = G.tuk, i = T.lights ? TT.LIGHT_MODES.indexOf(T.lightMode || 'low') : -1, n = i + 1;
    if (n >= TT.LIGHT_MODES.length) { T.lights = false; } else { T.lights = true; T.lightMode = TT.LIGHT_MODES[n]; }
    TT.Audio.play('click');
    toast(T.lights ? { low: TT.t('💡 نور واطي', '💡 Low beam'), high: TT.t('🔆 نور عالي', '🔆 High beam'), fog: TT.t('🌫️ كشافات شبورة', '🌫️ Fog lights') }[T.lightMode] : TT.t('⚫ الكشافات اتقفلت', '⚫ Lights off'), 'info', 1.2);
  };
  TT.cycleMode = function () { const m = ['eco', 'normal', 'sport']; G.tuk.mode = m[(m.indexOf(G.tuk.mode) + 1) % 3]; TT.Audio.play('click'); return G.tuk.mode; };

  /* ---------- exit / enter tuktuk ---------- */
  TT.canExit = function () { const T = G.tuk; return G.L && !G.driver && !G.flip && !G.fight && Math.abs(T.vx) < 0.3 && T.grounded && !G.boardingLock; };
  TT.exitTuk = function () {
    if (!TT.canExit()) { toast(TT.t('مينفعش تنزل والتوكتوك ماشي', 'Stop completely before getting out'), 'warn'); return; }
    G.tuk.occupied = 'empty'; G.tuk.engineOn = false;
    G.driver = { x: G.tuk.x + 0.2, facing: 1, pose: 'walk', t: 0, vx: 0, anim: 'exit', animT: 0 };
    TT.Audio.play('pop');
  };
  TT.enterTuk = function () {
    if (!G.driver || G.fight) return;
    if (Math.abs(G.driver.x - G.tuk.x) > 2.2) { toast(TT.t('قرّب من التوكتوك الأول', 'Walk to the tuk tuk first'), 'warn'); return; }
    G.driver = null; G.tuk.occupied = 'driver'; TT.Audio.play('pop'); TT.UI.closeTalk();
  };
  function nearestNPC() {
    if (!G.driver) return null; let best = null, bd = 1e9;
    for (const n of G.L.npcs) { if (n.state === 'gone' || n.state === 'fled') continue; const d = Math.abs(n.x - G.driver.x); if (d < bd) { bd = d; best = n; } }
    return best;
  }

  /* ============================ NPC TALK ============================
     التفاعل مع الشخصيات: النتيجة بتعتمد على طبع الشخص + سمعة السواق */
  const TEMPER = { calm: { apol: 50, move: 0.85, argueGive: 0.5 }, stubborn: { apol: 25, move: 0.4, argueGive: 0.25 }, hothead: { apol: 15, move: 0.25, argueGive: 0.1 }, coward: { apol: 40, move: 0.9, argueGive: 0.6 } };
  TT.talk = function (npc, opt) {
    const tp = TEMPER[npc.temper], rep = Save.data.rep, d = Save.data;
    const conflict = (npc.kind !== 'bystander' && !npc.resolved) || npc.mood > 40;
    let reply = '', end = false;
    G.driverPose = { name: 'talk', t: 1.4 };
    npc.state = 'talk'; npc.stateT = 1.6;
    switch (opt) {
      case 'greet':
        if (!conflict) { reply = pick(Math.random, ['أهلًا يا اسطى، نورت', 'وعليكم السلام ورحمة الله', 'إزيك يا كبير']); if (!npc.greeted) { npc.greeted = true; d.rep = clamp(d.rep + 1, 0, 100); reply += TT.t(' (+1 سمعة)', ' (+1 rep)'); } }
        else { npc.mood -= 4; reply = pick(Math.random, ['سلام إيه وبتاع إيه!', 'وعليكم... بس برضه غلطان']); }
        break;
      case 'apologize':
        if (!conflict) { reply = 'على إيه يا راجل؟ مفيش حاجة'; break; }
        npc.mood -= tp.apol + rep * 0.15; G.driverPose = { name: 'apologize', t: 1.6 };
        if (npc.mood <= 20) { reply = pick(Math.random, ['خلاص حصل خير', 'ماشي يا سيدي، المسامح كريم']); d.rep = clamp(d.rep + 2, 0, 100); resolveNPC(npc, 'peace'); end = true; }
        else reply = pick(Math.random, ['آسف دي مش هتصلّح حاجة', 'كلام... كلام']);
        break;
      case 'move':
        if (npc.kind !== 'blocker') { reply = npc.kind === 'crash' ? 'أتحرك إزاي وانت خابطني؟!' : 'أنا مش واقف في طريقك يا عم'; if (npc.kind === 'crash') npc.mood += 5; break; }
        if (npc.mood < 55 && Math.random() < tp.move + rep * 0.003) { reply = pick(Math.random, ['حاضر، دقيقة وهحرك العربية', 'ماشي ماشي، انت عندك حق']); resolveNPC(npc, 'move'); end = true; }
        else { npc.mood += 12; reply = pick(Math.random, ['مش هتحرك! استنى شوية', 'انت شايفني فاضيلك؟', 'لما أخلص مشواري']); }
        break;
      case 'complain':
        addCrowd(npc.x, 1);
        if (!conflict) { reply = pick(Math.random, ['والله عندك حق، البلد بقت زحمة', 'اشتكي لمين بس؟']); break; }
        if (npc.kind === 'blocker' && (npc.temper === 'calm' || npc.temper === 'coward') && Math.random() < 0.6) { reply = 'عندك حق، أنا راكن صف تاني. هحرّك'; resolveNPC(npc, 'move'); end = true; }
        else { npc.mood += 14; reply = pick(Math.random, ['تشتكي مين؟ روح اشتكي!', 'انت اللي غلطان من الأول']); }
        break;
      case 'argue':
        G.driverPose = { name: 'argue', t: 2.2 }; npc.state = 'argue'; npc.stateT = 2.2;
        npc.mood += 18; addCrowd(npc.x, 1);
        if (conflict && Math.random() < tp.argueGive) { reply = pick(Math.random, ['خلاص يا عم، صدّعتني! خد طريقك', 'مش عايز وجع دماغ، اتفضل']); resolveNPC(npc, 'argue'); end = true; }
        else if (!conflict) reply = pick(Math.random, ['انت بتتخانق معايا ليه؟ أنا مالي!', 'روح يا عم شوف شغلك']);
        else reply = pick(Math.random, ['صوتك ميعلاش عليّا!', 'انت مين أصلًا؟', 'ده انت ليلتك طويلة']);
        if (conflict && npc.mood > 95 && npc.temper === 'hothead') { reply = 'كده كتير! تعالى بقى!'; TT.UI.closeTalk(); setTimeout(() => startFight(npc), 300); return { reply, end: true }; }
        break;
      case 'peace': // ربنا يهديك وأمشي
        d.stats.peace++; d.rep = clamp(d.rep + 1, 0, 100); reply = pick(Math.random, ['ويهديك انت كمان', 'ماشي يا عم، سلام']);
        G.driverPose = { name: 'wave', t: 1.2 };
        if (conflict) { npc.calmDown = 9 + Math.random() * 5; if (npc.kind === 'crash') resolveNPC(npc, 'peace'); }
        end = true; break;
      case 'fight':
        TT.UI.closeTalk(); startFight(npc); return { reply: '', end: true };
    }
    npc.mood = clamp(npc.mood, 0, 100);
    say(npc, reply, 2.8);
    return { reply, end };
  };
  function resolveNPC(npc, how) {
    npc.resolved = true; npc.kind === 'blocker' && G.L.blockers.forEach(b => { if (b.npc === npc) resolveBlocker(b); });
    if (npc.kind === 'crash') { const v = G.traffic.find(v => v.angryNpc === npc); if (v) { v.angryNpc = null; v.reenter = npc; } }
  }
  function resolveBlocker(b, instant) {
    if (b.resolved) return; b.resolved = true;
    const v = b.veh || G.traffic.find(t => t.id === b.id);
    if (b.npc) { b.npc.resolved = true; b.npc.state = 'walkToCar'; }
    if (v) { v.state = instant ? 'gone' : 'leaving'; v.leaveT = 0; }
    if (instant && b.npc) b.npc.state = 'gone';
    if (!instant) toast(TT.t('الطريق فضي!', 'Road cleared!'), 'good');
  }

  /* ============================ FIGHT (cartoon) ============================
     خناقة كرتونية بدون دم: زق / تفادي / صالح — والناس بتحوش بعد ثواني */
  function startFight(npc) {
    if (G.fight || !G.driver) return;
    G.fight = { npc, t: 0, pHP: 100, nHP: npc.temper === 'hothead' ? 125 : npc.temper === 'coward' ? 55 : 95, nState: 'idle', nT: 1.0, pDodge: 0, pCool: 0, pAnim: null, pAnimT: 0, nAnim: 'argue', end: null, separateAt: 7.5 + Math.random() * 2 };
    npc.state = 'fight'; G.stats.fights++; Save.data.stats.fights++; rec('fights');
    G.driver.x = npc.x - 1.25 * Math.sign(npc.x - G.driver.x || 1); G.driver.facing = Math.sign(npc.x - G.driver.x) || 1; npc.facing = -G.driver.facing;
    TT.UI.showFight(true);
    say(npc, pick(Math.random, ['تعالى بقى!', 'ده انت اللي جبته لنفسك!', 'يا ساتر!']), 1.6);
  }
  TT.fightAction = function (act) {
    const F = G.fight; if (!F || F.end) return;
    if (act === 'push' && F.pCool <= 0) {
      F.pCool = 0.6; F.pAnim = 'push'; F.pAnimT = 0.35; TT.Audio.play('punch');
      const dodgeCh = F.npc.temper === 'hothead' ? 0.2 : F.npc.temper === 'coward' ? 0.1 : 0.3;
      if (F.nState === 'windup' || Math.random() > dodgeCh) { F.nHP -= 22; F.nAnim = 'stumble'; F.nState = 'hit'; F.nT = 0.5; burstStars(F.npc.x); G.cam.shake = 5; }
      else { F.nAnim = 'dodge'; F.nState = 'dodging'; F.nT = 0.5; }
    } else if (act === 'dodge' && F.pCool <= 0) { F.pDodge = 0.5; F.pCool = 0.75; F.pAnim = 'dodge'; F.pAnimT = 0.5; }
    else if (act === 'peace' && F.t > 1.5) { endFight('reconcile'); }
  };
  function updateFight(dt) {
    const F = G.fight; if (!F) return;
    F.t += dt; F.pCool -= dt; F.pDodge -= dt; F.pAnimT -= dt; F.nT -= dt;
    const npc = F.npc;
    if (F.end) { F.endT -= dt; if (F.endT <= 0) finishFight(); return; }
    // NPC AI
    if (F.nT <= 0) {
      if (F.nState === 'windup') {
        F.nState = 'attack'; F.nAnim = 'push'; F.nT = 0.35;
        if (F.pDodge > 0) { F.nHP -= 12; say(npc, 'إيه ده؟!', 1); F.nAnim = 'stumble'; }
        else { F.pHP -= npc.temper === 'hothead' ? 30 : 22; F.pAnim = 'stumble'; F.pAnimT = 0.6; TT.Audio.play('punch'); burstStars(G.driver.x); G.cam.shake = 6; vibrate(60); }
      } else { F.nState = Math.random() < 0.65 ? 'windup' : 'idle'; F.nAnim = F.nState === 'windup' ? 'windup' : 'argue'; F.nT = F.nState === 'windup' ? 0.75 : 0.6 + Math.random() * 0.8; }
    }
    if (F.nHP <= 0) endFight(npc.temper === 'coward' ? 'fled' : 'won');
    else if (F.pHP <= 0) endFight('lost');
    else if (F.t > F.separateAt) endFight('separated');
    if (Math.random() < dt * 6) G.particles.push({ kind: 'dust', x: (G.driver.x + npc.x) / 2 * PX + (Math.random() - 0.5) * 60, y: ROAD_Y - 10 - Math.random() * 30, vx: (Math.random() - 0.5) * 40, vy: -20, r: 8 + Math.random() * 10, life: 0.8, max: 0.8, col: '#c8b8a0', a: 0.6, world: true });
  }
  function endFight(result) {
    const F = G.fight; F.end = result; F.endT = 2.2;
    const npc = F.npc, d = Save.data;
    const msgs = {
      won: ['خلاص خلاص! أنا آسف', 'ماشي يا عم، انت الكسبان'], fled: ['يا ماما!', 'أنا ماشي أنا ماشي!'],
      lost: ['اتعلم الأدب!', 'كده تتعلم'], separated: ['صلّوا على النبي يا جماعة!', 'خلاص يا رجالة عيب كده!'], reconcile: ['خلاص حقك عليّا', 'المسامح كريم']
    };
    say(npc, pick(Math.random, msgs[result]), 2.4);
    if (result === 'separated') { G.peds.push({ id: 'sep', kind: 'ped', human: true, x: npc.x + 1.6, depth: 0.5, state: 'stand', t: 0, look: { skin: '#a8714a', shirt: '#795548', pants: '#333', galabeya: true, taqiya: '#fff', mustache: true }, temp: 3 }); }
    if (result === 'lost') { G.driverPose = { name: 'fallen', t: 1.6 }; }
    if (result === 'won' || result === 'fled') { npc.state = result === 'fled' ? 'fled' : 'idle'; }
    d.rep = clamp(d.rep - (result === 'reconcile' ? 3 : 7), 0, 100);
    for (const p of G.riding) { p.sat -= 18; }
  }
  function finishFight() {
    const F = G.fight, npc = F.npc;
    if (F.end !== 'reconcile') {
      // الناس اتلمت — يا تتصالحوا يا البوكس ييجي
      G.pendingMediation = npc; TT.UI.openMediation(npc, G.crowd.length);
    } else { toast(TT.t('اتصالحتوا قدام الناس 🤝', 'You made peace in front of everyone 🤝'), 'good'); dispersCrowd(); }
    if (npc.kind !== 'bystander') resolveNPC(npc, 'fight');
    if (F.end === 'fled') npc.state = 'fled';
    G.fight = null; TT.UI.showFight(false);
    npc.state = npc.state === 'fight' ? 'idle' : npc.state;
    G.peds = G.peds.filter(p => p.id !== 'sep');
  }

  /* ============================ CROWD / POLICE BOX / CLAMP ============================
     الناس بتتلم حوالين الخناقة. لو مفيش صلح → البوكس ييجي ياخد السواق والطرف التاني،
     والمركبة بتتكلبش لحد ما تدفع */
  const CROWD_LINES = ['الله الله!', 'صلّوا على النبي يا جماعة!', 'سيبوه يا جدعان!', 'عيب كده يا رجالة!', 'حد يكلم البوليس!', 'إيه اللي حصل؟', 'هاتوا الحاج يفصل بينهم!'];
  function addCrowd(x, n) {
    for (let i = 0; i < n && G.crowd.length < 10; i++) {
      const side = Math.random() < 0.5 ? -1 : 1;
      const p = { x: x + side * (1.5 + Math.random() * 4), depth: Math.random() < 0.5 ? 0 : 0.9, look: pick(Math.random, G.L.W.id === 'mars' ? [TT.PASSENGER_TYPES.alien.look, TT.PASSENGER_TYPES.astro.look] : TT.NPC_LOOKS.concat(G.L.W.passengers.map(k => TT.PASSENGER_TYPES[k].look))), t: Math.random() * 5, pose: pick(Math.random, ['cheer', 'angry', 'talk', 'point', 'surprised']), facing: side > 0 ? -1 : 1, enter: 1 };
      G.crowd.push(p);
      if (Math.random() < 0.5) say(p, pick(Math.random, CROWD_LINES), 2.2);
    }
  }
  function dispersCrowd() { for (const p of G.crowd) p.leaving = true; }
  TT.mediate = function (accept) {
    const npc = G.pendingMediation; G.pendingMediation = null;
    if (accept) {
      Save.data.rep = clamp(Save.data.rep + 2, 0, 100); Save.data.stats.peace++;
      say(npc, pick(Math.random, ['خلاص يا سيدي، المسامح كريم', 'حقك عليّا يا اسطى']), 2.4);
      toast(TT.t('اتصالحتوا قدام الناس 🤝 — مفيش بوليس', 'You made peace — no police'), 'good');
      dispersCrowd(); if (npc && npc.kind !== 'bystander') resolveNPC(npc, 'peace'); if (npc) npc.mood = 0;
    } else startArrest(npc);
  };
  function startArrest(npc) {
    const D = G.driver; if (!D) return;
    G.arrest = { phase: 'arrive', t: 0, npc, x0: D.x - 45, x: D.x - 45, target: Math.max(D.x, npc ? npc.x : D.x) + 3 };
    TT.Audio.play('whistle'); toast(TT.t('🚓 البوكس جاي!', '🚓 Police truck is coming!'), 'bad', 3);
    addCrowd(D.x, 3);
  }
  function updateArrest(dt) {
    const R = G.arrest; if (!R) return;
    R.t += dt; const D = G.driver;
    if (R.phase === 'arrive') { const k = smooth(clamp(R.t / 3, 0, 1)); R.x = lerp(R.x0, R.target - 5, k); R.sir = (R.sir || 0) - dt; if (R.sir <= 0) { R.sir = 0.8; TT.Audio.play('siren'); } if (k >= 1) { R.phase = 'load'; R.t = 0; say({ x: R.x + 4, h: 2.4 }, TT.t('اتفضلوا معانا على القسم!', 'Into the truck, both of you!'), 2.5); } }
    else if (R.phase === 'load') { const k = clamp(R.t / 2, 0, 1); if (D) { D.x = lerp(D.x, R.x + 1.5, k * 0.15); D.moving = true; } if (R.npc) { R.npc.x = lerp(R.npc.x, R.x + 2.5, k * 0.15); R.npc.state = 'walkToCar'; } if (k >= 1) { R.phase = 'leave'; R.t = 0; R.caged = true; if (D) D.hidden = true; if (R.npc) R.npc.state = 'gone'; } }
    else if (R.phase === 'leave') { R.x += dt * (2 + R.t * 4); if (R.t > 2.5) { R.phase = 'station'; dispersCrowd(); TT.UI.openStation(); } }
  }
  TT.arrestDone = function () {
    const R = G.arrest; G.arrest = null;
    for (const p of G.riding.slice()) passengerLeaves(p, 0, 'late');
    violation('fight', 'fight' + (R && R.npc ? R.npc.id : G.time.toFixed(0)), TT.t('خناقة في الشارع ومفيش صلح — اتاخدت على القسم', 'Street fight without reconciliation — taken to the station'));
    Save.data.rep = clamp(Save.data.rep - 8, 0, 100);
    G.clamped = true;
    if (G.driver) { G.driver.hidden = false; G.driver.x = G.tuk.x - 2; }
    if (R && R.npc && R.npc.kind === 'blocker') G.L.blockers.forEach(b => { if (b.npc === R.npc) resolveBlocker(b, true); });
    toast(TT.t('🔒 المركبة متكلبشة — ادفع عشان تفكها', '🔒 Vehicle clamped — pay to release'), 'bad', 3.5);
  };
  TT.unclampCost = 200;
  TT.unclamp = function () {
    if (!G.clamped) return;
    Save.ledger(TT.t('فك الكلبش', 'Clamp release'), -TT.unclampCost, 'fine'); G.stats.fines += TT.unclampCost;
    G.clamped = false; TT.Audio.play('fuel'); toast(TT.t('🔓 اتفك الكلبش', '🔓 Clamp removed'), 'good');
  };
  function updateCrowd(dt) {
    for (const p of G.crowd) { p.t += dt; if (p.leaving) { p.x += (p.facing > 0 ? -1 : 1) * 1.6 * dt; p.gone = (p.gone || 0) + dt; } }
    G.crowd = G.crowd.filter(p => !p.gone || p.gone < 2.5);
    if (G.fight && Math.random() < dt * 0.9) addCrowd((G.driver.x + G.fight.npc.x) / 2, 1);
    if (G.celebrate > 0) G.celebrate -= dt;
  }

  /* ---------- طرد الركاب في نص الطريق ---------- */
  TT.kickOut = function () {
    const T = G.tuk; if (!G.riding.length || Math.abs(T.vx) > 0.6 || G.driver || G.flip) return;
    const lines = ['انزلوا يا جماعة، أنا مش رايح!', 'يلا انزل، الأجرة دي مش جايبة همّها!', 'انزل يا عم، أنا رايح أتغدى!', 'آخر الخط هنا… اتفضلوا!'];
    say({ x: T.x + 0.5, h: 2.2, isDriver: true }, pick(Math.random, lines), 2.5);
    let n = 0; for (const p of G.riding.slice()) { if (p.state !== 'riding') continue; passengerLeaves(p, 0, 'kicked'); n++; }
    Save.data.rep = clamp(Save.data.rep - 3 * n, 0, 100); G.stats.kicked = (G.stats.kicked || 0) + n;
    toast(TT.t('نزّلت ' + n + ' راكب من غير أجرة (−' + 3 * n + ' سمعة)', 'Kicked out ' + n + ' riders, no fare (−' + 3 * n + ' rep)'), 'warn');
  };

  /* ---------- تحميل أوتوماتيك: تقف في الموقف وتشد فرامل اليد ---------- */
  function autoStation() {
    const T = G.tuk; if (G.driver || G.flip || G.fight || G.arrest || G.modal) return;
    const st = stationHere();
    if (!st || Math.abs(T.vx) > 0.3) { if (!st) G.autoDone = null; G.stopAtSt = 0; return; }
    G.stopAtSt = (G.stopAtSt || 0) + 1 / 120;
    if (G.stopAtSt < 0.45 || !T.grounded || G.autoDone === st.id || G.boardingLock) return;
    G.autoDone = st.id;
    const drop = G.riding.filter(p => p.to === st.idx && p.state === 'riding'); drop.forEach(deliver);
    let boarded = 0, cap = Save.model().seats || 3;
    for (const p of st.waiting.slice()) if (seatsUsed() + p.seats <= cap) { TT.boardPassenger(p, false); boarded++; }
    if (boarded) toast(TT.t('⏫ ركب ' + boarded + ' راكب', '⏫ ' + boarded + ' boarded'), 'good');
    else if (!drop.length) toast(st.waiting.length ? TT.t('المركبة مليانة', 'Vehicle is full') : TT.t('مفيش ركاب في الموقف ده', 'No riders at this stop'), 'warn');
  }

  /* ---------- سماعة الصب ---------- */
  TT.toggleSub = function () { if (!accOpts().sub) return; G.subOn = !G.subOn; TT.Audio.bass(G.subOn); };
  TT.toggleParty = function () { if (!accOpts().party) return; G.partyOn = !G.partyOn; TT.Audio.play('click'); };

  /* ---------- الزحمة ---------- */
  function spawnJam() {
    const L = G.L, T = G.tuk;
    for (const z of L.zones.jam) {
      if (z.spawned || T.x < z.a - 140 || T.x > z.b || Save.data.settings.traffic === 'none') continue;
      z.spawned = true; const r = G.trafficSeed;
      for (let x = Math.max(z.a, T.x + 25); x < z.b; x += 6.5 + r() * 3) {
        const type = pick(r, L.W.vehicles.filter(v => v !== 'bus')); if (G.traffic.some(v => Math.abs(v.x - x) < 6)) continue;
        G.traffic.push({ id: 'j' + Math.floor(r() * 1e9), type, x, v: 0, vt: 1 + r(), len: A.VEH[type].len, color: pick(r, A.VEH[type].col), state: 'drive', lane: 0, laneT: 0, wr: 0, jam: z });
        x += A.VEH[type].len;
      }
      toast(TT.t('🚗🚗🚗 زحمة قدام — هدّي سرعتك (الحد 20)', '🚗🚗🚗 Traffic jam ahead — slow down (20)'), 'warn', 3.4);
    }
  }

  /* ============================ TRAFFIC ============================ */
  function lightState(l) { const c = (G.time + l.phase) % 14; return c < 7 ? 'green' : c < 9 ? 'yellow' : 'red'; }
  TT.lightState = lightState;
  function spawnTraffic() {
    const L = G.L, T = G.tuk, r = G.trafficSeed;
    spawnJam();
    const ahead = G.traffic.filter(v => v.lane === 0 && v.state !== 'gone' && v.state !== 'blocker' && v.x > T.x).length;
    const TM = { none: 0, few: 0.45, normal: 1, many: 1.8 }[Save.data.settings.traffic]; const tm = TM == null ? 1 : TM;
    const maxN = Math.round((1 + L.W.traffic * 2) * Math.min(tm, 1.4));
    if (ahead < maxN && r() < 0.02 * L.W.traffic * tm) {
      const x = T.x + 90 + r() * 110;
      if (x > L.finish - 30) return;
      if (G.traffic.some(v => Math.abs(v.x - x) < 14)) return;
      if (L.blockers.some(b => !b.resolved && x > b.x - 30 && x < b.x + 15)) return;
      if (L.zones.jam.some(z => x > z.a - 10 && x < z.b + 10)) return;
      const type = pick(r, L.W.vehicles);
      G.traffic.push({ id: 'v' + Math.floor(r() * 1e9), type, x, v: 0, vt: (type === 'tractor' || type === 'cart' ? 2.2 : 3 + r() * 2.2), len: A.VEH[type].len, color: pick(r, A.VEH[type].col), state: 'drive', lane: 0, laneT: 0, wr: 0 });
    }
    // decorative oncoming vehicles in the back lane
    if (r() < 0.012 * L.W.traffic * tm) { const type = pick(r, L.W.vehicles); G.traffic.push({ id: 'o' + Math.floor(r() * 1e9), type, x: T.x + 60, v: -(3.5 + r() * 2.5), len: A.VEH[type].len, color: pick(r, A.VEH[type].col), state: 'oncoming', lane: 1, laneT: 1, wr: 0, flip: true }); }
  }
  function updateTraffic(dt) {
    const L = G.L, T = G.tuk;
    spawnTraffic();
    for (const v of G.traffic) {
      v.wr += v.v / 0.3 * dt;
      if (v.state === 'oncoming') { v.x += v.v * dt; if (v.x < T.x - 60) v.state = 'gone'; continue; }
      if (v.reenter) { const n = v.reenter; if (n.state !== 'gone') n.state = 'walkToCar'; else { v.reenter = null; v.state = 'leaving'; v.leaveT = 0; } continue; }
      if (v.state === 'blocker' || v.state === 'crashed') { v.v = 0; continue; }
      if (v.state === 'leaving') { v.leaveT += dt; v.laneT = clamp(v.leaveT / 1.5, 0, 1); v.v = Math.min(8, v.v + 3 * dt); v.x += v.v * dt; if (v.leaveT > 1.5) { v.lane = 1; } if (v.leaveT > 6) v.state = 'gone'; continue; }
      if (v.state === 'pullover') { v.pullT += dt; v.laneT = clamp(v.pullT / 1.2, 0, 1); if (v.pullT > 1.2) v.lane = 1; v.v = Math.max(2, v.v - 2 * dt); v.x += v.v * dt; if (v.pullT > 3.5) { v.state = 'gone'; } continue; }
      // car-following + red lights
      let target = v.vt;
      if (v.jam) { if (v.x > v.jam.b + 5) { v.vt = 4 + (v.vt % 1) * 2; v.jam = null; } else target = Math.max(0, 0.9 + Math.sin(G.time * 0.7 + v.x * 0.3) * 0.9); }
      for (const l of L.lights) { const stopX = l.x - 2 - v.len; const d = stopX - v.x; if (d > -0.5 && d < 30 && lightState(l) !== 'green') target = Math.min(target, Math.max(0, d * 0.5)); }
      for (const o of G.traffic) if (o !== v && o.lane === 0 && o.state !== 'gone' && o.state !== 'oncoming' && o.x > v.x) { const gap = o.x - (v.x + v.len); if (gap < 12) target = Math.min(target, Math.max(0, (gap - 2) * 0.6), o.v + 0.5); }
      // vehicles pass blockers by lane change
      const bk = L.blockers.find(b => !b.resolved && b.x - (v.x + v.len) < 10 && b.x - v.x > -5);
      if (bk) { v.laneT = clamp(v.laneT + dt, 0, 1); } else if (v.laneT > 0 && v.state === 'drive') v.laneT = clamp(v.laneT - dt, 0, 1);
      v.v += clamp(target - v.v, -6 * dt, 2 * dt);
      v.x += v.v * dt;
      if (v.x > L.finish + 40 || v.x < T.x - 120) v.state = 'gone';
      // auto pull over if player is stuck behind for a while
      if (v.x > T.x && v.x - (T.x + geom().front) < 6 && Math.abs(T.vx) < 1.5) { v.behindT = (v.behindT || 0) + dt; if (v.behindT > 7 && !v.jam && !L.lights.some(l => Math.abs(l.x - v.x) < 25)) { v.state = 'pullover'; v.pullT = 0; } }
    }
    G.traffic = G.traffic.filter(v => v.state !== 'gone');
    // ---- collisions with the tuktuk (main lane only) ----
    if (G.flip) return;
    const GMc = geom(), front = T.x + GMc.front, rear = T.x - GMc.back;
    for (const v of G.traffic) {
      if (v.lane !== 0 || v.laneT > 0.5 || v.state === 'oncoming') continue;
      if (front > v.x && rear < v.x + v.len) {
        const rel = T.vx - v.v;
        if (T.x < v.x + v.len / 2) { // we are behind it
          T.x = v.x - GMc.front; // resolve overlap
          if (rel > 1.6) crashInto(v, rel);
          else { T.vx = Math.min(T.vx, v.v); }
        } else { T.x = v.x + v.len + GMc.back; T.vx = Math.max(T.vx, v.v); }
      }
    }
  }
  function crashInto(v, rel) {
    const T = G.tuk;
    T.vx = v.v - rel * 0.25; T.av -= Math.min(1.2, rel * 0.1); G.cam.shake = 12;
    damage('body', 0.045 * rel); damage('suspension', 0.015 * rel); damage('engine', 0.02 * rel); driverSay('crash');
    TT.Audio.play('crash'); vibrate([60, 40, 90]); rec('crashes'); G.stats.crashes = (G.stats.crashes || 0) + 1;
    for (const p of G.riding) { p.sat -= 20; say(p, pick(Math.random, TT.LINES.angry)); }
    const name = { car: 'عربية', microbus: 'ميكروباص', tuktuk: 'توكتوك', bus: 'أتوبيس', police: 'عربية شرطة', moto: 'موتوسيكل', tractor: 'جرار', cart: 'عربية كارو', jeep: 'جيب', truck: 'نقل', rover: 'مركبة فضائية' }[v.type] || 'مركبة';
    violation('crashCar', 'crash' + v.id, TT.t('خبطت ' + name + ' بفرق سرعة ' + kmh(rel) + ' كم/س', 'Rear-ended a vehicle at ' + kmh(rel) + ' km/h'));
    for (let i = 0; i < 10; i++) G.particles.push({ kind: 'spark', x: (T.x + geom().front) * PX, y: ROAD_Y - 20, vx: (Math.random() - 0.5) * 200, vy: -Math.random() * 150, r: 2, life: 0.5, max: 0.5, col: '#ffcc80', world: true, g: 400 });
    if (v.state === 'blocker') { const b = G.L.blockers.find(b => b.id === v.id); if (b && b.npc) { b.npc.mood = Math.min(100, b.npc.mood + 30); say(b.npc, 'انت خبطت عربيتي كمان؟!', 2.5); } return; }
    // other driver gets out angry (blocks the road until resolved)
    if (v.state !== 'crashed' && v.type !== 'moto' && v.type !== 'bus') {
      v.state = 'crashed'; v.v = 0;
      const npc = makeNPC('crash_' + v.id, v.x + 1.2, 'crash', pick(Math.random, ['calm', 'stubborn', 'hothead', 'coward']), Math.random, G.L.W);
      npc.mood = 70; npc.facing = -1; npc.timeout = 25; v.angryNpc = npc; G.L.npcs.push(npc);
      say(npc, pick(Math.random, ['انت عمي؟! بص عملت إيه في العربية!', 'يا نهار أبيض! انزل كلمني!', 'إيه السواقة دي؟!']), 3);
    }
  }

  /* ============================ PEDESTRIANS / ANIMALS ============================ */
  function updatePeds(dt) {
    const L = G.L, T = G.tuk, W = L.W;
    for (const cw of L.crosswalks.concat(L.herds)) {
      cw.cool -= dt;
      const d = cw.x - T.x;
      if (d > 12 && d < 55 && cw.cool <= 0 && !G.peds.some(p => p.src === cw.id)) {
        const isHerd = L.herds.includes(cw);
        const kind = isHerd ? pick(Math.random, W.peds.filter(p => p !== 'ped')) : (W.peds.includes('alienPed') ? 'alienPed' : 'ped');
        const human = kind === 'ped' || kind === 'alienPed';
        const n = isHerd ? 1 + (Math.random() < 0.5 ? 1 : 0) : 1 + (Math.random() < 0.4 ? 1 : 0);
        for (let i = 0; i < n; i++) {
          const T2 = pick(Math.random, W.passengers.map(k => TT.PASSENGER_TYPES[k]));
          G.peds.push({ id: cw.id + '_' + G.time.toFixed(2) + i, src: cw.id, kind, human, x: cw.x + (i - 0.5) * 1.4, depth: -0.05 - i * 0.18, state: 'cross', speed: human ? 0.2 : 0.11, t: Math.random() * 5, look: kind === 'alienPed' ? TT.PASSENGER_TYPES.alien.look : T2.look, facing: 1 });
        }
        cw.cool = 14 + Math.random() * 8;
      }
    }
    for (const p of G.peds) {
      p.t += dt;
      if (p.state === 'cross') {
        p.depth += p.speed * (p.hurry ? 2 : 1) * dt;
        if (p.depth > 1.15) p.state = 'done';
      } else if (p.state === 'hit') { p.hitT -= dt; if (p.hitT <= 0) { p.state = 'angry'; p.angryT = 2.2; if (p.human) say(p, pick(Math.random, TT.LINES.pedHit), 2); } }
      else if (p.state === 'angry') { p.angryT -= dt; if (p.angryT <= 0) { p.state = 'cross'; p.hurry = true; } }
      else if (p.state === 'stand') { p.temp -= dt; if (p.temp <= 0) p.state = 'done'; }
      // collision with tuktuk when in our lane
      if ((p.state === 'cross') && p.depth > 0.36 && p.depth < 0.74 && !G.flip) {
        const rel = Math.abs(T.vx);
        if (p.x > T.x - geom().back && p.x < T.x + geom().front) {
          if (rel > 0.9) {
            p.state = 'hit'; p.hitT = 1.8; burstStars(p.x);
            T.vx *= 0.3; G.cam.shake = 8; TT.Audio.play('crash');
            for (const q of G.riding) q.sat -= 22;
            if (p.human) violation('hitPed', 'ped' + p.id, TT.t('خبطت واحد ماشي على المشاة بسرعة ' + kmh(rel) + ' كم/س', 'Hit a pedestrian at ' + kmh(rel) + ' km/h'));
            else { damage('body', 0.06); rec('animals'); G.stats.crashes = (G.stats.crashes || 0) + 1; violation('animalHit', 'ah' + Math.round(T.x), TT.t('خبطت بهيمة في الطريق', 'Hit an animal on the road')); toast(TT.t('خبطت بهيمة! دفعت تعويض 80 جنيه', 'Hit an animal! Paid 80 compensation'), 'bad'); }
          } else if (T.vx > 0) { T.vx = 0; }
        }
      }
    }
    G.peds = G.peds.filter(p => p.state !== 'done');
  }

  /* ============================ RULE CHECKS ============================ */
  function updateRules(dt) {
    const L = G.L, T = G.tuk, v = T.vx, sp = kmh(v);
    // radars
    for (const r of L.radars) {
      r.flash = Math.max(0, r.flash - dt * 3);
      if (!r.passed && T.x > r.x) { r.passed = true; if (sp > r.limit + 3) { r.flash = 1; violation('speeding', 'rad' + r.id, TT.t('الرادار صوّرك بسرعة ' + sp + ' كم/س والحد ' + r.limit, 'Radar: ' + sp + ' km/h in a ' + r.limit + ' zone')); } }
      if (T.x < r.x - 5) r.passed = false;
    }
    // red lights (stop line = light.x - 2)
    for (const l of L.lights) {
      const line = l.x - 2;
      if (T.prevFront != null && T.prevFront <= line && T.x + geom().front > line && T.vx > 0.3) {
        if (lightState(l) === 'red') violation('redLight', 'red' + l.id + Math.floor(G.time / 14), TT.t('عديت خط الوقوف والإشارة حمرا', 'Crossed the stop line on red'));
      }
    }
    T.prevFront = T.x + geom().front;
    // no parking (stopped > 4s inside)
    const np = L.zones.noPark.find(z => T.x > z.a && T.x < z.b);
    if (np && Math.abs(v) < 0.3 && !G.flip) { G.noParkT += dt; if (G.noParkT > 1.5 && G.noParkT - dt <= 1.5) toast(TT.t('⚠️ ممنوع الوقوف هنا!', '⚠️ No parking here!'), 'warn', 2); if (G.noParkT > 4) violation('noParking', 'np' + np.id, TT.t('وقفت أكتر من 4 ثواني في الممنوع', 'Stopped > 4 s in a no-parking zone')); }
    else G.noParkT = 0;
    // village speed zone
    const vz = L.zones.village.find(z => T.x > z.a && T.x < z.b);
    if (vz && sp > vz.limit + 3) { G.villageT += dt; if (G.villageT > 1.5 && !G.vwarn) { G.vwarn = true; toast(TT.t('🏘️ هدّي! إنت جوه القرية والحد 40', '🏘️ Slow down — village limit 40'), 'warn', 2.6); } if (false) violation('village', 'vz' + vz.id, TT.t('سرعتك ' + sp + ' جوه ' + vz.name + ' والحد ' + vz.limit, sp + ' km/h inside a village (limit ' + vz.limit + ')')); } else G.villageT = 0;
    { const lim = TT.limitAt(L, T.x); if (sp > lim + 5 && T.occupied === 'driver') { G.spWarnT = (G.spWarnT || 0) + dt; if (G.spWarnT > 1.2 && G.time - (G.spWarnAt || -99) > 9) { G.spWarnAt = G.time; toast(TT.t('⚠️ سرعتك ' + sp + ' والحد هنا ' + lim + ' — هدّي (المخالفة بس عند الرادار 📸)', '⚠️ ' + sp + ' km/h, limit ' + lim + ' (fines only at radars)'), 'warn', 2.6); } } else G.spWarnT = 0; }
    // headlights rule in storms / tunnels
    const dark = L.zones.storm.find(z => T.x > z.a && T.x < z.b) || L.zones.tunnel.find(z => T.x > z.a && T.x < z.b) || (G.env && (G.env.dark > 0.38 || (G.env.fog || 0) > 0.4) ? { id: 'night' + Math.floor(G.env.day || 0) + (G.env.fog > 0.4 ? 'f' : ''), night: true } : null);
    G.inDark = dark || null;
    if (dark && !T.lights && Math.abs(v) > 1 && T.occupied === 'driver') { G.darkT += dt; if (G.darkT > 0.5 && G.darkT - dt <= 0.5) toast(TT.t('شغّل الكشافات! (L)', 'Turn on headlights! (L)'), 'warn'); if (G.darkT > 3.5) violation('noLights', 'nl' + dark.id, TT.t('سايق في ' + (dark.night ? 'الليل' : L.zones.storm.includes(dark) ? 'العاصفة' : 'النفق') + ' من غير كشافات', 'Driving in the dark without headlights')); }
    else G.darkT = 0;
    // checkpoint: must stop within 10 m before it
    for (const c of L.checkpoints) {
      if (c.done) continue;
      const d = c.x - T.x;
      if (d < 12 && d > -1 && Math.abs(v) < 0.4) {
        c.stopT += dt;
        if (c.stopT > 1.0 && !c.inspecting) { c.inspecting = true; T.vx = 0; driverSay('police', true); TT.UI.openPolice(c); }
      }
      if (T.x > c.x + 1 && !c.done) { c.done = true; c.state = 'open'; if (T.x - c.x < 15) startChase(c); }
    }
    // missed destination reminder
    for (const p of G.riding) { const st = L.stations[p.to]; if (p.state === 'riding' && T.x > st.x + 9 && !p.missWarn) { p.missWarn = true; toast(TT.t('فاتتك محطة ' + st.name + '! ارجع بالراحة (ممسوك لورا لحد 40م)', 'You passed ' + st.name + '! Back up (max 40 m)'), 'warn', 3.5); } if (T.x < st.x + 6) p.missWarn = false; }
  }

  /* ---------- تفتيش الشرطة: رخص + بطاقة + تحليل ---------- */
  TT.policeStep = function (c, step, choice) {
    const d = Save.data; d.license = d.license || { left: 25 };
    if (step === 'papers') {
      if (choice === 'forgot') { violation('noLicense', 'nl' + c.id, TT.t('مكانش معاك رخص ولا بطاقة في الكمين', 'No license or ID at the checkpoint')); return { ok: false }; }
      if (d.license.left <= 0) { violation('license', 'lx' + c.id, TT.t('رخصة القيادة منتهية — جدّدها من المرآب', 'Driving license expired — renew it in the garage')); return { ok: false, expired: true }; }
      return { ok: true };
    }
    if (step === 'test') {
      if (choice === 'refuse') { violation('refuseTest', 'rt' + c.id, TT.t('رفضت تعمل تحليل المخدرات في الكمين', 'Refused the drug test')); d.rep = clamp(d.rep - 4, 0, 100); return { ok: false }; }
      if (choice === 'ok' && Math.random() < 0.1) return { ok: false, positive: true };
      d.rep = clamp(d.rep + 2, 0, 100); return { ok: true };
    }
    if (step === 'quiz') {
      if (choice === 'wrong') { violation('quiz', 'qz' + c.id + Math.round(G.time), TT.t('جاوبت غلط على سؤال الكمين', 'Wrong answer at the checkpoint')); return { ok: false }; }
      d.rep = clamp(d.rep + 1, 0, 100); return { ok: true };
    }
  };
  TT.policeNeedsTest = c => Math.random() < (Save.data.rep < 35 ? 0.7 : 0.35);
  TT.policeDone = function (c) {
    c.done = true; c.state = 'open'; c.inspecting = false;
    const dm = Save.veh().damage; let worst = null, wv = 0;
    const nm = { engine: 'المحرك', tires: 'الإطارات', suspension: 'التعليق', brakes: 'الفرامل', body: 'الهيكل' };
    for (const k in dm) if (dm[k] > wv) { wv = dm[k]; worst = k; }
    if (wv > 0.65) violation('badVehicle', 'bv' + c.id, TT.t('الكمين لقى ' + nm[worst] + ' حالتها ' + Math.round((1 - wv) * 100) + '% بس', 'Inspection: ' + worst + ' at ' + Math.round((1 - wv) * 100) + '%'));
    else toast(TT.t('👮 اتفضل يا اسطى، كله تمام', '👮 All good, carry on'), 'good');
  };

  /* ============================ وضع البيّاع ============================
     بدل الركاب: المركبة عليها فرن بطاطا / شوّاية درة / حلّة ترمس / فرن عيش.
     تقف عند التجمعات (المحطات) والناس تيجي تشتري، أو تنادي على بضاعتك */
  function setupVendor(L) {
    const d = Save.data, on = d.settings.mode === 'vendor';
    G.vendor = null; if (!on) return;
    const gid = d.settings.goods || 'potato', gd = TT.GOODS[gid];
    d.carts = d.carts || {}; const tier = d.carts[gid] || 0, TR = TT.CART_TIERS[tier];
    const stock = Math.round(Math.min(45, 22 + Math.floor(Math.min(L.li, 30) * 0.6)) * TR.stock), price = Math.round(gd.price * TR.priceMul);
    const cost = Math.round(stock * gd.cost);
    G.vendor = { id: gid, gd, tier, TR, price, stock, start: stock, sold: 0, buyers: [], callCool: 0, spotDone: {} };
    Save.ledger(TT.t('بضاعة: ', 'Stock: ') + stock + ' ' + gd.name, -cost, 'fuel'); G.stats.fuel += cost;
    // الركاب مش موجودين في وضع البياع — المحطات بقت تجمعات زباين
    L.passengers = []; for (const st of L.stations) { st.waiting = []; st.buyers = Math.round((2 + Math.floor(L.r() * 3)) * TR.attract); }
    L.required = Math.min(stock - 4, 8 + Math.floor(Math.min(L.li, 30) * 0.4));
    L.target = Math.round(L.required * price * 1.25 / 5) * 5;
  }
  function updateVendor(dt) {
    const V = G.vendor; if (!V) return;
    const T = G.tuk, L = G.L;
    V.callCool -= dt;
    const stopped = Math.abs(T.vx) < 0.3 && !G.driver && !G.flip;
    // زباين المحطة
    const st = L.stations.find(s => Math.abs(s.x - T.x) < 9);
    if (st && stopped && st.buyers > 0 && V.stock > 0) { st.waitT = (st.waitT || 0) + dt; if (st.waitT > 0.5 && V.buyers.length < V.TR.buyersMax) { st.buyers--; st.waitT = 0; spawnBuyer(st.x - 2 + Math.random() * 4, true); } }
    // البيع
    for (const b of V.buyers) {
      b.t += dt;
      if (b.phase === 'come') { b.x += Math.sign(T.x - 0.8 - b.x) * 1.9 * dt; b.depth = Math.min(0.5, b.depth + dt * 0.4); if (Math.abs(b.x - (T.x - 0.8)) < 0.3) { b.phase = 'buy'; b.t = 0; } if (!stopped && b.t > 1) { b.phase = 'leave'; say(b, 'استنى يا عم!', 1.4); } }
      else if (b.phase === 'buy' && b.t > 0.7) {
        b.phase = 'leave'; b.t = 0;
        if (V.stock > 0) {
          V.stock--; V.sold++; G.stats.delivered++;
          const tip = Math.random() < 0.2 ? 1 + Math.floor(Math.random() * 3) : 0, pay = V.price + tip;
          Save.ledger(TT.t('بيع ', 'Sold ') + V.gd.name, pay, 'fare'); G.stats.income += V.price; G.stats.tips += tip; Save.data.stats.deliveries++; Save.data.xp += pay;
          TT.Audio.play('coin'); burst(T.x - 0.5, 1.8, '+' + pay + ' ج', '#ffd54f');
          say(b, pick(Math.random, V.gd.buyLines), 1.8);
          if (Math.random() < 0.1) vendorDispute(b);
        }
      } else if (b.phase === 'leave') { b.x -= 1.6 * dt; b.depth = Math.max(0, b.depth - dt * 0.4); if (b.t > 3) b.gone = true; }
    }
    V.buyers = V.buyers.filter(b => !b.gone);
    if (V.stock <= 0 && !V.emptyWarned) { V.emptyWarned = true; toast(TT.t('📦 البضاعة خلصت! كمّل لآخر الخط', '📦 Sold out! Head to the finish'), 'good', 3); driverSay('money', true); }
  }
  function spawnBuyer(x, fromSpot) {
    const W = G.L.W, look = W.id === 'mars' ? pick(Math.random, [TT.PASSENGER_TYPES.alien.look, TT.PASSENGER_TYPES.astro.look]) : pick(Math.random, TT.NPC_LOOKS.concat(W.passengers.map(k => TT.PASSENGER_TYPES[k].look)));
    G.vendor.buyers.push({ x, depth: 0, look, t: 0, phase: 'come', id: 'b' + Math.random() });
  }
  TT.vendorCall = function () {
    const V = G.vendor; if (!V || V.callCool > 0 || G.driver) return;
    V.callCool = 4; TT.Audio.play('hornMusic');
    driverSayLine(pick(Math.random, V.gd.calls));
    const T = G.tuk; let n = 0;
    for (const npc of G.L.npcs) { if (npc.kind !== 'bystander' || npc.bought || npc.state === 'gone' || Math.abs(npc.x - T.x) > 28 * Math.sqrt(V.TR.attract)) continue; if (Math.random() < Math.min(0.95, 0.65 * V.TR.attract) && V.stock > n) { npc.bought = true; n++; spawnBuyer(npc.x, false); } }
    if (!n) setTimeout(() => toast(TT.t('محدش جه… جرّب عند تجمّع ناس', 'Nobody came… try near a crowd'), 'warn'), 900);
  };
  function driverSayLine(line) { say({ x: G.tuk.x + 0.4, h: 2.3, isDriver: true }, line, 2.4); }
  function vendorDispute(b) {
    const npc = makeNPC('dsp' + G.time.toFixed(1), G.tuk.x + 1.5, 'crash', pick(Math.random, ['calm', 'stubborn', 'hothead']), Math.random, G.L.W);
    npc.look = b.look; npc.mood = 55; npc.timeout = 22; npc.dispute = true; G.L.npcs.push(npc);
    say(npc, pick(Math.random, ['دي باردة يا عم! رجّعلي فلوسي', 'إنت مدّيني الباقي غلط!', 'دي بايتة من امبارح!']), 3);
    toast(TT.t('😠 زبون بيتخانق — انزل كلّمه', '😠 Angry customer — get out and talk'), 'warn', 3);
  }

  /* ============================ COINS ============================ */
  function updateCoins() {
    const T = G.tuk, L = G.L;
    if (G.driver || G.flip) return;
    for (const c of L.coins) {
      if (c.taken) continue;
      if (Math.abs(c.x - T.x) < 1.3) {
        const gy = groundAt(L, c.x) + c.h;
        if (Math.abs(gy - (T.y + 0.1)) < 1.0) {
          c.taken = true; G.stats.coins++; Save.data.stats.coins++;
          const val = L.W.id === 'mars' ? 2 : 1;
          Save.data.money += val; G.stats.income += val; Save.data.stats.earned += val;
          TT.Audio.play('coin'); burst(c.x, c.h + 0.5, '+' + val, '#ffe082');
        }
      }
    }
  }

  /* ============================ PARTICLES ============================ */
  function dust(x, n, col) {
    if (Save.data.settings.quality === 'low') n = Math.ceil(n / 3);
    for (let i = 0; i < n; i++) G.particles.push({ kind: 'dust', x: (x - 1.2) * PX + (Math.random() - 0.5) * 30, y: ROAD_Y - groundAt(G.L, x) * PX - 4, vx: -30 - Math.random() * 60, vy: -10 - Math.random() * 30, r: 4 + Math.random() * 7, life: 0.9, max: 0.9, col, a: 0.55, world: true, grow: 10 });
  }
  function burst(x, h, txt, col) { G.particles.push({ kind: 'coin', x: x * PX, y: ROAD_Y - (groundAt(G.L, x) + h) * PX - 20, vx: 0, vy: -50, r: 0, life: 1.1, max: 1.1, col, txt, world: true }); }
  function burstStars(x) { for (let i = 0; i < 6; i++) G.particles.push({ kind: 'star', x: x * PX, y: ROAD_Y - 70, vx: (Math.random() - 0.5) * 140, vy: -60 - Math.random() * 80, r: 4 + Math.random() * 3, life: 0.9, max: 0.9, col: '#ffd400', world: true, g: 200 }); }
  function updateParticles(dt) {
    const T = G.tuk, L = G.L, q = Save.data.settings.quality;
    // exhaust + dust emitters
    if (!G.flip && T.occupied === 'driver') {
      if (Save.model().fuel !== false && Math.random() < (q === 'low' ? 0.08 : 0.25) * (0.3 + T.throttle)) G.particles.push({ kind: 'smoke', x: (T.x - geom().back) * PX, y: ROAD_Y - (T.y - 0.35) * PX, vx: -20 - T.vx * 4, vy: -15, r: 3, life: 1.2, max: 1.2, col: '#9e9e9e', a: 0.35, world: true, grow: 8 });
      if (T.grounded && T.throttle > 0.5 && Math.abs(T.vx) < 8 && Math.random() < (q === 'low' ? 0.15 : 0.5)) dust(T.x, 1, L.W.theme === 'mars' ? '#c0563a' : L.W.theme === 'desert' ? '#e8c07a' : '#b8a68a');
      if (T.surface && T.surface.type === 'water' && Math.abs(T.vx) > 2 && Math.random() < 0.6) { for (let i = 0; i < 3; i++) G.particles.push({ kind: 'splash', x: (T.x + (Math.random() - 0.5) * 2) * PX, y: ROAD_Y - 4, vx: (Math.random() - 0.5) * 80, vy: -80 - Math.random() * 80, r: 3, life: 0.6, max: 0.6, col: '#90caf9', world: true, g: 400 }); if (!T.splashed) { T.splashed = true; TT.Audio.play('splash'); } }
      else if (!T.surface || T.surface.type !== 'water') T.splashed = false;
      if (T.surface && T.surface.sandy && Math.abs(T.vx) > 1 && Math.random() < 0.6) dust(T.x, 1, '#e3c27e');
    }
    for (const p of G.particles) { p.life -= dt; p.x += p.vx * dt; p.y += p.vy * dt; if (p.g) p.vy += p.g * dt; if (p.grow) p.r += p.grow * dt; }
    G.particles = G.particles.filter(p => p.life > 0);
    if (G.particles.length > 400) G.particles.splice(0, G.particles.length - 400);
  }

  /* ============================ KNOCKABLES ============================ */
  function updateKnock(dt) {
    const T = G.tuk, L = G.L;
    for (const o of L.obstacles) {
      if (o.kind !== 'knock') continue;
      if (o.hit) { o.t += dt; o.dx += o.vx * dt; o.dy += o.vy * dt; o.vy -= 12 * dt; o.rot += o.vr * dt; if (o.dy < 0 && o.t > 0.1) { o.dy = 0; o.vy = 0; o.vx *= 0.8; o.vr *= 0.7; } continue; }
      if (!G.flip && T.occupied === 'driver' && Math.abs(o.x - (T.x + geom().front - 0.3)) < 0.5 + o.w / 2 && T.vx > 0.8) {
        o.hit = true; o.t = 0; o.dx = 0; o.dy = 0; o.vx = T.vx * 0.8 + 1; o.vy = 2 + T.vx * 0.25; o.rot = 0; o.vr = 6 + Math.random() * 6;
        const def = TT.OBSTACLES[o.type];
        if (def.dmg) { damage('body', def.dmg / 100); T.vx *= o.type === 'box' ? 0.8 : 0.95; }
        TT.Audio.play(o.type === 'chicken' ? 'pop' : 'bump');
        if (o.type === 'chicken') { say({ x: o.x, h: 1.4 }, 'كاااك!', 1.2); for (const p of G.riding) p.sat -= 2; }
        else for (const p of G.riding) p.sat -= 3;
      }
    }
  }

  /* ============================ ON FOOT ============================ */
  function updateDriver(dt) {
    const D = G.driver; if (!D) return;
    D.t += dt;
    if (G.fight || G.arrest) return;
    const I = G.input, T = G.tuk;
    const dir = (I.right || I.gas ? 1 : 0) - (I.left || I.brake ? 1 : 0);
    D.holdT = dir ? (D.holdT || 0) + dt : 0;
    const speed = I.run || D.holdT > 1.2 ? 3.6 : 1.8;
    D.vx = dir * speed;
    let nx = D.x + D.vx * dt;
    const accA = (G.L.accidents || []).find(a => a.state !== 'done' && a.spawned && a.x > T.x && a.x - T.x < 120);
    nx = clamp(nx, T.x - 8, G.chase ? T.x + 80 : accA ? Math.max(T.x + 18, accA.x + 8) : T.x + 18);
    // can't walk through a blocking car? allowed to walk along the side — fine
    D.x = nx; if (dir) D.facing = dir;
    D.moving = !!dir; D.running = !!dir && speed > 2;
  }

  /* ============================ NPC UPDATE ============================ */
  function updateNPCs(dt) {
    const L = G.L;
    for (const n of L.npcs) {
      n.t += dt;
      if (n.stateT > 0) { n.stateT -= dt; if (n.stateT <= 0 && (n.state === 'talk' || n.state === 'argue')) n.state = 'idle'; }
      if (n.calmDown > 0) { n.calmDown -= dt; if (n.calmDown <= 0 && !n.resolved) { say(n, 'خلاص... ماشي'); resolveNPC(n, 'time'); } }
      if (n.kind === 'crash' && !n.resolved) { n.timeout -= dt; if (n.timeout <= 0) { say(n, 'أنا مش فاضيلك! سلام'); resolveNPC(n, 'time'); } }
      if (n.state === 'walkToCar') {
        const v = G.traffic.find(t => t.id === (n.vehicleId || '') || t.reenter === n);
        const tx = v ? v.x + v.len * 0.6 : n.x;
        n.x += Math.sign(tx - n.x) * 1.8 * dt; n.facing = Math.sign(tx - n.x) || 1;
        if (Math.abs(tx - n.x) < 0.3 || !v) n.state = 'gone';
      }
      if (n.state === 'fled') { n.x += 3 * dt; n.facing = 1; if (n.x > G.tuk.x + 40) n.state = 'gone'; }
      if (n.line) { n.lineT -= dt; }
      if (G.driver && n.state === 'idle') n.facing = Math.sign(G.driver.x - n.x) || n.facing;
    }
    // blockers that were "calmed" move eventually
    for (const b of L.blockers) if (!b.resolved && b.npc && b.npc.resolved) resolveBlocker(b);
  }

  /* ============================ PASSENGER TICK ============================ */
  function updatePassengers(dt) {
    const T = G.tuk;
    for (const p of G.riding) {
      if (p.state === 'boarding') { p.boardAnim.t += dt; if (p.boardAnim.t > 0.9) { p.state = 'riding'; G.boardingLock = G.riding.some(q => q.state === 'boarding'); } continue; }
      if (p.state !== 'riding') continue;
      p.t += dt;
      // personality effects
      if (p.T.likesFast && Math.abs(T.vx) > G.vp.vmax * 0.8) p.sat += 0.6 * dt;
      if (G.subOn) { if (['student', 'moallem', 'tourist', 'alien'].includes(p.type)) p.sat += 0.5 * dt; else if (['granny', 'mother', 'employee'].includes(p.type)) { p.sat -= 0.6 * dt; if (Math.random() < dt * 0.08) say(p, pick(Math.random, ['وطّي الصوت ده يا ابني!', 'دماغي هتنفجر!', 'إيه الدوشة دي؟']), 2); } }
      if (p.T.smooth && Math.abs(T.vx) > 11) p.sat -= 0.7 * dt;
      if (p.t > p.timeLimit) {
        p.sat -= 1.2 * dt;
        if (!p.lateWarn) { p.lateWarn = true; say(p, pick(Math.random, TT.LINES.late), 2.4); toast(TT.t('اتأخرت على ' + p.T.name + '! لو كمّلت كده هينزل', 'Running late for ' + p.T.en + '!'), 'warn'); }
      }
      p.sat = clamp(p.sat, 0, 100);
      if (p.t > p.timeLimit * 1.6) { passengerLeaves(p, Math.round(p.fare * 0.3), 'late'); continue; }
      // random chatter
      p.chatT = (p.chatT || 6 + Math.random() * 10) - dt;
      if (p.chatT <= 0) { p.chatT = 12 + Math.random() * 14; const lines = TT.LINES.ride[p.type]; if (lines) say(p, pick(Math.random, lines), 2.6); }
    }
    // interactive chat question (one at a time)
    G.chatCool = (G.chatCool == null ? 14 : G.chatCool) - dt;
    if (G.chatCool <= 0 && G.riding.some(p => p.state === 'riding') && !G.activeChat && Math.abs(T.vx) > 2) {
      const p = pick(Math.random, G.riding.filter(q => q.state === 'riding'));
      const c = pick(Math.random, TT.CHATS);
      G.activeChat = { p, c, t: 9 }; G.chatCool = 28 + Math.random() * 18;
      TT.UI.showChat(p, c);
    }
    if (G.activeChat) { G.activeChat.t -= dt; if (G.activeChat.t <= 0 || G.activeChat.p.state !== 'riding') { G.activeChat = null; TT.UI.hideChat(); } }
    // walkers (passengers who got off)
    for (const p of G.walkers) { p.exitAnim.t += dt; }
    G.walkers = G.walkers.filter(p => p.exitAnim.t < 4);
  }
  TT.answerChat = function (i) {
    const A2 = G.activeChat; if (!A2) return;
    const ans = A2.c.a[i]; A2.p.sat = clamp(A2.p.sat + ans.s, 0, 100);
    say({ x: G.tuk.x + 0.5, h: 2.2, isDriver: true }, ans.t, 2);
    setTimeout(() => say(A2.p, ans.s > 0 ? pick(Math.random, ['هههه حلو', 'تسلم يا اسطى', 'ماشي كلامك']) : pick(Math.random, ['ماشي يا سيدي…', 'طب ماشي!', 'ده انت رخم']), 2), 900);
    G.activeChat = null; TT.UI.hideChat();
  };

  /* ============================ END OF LEVEL ============================ */
  function checkEnd() {
    const L = G.L, T = G.tuk;
    if (G.chase || G.cine) return;
    if (G.free) { if (T.x >= L.finish - 4 && G.mode === 'play' && !G.flip && !G.race) nextFreeSegment(); return; }
    if (T.x >= L.finish && G.mode === 'play' && !G.flip) endLevel(false);
  }
  function endLevel(failed) {
    const L = G.L;
    if (G.free) { endFree(failed); return; }
    {
      // riding passengers at the finish leave without paying (their stop was earlier)
      for (const p of G.riding.slice()) passengerLeaves(p, 0, 'late');
      G.mode = 'end'; G.subOn = false; TT.Audio.stopAll();
      const s = G.stats, d = Save.data;
      const fareIncome = s.income + s.tips;
      const st1 = !failed && s.delivered >= L.required;
      const st2 = st1 && fareIncome >= L.target;
      const st3 = st2 && s.violations === 0 && s.flips === 0;
      const ch = failed ? null : challengeEnd(s);
      const stars = st3 ? 3 : st2 ? 2 : st1 ? 1 : 0;
      const key = L.W.id + '-' + L.li;
      if (stars > (d.stars[key] || 0)) d.stars[key] = stars;
      const avgR = s.ratings.length ? s.ratings.reduce((a, b) => a + b, 0) / s.ratings.length : (G.vendor ? 4 : 0);
      const rate = stars ? Math.min(5, stars + (ch && ch.done ? 1 : 0) + (avgR >= 4 || s.flips + s.violations === 0 ? 1 : 0)) : 0;
      d.rates = d.rates || {}; if (rate > (d.rates[key] || 0)) d.rates[key] = rate;
      d.license = d.license || { left: 5 }; rec('levels'); if (stars >= 1 && d.license.left > 0) d.license.left--;
      if (s.violations === 0 && st1) d.stats.cleanLevels++;
      d.stats.stars = Save.totalStars();
      d.snapshot = null;
      Save.write();
      TT.Audio.play(stars ? 'win' : 'error'); if (stars) G.celebrate = 6;
      TT.UI.levelEnd({ reason: G.failReason, failed, vendor: !!G.vendor, stars, st1, st2, st3, ch, rate, stats: s, L, avg: s.ratings.length ? (s.ratings.reduce((a, b) => a + b, 0) / s.ratings.length) : 0 });
    }
  }

  /* ============================ MAIN UPDATE ============================ */
  function update(dt) {
    if (G.mode !== 'play' || G.paused || G.modal) return;
    G.time += dt;
    G.vp = vehParams();
    const T = G.tuk;
    if (G.cine) { updateCine(dt); updateTraffic(dt); updateAccidents(dt); updateCrowd(dt); updateParticles(dt); for (const b of G.bubbles) b.t -= dt; G.bubbles = G.bubbles.filter(b => b.t > 0); return; }
    if (G.exploded) { G.exploded.t += dt; updateParticles(dt); for (const b of G.bubbles) b.t -= dt; G.cam.shake = Math.max(0, G.cam.shake - dt * 20); return; }
    if (G.flip) updateFlip(dt); else physicsStep(dt);
    updateTraffic(dt); updatePeds(dt); updateNPCs(dt); updateDriver(dt); updateFight(dt);
    updatePassengers(dt); updateKnock(dt); updateCoins(); updateRules(dt); updateParticles(dt);
    updateCrowd(dt); updateArrest(dt); if (!G.vendor) autoStation(); updateVendor(dt); updateHealth(dt); radarWarn(); updatePatrol(); updateDriverChatter(dt); updateBanter(dt); updatePhone(dt); updateChallenge(dt); updatePour(dt); updateChase(dt); updateOwner(); updateAccidents(dt); updateEnv(dt); if (G.free) { updateFatigue(dt); updateRace(dt); }
    for (const b of G.bubbles) b.t -= dt; G.bubbles = G.bubbles.filter(b => b.t > 0);
    if (G.driverPose) { G.driverPose.t -= dt; if (G.driverPose.t <= 0) G.driverPose = null; }
    if (T.honkT > 0) T.honkT -= dt;
    // camera
    const focusX = G.driver ? G.driver.x : T.x;
    const look = G.driver ? 1 : clamp(T.vx, -4, 16) * 0.55;
    G.cam.x = lerp(G.cam.x, focusX + look, 1 - Math.exp(-dt * 4));
    const zt = 1 - 0.2 * clamp(Math.abs(T.vx) / 14, 0, 1);
    G.cam.z = lerp(G.cam.z, G.driver ? 1.05 : zt, 1 - Math.exp(-dt * 1.5));
    G.cam.shake = Math.max(0, G.cam.shake - dt * 30);
    // engine sound
    TT.Audio.engine(clamp(Math.abs(T.vx) / G.vp.vmax * 0.7 + T.throttle * 0.3, 0, 1), G.mode === 'play' && !G.exploded && (T.engineOn || G.vp.human) && !G.vp.human && T.occupied === 'driver' && !G.flip && Save.veh().fuel > 0);
    if (!G.vp.human) { const fp = Save.veh().fuel / G.vp.tank; if (fp < 0.2 && !G.lowFuelWarned) { G.lowFuelWarned = true; const ng = G.L.gas.find(g => g.x > T.x); toast(TT.t('⛽ البنزين قرّب يخلص!', '⛽ Fuel is low!') + (ng ? TT.t(' أقرب بنزينة بعد ' + Math.round(ng.x - T.x) + ' م', ' Next station in ' + Math.round(ng.x - T.x) + ' m') : ''), 'warn', 3.5); } if (fp > 0.3) G.lowFuelWarned = false; }
    if (Save.veh().fuel <= 0 && T.engineOn && !G.vp.human) { T.engineOn = false; toast(TT.t('المحرك فصل — البنزين خلص', 'Engine stalled — out of fuel'), 'bad'); }
    if (Save.veh().fuel <= 0 && !G.fuelWarned) { G.fuelWarned = true; TT.UI.fuelEmpty(true); }
    if (Save.veh().fuel > 0 && G.fuelWarned) { G.fuelWarned = false; TT.UI.fuelEmpty(false); }
    // periodic snapshot for resume
    G.lastSnap += dt; if (G.lastSnap > 8) { G.lastSnap = 0; saveSnapshot(); }
    checkEnd();
  }

  /* ============================ RENDER ============================ */
  let canvas, ctx, VW = 960, scale = 1;
  function resize() {
    const w = window.innerWidth, h = window.innerHeight;
    const dpr = Math.min(window.devicePixelRatio || 1, Save.data && Save.data.settings.quality === 'low' ? 1 : 2);
    VW = clamp(VH * w / h, 640, 1400);
    scale = h / VH * dpr;
    canvas.width = Math.round(VW * scale); canvas.height = Math.round(VH * scale);
    canvas.style.width = w + 'px'; canvas.style.height = h + 'px';
    if (VH * w / h > 1400) { canvas.style.width = (1400 * h / VH) + 'px'; }
    A.clearCache();
  }
  TT.resize = () => canvas && resize();
  const sy = h => ROAD_Y - h * PX; // world height (m) → screen y

  function render() {
    if (!G.L) { ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.fillStyle = '#1b1b2f'; ctx.fillRect(0, 0, canvas.width, canvas.height); return; }
    const L = G.L, T = G.tuk, theme = L.W.theme, pal = A.PAL[theme], t = G.time;
    const q = Save.data.settings.quality;
    const shx = (Math.random() - 0.5) * G.cam.shake, shy = (Math.random() - 0.5) * G.cam.shake;
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    // background (screen space)
    A.background(ctx, theme, G.cam.x * PX, VW, VH, t, scale, q, G.env);
    ctx.fillStyle = pal.ground; ctx.fillRect(0, A.HORIZON + 8, VW, VH);
    // world transform
    const z = G.cam.z, pivotX = VW * 0.3;
    const camPx = G.cam.x * PX;
    ctx.setTransform(scale * z, 0, 0, scale * z, scale * (pivotX - camPx * z + shx), scale * (ROAD_Y - ROAD_Y * z + shy));
    const x0 = camPx - pivotX / z - 40, x1 = camPx + (VW - pivotX) / z + 40;
    const mx0 = x0 / PX - 2, mx1 = x1 / PX + 2;
    const vis = (x, m) => x > mx0 - (m || 0) && x < mx1 + (m || 0);
    // ground bands following terrain
    const step = 10;
    const band = (top, bot, col) => { ctx.beginPath(); for (let x = x0; x <= x1 + step; x += step) ctx.lineTo(x, sy(groundAt0(x / PX)) + top); for (let x = x1 + step; x >= x0; x -= step) ctx.lineTo(x, bot == null ? VH / z + 400 : sy(groundAt0(x / PX)) + bot); ctx.closePath(); ctx.fillStyle = col; ctx.fill(); };
    const groundAt0 = x => terrain(L, x); // base terrain without obstacle profiles for bands
    band(-56, -38, pal.side);
    ctx.fillStyle = 'rgba(0,0,0,.08)'; for (let x = Math.floor(x0 / 40) * 40; x < x1; x += 40) ctx.fillRect(x, sy(groundAt0(x / PX)) - 56, 2, 18);
    band(-38, -33, pal.curb);
    band(-33, 22, pal.road);
    band(22, 28, pal.curb);
    band(28, 46, pal.side);
    band(46, null, pal.fore);
    // ---- كباري: فراغ تحت الطريق + أعمدة + سور ----
    for (const br of L.zones.bridge) if (br.b > mx0 && br.a < mx1) {
      const xa = Math.max(br.a, mx0), xb = Math.min(br.b, mx1);
      ctx.beginPath();
      for (let x = xa; x <= xb; x += 0.5) ctx.lineTo(x * PX, sy(groundAt0(x)) + 28);
      for (let x = xb; x >= xa; x -= 0.5) ctx.lineTo(x * PX, sy(groundAt0(x) - bridgeH(L, x)) + 70);
      ctx.closePath();
      const gr = ctx.createLinearGradient(0, ROAD_Y - 60, 0, ROAD_Y + 90);
      if (br.river) { gr.addColorStop(0, '#5aa9d6'); gr.addColorStop(1, '#2f6f99'); } else { gr.addColorStop(0, 'rgba(40,40,50,.55)'); gr.addColorStop(1, pal.fore); }
      ctx.fillStyle = gr; ctx.fill();
      if (br.river) { ctx.fillStyle = 'rgba(255,255,255,.35)'; for (let x = Math.ceil(xa / 3) * 3; x < xb; x += 3) ctx.fillRect(x * PX + Math.sin(t + x) * 6, sy(groundAt0(x) - bridgeH(L, x)) + 55, 18, 2); }
      ctx.fillStyle = '#8d8f94';
      for (let x = Math.ceil(br.a / 14) * 14; x < br.b; x += 14) { if (x < mx0 - 1 || x > mx1 + 1 || bridgeH(L, x) < 0.6) continue; const top = sy(groundAt0(x)) + 28, bot = sy(groundAt0(x) - bridgeH(L, x)) + 72; ctx.fillRect(x * PX - 9, top, 18, bot - top); ctx.fillStyle = 'rgba(0,0,0,.18)'; ctx.fillRect(x * PX + 3, top, 6, bot - top); ctx.fillStyle = '#8d8f94'; }
      ctx.fillStyle = '#b0b3b8'; ctx.beginPath(); for (let x = xa; x <= xb; x += 0.5) ctx.lineTo(x * PX, sy(groundAt0(x)) + 22); for (let x = xb; x >= xa; x -= 0.5) ctx.lineTo(x * PX, sy(groundAt0(x)) + 34); ctx.closePath(); ctx.fill();
      if (br.a > mx0 - 5 && br.a < mx1) { const yy = sy(groundAt0(br.a + 8)) - 100; ctx.fillStyle = '#1b5e20'; A.rr(ctx, br.a * PX + 200, yy, 120, 26, 4); ctx.fill(); A.text(ctx, TT.t('كوبري ' + (L.W.stations[(br.a | 0) % L.W.stations.length]), 'Bridge'), br.a * PX + 260, yy + 13, 10, '#fff'); }
    }
    // lane markings
    ctx.fillStyle = theme === 'country' || theme === 'mars' ? 'rgba(255,255,255,.18)' : 'rgba(255,255,255,.7)';
    // جزيرة في نص الطريق بين الرايح والجاي (المدن)، وخط أصفر مزدوج في الطرق السريعة والريف
    const urban = !['country', 'desert', 'mars'].includes(theme);
    if (urban) {
      band(-21, -9, '#80858c'); band(-21, -16, '#5e9c43'); band(-16, -15, '#a5d6a7');
      ctx.fillStyle = '#212121'; for (let x = Math.floor(x0 / 16) * 16; x < x1; x += 16) { const gy0 = sy(groundAt0(x / PX)); ctx.fillStyle = ((x / 16) | 0) % 2 ? '#fdd835' : '#212121'; ctx.fillRect(x, gy0 - 14, 16, 5); }
      for (let x = Math.floor(x0 / 110) * 110; x < x1; x += 110) { const gy0 = sy(groundAt0(x / PX)), h = A.hash(x * 0.013); if (h > 0.55) { ctx.fillStyle = '#4c8a32'; ctx.beginPath(); ctx.ellipse(x + 20, gy0 - 22, 11, 7, 0, 0, 7); ctx.fill(); ctx.fillStyle = '#6fb04a'; ctx.beginPath(); ctx.ellipse(x + 16, gy0 - 25, 7, 4, 0, 0, 7); ctx.fill(); } else if (h > 0.25) { ctx.fillStyle = '#5d6168'; ctx.fillRect(x + 18, gy0 - 66, 3, 48); ctx.fillRect(x + 18, gy0 - 66, 14, 3); ctx.fillStyle = (G.env && G.env.dark > 0.3) ? '#fff3b0' : '#cfd8dc'; ctx.fillRect(x + 28, gy0 - 64, 6, 3); } }
    } else {
      ctx.fillStyle = theme === 'mars' ? 'rgba(255,255,255,.25)' : '#fbc02d';
      for (let x = Math.floor(x0 / 10) * 10; x < x1; x += 10) { const yy = sy(groundAt0(x / PX)) - 14; ctx.fillRect(x, yy, 10, 1.6); ctx.fillRect(x, yy + 3.2, 10, 1.6); }
    }
    // zones painted on curb (no-parking red/white, quiet blue)
    for (const zn of L.zones.noPark) if (vis(zn.a, 40)) { for (let x = zn.a * PX; x < zn.b * PX; x += 16) { ctx.fillStyle = ((x / 16) | 0) % 2 ? '#fff' : '#d32f2f'; ctx.fillRect(x, sy(groundAt0(x / PX)) - 38, 16, 5); } }
    for (const zn of L.zones.work) if (vis(zn.x, 30)) A.workZone(ctx, zn.x * PX, sy(groundAt0(zn.x)) - 44, t);
    // fore-ground decor stripes
    // back sidewalk objects (y = sidewalk feet line)
    const sideY = x => sy(groundAt0(x)) - 44;
    for (const st of L.stations) if (/كوبري/.test(st.name) && vis(st.x, 14)) { const r = A.bridgeLandmark(ctx, st.x * PX, sideY(st.x) - 6, t, st.name); if (r.show && Math.abs(r.trainX / PX - G.tuk.x) < 18 && G.time - (G.trainHornT || -99) > 12) { G.trainHornT = G.time; TT.Audio.play('train'); } }
    for (const p of L.props) if (vis(p.x, 6) && !L.stations.some(st => /كوبري/.test(st.name) && Math.abs(st.x - p.x) < 9)) A.prop(ctx, p, sideY(p.x), t, theme);
    for (const g of L.gas) if (vis(g.x, 6)) A.gasStation(ctx, g.x * PX, sideY(g.x), t, g.name);
    for (const s of L.signs) if (vis(s.x, 4)) A.sign(ctx, s, sideY(s.x), t);
    for (const zn of L.zones.storm) { }
    for (const tn of L.zones.tunnel) if (tn.b > mx0 && tn.a < mx1) {
      const ax = tn.a * PX, bx = tn.b * PX, top = sy(groundAt0(tn.a)) - 250;
      ctx.fillStyle = '#4a4f58'; ctx.fillRect(ax, top, bx - ax, 212);
      ctx.fillStyle = '#5c626d'; for (let x = ax; x < bx; x += 64) ctx.fillRect(x, top, 4, 212);
      ctx.fillStyle = '#ffd54f'; for (let x = ax + 30; x < bx; x += 160) { ctx.fillRect(x, top + 20, 50, 6); }
      ctx.fillStyle = '#2e7d32'; A.rr(ctx, (ax + bx) / 2 - 60, top + 60, 120, 30, 4); ctx.fill(); A.text(ctx, TT.t('نفق — شغّل الكشافات', 'Tunnel — lights on'), (ax + bx) / 2, top + 75, 11, '#fff');
    }
    for (const st of L.stations) if (vis(st.x, 10)) {
      const hl = G.riding.some(p => p.to === st.idx);
      const busy = st.waiting.length || (G.vendor && st.buyers > 0);
      // علامة الموقف على الأسفلت
      const gy0 = sy(groundAt0(st.x)), col = hl ? '255,202,40' : busy ? '79,195,247' : '255,255,255';
      ctx.fillStyle = 'rgba(' + col + ',.22)'; ctx.fillRect((st.x - 7) * PX, gy0 - 31, 14 * PX, 50);
      ctx.strokeStyle = 'rgba(' + col + ',.9)'; ctx.lineWidth = 3; ctx.setLineDash([14, 10]); ctx.strokeRect((st.x - 7) * PX, gy0 - 31, 14 * PX, 50); ctx.setLineDash([]);
      A.text(ctx, TT.t('موقف', 'STOP'), st.x * PX, gy0 + 6, 16, 'rgba(' + col + ',.85)', 'center', true);
      ctx.save(); ctx.translate(st.x * PX, sideY(st.x)); ctx.scale(1.25, 1.25); ctx.translate(-st.x * PX, -sideY(st.x));
      A.station(ctx, st, sideY(st.x), t, hl);
      ctx.restore();
      if (hl || busy) { const pr = (t * 1.5) % 1; ctx.strokeStyle = 'rgba(' + col + ',' + (1 - pr) + ')'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(st.x * PX, sideY(st.x) - 150, 14 + pr * 22, 0, 7); ctx.stroke(); ctx.fillStyle = 'rgb(' + col + ')'; ctx.beginPath(); ctx.arc(st.x * PX, sideY(st.x) - 150, 12, 0, 7); ctx.fill(); A.text(ctx, hl ? '⬇' : G.vendor ? TT.GOODS[G.vendor.id].icon : '⬆', st.x * PX, sideY(st.x) - 150, 14, '#111'); }
      if (G.vendor && st.buyers > 0) for (let i = 0; i < st.buyers; i++) A.person(ctx, (st.x - 2.5 + i * 1.3) * PX, sideY(st.x) + 2, TT.NPC_LOOKS[(i + st.idx) % TT.NPC_LOOKS.length], 'wave', t + i, { facing: -1 });
      st.waiting.forEach((p, i) => { const px = (st.x - 2.5 + i * 1.3) * PX; A.person(ctx, px, sideY(st.x) + 2, p.look, Math.abs(T.x - st.x) < 25 ? 'wave' : 'idle', t + i, { facing: -1, noKid: false }); if (Math.abs(T.x - st.x) < 30) A.text(ctx, '💰' + p.fare, px, sideY(st.x) - 92, 10, '#ffe082', 'center', true, 3); });
      if (hl) A.text(ctx, TT.t('نزول هنا', 'DROP HERE'), st.x * PX, sideY(st.x) - 178 + Math.sin(t * 5) * 3, 15, '#ffca28', 'center', true, 4);
      else if (busy) A.text(ctx, G.vendor ? TT.t('زباين', 'CUSTOMERS') : TT.t('ركاب مستنيين', 'RIDERS WAITING'), st.x * PX, sideY(st.x) - 178 + Math.sin(t * 5) * 3, 15, '#4fc3f7', 'center', true, 4);
    }
    for (const l of L.lights) if (vis(l.x, 5)) { A.trafficLight(ctx, l.x * PX, sideY(l.x), lightState(l)); A.stopLine(ctx, (l.x - 2) * PX, sy(groundAt0(l.x)) - 8); }
    for (const r of L.radars) if (vis(r.x, 5)) A.radar(ctx, r.x * PX, sideY(r.x), r.flash);
    for (const c of L.checkpoints) if (vis(c.x, 5)) A.checkpoint(ctx, c.x * PX, sy(groundAt0(c.x)) + 6, t, c.state === 'open');
    for (const cw of L.crosswalks) if (vis(cw.x, 4)) A.crosswalk(ctx, cw.x * PX, sy(groundAt0(cw.x)) - 6);
    if (vis(L.finish, 6)) A.finish(ctx, L.finish * PX - 70, sideY(L.finish), G.free ? TT.t('على ' + TT.WORLDS[freeWi(freeData().seg + 1)].name, 'To ' + TT.WORLDS[freeWi(freeData().seg + 1)].en) : TT.t('نهاية الخط', 'FINISH'));
    // NPCs on the sidewalk (bystanders)
    const drawNPC = n => {
      if (n.state === 'gone') return;
      let pose = 'idle';
      if (n.state === 'talk') pose = 'talk'; else if (n.state === 'argue') pose = 'argue';
      else if (n.state === 'walkToCar' || n.state === 'fled') pose = n.state === 'fled' ? 'run' : 'walk';
      else if (n.kind !== 'bystander' && !n.resolved) pose = n.mood > 60 ? 'angry' : 'talk';
      if (G.fight && G.fight.npc === n) pose = G.fight.end ? ({ won: 'apologize', fled: 'run', lost: 'celebrate', separated: 'angry', reconcile: 'apologize' }[G.fight.end]) : G.fight.nAnim;
      const yy = n.kind === 'bystander' ? sideY(n.x) + 2 : sy(groundAt0(n.x)) + 20;
      A.person(ctx, n.x * PX, yy, n.look, pose, n.t, { facing: n.facing || -1 });
      if (G.driver && !G.fight && Math.abs(n.x - G.driver.x) < 1.8) A.text(ctx, '💬 ' + n.name, n.x * PX, yy - 100, 11, '#fff', 'center', true, 3);
      if (n.kind !== 'bystander' && !n.resolved && !G.fight) A.text(ctx, n.mood > 60 ? '😡' : '😠', n.x * PX + 14, yy - 92, 16);
    };
    for (const n of L.npcs) if (n.kind === 'bystander' && vis(n.x, 3)) drawNPC(n);
    // back-lane vehicles
    for (const v of G.traffic) if (v.lane === 1 || v.laneT > 0.5) if (vis(v.x, v.len + 2)) {
      ctx.save(); const yy = sy(groundAt0(v.x)) - 24 * Math.max(v.laneT, v.lane);
      if (v.flip) { ctx.translate(v.x * PX + v.len * PX / 2, 0); ctx.scale(-1, 1); ctx.translate(-(v.x * PX + v.len * PX / 2), 0); }
      A.vehicle(ctx, v.type, v.x * PX, yy, { t, color: v.color, wr: v.wr, scale: 0.9, noText: v.flip }); ctx.restore();
    }
    // obstacles + coins
    for (const o of L.obstacles) if (vis(o.x, 6)) A.obstacle(ctx, o, sy(groundAt0(o.x)), t);
    const cosmic = L.W.id === 'mars';
    for (const c of L.coins) if (!c.taken && vis(c.x, 2)) A.coin(ctx, c.x * PX, sy(groundAt(L, c.x) + c.h) , t, cosmic);
    // peds behind the tuktuk lane
    const drawPed = p => {
      const yy = lerp(sideY(p.x) + 2, sy(groundAt0(p.x)) + 36, clamp(p.depth, 0, 1.1));
      if (p.kind === 'ped' || p.kind === 'alienPed') {
        const pose = p.state === 'hit' ? 'fallen' : p.state === 'angry' ? 'angry' : p.state === 'stand' ? 'argue' : (p.hurry ? 'run' : 'walk');
        A.person(ctx, p.x * PX, yy, p.look, pose, p.t, { facing: p.state === 'angry' ? (T.x > p.x ? 1 : -1) : 1, scale: 0.92 + p.depth * 0.08 });
      } else {
        A.animal(ctx, p.kind, p.x * PX, yy, p.state === 'cross' ? p.t : 0, 0.9 + p.depth * 0.1, 1);
        if (p.state === 'hit') A.text(ctx, '💫', p.x * PX, yy - 70, 18);
      }
    };
    for (const p of G.peds) if (p.depth < 0.55 && vis(p.x, 3)) drawPed(p);
    // walkers (passengers boarding/alighting)
    const drawWalker = p => {
      const st = L.stations[p.state === 'boarding' ? p.from : p.to] || L.stations[0];
      let x, yy, pose = 'walk', a = 1, facing = 1;
      if (p.state === 'boarding') { const k = clamp(p.boardAnim.t / 0.9, 0, 1); x = lerp(p.boardAnim.x0, T.x - 0.6, k); yy = lerp(sideY(st.x) + 2, sy(groundAt0(T.x)) - 4, k); facing = Math.sign(T.x - p.boardAnim.x0) || 1; }
      else { const k = clamp(p.exitAnim.t / 1.6, 0, 1); x = p.exitAnim.x - k * 1.8; yy = lerp(sy(groundAt0(p.exitAnim.x)) - 4, sideY(p.exitAnim.x) + 2, k); facing = -1; a = 1 - clamp((p.exitAnim.t - 3) / 1, 0, 1); pose = p.exitAnim.t > 1.6 ? (p.exitAnim.kind === 'dizzy' ? 'dizzy' : p.exitAnim.kind === 'happy' ? 'wave' : 'angry') : 'walk'; }
      ctx.globalAlpha = a; A.person(ctx, x * PX, yy, p.look, pose, G.time, { facing }); ctx.globalAlpha = 1;
      p._x = x; p._y = yy;
    };
    for (const p of G.walkers) drawWalker(p);
    for (const p of G.riding) if (p.state === 'boarding') drawWalker(p);
    if (G.vendor) for (const b of G.vendor.buyers) { const yy = lerp(sideY(b.x) + 2, sy(groundAt0(b.x)) + 30, clamp(b.depth, 0, 1)); A.person(ctx, b.x * PX, yy, b.look, b.phase === 'buy' ? 'talk' : 'walk', b.t + 1, { facing: b.phase === 'leave' ? -1 : (T.x > b.x ? 1 : -1) }); b._x = b.x; b._y = yy; if (b.phase === 'buy') A.text(ctx, TT.GOODS[G.vendor.id].icon, b.x * PX + 14, yy - 60, 16); }
    if (G.roofFly) { const R = G.roofFly; ctx.save(); ctx.translate(R.x * PX, sy(R.y)); ctx.rotate(R.rot); ctx.fillStyle = '#111'; A.rr(ctx, -62, -6, 124, 10, 5); ctx.fill(); ctx.fillStyle = '#f2c230'; ctx.fillRect(-60, 2, 120, 2.5); ctx.restore(); }
    // main-lane vehicles
    for (const v of G.traffic) if (v.lane === 0 && v.laneT <= 0.5 && vis(v.x, v.len + 2)) {
      const yy = sy(groundAt0(v.x)) - 20 * v.laneT;
      A.vehicle(ctx, v.type, v.x * PX, yy, { t, color: v.color, wr: v.wr });
      if (v.state === 'blocker') { const b = L.blockers.find(b => b.id === v.id); if (b && !b.resolved) A.text(ctx, TT.t('🚫 راكن صف تاني', '🚫 Double-parked'), (v.x + v.len / 2) * PX, yy - 82, 12, '#ff8a80', 'center', true, 3); }
      if (v.state === 'crashed') A.text(ctx, '💥', (v.x + 0.3) * PX, yy - 50, 22);
    }
    // npcs in road (crash / blocker drivers) — standing on the front side of the lane
    for (const n of L.npcs) if (n.kind !== 'bystander' && vis(n.x, 3)) drawNPC(n);
    // ---- TUKTUK ----
    if (G.race && G.race.finishX && vis(G.race.finishX, 6)) A.finish(ctx, G.race.finishX * PX - 70, sideY(G.race.finishX), TT.t('خط السباق', 'RACE FINISH'));
    for (const q of (L.rests || [])) if (vis(q.x, 8)) A.restStop(ctx, q.x * PX, sideY(q.x), t, q.name);
    for (const q of (L.shops || [])) if (vis(q.x, 8)) A.roadShop(ctx, q.x * PX, sideY(q.x), t, q.name);
    if (G.rival) drawRival(t);
    drawTuk(t);
    // driver on foot
    if (G.driver && !G.driver.hidden) {
      const D = G.driver; let pose = D.moving ? (D.running ? 'run' : 'walk') : 'idle';
      if (G.driverPose) pose = G.driverPose.name;
      if (G.fight) { const F = G.fight; pose = F.end ? ({ won: 'celebrate', fled: 'celebrate', lost: 'fallen', separated: 'argue', reconcile: 'apologize' }[F.end]) : (F.pAnimT > 0 ? F.pAnim : 'argue'); }
      if (G.flip) pose = G.flip.phase === 'righting' ? 'push' : (Math.abs(D.x - T.x) < 2.5 ? 'surprised' : pose);
      drawDriver(ctx, D.x * PX, sy(groundAt0(D.x)) + 6, pose, D.t, { facing: D.facing, stars: pose === 'fallen' });
    }
    for (const p of G.peds) if (p.depth >= 0.55 && vis(p.x, 3)) drawPed(p);
    for (const br of L.zones.bridge) if (br.b > mx0 && br.a < mx1) {
      ctx.strokeStyle = '#cfd2d6'; ctx.lineWidth = 3; ctx.beginPath(); let first = true;
      for (let x = Math.max(br.a + 4, mx0); x <= Math.min(br.b - 4, mx1); x += 0.5) { const yy = sy(groundAt0(x)) + 4; if (first) { ctx.moveTo(x * PX, yy); first = false; } else ctx.lineTo(x * PX, yy); }
      ctx.stroke(); ctx.lineWidth = 2;
      for (let x = Math.ceil((br.a + 4) / 1.5) * 1.5; x < br.b - 4; x += 1.5) { if (x < mx0 || x > mx1) continue; const yy = sy(groundAt0(x)); ctx.beginPath(); ctx.moveTo(x * PX, yy + 4); ctx.lineTo(x * PX, yy + 24); ctx.stroke(); }
    }
    // crowd (الناس اللي اتلمت)
    for (const p of G.crowd) { if (!vis(p.x, 3)) continue; const yy = p.depth > 0.5 ? sy(groundAt0(p.x)) + 34 : sideY(p.x) + 2; ctx.globalAlpha = p.gone ? clamp(1 - p.gone / 2.5, 0, 1) : 1; A.person(ctx, p.x * PX, yy, p.look, p.leaving ? 'walk' : p.pose, p.t, { facing: p.leaving ? -p.facing : p.facing, scale: p.depth > 0.5 ? 1.05 : 0.95 }); ctx.globalAlpha = 1; }
    // البوكس
    drawCine(t);
    if (G.arrest) { const R = G.arrest; A.vehicle(ctx, 'box', R.x * PX, sy(groundAt0(R.x)) + 2, { t, wr: R.x * 3, inCage: R.caged ? (c => { A.person(c, 50, -62, driverLook(), 'apologize', t, { scale: 0.75, noShadow: true }); if (R.npc) A.person(c, 95, -62, R.npc.look, 'angry', t, { scale: 0.75, noShadow: true }); }) : null }); }
    // tunnel front portals + ceiling
    for (const tn of L.zones.tunnel) if (tn.b > mx0 - 10 && tn.a < mx1 + 10) {
      const ax = tn.a * PX, bx = tn.b * PX, gy0 = sy(groundAt0(tn.a));
      ctx.fillStyle = '#3b4048'; ctx.fillRect(ax - 30, gy0 - 330, bx - ax + 60, 80);
      ctx.fillStyle = '#7d8590'; ctx.fillRect(ax - 30, gy0 - 330, 30, 400); ctx.fillRect(bx, gy0 - 330, 30, 400);
      ctx.fillStyle = '#9aa1ab'; ctx.fillRect(ax - 34, gy0 - 336, bx - ax + 68, 10);
    }
    // particles
    for (const p of G.particles) A.particle(ctx, p);
    // speech bubbles
    const placedB = [];
    for (const b of G.bubbles) {
      const e = b.ent; let bx, by;
      if (e.isDriver) { const ex = e.follow ? T.x + 0.4 : e.x; bx = ex * PX; by = sy(groundAt0(ex) + e.h + (e.follow ? T.y - geom().H0 : 0)); }
      else if (e.exitAnim || (e.boardAnim && e.state === 'boarding')) { bx = (e._x || T.x) * PX; by = (e._y || ROAD_Y) - 96; }
      else if (e.seat != null && e.state === 'riding') { bx = (T.x - 0.6 + e.seat * 0.25) * PX; by = sy(T.y + (Save.model().kind === 'sport' ? 1.25 : 1.95)); }
      else if (e.depth != null) { bx = e.x * PX; by = lerp(sideY(e.x), sy(groundAt0(e.x)) + 36, clamp(e.depth, 0, 1)) - 96; }
      else if (e.kind) { bx = e.x * PX; by = (e.kind === 'bystander' ? sideY(e.x) : sy(groundAt0(e.x)) + 16) - 98; }
      else { bx = e.x * PX; by = sy(groundAt0(e.x) + (e.h || 2)); }
      for (let k = 0; k < 4 && placedB.some(q => Math.abs(q[0] - bx) < 150 && Math.abs(q[1] - by) < 32); k++) by -= 34;
      placedB.push([bx, by]);
      const md = b.mood || (e.isDriver ? (G.anger > 0 ? 'angry' : 'driver') : e.sat != null ? (e.sat > 72 ? 'happy' : e.sat < 38 ? 'angry' : 'neutral') : 'neutral');
      ctx.globalAlpha = clamp(b.t * 3, 0, 1); A.bubble(ctx, bx, by, b.line, null, md, b.max ? clamp((b.max - b.t) * 6, 0, 1) : 1); ctx.globalAlpha = 1;
    }
    // ---- screen-space overlays ----
    // مؤشر أقرب محطة مهمة لو برة الشاشة
    {
      const tgt = L.stations.find(st => st.x > T.x + 4 && (G.riding.some(p => p.to === st.idx) || st.waiting.length || (G.vendor && st.buyers > 0)));
      const sxS = tgt ? pivotX + (tgt.x * PX - camPx) * z : 0;
      if (tgt && sxS > VW - 30) {
        ctx.setTransform(scale, 0, 0, scale, 0, 0);
        const dist = Math.round(tgt.x - T.x), hl = G.riding.some(p => p.to === tgt.idx), lbl = (hl ? '⬇ ' : '🚏 ') + tgt.name + ' · ' + dist + TT.t('م', 'm') + ' ▶';
        ctx.font = 'bold 13px ' + A.FONT; const w = ctx.measureText(lbl).width + 22, y0 = 230;
        ctx.fillStyle = hl ? 'rgba(255,193,7,.95)' : 'rgba(41,182,246,.95)'; A.rr(ctx, VW - w - 10, y0, w, 26, 13); ctx.fill();
        A.text(ctx, lbl, VW - w / 2 - 10, y0 + 13, 13, '#10131c', 'center', true);
      }
    }
    ctx.setTransform(scale, 0, 0, scale, 0, 0);
    // tunnel / storm darkness with headlight cone
    const inTun = L.zones.tunnel.some(zn => T.x > zn.a - 8 && T.x < zn.b + 8);
    drawEnv(ctx, VW, VH, pivotX, camPx, z, inTun);
    const darkZone = L.zones.storm.find(zn => T.x > zn.a - 15 && T.x < zn.b + 15) || L.zones.tunnel.find(zn => T.x > zn.a - 8 && T.x < zn.b + 8);
    if (darkZone) {
      const isStorm = L.zones.storm.includes(darkZone);
      const edge = Math.min(T.x - (darkZone.a - (isStorm ? 15 : 8)), (darkZone.b + (isStorm ? 15 : 8)) - T.x);
      const k = clamp(edge / (isStorm ? 15 : 8), 0, 1);
      const sxT = pivotX + (T.x * PX - camPx) * z, syT = ROAD_Y - (T.y - 0.2) * PX * z;
      const lr = (T.lights && !G.driver ? 260 + 40 * G.vp.lights : 90) * z;
      const gx = sxT + (T.lights ? lr * 0.55 : 20);
      const grd = ctx.createRadialGradient(gx, syT, 10, gx, syT, lr);
      const c0 = isStorm ? 'rgba(170,120,60,' : 'rgba(5,5,12,';
      grd.addColorStop(0, c0 + (0.05 * k) + ')'); grd.addColorStop(0.7, c0 + (0.6 * k) + ')'); grd.addColorStop(1, c0 + (0.9 * k) + ')');
      ctx.fillStyle = grd; ctx.fillRect(0, 0, VW, VH);
      if (isStorm && q !== 'low') { ctx.strokeStyle = 'rgba(240,200,140,' + (0.4 * k) + ')'; ctx.lineWidth = 1.5; for (let i = 0; i < 40; i++) { const xx = (A.hash(i) * VW * 1.5 - (t * 600 + i * 50) % (VW * 1.5) + VW * 1.5) % (VW * 1.5) - 100, yy = A.hash(i + 99) * VH; ctx.beginPath(); ctx.moveTo(xx, yy); ctx.lineTo(xx - 30, yy + 4); ctx.stroke(); } }
      if (!isStorm) { ctx.fillStyle = 'rgba(40,40,50,' + 0.9 * k + ')'; ctx.fillRect(0, 0, VW, 150); for (let i = 0; i < 6; i++) { ctx.fillStyle = 'rgba(255,220,120,' + 0.8 * k + ')'; ctx.fillRect(((i * 220 - camPx * z) % (VW + 220) + VW + 220) % (VW + 220) - 110, 140, 60, 5); } }
      if (T.lights && !G.driver) { ctx.fillStyle = 'rgba(255,250,200,' + 0.12 * k + ')'; ctx.beginPath(); ctx.moveTo(sxT + 58 * z, syT - 4); ctx.lineTo(sxT + lr * 1.1, syT - lr * 0.35); ctx.lineTo(sxT + lr * 1.1, syT + lr * 0.25); ctx.closePath(); ctx.fill(); }
    }
    if (G.L.W.heat && T.grounded && Math.abs(T.vx) > 0 && q !== 'low') { ctx.fillStyle = 'rgba(255,200,120,.06)'; ctx.fillRect(0, 0, VW, VH); }
  }
  TT.paintColor = function (vehId) {
    const d = Save.data, id = vehId || d.tuktuk, v = d.vehicles[id], m = TT.TUKTUKS.find(t => t.id === id);
    const p = v && v.paint && TT.PAINTS.find(p => p.id === v.paint);
    return p ? p.c : m.color;
  };
  function driverLook(id, outfitId) {
    const d = Save.data, dr = TT.DRIVERS.find(x => x.id === (id || d.driver)) || TT.DRIVERS[0];
    const oid = outfitId || (d.outfitOn || {})[dr.id] || 'default', of = TT.OUTFITS.find(o => o.id === oid);
    if (!of || oid === 'default') return dr.look;
    const L = Object.assign({}, dr.look, of.o); delete L.sheet; for (const k in L) if (L[k] === null) delete L[k]; if (dr.look.hijab) for (const k of ['turban', 'taqiya', 'cap', 'capBack', 'hat', 'beret']) delete L[k];
    return L;
  }
  TT.driverLook = driverLook;
  const SEATS = {
    tuktuk:   { drv: [22, 20.5, 0.78, 'drive'], pax: [[-16, 20.5], [-32, 20.5], [-48, 20.5]], pose: 'sit', sc: 0.78 },
    scooter:  { drv: [-14, 7, 0.85, 'drive'], pax: [[-30, 7]], pose: 'sit', sc: 0.85 },
    bike:     { drv: [-6, 5, 0.85, 'pedal'], pax: [[-22, 21]], pose: 'sit', sc: 0.85 },
    skate:    { drv: [6, -1, 0.95, 'skate'], pax: [[-12, -1]], pose: 'skate', sc: 0.9 },
    microbus: { drv: [86, -7, 0.8, 'drive'], pax: [[-102, -7], [-80, -7], [-58, -7], [-36, -7], [-14, -7], [8, -7], [40, -7]], pose: 'sit', sc: 0.8 },
    sport:    { drv: [-4, 10, 0.56, 'drive'], pax: [[-26, 10]], pose: 'sit', sc: 0.56 }
  };
  function accOpts() {
    const d = Save.data, own = d.accessories || [], on = d.accOn || {};
    const acc = {}; for (const a of own) acc[a] = on[a] !== false;
    return acc;
  }
  TT.accOpts = accOpts;
  function drawTuk(t) {
    const T = G.tuk, L = G.L, vp = G.vp || vehParams();
    const d = Save.data, m = Save.model(), kind = m.kind || 'tuktuk', g = geom();
    const shift = comShift();
    const ca = Math.cos(T.a), sa = Math.sin(T.a);
    const paint = TT.paintColor();
    const acc = accOpts();
    const gy = groundAt(L, T.x);
    const half = (g.front + g.back) / 2 * PX;
    ctx.globalAlpha = clamp(0.35 - (T.y - gy - g.H0) * 0.2, 0.05, 0.35); ctx.fillStyle = '#000'; ctx.beginPath(); ctx.ellipse(T.x * PX, sy(gy) + 2, half, 6, 0, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1;
    const wr = g.wheelR * PX, wcol = d.tireType === 'sand' ? '#d7a85b' : d.tireType === 'farm' ? '#f9a825' : d.tireType === 'space' ? '#38d9ff' : undefined;
    const drawWheel = (x, y, rot) => { if (kind === 'bike') { ctx.strokeStyle = '#222'; ctx.lineWidth = 3; ctx.beginPath(); ctx.arc(x, y, wr - 1.5, 0, Math.PI * 2); ctx.stroke(); ctx.strokeStyle = '#999'; ctx.lineWidth = 0.8; for (let k = 0; k < 6; k++) { const a = rot + k * Math.PI / 3; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(a) * (wr - 2), y + Math.sin(a) * (wr - 2)); ctx.stroke(); } } else if (kind === 'skate') { ctx.beginPath(); ctx.arc(x, y, Math.max(2.5, wr), 0, Math.PI * 2); ctx.fillStyle = '#fafafa'; ctx.fill(); } else A.wheel(ctx, x, y, wr, rot, wcol); };
    if (!G.flip) {
      for (let i = 0; i < 2; i++) {
        const dx = (i ? g.frontX : g.rearX) + shift;
        const rx = dx * ca + g.H0 * sa, ry = dx * sa - g.H0 * ca;
        const wx = T.x + rx, wy = T.y + ry;
        const wg = wheelGround(L, wx, g.wheelR);
        const bottom = Math.max(wy, Math.min(wg, wy + Math.max(0.08, vp.travel)));
        drawWheel(wx * PX, sy(bottom + g.wheelR), T.wheelRot);
      }
    }
    ctx.save();
    ctx.translate(T.x * PX, sy(T.y) - (acc.sub && G.subOn ? Math.abs(Math.sin(t * 16)) * 1.5 : 0));
    ctx.rotate(-T.a);
    ctx.translate(shift * PX, 0);
    const shake = Math.abs(T.vx) > 1 ? 0.4 : 0;
    // صور المركبة من assets/tuktuk (طبقة خلفية → السواق والركاب → طبقة أمامية). لو دهنتها من المرآب بتترسم باللون الجديد
    const tb = A.img(A.P.tuk(m.id, 'back')), tf = A.img(A.P.tuk(m.id, 'front')), te = A.PIMG[kind];
    const cart = G.vendor && kind === 'tuktuk';
    if (cart) A.vendorCart(ctx, G.vendor.id, G.vendor.tier, { color: paint, t, stockFrac: G.vendor.stock / G.vendor.start, sign: TT.t(TT.CART_NAMES[G.vendor.id][0], TT.CART_NAMES[G.vendor.id][1]), lights: T.lights, noRoof: !!Save.veh().roofOff || !!G.exploded, exploded: !!G.exploded, inside: c => insideTuk(c, t) });
    else if (tb && tf && te && !Save.veh().paint && !Save.veh().roofOff && !G.exploded) {
      const sc = 1 / 1.4;
      ctx.drawImage(tb, -te.ax * sc, -te.ay * sc, tb.width * sc, tb.height * sc);
      insideTuk(ctx, t);
      ctx.drawImage(tf, -te.ax * sc, -te.ay * sc, tf.width * sc, tf.height * sc);
      if (kind === 'tuktuk') A.decal(ctx, d.decal, -40, -10);
    } else
      A.playerBody(ctx, kind, {
        color: G.exploded ? '#2b2b2b' : paint, trim: G.exploded ? '#444' : m.trim, noRoof: !!Save.veh().roofOff || !!G.exploded, space: m.space, style: m.style, decal: d.decal, t, shake: shake + (T.honkT > 0 ? 1 : 0), lights: T.lights, damage: 1 - conditionPct(),
        inside: c => insideTuk(c, t)
      });
    if (m.race && !G.exploded && !cart) A.raceDeco(ctx, kind, t);
    A.accessories(ctx, kind, cart ? Object.assign({}, acc, { sub: false, spoiler: false }) : acc, t, { subOn: G.subOn, partyOn: G.partyOn, celebrate: G.celebrate > 0, dirt: Save.veh().dirt || 0, clamped: !!G.clamped });
    if (G.pour) { // السواق بيصب الجركن في التانك
      const P = G.pour, tilt = Math.min(1, P.t / 0.5) * (P.t > P.dur - 0.3 ? (P.dur - P.t) / 0.3 : 1), tx = -g.back * PX * 0.62, ty = -g.H0 * PX * 0.2 - 30;
      ctx.save(); ctx.translate(tx, ty); ctx.rotate(-1.1 * tilt); ctx.fillStyle = '#c62828'; A.rr(ctx, -12, -16, 24, 30, 4); ctx.fill(); ctx.strokeStyle = '#7f0000'; ctx.lineWidth = 1.5; ctx.stroke();
      ctx.fillStyle = '#fbc02d'; ctx.fillRect(-12, -4, 24, 3); ctx.strokeStyle = '#424242'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-6, -16); ctx.lineTo(-6, -22); ctx.lineTo(6, -22); ctx.lineTo(6, -16); ctx.stroke();
      ctx.fillStyle = '#424242'; ctx.fillRect(8, -18, 10, 4); ctx.restore();
      if (tilt > 0.6) { ctx.strokeStyle = 'rgba(255,193,7,.85)'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(tx - 4, ty - 20); ctx.quadraticCurveTo(tx - 10, ty - 6, tx - 6, ty + 14); ctx.stroke(); for (let i = 0; i < 3; i++) { const dy = ((t * 60 + i * 9) % 22); ctx.fillStyle = 'rgba(255,213,79,.9)'; ctx.beginPath(); ctx.arc(tx - 7, ty - 4 + dy, 2, 0, 7); ctx.fill(); } }
      const bw = 60, pr = Math.min(1, P.given / (P.amt || 1)); ctx.fillStyle = 'rgba(0,0,0,.6)'; A.rr(ctx, tx - bw / 2, ty - 62, bw, 12, 6); ctx.fill(); ctx.fillStyle = '#ffb300'; A.rr(ctx, tx - bw / 2 + 2, ty - 60, (bw - 4) * pr, 8, 4); ctx.fill(); A.text(ctx, '⛽', tx - bw / 2 - 10, ty - 56, 12);
    }
    if (G.flip) { const rx = g.rearX * PX, fx = g.frontX * PX, wy = (g.H0 - g.wheelR) * PX; drawWheel(rx, wy, t * 6); drawWheel(fx, wy, t * 6); }
    // ---- إضاءة المركبة: كشافات قدام + فوانيس ورا + نور الفرامل ----
    const LP = { tuktuk: [[60, -8], [-73, -24]], microbus: [[114, -18], [-120, -24]], scooter: [[30, -30], [-36, -8]], bike: [[24, -14], [-24, -4]], sport: [[98, -8], [-99, -11]] }[kind];
    if (LP && !G.exploded) {
      const dk = G.env ? G.env.dark + (G.env.rain || 0) * 0.3 : 0, braking = G.input.brake > 0 && T.occupied === 'driver' && Math.abs(T.vx) > 0.3;
      ctx.save(); ctx.globalCompositeOperation = 'lighter';
      if (T.lights) { const [hx, hy] = LP[0], gl = ctx.createRadialGradient(hx, hy, 1, hx, hy, 22 + dk * 18); gl.addColorStop(0, 'rgba(255,250,215,' + (0.55 + dk * 0.4) + ')'); gl.addColorStop(1, 'rgba(255,250,215,0)'); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(hx, hy, 22 + dk * 18, 0, 7); ctx.fill(); }
      const tail = braking ? 0.9 : T.lights ? 0.45 + dk * 0.3 : 0;
      if (tail > 0) { const [bx, by] = LP[1], r2 = braking ? 20 : 12, gl = ctx.createRadialGradient(bx, by, 1, bx, by, r2); gl.addColorStop(0, 'rgba(255,40,30,' + tail + ')'); gl.addColorStop(1, 'rgba(255,40,30,0)'); ctx.fillStyle = gl; ctx.beginPath(); ctx.arc(bx, by, r2, 0, 7); ctx.fill(); }
      ctx.restore();
    }
    ctx.restore();
    if (G.flip) { for (let i = 0; i < 3; i++) { const a = t * 4 + i * 2.1; A.star(ctx, T.x * PX + Math.cos(a) * 30, sy(T.y + 1.6) + Math.sin(a) * 6, 5, '#ffd400'); } }
  }
  function insideTuk(c, t) {
    const T = G.tuk, kind = Save.model().kind || 'tuktuk', S = SEATS[kind];
    if (G.vendor) { const cart = kind === 'tuktuk'; if (!cart) A.vendorLoad(c, kind, G.vendor.id, t, G.vendor.stock / G.vendor.start); if ((G.vendor.id === 'potato' || (G.vendor.id === 'bread' && G.vendor.tier)) && Math.random() < 0.15 && !G.paused) G.particles.push({ kind: 'smoke', x: (T.x - (cart ? 0.78 : 0.3)) * PX, y: ROAD_Y - (T.y + (cart ? 1.45 : 1.25)) * PX, vx: -8 - T.vx * 5, vy: -25, r: 3, life: 1.4, max: 1.4, col: '#9e9e9e', a: 0.45, world: true, grow: 9 }); }
    for (const p of G.riding) {
      if (p.state !== 'riding') continue;
      const sp = S.pax[p.seat] || S.pax[0];
      A.person(c, sp[0], sp[1], p.look, S.pose, t + p.seat, { scale: S.sc, noShadow: true, noKid: true, expr: p.sat > 75 ? 'happy' : p.sat < 35 ? 'angry' : 'normal' });
      if (p.look.kid && S.pax[p.seat + 1]) A.person(c, S.pax[p.seat + 1][0], S.pax[p.seat + 1][1], TT.KID_LOOK, S.pose, t, { scale: S.sc, noShadow: true });
    }
    if (T.occupied === 'owner') { const dv = S.drv; A.person(c, dv[0], dv[1], OWNER_LOOK, 'drive', t, { scale: dv[2], noShadow: true, expr: 'angry' }); }
    if (T.occupied === 'driver' && !G.driverOut) { const dv = S.drv; drawDriver(c, dv[0], dv[1], dv[3], dv[3] === 'pedal' ? (T.pedal || 0) / 6 : t, { scale: dv[2], noShadow: true, steer: T.lean, look: T.lean * 0.1, pedal: T.pedal, expr: T.honkT > 0 ? 'angry' : undefined }); }
  }

  /* ============================ INPUT ============================ */
  const keys = {};
  function keyChange(e, down) {
    if (e.target && (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT')) return;
    const k = e.key.toLowerCase(); const code = e.code;
    if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' '].includes(k)) e.preventDefault();
    const was = keys[code]; keys[code] = down;
    const I = G.input;
    I.gas = keys.KeyW || keys.ArrowUp ? 1 : (TT.UI.touch.gas ? 1 : 0);
    I.brake = keys.KeyS || keys.ArrowDown ? 1 : (TT.UI.touch.brake ? 1 : 0);
    I.left = keys.KeyA || keys.ArrowLeft ? 1 : (TT.UI.touch.left ? 1 : 0);
    I.right = keys.KeyD || keys.ArrowRight ? 1 : (TT.UI.touch.right ? 1 : 0);
    I.hand = keys.KeyH ? 1 : (TT.UI.touch.hand ? 1 : 0);
    I.run = keys.ShiftLeft || keys.ShiftRight ? 1 : (TT.UI.touch.run ? 1 : 0);
    if (down && !was) {
      if (code === 'Escape' || code === 'KeyP') { TT.UI.togglePause(); return; }
      if (G.mode !== 'play' || G.paused || G.modal) { if (G.modal && code === 'Escape') TT.UI.closeModal(); return; }
      if (G.fight) { if (code === 'KeyJ' || code === 'Space') TT.fightAction('push'); if (code === 'KeyK' || code === 'KeyS' || code === 'ArrowDown') TT.fightAction('dodge'); if (code === 'KeyR') TT.fightAction('peace'); return; }
      if (G.flip && G.flip.phase === 'down') { if (code === 'Space' || code === 'KeyE') TT.UI.flipSelf(); return; }
      if (code === 'Space') { if (G.driver) TT.doAction(); else TT.horn(); }
      if (code === 'KeyE') TT.doAction();
      if (code === 'KeyF') { if (G.driver) TT.enterTuk(); else TT.exitTuk(); }
      if (code === 'KeyL') TT.toggleLights();
      if (code === 'KeyI') TT.ignition();
      if (code === 'KeyC' && G.vendor) TT.vendorCall();
      if (code === 'Tab') { e.preventDefault(); TT.UI.toggleBigMap(); }
      if (code === 'KeyM') TT.UI.setMode(TT.cycleMode());
    }
  }
  TT.syncTouchInput = function () { keyChange({ key: '', code: '__touch', target: null, preventDefault() { } }, false); };

  /* ============================ LOOP ============================ */
  let last = 0, acc = 0, hudT = 0;
  function frame(ts) {
    const dtReal = Math.min(0.1, (ts - last) / 1000 || 0); last = ts;
    acc += dtReal;
    let n = 0;
    while (acc >= DT && n < 24) { update(DT); acc -= DT; n++; }
    if (n >= 24) acc = 0;
    render();
    hudT += dtReal; if (hudT > 0.1) { hudT = 0; TT.UI.hud(); }
    requestAnimationFrame(frame);
  }

  /* ============================ PUBLIC API ============================ */
  TT.Game = {
    G, startLevel, saveSnapshot, update, render, startFree: (n) => TT.Game_startFree(n),
    pause(p) { G.paused = p; if (p) { saveSnapshot(); TT.Audio.engine(0, false); TT.Audio.rain && TT.Audio.rain(0); if (G.subOn) TT.Audio.bass(false); } else if (G.subOn) TT.Audio.bass(true); },
    quit() { saveSnapshot(); G.mode = 'menu'; G.L = null; G.subOn = false; TT.Audio.stopAll(); },
    restart() { const L = G.L; Save.data.snapshot = null; startLevel(L.wi, L.li, false); },
    seatsUsed, conditionPct, kmh, groundAt: x => groundAt(G.L, x),
    // test hooks (used by tools/test.html and headless tests)
    _physicsStep: physicsStep, _genLevel: genLevel, _violation: violation, _deliver: deliver
  };
  window.addEventListener('load', () => {
    Save.load();
    try { TT.applyCustomLines(Save.data.customLines || {}); } catch (e) { }
    canvas = document.getElementById('game'); ctx = canvas.getContext('2d');
    resize(); window.addEventListener('resize', resize);
    window.addEventListener('keydown', e => keyChange(e, true));
    window.addEventListener('keyup', e => keyChange(e, false));
    window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; for (const k in G.input) G.input[k] = 0; });
    document.addEventListener('visibilitychange', () => { if (document.hidden && G.mode === 'play') { TT.UI.togglePause(true); } });
    A.loadAssets();
    TT.UI.init();
    requestAnimationFrame(frame);
  });
})();
