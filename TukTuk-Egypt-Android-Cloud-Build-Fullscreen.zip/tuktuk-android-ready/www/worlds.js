/* =====================================================================
   توك توك مصر – Tuk Tuk Egypt Adventure
   worlds.js — بيانات العوالم والركاب والحوارات (Data only, no logic)
   لإضافة عالم جديد: أضف عنصرًا إلى TT.WORLDS بنفس الشكل، وأضف رسام خلفية
   باسم theme في art.js (TT.Art.backgrounds). المحرك لا يحتاج تعديل.
   ===================================================================== */
window.TT = window.TT || {};

/* ---------- أنواع العوائق ----------
   kind: 'profile' = يغيّر شكل الأرض (مطب/حفرة) فيؤثر على العجلات فيزيائيًا
         'surface' = يغيّر الاحتكاك (مياه/زيت/رمل)
         'knock'   = جسم صغير يطير لما تخبطه (مخروط/صندوق) ويعمل ضرر بسيط
         'solid'   = جسم ثابت صغير يتصرّف كنتوء حاد (حجر/كفر)            */
TT.OBSTACLES = {
  bump:    { kind: 'profile', h: 0.15, w: 0.85, name: 'مطب',   en: 'Speed bump', warn: true },
  pothole: { kind: 'profile', h: -0.28, w: 1.2, name: 'حفرة',  en: 'Pothole',    warn: true },
  crater:  { kind: 'profile', h: -0.32, w: 2.4, name: 'فوهة',  en: 'Crater',     warn: true },
  ramp:    { kind: 'profile', h: 0.55, w: 4.5, ramp: true, name: 'منحدر', en: 'Ramp' },
  rock:    { kind: 'profile', h: 0.20, w: 0.6, name: 'حجارة', en: 'Rock' },
  tire:    { kind: 'profile', h: 0.16, w: 0.7, name: 'كفر',   en: 'Tire' },
  water:   { kind: 'surface', grip: 0.55, drag: 0.6, w: 3.2, name: 'مياه', en: 'Water' },
  oil:     { kind: 'surface', grip: 0.25, drag: 0.0, w: 2.6, name: 'زيت',  en: 'Oil' },
  sand:    { kind: 'surface', grip: 0.5, drag: 1.5, w: 7, sandy: true, name: 'غرز رمل', en: 'Soft sand' },
  cone:    { kind: 'knock', w: 0.45, dmg: 2, name: 'مخروط', en: 'Cone' },
  box:     { kind: 'knock', w: 0.8, dmg: 5, name: 'صندوق', en: 'Box' },
  chicken: { kind: 'knock', w: 0.45, dmg: 0, animal: true, name: 'فرخة', en: 'Chicken' }
};

/* ---------- أنواع الركاب ---------- */
TT.PASSENGER_TYPES = {
  student:  { name: 'طالب مدرسة', en: 'Student', look: { shirt: '#f4f4f4', pants: '#5b6b8a', skin: '#c98f62', hair: '#1d1410', bag: '#2a6ad1', small: 0.86 }, negotiate: 0.15, likesFast: true, patience: 0.8 },
  employee: { name: 'موظف', en: 'Employee', look: { shirt: '#9fc7ea', pants: '#2b2f3a', skin: '#b97f55', hair: '#151010', tie: '#a22', glasses: true }, negotiate: 0.35, patience: 0.75 },
  mother:   { name: 'أم معاها عيالها', en: 'Mom with kids', look: { shirt: '#7a3b6e', pants: '#7a3b6e', skin: '#d39a6c', hijab: '#e7b84a', dress: true, kid: true }, negotiate: 0.45, smooth: true, patience: 1.0, seats: 2 },
  merchant: { name: 'تاجر', en: 'Merchant', look: { shirt: '#e8e2d0', pants: '#e8e2d0', skin: '#a8714a', galabeya: true, cap: '#f5f5f5', mustache: true, sack: true }, negotiate: 0.25, patience: 1.0 },
  farmer:   { name: 'فلاح', en: 'Farmer', look: { shirt: '#6d5a3e', pants: '#6d5a3e', skin: '#9b6640', galabeya: true, turban: '#f2efe6', mustache: true }, negotiate: 0.5, patience: 1.2 },
  tourist:  { name: 'سائح', en: 'Tourist', look: { shirt: '#f2a03c', pants: '#d8c08a', skin: '#f2c9a5', hair: '#e6c15a', hat: '#e9d9a8', camera: true, shorts: true }, negotiate: 0.75, smooth: true, tips: 1.6, patience: 1.1 },
  moallem:  { name: 'المعلم', en: 'The Boss', look: { shirt: '#2e2e2e', pants: '#2e2e2e', skin: '#9c6a45', galabeya: true, belly: true, shades: true, mustache: true }, negotiate: 0.2, offended: 0.35, tips: 2, patience: 0.7, comic: true },
  granny:   { name: 'الحاجة', en: 'Granny', look: { shirt: '#222', pants: '#222', skin: '#c58c63', hijab: '#222', dress: true, stick: true }, negotiate: 0.6, smooth: true, patience: 1.4, comic: true },
  alien:    { name: 'راكب فضائي', en: 'Alien', look: { alien: true, shirt: '#6a3ccf', pants: '#6a3ccf', skin: '#7bd36a' }, negotiate: 0.6, patience: 1.0, comic: true },
  astro:    { name: 'رائد فضاء', en: 'Astronaut', look: { astro: true, shirt: '#e9edf2', pants: '#e9edf2', skin: '#c98f62' }, negotiate: 0.4, patience: 0.9 }
};

/* ---------- كلام الركاب (عامية مصرية) ---------- */
TT.LINES = {
  board: ['على المحطة الجاية يا اسطى', 'بسرعة لو سمحت متأخر', 'هات الباقي بعدين', 'الله يكرمك يا ريس', 'شغل الكاسيت يا عم'],
  ride: {
    student:  ['الامتحان كمان ربع ساعة يا عم!', 'دوس دوس!', 'هو التوكتوك ده بيطير؟'],
    employee: ['المدير هيرفدني لو اتأخرت', 'الزحمة دي كل يوم كده؟', 'ممكن تقفل الكاسيت؟ عندي ميتنج'],
    mother:   ['بالراحة يا ابني العيال معايا', 'يا ولد اقعد ساكت!', 'ربنا يسترها'],
    merchant: ['البضاعة دي غالية، خلي بالك', 'السوق النهارده نار', 'الدنيا غليت يا اسطى'],
    farmer:   ['الأرض محتاجة مية', 'الجاموسة ولدت امبارح', 'على المسقى اللي جاية'],
    tourist:  ['Wow! Very nice tuk tuk!', 'شُكرَن! هبيبي!', 'Pyramids this way?'],
    moallem:  ['انت عارف انت شايل مين؟', 'هات يا ابني الطريق المختصر', 'خلّي بالك من الجلابية'],
    granny:   ['بالراحة يا ضنايا ركبي!', 'انت ابن مين يا حبيبي؟', 'زمان كنا بنركب الكارو', 'شغّل القرآن يا ابني مش الأغاني', 'ربنا يسترها عليك ويرزقك'],
    alien:    ['بيب بوب... كُشري؟', 'كوكبكم ده فيه زحمة أكتر من عندنا', 'إيه الكائن الأخضر ده؟ آه دي أنا'],
    astro:    ['الأكسجين كفاية لحد المحطة', 'الجاذبية هنا بتعمل حركات', 'المريخ أوسع من الدقي']
  },
  happy: ['تسلم إيدك يا اسطى!', 'أحلى سواق في مصر', 'خد الباقي حلاوة'],
  angry: ['إيه ده يا عم انت سايق ولا بتحرت؟', 'نزلني هنا!', 'الرحلة دي بقت فيلم رعب'],
  late:  ['اتأخرنا خالص!', 'كده كتير والله', 'هو احنا رايحين أسوان؟'],
  dizzy: ['الدنيا بتلف بيا...', 'أنا فين؟', 'مش راكبة توكتوك تاني!'],
  honkPed: ['إيه يا عم! ما تستنى!', 'شايفني يعني!', 'حاضر حاضر!'],
  pedHit: ['آآآه! مش شايف قدامك؟!', 'حاسب يا جدع!', 'هشتكيك!']
};

/* أسئلة كوميدية أثناء الرحلة: اختيار الرد يغيّر رضا الراكب */
TT.CHATS = [
  { q: 'ممكن تعلّي الأغاني شوية؟', a: [{ t: 'حاضر يا باشا 🎵', s: 10 }, { t: 'الكاسيت بايظ والله', s: -5 }] },
  { q: 'هو انت ليه ماشي من هنا؟', a: [{ t: 'ده الطريق الأسرع يا فندم', s: 6 }, { t: 'انا السواق ولا انت؟', s: -12 }] },
  { q: 'معاك فكة مية جنيه؟', a: [{ t: 'نتصرف متقلقش', s: 8 }, { t: 'مفيش فكة خالص!', s: -6 }] },
  { q: 'الجو حر أوي النهارده', a: [{ t: 'افتح الستارة الجانبية 😄', s: 6 }, { t: 'ده التوكتوك بتكييف طبيعي', s: 3 }] },
  { q: 'ممكن نعدّي على الصيدلية دقيقة؟', a: [{ t: 'ماشي بس بسرعة', s: 9 }, { t: 'مش في الأجرة يا باشا', s: -4 }] },
  { q: 'انت بتشجع الأهلي ولا الزمالك؟', a: [{ t: 'اللي انت بتشجعه 😉', s: 7 }, { t: 'الإسماعيلي يا عم!', s: 2 }] }
];

/* ---------- السائقين (تصميمات أصلية) ---------- */
TT.DRIVERS = [
  { id: 'sayed', name: 'عم سيد', en: 'Uncle Sayed', desc: 'هادي وخبرة — الركاب بيرتاحوا معاه', look: { skin: '#a9714b', shirt: '#2f7d4f', pants: '#3a3a44', hair: '#2a2a2a', taqiya: '#efe6d2', mustache: true, vest: '#5a3d2b' }, perk: { sat: 6 } },
  { id: 'hamo', name: 'حمّو', en: 'Hamo', desc: 'شاب سريع — فرامل ورد فعل أحسن', look: { skin: '#c48a5c', shirt: '#1e88c9', pants: '#23262f', hair: '#120c08', capBack: '#f2c230', stripes: true }, perk: { brake: 0.08 } },
  { id: 'adel', name: 'الأسطى عادل', en: 'Master Adel', desc: 'ميكانيكي قديم — الضرر عليه أقل', look: { skin: '#8f5f3d', shirt: '#c96a2b', pants: '#4b3b2a', hair: '#555', beret: '#3d3d3d', mustache: true, beard: true }, perk: { dmg: 0.8 } }
];

/* ---------- موديلات التوكتوك ---------- */
/* ---------- المركبات (توكتوك + سكوتر + ميكروباص + عجلة + سكيت) ----------
   kind = شكل الرسم والفيزياء. seats = عدد الركاب. fuel=false = بالمجهود (من غير بنزين)
   geom: rearX/frontX = مكان العجل من مركز الثقل (متر)، H0 = ارتفاع المركز فوق العجل،
         wheelR = نص قطر العجلة، roof = ارتفاع أعلى نقطة، inertia = القصور الدوراني */
TT.TUKTUKS = [
  { id: 'basic', kind: 'tuktuk', name: 'التوكتوك العادي', en: 'Basic tuk tuk', price: 0, power: 1.0, vmax: 12.5, tank: 100, seats: 3, fuel: true, color: '#1f8f3a', trim: '#f2c230', space: false, req: 0 },
  { id: 'prince', kind: 'tuktuk', name: 'البرنس', en: 'The Prince', price: 3500, power: 1.25, vmax: 14.5, tank: 115, seats: 3, fuel: true, color: '#141414', trim: '#f2c230', space: false, req: 4 },
  { id: 'space', kind: 'tuktuk', name: 'توكتوك الفضاء', en: 'Space Tuk', price: 9000, power: 1.35, vmax: 15.5, tank: 130, seats: 3, fuel: true, color: '#c9d2dc', trim: '#38d9ff', space: true, req: 8 },
  { id: 'skate', kind: 'skate', name: 'سكيت', en: 'Skateboard', price: 150, power: 0.5, vmax: 6.5, tank: 0, seats: 1, fuel: false, color: '#ff7043', trim: '#263238', req: 0 },
  { id: 'bike', kind: 'bike', name: 'عجلة', en: 'Bicycle', price: 350, power: 0.6, vmax: 8, tank: 0, seats: 1, fuel: false, color: '#1e88e5', trim: '#eceff1', req: 1 },
  { id: 'scooter', kind: 'scooter', name: 'سكوتر', en: 'Scooter', price: 1800, power: 0.95, vmax: 14, tank: 60, seats: 1, fuel: true, color: '#e53935', trim: '#fafafa', req: 2 },
  { id: 'microbus', kind: 'microbus', name: 'ميكروباص', en: 'Microbus', price: 7000, power: 1.15, vmax: 14, tank: 170, seats: 7, fuel: true, color: '#f5f5f5', trim: '#1565c0', req: 5 }
];
TT.GEOM = {
  tuktuk:   { rearX: -0.85, frontX: 0.95, H0: 0.62, wheelR: 0.30, roof: 1.2, front: 1.3, back: 1.5, inertia: 0.55, len: 2.8 },
  scooter:  { rearX: -0.62, frontX: 0.66, H0: 0.55, wheelR: 0.24, roof: 1.45, front: 0.95, back: 0.9, inertia: 0.42, len: 1.8 },
  bike:     { rearX: -0.52, frontX: 0.55, H0: 0.62, wheelR: 0.34, roof: 1.5, front: 0.9, back: 0.85, inertia: 0.45, len: 1.75 },
  skate:    { rearX: -0.32, frontX: 0.32, H0: 0.16, wheelR: 0.09, roof: 1.75, front: 0.45, back: 0.45, inertia: 0.4, len: 0.9 },
  microbus: { rearX: -1.55, frontX: 1.45, H0: 0.78, wheelR: 0.34, roof: 1.75, front: 2.45, back: 2.55, inertia: 1.6, len: 5.0 },
  sport:    { rearX: -1.25, frontX: 1.3, H0: 0.52, wheelR: 0.32, roof: 1.05, front: 2.2, back: 2.1, inertia: 1.35, len: 4.3 }
};

/* ---------- اكسسوارات المرآب ---------- */
TT.ACCESSORIES = [
  { id: 'sub', name: 'سماعة صب', en: 'Subwoofer', icon: '🔊', price: 900, desc: 'بيس يهز الشارع — الشباب بيحبوه والكبار بيتضايقوا' },
  { id: 'party', name: 'نور زينة', en: 'Festive lights', icon: '✨', price: 700, desc: 'لمبات ملونة حوالين المركبة بتنور وتطفي، وبتحتفل لما توصّل راكب' },
  { id: 'neon', name: 'نيون تحت المركبة', en: 'Underglow neon', icon: '🟣', price: 800, desc: 'إضاءة نيون تحت الشاسيه' },
  { id: 'musicHorn', name: 'كلاكس مزيكا', en: 'Musical horn', icon: '🎺', price: 500, desc: 'الكلاكس بيعزف لحن بدل التزميرة العادية' },
  { id: 'flag', name: 'علم مصر', en: 'Egypt flag', icon: '🇪🇬', price: 200, desc: 'علم بيرفرف فوق المركبة' },
  { id: 'spoiler', name: 'جناح رياضي', en: 'Spoiler', icon: '🪽', price: 600, desc: 'شكل رياضي (للتوكتوك والميكروباص)' }
];

/* ---------- التطويرات ---------- */
TT.UPGRADES = [
  { id: 'engine', name: 'المحرك', en: 'Engine', icon: '⚙️', base: 250 },
  { id: 'speed', name: 'السرعة القصوى', en: 'Top speed', icon: '⏱️', base: 220 },
  { id: 'brakes', name: 'الفرامل', en: 'Brakes', icon: '🛑', base: 180 },
  { id: 'suspension', name: 'التعليق', en: 'Suspension', icon: '🔩', base: 200 },
  { id: 'tires', name: 'الإطارات', en: 'Tires', icon: '🛞', base: 180 },
  { id: 'fuel', name: 'استهلاك الوقود', en: 'Fuel economy', icon: '⛽', base: 180 },
  { id: 'lights', name: 'الكهرباء والكشافات', en: 'Lights', icon: '💡', base: 150 }
];
TT.TIRE_TYPES = [
  { id: 'std', name: 'إطارات عادية', en: 'Standard', price: 0, sand: 0, farm: 0 },
  { id: 'farm', name: 'إطارات زراعي', en: 'Farm tires', price: 600, sand: 0.25, farm: 0.6 },
  { id: 'sand', name: 'إطارات رمال', en: 'Sand tires', price: 1200, sand: 0.8, farm: 0.4 },
  { id: 'space', name: 'إطارات فضائية', en: 'Space tires', price: 2500, sand: 0.7, farm: 0.5, space: true }
];
TT.PAINTS = [
  { id: 'green', c: '#1f8f3a', price: 0 }, { id: 'black', c: '#151515', price: 150 }, { id: 'red', c: '#c62828', price: 150 },
  { id: 'blue', c: '#1e5bb8', price: 150 }, { id: 'yellow', c: '#f2b705', price: 200 }, { id: 'purple', c: '#6a2c91', price: 250 }
];
TT.DECALS = [
  { id: 'none', name: 'بدون', price: 0 }, { id: 'eye', name: 'عين حورس', price: 120 },
  { id: 'crown', name: 'التاج', price: 180 }, { id: 'flag', name: 'علم مصر', price: 150 }, { id: 'pharaoh', name: 'الفرعون', price: 260 }
];

/* ---------- العوالم ----------
   كل عالم = إعدادات + أوزان العوائق + المركبات + القواعد. المراحل تتولّد
   بشكل محدد (seeded) من هذه البيانات، فنفس المرحلة دائمًا نفس الشكل. */
TT.WORLDS = [
  {
    id: 'streets', name: 'شوارع مصر', en: 'Egypt Streets', theme: 'streets', unlockStars: 0,
    gravity: 9.8, fuelName: 'بنزين', fuelPrice: 0.9, levels: 50, terrain: 0,
    obstacles: { bump: 5, pothole: 4, water: 2, oil: 1, cone: 2, box: 1, tire: 1 },
    vehicles: ['car', 'microbus', 'tuktuk', 'bus', 'police', 'moto'], traffic: 0.8,
    passengers: ['student', 'employee', 'mother', 'merchant', 'tourist', 'moallem', 'granny'],
    stations: ['ميدان الجيزة', 'السيدة زينب', 'باب الشعرية', 'العتبة', 'شبرا', 'إمبابة', 'بولاق', 'الدقي', 'المنيل', 'روض الفرج', 'الحسين', 'العباسية'],
    features: { lights: true, radars: true, quiet: true, noParking: true, checkpoints: true, crosswalks: true, blockers: true, works: true },
    peds: ['ped'], speedLimit: 40
  },
  {
    id: 'country', name: 'الريف المصري', en: 'Countryside', theme: 'country', unlockStars: 15,
    gravity: 9.8, fuelName: 'بنزين', fuelPrice: 0.9, levels: 50, terrain: 0.25, roughness: 0.04,
    obstacles: { bump: 3, pothole: 5, water: 3, rock: 2, chicken: 2, tire: 1 },
    vehicles: ['tractor', 'cart', 'tuktuk', 'microbus', 'moto'], traffic: 0.6,
    passengers: ['farmer', 'student', 'mother', 'merchant', 'granny'],
    stations: ['كفر الشيخ مبروك', 'سوق الثلاث', 'موقف المواصلات', 'عزبة النخل', 'الكوبري الصغير', 'المسقى', 'دوار العمدة', 'الجمعية الزراعية', 'مدرسة القرية'],
    features: { villageZones: true, crosswalks: true, checkpoints: true, blockers: true },
    peds: ['ped', 'cow', 'buffalo'], speedLimit: 30, rules: ['village']
  },
  {
    id: 'alex', name: 'إسكندرية', en: 'Alexandria', theme: 'alex', unlockStars: 35,
    gravity: 9.8, fuelName: 'بنزين', fuelPrice: 0.95, levels: 50, terrain: 0.15,
    obstacles: { bump: 4, pothole: 3, water: 4, oil: 1, cone: 1, tire: 1 },
    vehicles: ['car', 'microbus', 'tuktuk', 'bus', 'police', 'moto'], traffic: 0.9,
    passengers: ['tourist', 'employee', 'student', 'merchant', 'mother', 'moallem'],
    stations: ['محطة الرمل', 'المنشية', 'بحري', 'سيدي جابر', 'ستانلي', 'جليم', 'المندرة', 'العصافرة', 'سان ستيفانو', 'قلعة قايتباي', 'كامب شيزار'],
    features: { lights: true, radars: true, quiet: true, noParking: true, checkpoints: true, crosswalks: true, blockers: true, works: true },
    peds: ['ped'], speedLimit: 45
  },
  {
    id: 'desert', name: 'الصحراء', en: 'Desert', theme: 'desert', unlockStars: 60,
    gravity: 9.8, fuelName: 'بنزين', fuelPrice: 1.1, levels: 50, terrain: 0.9, roughness: 0.02, heat: true,
    obstacles: { sand: 5, rock: 3, pothole: 2, tire: 1, ramp: 1 },
    vehicles: ['jeep', 'truck', 'microbus'], traffic: 0.35,
    passengers: ['tourist', 'merchant', 'employee', 'farmer'],
    stations: ['مخيم الواحة', 'بنزينة الكيلو 40', 'استراحة الهرم', 'نقطة البدو', 'واحة سيوة الصغيرة', 'مخيم النجوم', 'مفترق الطرق'],
    features: { storms: true, radars: true, checkpoints: true, fuelStations: 2 },
    peds: ['camel'], speedLimit: 60, rules: ['storm']
  },
  {
    id: 'saeed', name: 'الصعيد', en: 'Upper Egypt', theme: 'saeed', unlockStars: 90,
    gravity: 9.8, fuelName: 'بنزين', fuelPrice: 1.0, levels: 50, terrain: 0.5, roughness: 0.03,
    obstacles: { pothole: 4, bump: 3, rock: 3, sand: 2, chicken: 1, tire: 1 },
    vehicles: ['tractor', 'cart', 'tuktuk', 'microbus', 'truck'], traffic: 0.55,
    passengers: ['farmer', 'tourist', 'merchant', 'granny', 'student'],
    stations: ['معبد الكرنك', 'كورنيش الأقصر', 'البر الغربي', 'سوق أسوان', 'خزان أسوان', 'جزيرة الموز', 'نجع حمادي', 'قنا الجديدة', 'كوم أمبو', 'إدفو'],
    features: { villageZones: true, radars: true, crosswalks: true, checkpoints: true, blockers: true, fuelStations: 2 },
    peds: ['ped', 'camel', 'buffalo'], speedLimit: 40, heat: true, rules: ['village']
  },
  {
    id: 'city', name: 'المدينة الحديثة', en: 'Modern City', theme: 'city', unlockStars: 120,
    gravity: 9.8, fuelName: 'بنزين', fuelPrice: 1.0, levels: 50, terrain: 0.15,
    obstacles: { bump: 3, pothole: 1, water: 1, cone: 3, oil: 1 },
    vehicles: ['car', 'car', 'bus', 'police', 'truck', 'moto'], traffic: 1.1,
    passengers: ['employee', 'tourist', 'student', 'moallem', 'mother'],
    stations: ['البرج الإداري', 'المول الكبير', 'محطة المونوريل', 'الحي المالي', 'الجامعة', 'المستشفى', 'النهر الأخضر', 'الكوبري المعلق'],
    features: { lights: 2, radars: 2, quiet: true, noParking: 2, checkpoints: true, crosswalks: true, tunnels: true, blockers: true, works: true },
    peds: ['ped'], speedLimit: 50, rules: ['tunnelLights']
  },
  {
    id: 'mars', name: 'المريخ', en: 'Mars', theme: 'mars', unlockStars: 150, needsSpace: true,
    gravity: 3.9, fuelName: 'طاقة', fuelPrice: 1.4, levels: 50, terrain: 1.3, roughness: 0.05,
    obstacles: { crater: 3, rock: 3, ramp: 2, sand: 2 },
    vehicles: ['rover'], traffic: 0.3,
    passengers: ['alien', 'astro', 'alien', 'tourist'],
    stations: ['قاعدة أوليمبوس', 'قبة الأمل', 'محطة الطاقة الشمسية', 'مرصد فوبوس', 'سوق الفضائيين', 'فوهة جيل', 'منصة الإطلاق'],
    features: { radars: true, quiet: true, crosswalks: true },
    peds: ['alienPed'], speedLimit: 45, rules: ['quietObservatory']
  }
];

/* أسماء المخالفات (غرامات خيالية خاصة باللعبة فقط) */
TT.VIOLATIONS = {
  speeding:    { name: 'سرعة زائدة', en: 'Speeding', fine: 60, rep: 3 },
  redLight:    { name: 'كسر إشارة حمراء', en: 'Ran a red light', fine: 100, rep: 5 },
  wrongWay:    { name: 'السير عكس الاتجاه', en: 'Wrong way', fine: 80, rep: 4 },
  crashCar:    { name: 'اصطدام بمركبة', en: 'Hit a vehicle', fine: 120, rep: 6 },
  animalHit:   { name: 'خبط بهيمة', en: 'Hit an animal', fine: 80, rep: 2 },
  phone:       { name: 'الموبايل أثناء القيادة', en: 'Phone while driving', fine: 100, rep: 3 },
  hitPed:      { name: 'صدم مشاة', en: 'Hit a pedestrian', fine: 150, rep: 10 },
  noParking:   { name: 'وقوف في الممنوع', en: 'No-parking stop', fine: 50, rep: 2 },
  badVehicle:  { name: 'توكتوك محتاج صيانة', en: 'Unsafe vehicle', fine: 90, rep: 3 },
  checkpoint:  { name: 'عدم الوقوف في الكمين', en: 'Skipped checkpoint', fine: 110, rep: 6 },
  quietHorn:   { name: 'كلاكس في منطقة هادئة', en: 'Horn in quiet zone', fine: 30, rep: 2 },
  village:     { name: 'سرعة جوه القرية', en: 'Speeding in village', fine: 50, rep: 4 },
  fight:       { name: 'مشاجرة في الطريق العام', en: 'Street fight', fine: 150, rep: 8 },
  noLights:    { name: 'سواقة من غير كشافات', en: 'No headlights', fine: 40, rep: 2 }
};

TT.ACHIEVEMENTS = [
  { id: 'firstRide', name: 'أول توصيلة', en: 'First ride', goal: 1, stat: 'deliveries' },
  { id: 'rides25', name: 'سواق محترف — 25 توصيلة', en: '25 rides', goal: 25, stat: 'deliveries' },
  { id: 'money2k', name: 'جمعت 2000 جنيه', en: 'Earned 2000', goal: 2000, stat: 'earned' },
  { id: 'clean', name: 'مرحلة من غير ولا مخالفة', en: 'Clean level', goal: 1, stat: 'cleanLevels' },
  { id: 'flip', name: 'اتقلبت ورجعت', en: 'Flipped and recovered', goal: 1, stat: 'recoveries' },
  { id: 'peace', name: 'ربنا يهديك — 5 مرات', en: 'Peacemaker x5', goal: 5, stat: 'peace' },
  { id: 'coins', name: 'لمّام الفكة — 200 عملة', en: '200 coins', goal: 200, stat: 'coins' },
  { id: 'stars30', name: '30 نجمة', en: '30 stars', goal: 30, stat: 'stars' },
  { id: 'mars', name: 'أول توصيلة على المريخ', en: 'First Mars ride', goal: 1, stat: 'marsRides' }
];

/* ---------- شخصيات ثانوية (المارة وأصحاب العربيات) ---------- */
TT.NPC_LOOKS = [
  { sheet: 'npc1', skin: '#a8714a', shirt: '#546e7a', pants: '#263238', hair: '#111', mustache: true },
  { sheet: 'npc2', skin: '#c48a5c', shirt: '#8e24aa', pants: '#37474f', hair: '#222' },
  { sheet: 'npc3', skin: '#9b6640', shirt: '#d7ccc8', pants: '#d7ccc8', galabeya: true, taqiya: '#fff', mustache: true },
  { sheet: 'npc4', skin: '#b97f55', shirt: '#43a047', pants: '#3e2723', hair: '#3e2723', beard: true },
  { sheet: 'npc5', skin: '#c98f62', shirt: '#f4511e', pants: '#1a237e', hair: '#000', capBack: '#212121' }
];
TT.KID_LOOK = { sheet: 'kid', skin: '#d39a6c', shirt: '#e05a47', pants: '#335', hair: '#1b1410', small: 0.55 };

/* كل شخصية ليها اسم sprite sheet: assets/characters/<sheet>_sheet.png */
for (const id in TT.PASSENGER_TYPES) TT.PASSENGER_TYPES[id].look.sheet = 'passenger_' + id;
for (const d of TT.DRIVERS) d.look.sheet = 'driver_' + d.id;

/* ---------- تعليقات السواق ---------- */
TT.LINES.driver = {
  idle: ['افرجها يا رب', 'يا رزّاق يا كريم', 'اليوم ده باين عليه حلو', 'رزقنا ورزقكم على الله', 'الحمد لله على كل حال', 'يا صباح الفل يا مصر'],
  jam: ['افرجها يا رب!', 'يا صبر أيوب', 'هي الدنيا واقفة ليه النهارده؟', 'الزحمة دي مش طبيعية'],
  crash: ['يا ساتر يا رب!', 'العوض على الله', 'يا نهار أبيض!', 'التوكتوك يا ناس!'],
  bump: ['آه يا ضهري!', 'مين اللي عامل المطب ده؟', 'الطريق ده عايز رصف'],
  lowFuel: ['البنزين هيخلص يا جدعان', 'لازم أفوّل قريب'],
  police: ['يا رب استر', 'حاضر يا باشا', 'الرخص معايا والحمد لله'],
  money: ['الحمد لله، فاتحة خير', 'ربنا يكرم', 'كده الدنيا تمام'],
  pickup: ['اتفضل يا باشا', 'نورت التوكتوك', 'على فين يا معلم؟'],
  smoke: ['إيه الدخان ده؟!', 'المحرك بيشتكي', 'لازم أروح الورشة'],
  engine: ['يلا يا حبيبي دوّر!', 'دوّر بقى!'],
  radar: ['بالراحة… فيه رادار', 'هدّي هدّي، الرادار قدام'],
  night: ['الدنيا ليّلت… نولّع الكشافات', 'ليل وطريق… ربنا يستر', 'مساء الفل يا مصر'],
  rain: ['يا ساتر على المطرة دي!', 'الطريق بقى صابون… بالراحة', 'المسّاحات فين بس'],
  race: ['ورّيني هتعمل إيه يا معلم!', 'أنا الأسطى… محدش يسبقني', 'دوس يا وحش!'],
  thunder: ['سبحان الذي يسبّح الرعد بحمده والملائكة من خيفته', 'اللهم لا تقتلنا بغضبك ولا تهلكنا بعذابك', 'يا ساتر يا رب… سبحان الله', 'اللهم صيّبًا نافعًا'],
  tired: ['عينيا بتقفل… محتاج شاي', 'لازم أريّح شوية في استراحة']
};
TT.LINES.scared = ['يا لهوي السقف طار!', 'نزلني يا عم أنا خايف!', 'إيه ده؟! احنا هنموت!', 'يا ساتر يا رب!'];

/* ---------- وضع البيّاع ---------- */
TT.GOODS = {
  potato: { name: 'بطاطا', en: 'Sweet potato', icon: '🍠', price: 10, cost: 4, calls: ['بطاطا سخنة يا بطاطا!', 'البطاطا المشوية… عسل يا بطاطا!', 'سكر يا بطاطا!'], buyLines: ['واحدة بطاطا سخنة', 'هات حتة كبيرة', 'الله! ريحتها حلوة'] },
  corn: { name: 'درة مشوي', en: 'Grilled corn', icon: '🌽', price: 8, cost: 3, calls: ['درة مشوي يا درة!', 'الدرة السخنة… على الفحم!'], buyLines: ['كوز درة لو سمحت', 'رش ملح كتير', 'دي ولا أجدع درة'] },
  termes: { name: 'ترمس', en: 'Lupini', icon: '🫘', price: 5, cost: 1.5, calls: ['ترمس يا ترمس!', 'الترمس الحلو… بالليمون!'], buyLines: ['قرطاس ترمس', 'زوّد الليمون', 'بالشطة لو سمحت'] },
  bread: { name: 'عيش بلدي', en: 'Baladi bread', icon: '🥖', price: 3, cost: 1, calls: ['عيش سخن يا عيش!', 'العيش البلدي طالع من الفرن!'], buyLines: ['خمسة أرغفة', 'عايز العيش السخن', 'ربنا يبارك'] }
};
Object.assign(TT.VIOLATIONS, {
  license: { name: 'رخصة منتهية', en: 'Expired license', fine: 120, rep: 3 },
  noLicense: { name: 'عدم حمل الرخص والبطاقة', en: 'No license/ID', fine: 150, rep: 4 },
  refuseTest: { name: 'رفض تحليل المخدرات', en: 'Refused drug test', fine: 250, rep: 6 }
});
/* مركبات سباق */
TT.TUKTUKS.push(
  { id: 'racetuk', kind: 'tuktuk', race: true, name: 'توكتوك سباق', en: 'Race tuk tuk', price: 6500, power: 1.65, vmax: 18, tank: 110, seats: 3, fuel: true, color: '#d50000', trim: '#ffffff', req: 6 },
  { id: 'racebike', kind: 'scooter', race: true, name: 'موتوسيكل سباق', en: 'Race bike', price: 5500, power: 1.6, vmax: 20, tank: 70, seats: 1, fuel: true, color: '#ffd600', trim: '#111111', req: 5 }
);

/* ---------- عربيات البيع ومستوياتها ---------- */
TT.CART_NAMES = { potato: ['عربية بطاطا', 'Sweet potato cart'], corn: ['عربية درة', 'Corn cart'], termes: ['عربية ترمس', 'Lupini cart'], bread: ['فرن عيش متنقل', 'Mobile bakery'] };
TT.CART_TIERS = [
  { id: 'wood', name: 'خشب', en: 'Wooden', icon: '🪵', price: 0, stock: 1, priceMul: 1, attract: 1, buyersMax: 2, desc: 'عربية خشب على قدها', descEn: 'A simple wooden cart' },
  { id: 'steel', name: 'ستانلس', en: 'Stainless', icon: '✨', price: 700, stock: 1.4, priceMul: 1.2, attract: 1.4, buyersMax: 3, desc: 'نضيفة ولامعة: بضاعة أكتر وسعر أعلى', descEn: 'Clean & shiny: more stock, higher price' },
  { id: 'shop', name: 'محل متنقل', en: 'Mobile shop', icon: '🏪', price: 2200, stock: 1.9, priceMul: 1.45, attract: 1.9, buyersMax: 4, desc: 'كشك بشباك ونور ويافطة: الزباين بتتلم', descEn: 'Kiosk with window, lights & sign: crowds come' }
];

/* ---------- عربيات السباق (غالية) ---------- */
TT.TUKTUKS.push(
  { id: 'gt', kind: 'sport', race: true, style: 'gt', name: 'صاروخ الكورنيش', en: 'Corniche Rocket', price: 45000, power: 2.5, vmax: 30, tank: 140, seats: 1, fuel: true, color: '#1565c0', trim: '#ffffff', req: 6 },
  { id: 'super', kind: 'sport', race: true, style: 'super', name: 'الفهد الأسود', en: 'Black Cheetah', price: 95000, power: 3.1, vmax: 37, tank: 150, seats: 1, fuel: true, color: '#1b1b1f', trim: '#ffd600', req: 9 },
  { id: 'hyper', kind: 'sport', race: true, style: 'hyper', name: 'برق الصحرا', en: 'Desert Lightning', price: 220000, power: 3.9, vmax: 45, tank: 160, seats: 1, fuel: true, color: '#ff6d00', trim: '#00e5ff', req: 12 }
);

/* ---------- دردشة مصرية بين الراكب والسواق (بتظهر فوق التوكتوك) ---------- */
TT.BANTER = {
  happy: [
    ['تسلم إيدك يا اسطى، سواقتك حلوة', 'ده من ذوقك يا باشا 😄'],
    ['الأغنية دي جامدة! علّي شوية', 'عيوني… النهارده إحنا في فرح'],
    ['أنا هركب معاك على طول بعد كده', 'نورتنا يا معلم، احفظ رقمي'],
    ['التوكتوك ده نضيف ما شاء الله', 'غسلته الصبح مخصوص علشانك'],
    ['الدنيا حلوة النهارده', 'ربنا يديمها نعمة يا رب'],
    ['إنت ابن مين يا اسطى؟', 'ابن الحتة كلها يا باشا 😎'],
    ['خليك على اليمين نوصل أسرع', 'إنت بتفهم في الطرق يا كبير!']
  ],
  neutral: [
    ['الزحمة النهارده مش طبيعية', 'كل يوم أوحش من اللي قبله والله'],
    ['هو البنزين غلي تاني؟', 'متفكرنيش… القلب مش ناقص'],
    ['الماتش امبارح كان عامل إيه؟', 'سيبك… الحكم كان مش شايف'],
    ['هو الطريق ده مقفول ولا إيه؟', 'هنلفّ من ورا متقلقش'],
    ['الجو حر ولا أنا اللي سخنان؟', 'الدنيا نار يا باشا… اشرب مية'],
    ['إنت شغال من الساعة كام؟', 'من الفجر… لقمة العيش صعبة']
  ],
  angry: [
    ['يا عم بالراحة! إحنا مش في سباق', 'حاضر حاضر… بس المطبات مش بإيدي'],
    ['إنت هتوصلني إمتى؟ اتأخرت!', 'خلاص قربنا… كلها دقيقتين'],
    ['التوكتوك ده هيتفكك!', 'ده أجمد من العربيات الجديدة يا باشا'],
    ['أنا مش هدفع الأجرة كاملة', 'لأ بقى… الأجرة أجرة يا حاج'],
    ['إنت داخل في كل حفرة ليه؟!', 'الحفر هي اللي داخلة فيا والله']
  ],
  calm: ['هدّي نفسك يا اسطى، عاوزين نوصل بالسلامة', 'استهدى بالله يا معلم', 'صلّي على النبي في قلبك كده', 'وحّد الله يا اسطى… مش مستاهلة', 'روّق يا باشا الدنيا ما طارتش']
};

/* ---------- المكالمات أثناء السواقة ---------- */
TT.CALLERS = [
  { id: 'wife', name: 'الجماعة ❤️', en: 'The wife', icon: '👩', bg: '#ad1457', imp: 3, w: 3,
    talks: [[['ألو، إنت فين يا راجل؟', 'في الشغل يا حبيبتي… سايق'], ['متنساش تجيب عيش وطماطم وانت راجع', 'حاضر حاضر… أي أوامر تانية؟'], ['وكيلو برتقان للعيال!', 'ماشي يا ستي 😅']],
            [['العيال عاوزين يكلموك', 'قوليلهم بابا سايق وراجع بالليل'], ['الغدا محشي النهارده', 'الله! خلاص هخلّص بدري']]] },
  { id: 'sayed', name: 'سيد الميكانيكي 🔧', en: 'Sayed the mechanic', icon: '🧑‍🔧', bg: '#e65100', imp: 3, w: 3, mechanic: true },
  { id: 'mom', name: 'أمي 🤍', en: 'Mom', icon: '👵', bg: '#6a1b9a', imp: 3, w: 2,
    talks: [[['إزيك يا حبيبي؟ كلت؟', 'الحمد لله يا ماما… كلت'], ['ربنا يحرسك ويرزقك يا ابني', 'آمين يا رب… ادعيلي']]] },
  { id: 'boss', name: 'المعلم صاحب التوكتوك', en: 'The tuk owner', icon: '🧔', bg: '#37474f', imp: 2, w: 2, annoy: true,
    talks: [[['فين اليومية يا ابني؟', 'بالليل يا معلم… الشغل نايم'], ['متتأخرش عليا زي امبارح', 'حاضر يا معلم… ربنا يسهّل']]] },
  { id: 'friend', name: 'حمادة صاحبي', en: 'Hamada (friend)', icon: '🧑', bg: '#1565c0', imp: 1, w: 2,
    talks: [[['تعالى على القهوة، الماتش بدأ', 'أنا شغال يا عم… سيبني'], ['طب هات معاك شاي وانت جاي 😂', 'ماشي يا رخم']]] },
  { id: 'spam', name: 'رقم غريب', en: 'Unknown number', icon: '❓', bg: '#424242', imp: 0, w: 2, annoy: true,
    talks: [[['مبروك! كسبت عربية جديدة، ابعت رقم الكارت', 'إيه الهبل ده؟! قفّل يا عم'], ['آلو… آلو؟', 'مين معايا؟… قفل!']]] }
];
TT.MECH_PARTS = [
  { part: 'brakes', name: 'تيل فرامل جديد', cost: 120 }, { part: 'engine', name: 'بوجيهات وزيت', cost: 150 }, { part: 'tires', name: 'كاوتش ورا', cost: 140 },
  { part: 'suspension', name: 'مساعدين قدام', cost: 160 }, { part: 'engine', name: 'سير المروحة', cost: 90 }, { part: 'body', name: 'سمكرة الرفرف', cost: 110 }
];

/* ---------- كل مدن مصر: مناطق جديدة (بتستخدم شكل أقرب منطقة) — المريخ بيفضل آخر واحدة ---------- */
(function () {
  const base = id => TT.WORLDS.find(w => w.id === id);
  const mk = (id, name, en, from, stars, ll, stations, extra) => Object.assign(JSON.parse(JSON.stringify(base(from))), { id, name, en, unlockStars: stars, ll, stations, needsSpace: false }, extra || {});
  const NEW = [
    mk('giza', 'الجيزة والأهرامات', 'Giza & Pyramids', 'streets', 140, [31.13, 29.98], ['الهرم', 'فيصل', 'المنيب', 'الدقي', 'المهندسين', 'بولاق الدكرور', 'نزلة السمان', 'حدائق الأهرام', 'العمرانية', 'ميدان الرماية'], { peds: ['ped', 'camel'], speedLimit: 40 }),
    mk('mansoura', 'المنصورة', 'Mansoura', 'country', 160, [31.38, 31.04], ['كوبري طلخا', 'المشاية', 'توريل', 'الجامعة', 'سوق الخواجات', 'حي الجامعة', 'شارع الجمهورية', 'ميت خميس'], { speedLimit: 40 }),
    mk('tanta', 'طنطا', 'Tanta', 'country', 180, [31.0, 30.79], ['مسجد السيد البدوي', 'محطة القطر', 'شارع البحر', 'سيجر', 'كفر عصام', 'الاستاد', 'سوق الحلاوة', 'شارع الجيش']),
    mk('portsaid', 'بورسعيد', 'Port Said', 'alex', 200, [32.3, 31.26], ['ممشى ديليسبس', 'الفنار القديم', 'بورفؤاد', 'شارع التجاري', 'المعدية', 'حي العرب', 'سوق الجمعة', 'الكورنيش']),
    mk('ismailia', 'الإسماعيلية', 'Ismailia', 'city', 220, [32.27, 30.6], ['بحيرة التمساح', 'حي الإفرنج', 'شارع الثلاثيني', 'نمرة 6', 'الشيخ زايد', 'محطة القطر', 'الملاحة', 'جامعة القناة'], { speedLimit: 45 }),
    mk('suez', 'السويس', 'Suez', 'city', 240, [32.55, 29.97], ['بور توفيق', 'الأربعين', 'الكورنيش الجديد', 'حي الجناين', 'ميناء الأدبية', 'شارع الجيش', 'السلام', 'عتاقة'], { speedLimit: 50 }),
    mk('fayoum', 'الفيوم', 'Fayoum', 'country', 260, [30.84, 29.31], ['السواقي', 'بحيرة قارون', 'وادي الريان', 'تونس', 'المسلة', 'سنورس', 'إطسا', 'قصر قارون']),
    mk('minya', 'المنيا', 'Minya', 'saeed', 280, [30.74, 28.1], ['كورنيش النيل', 'بني حسن', 'ملوي', 'مطاي', 'سمالوط', 'تل العمارنة', 'أبو قرقاص', 'المنيا الجديدة']),
    mk('luxor', 'الأقصر', 'Luxor', 'saeed', 300, [32.64, 25.69], ['معبد الكرنك', 'طريق الكباش', 'معبد الأقصر', 'البر الغربي', 'وادي الملوك', 'الدير البحري', 'سوق الأقصر', 'المرسى'], { peds: ['ped', 'camel'] }),
    mk('aswan', 'أسوان', 'Aswan', 'saeed', 320, [32.9, 24.09], ['كورنيش أسوان', 'السوق السياحي', 'جزيرة الفنتين', 'خزان أسوان', 'السد العالي', 'غرب سهيل', 'معبد فيلة', 'كوم أمبو'], { heat: true }),
    mk('hurghada', 'الغردقة', 'Hurghada', 'alex', 340, [33.81, 27.26], ['الممشى السياحي', 'الدهار', 'السقالة', 'المارينا', 'الكوثر', 'الأحياء', 'مكادي', 'سهل حشيش'], { heat: true, speedLimit: 50 }),
    mk('sharm', 'شرم الشيخ', 'Sharm El Sheikh', 'alex', 360, [34.33, 27.91], ['خليج نعمة', 'السوق القديم', 'رأس محمد', 'شرم المية', 'هضبة أم السيد', 'نبق', 'ممشى السلام', 'خليج القرش'], { heat: true, speedLimit: 50 }),
    mk('matrouh', 'مرسى مطروح', 'Marsa Matrouh', 'alex', 380, [27.24, 31.35], ['شاطئ الغرام', 'عجيبة', 'كليوباترا', 'الأبيض', 'شارع الإسكندرية', 'سوق ليبيا', 'روميل', 'الكورنيش']),
    mk('siwa', 'واحة سيوة', 'Siwa Oasis', 'desert', 400, [25.52, 29.2], ['جبل الموتى', 'معبد آمون', 'قلعة شالي', 'عين كليوباترا', 'بحيرة الملح', 'جبل الدكرور', 'السوق', 'بير واحد'], { peds: ['camel', 'ped'] }),
    mk('damietta', 'دمياط', 'Damietta', 'alex', 420, [31.81, 31.42], ['رأس البر', 'اللسان', 'سوق الموبيليا', 'كورنيش النيل', 'عزبة البرج', 'دمياط الجديدة', 'باب الحرس', 'شارع 47'])
  ];
  const mi = TT.WORLDS.findIndex(w => w.id === 'mars');
  TT.WORLDS.splice(mi, 0, ...NEW);
  const mars = TT.WORLDS.find(w => w.id === 'mars'); mars.unlockStars = 450;
  const LL = { streets: [31.26, 30.06], country: [30.65, 30.62], alex: [29.92, 31.2], desert: [28.85, 27.9], saeed: [32.72, 26.16], city: [31.73, 30.0], mars: [36.4, 31.0] };
  for (const w of TT.WORLDS) if (!w.ll) w.ll = LL[w.id];
})();

/* ---------- سواقين زيادة (بيتشتروا) ---------- */
TT.DRIVERS.forEach(d => { d.price = 0; });
TT.DRIVERS.push(
  { id: 'ragab', name: 'عم رجب', en: 'Uncle Ragab', price: 900, desc: 'راجل كبير وموفّر — بيصرف بنزين أقل', look: { skin: '#9b6640', shirt: '#d7ccc8', pants: '#d7ccc8', hair: '#bdbdbd', galabeya: true, taqiya: '#fff', mustache: true }, perk: { fuel: 0.88 } },
  { id: 'tamer', name: 'كابتن تامر', en: 'Captain Tamer', price: 1500, desc: 'بتاع سباقات — المنافسين بيبقوا أبطأ', look: { skin: '#c48a5c', shirt: '#212121', pants: '#263238', hair: '#111', shades: true, capBack: '#d50000' }, perk: { race: 0.94, brake: 0.04 } },
  { id: 'saadia', name: 'الحاجة سعدية', en: 'Hagga Saadia', price: 1200, desc: 'دمها خفيف — الركاب بيدّوها بقشيش أكتر', look: { skin: '#b07a50', shirt: '#6a1b9a', pants: '#4a148c', hair: '#111', hijab: '#ad1457', dress: true }, perk: { tips: 1.6, sat: 3 } },
  { id: 'mido', name: 'ميدو', en: 'Mido', price: 700, desc: 'طالب جامعة بيشتغل — أسرع في التحميل والمشاوير', look: { skin: '#d7a27a', shirt: '#00897b', pants: '#37474f', hair: '#3e2723', glasses: true, bag: true }, perk: { sat: 2, brake: 0.03 } }
);
/* ---------- لبس السواق ---------- */
TT.OUTFITS = [
  { id: 'default', name: 'اللبس الأصلي', en: 'Original', price: 0, icon: '👕', o: {} },
  { id: 'galabeya', name: 'جلابية وطاقية', en: 'Galabeya', price: 300, icon: '🧕', o: { galabeya: true, shirt: '#ece4d0', pants: '#ece4d0', taqiya: '#ffffff', vest: null, stripes: false, capBack: null, beret: null, cap: null, hat: null } },
  { id: 'sport', name: 'ترينج رياضي', en: 'Tracksuit', price: 450, icon: '🏃', o: { shirt: '#c62828', pants: '#1a237e', stripes: true, capBack: '#111111', vest: null, galabeya: false, taqiya: null, beret: null } },
  { id: 'cool', name: 'نضارة شمس وكاب', en: 'Shades & cap', price: 600, icon: '🕶️', o: { shades: true, cap: '#1565c0', capBack: null, shirt: '#fafafa', taqiya: null, beret: null, hat: null } },
  { id: 'winter', name: 'جاكيت شتوي', en: 'Winter jacket', price: 700, icon: '🧥', o: { shirt: '#5d4037', vest: '#8d6e63', hat: '#3e2723', taqiya: null, capBack: null, beret: null, cap: null } },
  { id: 'suit', name: 'بدلة وكرافتة', en: 'Suit & tie', price: 1100, icon: '🤵', o: { shirt: '#263238', pants: '#263238', tie: '#c62828', vest: null, galabeya: false, taqiya: null, capBack: null, stripes: false } },
  { id: 'eid', name: 'جلابية العيد', en: 'Eid galabeya', price: 1500, icon: '🌙', o: { galabeya: true, shirt: '#1565c0', pants: '#1565c0', turban: '#ffffff', taqiya: null, capBack: null, beret: null, cap: null } },
  { id: 'racer', name: 'لبس سواق سباق', en: 'Racing suit', price: 2500, icon: '🏁', o: { shirt: '#d50000', pants: '#d50000', stripes: true, cap: '#111111', shades: true, vest: null, taqiya: null, beret: null, galabeya: false } }
];

/* ---------- محرر التعليقات: كل التعليقات اللي ممكن تغيّرها من اللعبة ----------
   type: list = سطر لكل تعليق · pair = "كلام الراكب | رد السواق" · chat = "السؤال | رد كويس | رد وحش" */
TT.LINE_CATS = (function () {
  const L = TT.LINES, out = [];
  const add = (group, id, name, get, set, type) => out.push({ group, id, name, get, set, type: type || 'list' });
  const DK = { idle: 'وهو ماشي عادي', jam: 'في الزحمة', crash: 'بعد خبطة', bump: 'على المطبات', lowFuel: 'البنزين قرّب يخلص', police: 'عند الكمين', money: 'لما ياخد فلوس', pickup: 'لما يركّب زبون', smoke: 'المركبة بتدخّن', engine: 'المحرك مش راضي يدور', radar: 'قبل الرادار', night: 'بالليل', rain: 'في المطر', race: 'في السباق', tired: 'وهو تعبان', thunder: 'لما الرعد يضرب (ذكر)', phone: 'بعد مكالمة', angryCall: 'متعصّب من المكالمة' };
  for (const k in L.driver) add('🧑‍✈️ السواق', 'driver.' + k, DK[k] || k, () => L.driver[k], v => { L.driver[k] = v; });
  const PK = { board: 'الزبون وهو بيركب', happy: 'الزبون مبسوط', angry: 'الزبون زعلان', late: 'الزبون متأخر', dizzy: 'الزبون دايخ', honkPed: 'الناس لما تزمّر عليهم', pedHit: 'الناس لما تخبطهم', scared: 'الركاب خايفين' };
  for (const k in PK) if (L[k]) add('🧍 الزباين والناس', k, PK[k], () => L[k], v => { L[k] = v; });
  if (L.ride) for (const k in L.ride) { const P = TT.PASSENGER_TYPES[k]; add('💬 كلام كل نوع زبون', 'ride.' + k, P ? P.name : k, () => L.ride[k], v => { L.ride[k] = v; }); }
  const BK = { happy: 'وهو مبسوط', neutral: 'كلام عادي', angry: 'وهو متضايق', calm: 'تهدية السواق' };
  if (TT.BANTER) for (const k in TT.BANTER) { if (typeof TT.BANTER[k][0] === 'string') add('🗣️ حوار الراكب والسواق', 'banter.' + k, BK[k] || k, () => TT.BANTER[k], v => { TT.BANTER[k] = v; }); else add('🗣️ حوار الراكب والسواق', 'banter.' + k, BK[k] || k, () => TT.BANTER[k].map(p => p[0] + ' | ' + p[1]), v => { TT.BANTER[k] = v.map(s => s.split('|').map(x => x.trim())).filter(p => p[0] && p[1]); }, 'pair'); }
  add('🗣️ حوار الراكب والسواق', 'chats', 'أسئلة الزبون والردود', () => TT.CHATS.map(c => [c.q].concat(c.a.map(a => a.t)).join(' | ')), v => { TT.CHATS = v.map(s => s.split('|').map(x => x.trim())).filter(p => p.length >= 3 && p[0]).map(p => ({ q: p[0], a: [{ t: p[1], s: 8 }, { t: p[2], s: -10 }] })); }, 'chat');
  for (const g in TT.GOODS) { const G = TT.GOODS[g]; add('🛒 البيّاع', 'calls.' + g, 'نداء ' + G.name, () => G.calls, v => { G.calls = v; }); add('🛒 البيّاع', 'buy.' + g, 'الزبون وهو بيشتري ' + G.name, () => G.buyLines, v => { G.buyLines = v; }); }
  return out;
})();
TT.LINE_ORIG = {}; TT.LINE_CATS.forEach(c => { TT.LINE_ORIG[c.id] = c.get().slice(); });
TT.applyCustomLines = function (custom) { for (const c of TT.LINE_CATS) { const v = custom && custom[c.id]; c.set(v && v.length ? v.slice() : TT.LINE_ORIG[c.id].slice()); } };

/* ---------- أسئلة الكمين ---------- */
TT.VIOLATIONS.quiz = { name: 'إجابة غلط في الكمين', en: 'Wrong answer at checkpoint', fine: 50, rep: 2 };
TT.POLICE_QS = [
  { q: 'الإشارة الصفرا معناها إيه؟', a: ['استعد للوقوف', 'دوس وعدّي بسرعة', 'كمّل عادي'] },
  { q: 'أقصى سرعة جوه القرية كام؟', a: ['40 كم/س', '80 كم/س', 'مفيش حد'] },
  { q: 'إمتى تشغّل الكشافات؟', a: ['بالليل وفي الشبورة والأنفاق', 'في الضهر بس', 'لما تحب'] },
  { q: 'رايح على فين يا اسطى؟', a: ['بوصّل زباين على الخط', 'مالكش دعوة', 'معرفش'] },
  { q: 'التوكتوك ده بتاعك؟', a: ['لأ بتاع الحاج وأنا سواق عليه وده العقد', 'أيوه لقيته في الشارع', 'سلّفهولي واحد معرفوش'] },
  { q: 'فين حزام الأمان… قصدي الخوذة؟ 😄 طب الطفاية فين؟', a: ['أهي تحت الكرسي يا باشا', 'مفيش طفاية', 'إيه الطفاية دي؟'] },
  { q: 'الرصيف الأحمر والأبيض معناه إيه؟', a: ['ممنوع الوقوف', 'موقف ببلاش', 'مكان للبياعين'] },
  { q: 'لو لقيت حادثة في الطريق تعمل إيه؟', a: ['أهدّي وأبلّغ وأساعد', 'أعدّي جري', 'أصوّرها وأمشي'] },
  { q: 'ركبت كام زبون النهارده؟', a: ['على قد الرزق يا باشا، الحمد لله', 'وانت مالك', 'مش فاكر خالص'] }
];
TT.LINES.cops = ['اقف على جنب!', 'هتروح مننا فين؟!', 'اركن يا توكتوك!', 'الرخص يا حلو!'];
TT.LINES.jail = ['والله يا باشا مظلوم 😭', 'أنا غلبان وعندي عيال يا باشا 😭', 'آخر مرة والله… سامحني 😭'];
/* ---------- قيم المخالفات: 50 للبسيطة و100 للكبيرة، وصدم المشاة 350 ---------- */
for (const k in TT.VIOLATIONS) { const V = TT.VIOLATIONS[k]; V.fine = k === 'hitPed' ? 350 : V.fine >= 90 ? 100 : 50; }

/* الحاجة الكبيرة بتطلب القرآن */
TT.GRANNY_QURAN = [['شغّل القرآن يا ابني… مش الأغاني دي!', 'من عينيا يا حاجة 📿'], ['ما تحطّلنا شيخ عبد الباسط كده', 'حاضر يا أمي، ربنا يبارك فيكي'], ['الأغاني دي وجعت دماغي، هات قرآن', 'أحلى قرآن عشان خاطرك يا حاجة 🤲']];
